import json, hashlib, zipfile
from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
from pypdf import PdfReader

root=Path('outputs/SmartVio-V20-Factory-Engineering-Review').resolve()
work=Path('work/v20').resolve()
pages=sorted(work.glob('pdf-page-*.png'))
expected=json.loads((root/'verification/pdf-build.json').read_text(encoding='utf-8'))['pages']
assert len(pages)==expected
reader=PdfReader(str(root/'SmartVio-V20-Review.pdf'))
assert len(reader.pages)==expected
assert all('HOLD' in (p.extract_text() or '') for p in reader.pages)
for start in range(0,len(pages),12):
    sheet=Image.new('RGB',(1800,1900),'#e6eeee');draw=ImageDraw.Draw(sheet)
    for i,file in enumerate(pages[start:start+12]):
        im=Image.open(file).convert('RGB');thumb=ImageOps.contain(im,(430,590));x=i%4*450+(450-thumb.width)//2;y=i//4*630+28
        sheet.paste(thumb,(x,y));draw.text((i%4*450+10,i//4*630+8),str(start+i+1),fill='#243739')
    sheet.save(work/f'contact-{start//12+1}.png')
qa={'pdfPages':expected,'renderedPages':len(pages),'allPagesHold':True,'visualReview':'Contact sheets generated; inspection recorded separately','hardwareTests':0,'pcbERC':False,'pcbDRC':False,'spice':False}
(root/'verification/pdf-qa.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
# Keep generation sources as evidence; only the Node model tests are portable in this package.
for name in ['build.cjs','render.cjs','qa.cjs','analog.py','report.py','package.py']:
    (root/'reproduce'/name).write_bytes((work/name).read_bytes())
(root/'reproduce/README.txt').write_text('Portable tests: run node reproduce/test.cjs from the extracted package (Node.js required).\nmodel.cjs is a host reference, not firmware.\nOther builders are archival workspace scripts and require the original V18/V19 workspace, bundled dependencies and Windows fonts; do not treat them as a standalone CAD toolchain.\nNo actual EDA routing, SPICE, shell CAD compilation or hardware test is included.\n',encoding='utf-8')
files=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='manifest.json':
        files.append({'file':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(root/'manifest.json').write_text(json.dumps({'release':'HOLD','files':files},ensure_ascii=False,indent=2),encoding='utf-8')
target=root.with_suffix('.zip')
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file():z.write(p,Path(root.name)/p.relative_to(root))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for f in files:
        assert hashlib.sha256(z.read(root.name+'/'+f['file'])).hexdigest()==f['sha256']
print(json.dumps({'zip':str(target),'files':len(files)+1,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'crcAndAllHashes':'PASS','pages':expected}))
