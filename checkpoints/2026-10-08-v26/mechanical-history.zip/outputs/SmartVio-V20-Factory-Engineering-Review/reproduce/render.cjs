const fs=require('node:fs'),path=require('node:path');
const root=path.resolve('outputs/SmartVio-V20-Factory-Engineering-Review');
const read=f=>JSON.parse(fs.readFileSync(path.join(root,f)));const write=(f,x)=>fs.writeFileSync(path.join(root,f),typeof x==='string'?x:JSON.stringify(x,null,2));
const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const txt=(x,y,s,size=19,color='#243739',anchor='start')=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" text-anchor="${anchor}">${e(s)}</text>`;
const rect=(x,y,w,h,fill='#e6f1ef',stroke='#39716b')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
const ln=(x,y,a,b,col='#39716b',dash='')=>`<line x1="${x}" y1="${y}" x2="${a}" y2="${b}" stroke="${col}" stroke-width="2" stroke-dasharray="${dash}"/>`;
const circle=(x,y,r,fill='#fff')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" stroke="#39716b" stroke-width="2"/>`;
const drawings=[];
function save(file,title,body,sub='候选工程尺寸 / 逻辑连接评审，不得按图直接生产'){
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1120" viewBox="0 0 1600 1120"><rect width="1600" height="1120" fill="white"/><g font-family="Microsoft YaHei,Arial,sans-serif" letter-spacing="0">${txt(48,52,title,28)}${txt(48,88,'V20 / HOLD / '+sub,17,'#ab3631')}${ln(48,110,1552,110)}${body}${ln(48,1060,1552,1060)}${txt(48,1093,'非生产放行 | PCB走线/焊盘/模具/扭矩未冻结 | 实物硬件测试 0 项',17,'#ab3631')}</g></svg>`;
 write(file+'.svg',svg);drawings.push({file:file+'.svg',title,width:1600,height:1120});
}
let b='';const k=8.7,x=v=>140+v*k,y=v=>220+v*k;
b+=rect(x(0),y(0),148*k,49*k,'#edf3f3');b+=rect(x(35),y(1),78*k,47*k,'#fdf0dc','#b67432');b+=rect(x(36),y(3),76*k,43*k,'#e6f2e9');
for(const[X,Y]of [[8,6],[140,6],[8,43],[140,43]])b+=circle(x(X),y(Y),11)+txt(x(X),y(Y)+34,`${X},${Y}`,14,'#333','middle');
for(const[i,X]of [57,78,98].entries())b+=rect(x(X-5),y(8),10*k,3*k,'#222')+txt(x(X),y(6),['VOL','TONE','FX'][i],15,'#243739','middle');
for(const[id,X,Y]of [['PHONES',56,22],['LINE OUT',80,22],['FX SEND',56,35],['AUX/RETURN',80,35],['USB-C',101,29]])b+=(id==='USB-C'?rect(x(X-4.5),y(Y-1.8),9*k,3.6*k,'#333'):circle(x(X),y(Y),16))+txt(x(X),y(Y+5),id,13,'#243739','middle');
for(const[i,X]of [51,67,83,99,115].entries())b+=circle(x(X),y(43),9)+txt(x(X),y(47.5),['FX','MODE','MIX','BT','PWR'][i],12,'#243739','middle');
b+=rect(x(14),y(17),18*k,18*k,'#f7dddd','#b73b34')+txt(x(23),y(26),'SPK ?',18,'#b73b34','middle');
b+=ln(x(0),180,x(148),180)+txt(x(74),165,'148 × 49 mm 上盖；孔位与开口均为分析输入，不是钻孔模板',21,'#243739','middle');
b+=txt(70,715,'深色中区：下沉舱76×43，局部x=36..112；旧腔x=35..113。立式插座必须落在原腔投影内。',20);
b+=txt(70,760,'金属琴尾基准：上盖110..258；原腔145..223；下沉舱146..222。新位置宽度/曲率仍待实测。',20);
b+=txt(70,805,'左SPK红区：旧18mm喇叭高度与5mm翼区冲突；薄喇叭或移入深舱尚未确定，不能锁定开孔。',20,'#ab3631');
b+=txt(70,850,'上盖四孔候选Ø2.6，局部(8,6)、(140,6)、(8,43)、(140,43)；不代表琴体有可用实心承力点。',20);
b+=txt(70,895,'插口与滚轮坐标仅保留视觉关系。须代入真实壳体、插头胶壳、焊脚与手指空间后重新检查。',20);
b+=txt(70,940,'所有接口朝控制正面；无DOCK、无话筒/48V。滚轮轴平行于面板，各视图不使用高柱旋钮。',20);
save('mechanical/M01-cover','M01 | 上壳、定位基准与待定开口',b);
b='';
b+=rect(100,210,140*9,43*9,'#edf2f2')+rect(100+32*9,210,76*9,43*9,'#cfe1e7');
for(const [X,Y]of [[100,210],[1360,210],[100,597],[1360,597]])b+=circle(X,Y,25,'white');
b+=txt(730,180,'下壳浅框140 ×43；中央下沉舱76 ×43 ×18',23,'#243739','middle');
b+=txt(730,420,'中央深舱；底厚1.2、壁厚1.2仅研究输入',23,'#243739','middle');
b+=txt(70,670,'四角开放缺口避让上盖至琴体的螺丝；下壳不设置装配螺丝孔、螺母柱或追加木体固定件。',21);
b+=txt(70,715,'上下壳四处弹性卡扣候选：梁长6、梁厚0.7、卡入挠度0.3mm；材料牌号和根部圆角未定。',21);
b+=txt(70,760,'简化悬臂表面应变 1.5×t×δ/L² = 0.875%；只是理想梁估算，不是疲劳/蠕变/装拆寿命通过。',21);
b+=txt(70,805,'端口承力：插座固定结构 → 上盖刚性框 → 四螺丝 → 胶合板；不要把插拔主载荷交给信号焊点。',21);
b+=txt(70,850,'插座厂家插入力可达29.4N；USB候选插入力可达20N。仍需弯矩、组合载荷与实琴验证。',21);
b+=txt(70,895,'木螺钉可研究ST2.2系列；有效入木、头型、导孔、扭矩须先量实心厚度再用同批材料试验。',21);
b+=txt(70,940,'SCAD仅供尺寸/装配讨论：未编译、未做模具/卡扣干涉检验，不能当成STL直接下单。',21,'#ab3631');
save('mechanical/M02-lower-clips','M02 | 下壳、卡扣与四点固定关系',b);
b='';const z=Z=>470-Z*14;
b+=rect(100,z(0),1100,22*14,'#dce3de')+rect(365,z(0),578,22*14,'#fff');
b+=rect(160,z(5),980,1.2*14,'#355a5c')+rect(380,z(0),548,18*14,'#ddebf0');
b+=ln(70,z(0),1430,z(0),'#aa4936','7 7');
for(const[Z,label,dy]of [[6,'滚轮最高候选+6',-18],[5,'非滚轮限高+5',14],[0,'琴背安装基准0',0],[-18,'下壳外底-18',0],[-22,'旧腔底-22',0]])b+=ln(1205,z(Z),1225,z(Z))+ln(1225,z(Z),1248,z(Z)+dy)+txt(1260,z(Z)+dy+6,label,17);
b+=txt(70,150,'只有原腔投影内可以下沉；整块148mm盖板不能被当作可挖空区。',23);
b+=txt(70,850,'名义整机厚度24mm（-18至+6）；25mm是否含滚轮暂按更严格口径。1mm不是已证明的公差余量。',20);
b+=txt(70,895,'电池和主板不能凭示意图叠放：必须计入插座焊脚、板厚、双面元件、支撑、绝缘、线束和电池膨胀。',20);
b+=txt(70,940,'原18mm喇叭浅翼堆叠0.8+5.8+0.3+1.2=8.1mm，失败；USB 6.5mm立式件也不能放在实木上方。',20,'#ab3631');
save('mechanical/M03-stack','M03 | 安装高度、剖面包络与失败项',b);
b='';
const flow=[['原拾音器 / 旧穿孔',65,185,310],['C07 → JPU → 高阻/保护',445,185,410],['ADC → DSP',980,185,390],['FX SEND 干声',65,455,310],['AUX/RETURN → ADC',445,455,410],['DAC → PHONES / LINE',980,455,500],['USB2主机 / BLE控制',65,755,450],['A2DP音响源端 / 待联调',580,755,470],['BTL → 独立喇叭',1080,755,420]];
for(const[label,X,Y,W]of flow)b+=rect(X,Y,W,90)+txt(X+W/2,Y+54,label,21,'#243739','middle');
b+=ln(375,230,445,230)+ln(855,230,980,230)+ln(650,275,650,340)+ln(650,340,220,340)+ln(220,340,220,455)+ln(855,500,920,500)+ln(920,500,920,230)+ln(920,230,980,230)+ln(1175,275,1175,455);
b+=txt(70,965,'独立并行输出，不把SEND串入ADC；RETURN不能回灌SEND；USB与蓝牙不是串联线；端口无话筒电源。',20);
save('electrical/E00-system','E00 | 音频、通信与保留拾音器全链路',b);
const circuits=read('electrical/circuits.json');
for(const sh of circuits){
 const pieces=[];for(const c of sh.components)for(let st=0;st<c.pins.length;st+=18)pieces.push({...c,pins:c.pins.slice(st,st+18),suffix:st?' (continued)':''});
 let n=1,body='',col=0,yy=165;
 const flush=()=>{if(body){save(`electrical/${sh.id}-${String(n++).padStart(2,'0')}`,sh.id+' | '+sh.title,body,'同名网络相连；逻辑引脚图，不是ERC合格的EDA生产原理图');body='';col=0;yy=165;}};
 for(const c of pieces){const h=c.pins.length===2?124:80+30*c.pins.length;if(yy+h>1035){if(col===0){col=1;yy=165;}else flush();}const xx=55+col*790;
  body+=txt(xx,yy,c.ref+' | '+c.value+c.suffix,17);
  if(c.pins.length===2){const cy=yy+49;body+=ln(xx+10,cy,xx+250,cy)+ln(xx+315,cy,xx+670,cy);
   if(c.type==='C')body+=ln(xx+264,cy-15,xx+264,cy+15)+ln(xx+299,cy-15,xx+299,cy+15)+ln(xx+250,cy,xx+264,cy)+ln(xx+299,cy,xx+315,cy);
   else body+=rect(xx+250,cy-12,65,24,'white')+(c.type!=='R'?txt(xx+282,cy+5,c.type,12,'#243739','middle'):'');
   body+=txt(xx+10,cy+30,c.pins[0].number+': '+(c.pins[0].net||'NC'),15)+txt(xx+670,cy+30,c.pins[1].number+': '+(c.pins[1].net||'NC'),15,'#243739','end');
  }else{body+=rect(xx+5,yy+22,235,h-44);for(const[i,p]of c.pins.entries()){const Y=yy+49+i*30;body+=txt(xx+227,Y,p.name,14,'#243739','end')+ln(xx+240,Y-5,xx+315,Y-5)+txt(xx+252,Y-10,p.number,12)+txt(xx+328,Y,p.net||'NC',16,p.net?'#17695f':'#ab3631');}}
  yy+=h;
 }flush();
}
const ac=read('simulation/analog-model.json');b='';const gx=f=>160+Math.log10(f/20)/3*1180,gy=g=>850-g*1500;
for(const g of [0,.1,.2,.3,.4])b+=ln(160,gy(g),1340,gy(g),'#ccd4d3')+txt(130,gy(g)+5,g.toFixed(1),16,'#243739','end');
for(const f of [20,100,1000,10000,20000])b+=txt(gx(f),885,String(f),16,'#243739','middle');
for(const[key,col]of [['oldGain','#ad4135'],['newGain','#16877a']])b+=`<polyline fill="none" stroke="${col}" stroke-width="4" points="${ac.sweep.map(r=>gx(r.hz)+','+gy(r[key])).join(' ')}"/>`;
b+=txt(160,165,'理想运放AC节点模型：红=旧网络错误，绿=修正后；不包括真实带宽、失真、ESD与供电故障。',20);
b+=txt(160,935,`1kHz增益：旧${ac.at1kHz.old.toFixed(4)}；修正${ac.at1kHz.corrected.toFixed(4)}；2000组假设容差范围${ac.at1kHz.min2000.toFixed(4)}..${ac.at1kHz.max2000.toFixed(4)}`,20);
b+=txt(160,980,'横轴Hz对数；纵轴幅度比。通过的是指定数学模型，不是整机电性能或制造可行性。',20,'#ab3631');
save('simulation/AC01-before-after','AC01 | 线路输出连接错误的模型复现与修正',b);
write('verification/drawings.json',drawings);
let dxf='0\nSECTION\n2\nHEADER\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';
const dl=(X,Y,A,B,layer)=>{dxf+=`0\nLINE\n8\n${layer}\n10\n${X}\n20\n${Y}\n30\n0\n11\n${A}\n21\n${B}\n31\n0\n`;};
for(const[X,Y,W,H,layer]of [[0,0,148,49,'PROPOSED_COVER_NO_CUT'],[4,3,140,43,'PROPOSED_SHALLOW_FRAME'],[36,3,76,43,'PROPOSED_CUP'],[35,1,78,47,'USER_CAVITY_NOMINAL']])for(const a of [[X,Y,X+W,Y],[X+W,Y,X+W,Y+H],[X+W,Y+H,X,Y+H],[X,Y+H,X,Y]])dl(...a,layer);
for(const[X,Y]of [[8,6],[140,6],[8,43],[140,43]]){dl(X-1,Y,X+1,Y,'UNAPPROVED_HOLE_CENTER');dl(X,Y-1,X,Y+1,'UNAPPROVED_HOLE_CENTER');}write('mechanical/outlines-study.dxf',dxf+'0\nENDSEC\n0\nEOF\n');
write('mechanical/enclosure-study.scad',`// V20 HOLD. Parametric geometry study only; not compiled or validated for printing/molding.
// Units mm. Top cover alone takes four violin-body screws; lower shell has reliefs, no screw holes.
// Clips are deliberately separate coupons: final hook/mating pocket and material are NOT released.
$fn=40;
show="exploded"; // cover, lower, exploded, clip_coupon
module cover(){difference(){translate([0,0,3.8])cube([148,49,1.2]);for(p=[[8,6],[140,6],[8,43],[140,43]])translate([p[0],p[1],3])cylinder(d=2.6,h=4);
for(p=[[56,22],[80,22],[56,35],[80,35]])translate([p[0],p[1],3])cylinder(d=6,h=4);
translate([96.5,27.2,3])cube([9,3.6,4]);for(x=[57,78,98])translate([x-5,8,3])cube([10,3,4]);
for(x=[51,67,83,99,115])translate([x,43,3])cylinder(d=4,h=4);
// Speaker aperture intentionally omitted until deep-cavity or thin-driver variant is approved.
}}
module lower(){difference(){union(){translate([4,3,0])cube([140,43,3.8]);translate([36,3,-18])cube([76,43,18.1]);}
translate([5.2,4.2,.8])cube([137.6,40.6,5]);translate([37.2,4.2,-16.8])cube([73.6,40.6,22]);
for(p=[[4,3],[144,3],[4,46],[144,46]])translate([p[0],p[1],-.1])cylinder(r=4.5,h=5);
// C07 cable slot, position/diameter unapproved. No cut into violin.
translate([35,20,-6])cube([3,4,3]);}}
module clip_coupon(){cube([4,4,2]);translate([4,1.5,0])cube([6,1,.7]);translate([9.3,1.5,.7])linear_extrude(height=.3)polygon([[0,0],[.7,0],[.7,1],[0,1]]);}
if(show=="cover")cover();else if(show=="lower")lower();else if(show=="clip_coupon")clip_coupon();else{color("gray")lower();color("silver")translate([0,0,14])cover();translate([155,0,0])clip_coupon();}
`);
const release=read('verification/release.json'),tests=read('verification/model-tests.json');
const table=(headers,rows)=>`<div class="scroll"><table><thead><tr>${headers.map(h=>`<th>${e(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${e(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
const blocks=read('verification/open-items.json'),changes=read('verification/changes.json');
const html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SmartVio V20 工厂工程评审</title><style>*{box-sizing:border-box}body{margin:0;font:15px/1.65 'Microsoft YaHei',Arial;color:#243739;background:#fff}main{max-width:1180px;margin:auto;padding:24px}h1{font-size:28px}h2{font-size:21px;margin-top:35px;border-bottom:2px solid #167466;padding-bottom:8px}.hold{background:#fff0e9;border-left:5px solid #b64132;padding:16px}a{color:#126d63}img{max-width:100%;height:auto}nav{display:flex;gap:20px;flex-wrap:wrap}table{border-collapse:collapse;width:100%;min-width:600px}th,td{border:1px solid #d6dfdd;padding:9px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#edf3f1}.scroll{max-width:100%;overflow:auto}.muted{color:#57686a}details{padding:12px 0;border-bottom:1px solid #d6dfdd}summary{cursor:pointer;font-weight:bold}code{overflow-wrap:anywhere} @media(max-width:600px){main{padding:16px}h1{font-size:23px}}</style><main>
<h1>智能电子小提琴 V20：工厂工程评审包</h1><p class="hold"><strong>HOLD / 不能直接投板、开模或批量采购。</strong><br>本版补齐设计追溯、逻辑连接、工序与部分主机模型测试，不是您要求的最终可生产工程。真实PCB、完整保护电路、器件/电池堆叠、固定扭矩和样机测试仍未闭合。</p>
<nav><a href="SmartVio-V20-Review.pdf">完整评审PDF</a><a href="#mechanical">结构图</a><a href="#electrical">电路连接图</a><a href="#tests">测试记录</a><a href="#factory">工厂工序</a><a href="#open">未完成项</a></nav>
<p>最新用户要求为准：原腔78×47×22mm、不新增开腔、保留旧拾音和穿孔、上盖四螺丝接琴体、上下壳仅卡扣、外凸≤5mm、整机≤25mm。25mm暂按含滚轮更严格处理。</p>
<details><summary>查看作为造型依据的最新效果图（不是制造尺寸图）</summary><img src="reference/latest-style-only.png" alt="V19造型参考"></details>
<h2>本轮修复与边界</h2>${table(['编号','发现的问题','本轮修正','仍须验证'],changes.map(x=>[x.id,x.problem,x.action,x.remaining]))}
<h2 id="mechanical">上壳、下壳与内部空间</h2><p>端口/电池/喇叭必须按真实最大包络装配；不能把示意元件缩小后宣布安装通过。原喇叭浅翼堆叠为8.1mm，明显超过5mm；两种重排路线尚待选定。</p>${drawings.filter(d=>d.file.startsWith('mechanical')).map(d=>`<h3>${e(d.title)}</h3><a href="${d.file}"><img src="${d.file}" alt="${e(d.title)}"></a>`).join('')}
<p><a href="mechanical/enclosure-study.scad">OpenSCAD尺寸研究源</a> / <a href="mechanical/outlines-study.dxf">DXF轮廓研究源</a>：未编译/未验证，缺最终卡扣配合，不是加工文件。</p>
<h2 id="electrical">逐引脚与逐网络连接</h2><p>${release.physicalComponents}条物理元件记录，${release.logicalPinRecords}条逻辑引脚记录，${release.logicalNets}个网络。它们不是已布铜的焊盘或路径；同名网络表示应连接，真实坐标、层、走线、过孔均未生成。</p>
<p><a href="electrical/circuits.json">电路结构数据</a> / <a href="electrical/pin-net-register.json">逐引脚表</a> / <a href="electrical/net-routing-register.json">逐网络布线要求</a> / <a href="electrical/component-register.json">候选物料记录</a></p>
${drawings.filter(d=>d.file.startsWith('electrical')).map(d=>`<details><summary>${e(d.title)} / ${e(path.basename(d.file))}</summary><img loading="lazy" src="${d.file}" alt="${e(d.title)}"></details>`).join('')}
<h2>通信与音频</h2><p>USB设备、BLE控制、A2DP音响源端按不同角色设计；音频不走115200串口。CRC不是身份认证；本包模型没有真实BLE加密或可烧录固件。</p><a href="communication/protocol.json">协议字段与命令定义</a>
<h2 id="tests">可重复测试</h2><p>${tests.counts.pass}项主机模型/规则检查通过；${tests.counts.fail}项失败。另有2项AC模型断言和2000组假设容差计算。这里的“通过”不包括硬件测试；已识别出的结构失败仍是OPEN。</p><img src="simulation/AC01-before-after.svg" alt="线路模型扫频"><p><a href="verification/model-tests.json">逐项测试记录</a> / <a href="simulation/analog-model.json">AC模型数据与假设</a></p><p class="muted">未运行：SPICE、EDA导入/ERC/DRC、热/结构/声学仿真、RF/USB实机、整机样机。本轮没有复测或修改V16客户端/后台。</p>
<h2 id="factory">工厂逐步作业及线束</h2><p>以下均是待批准工艺要求，不是已执行的生产记录。每焊点必须先有正式封装、焊盘和工艺文件，不能用空坐标表替代。</p>${table(['工序','操作','作业要求','保存证据'],read('assembly/process-traveler.json').map(s=>[s.id,s.operation,s.instruction,s.evidence]))}<p><a href="assembly/cable-register.json">C01-C07线材与接线要求</a> / <a href="verification/dvp.json">15项DVP计划</a> / <a href="verification/feature-matrix.json">全功能完成度表</a></p>
<h2 id="open">制造放行前必须关闭</h2>${table(['编号','责任方','阻断问题','关闭证据'],blocks.map(x=>[x.id,x.owner,x.reason,x.closure]))}
<h2>原厂依据</h2>${read('sources/index.json').map(s=>`<p><a href="${e(s.url)}">${e(s.id)}</a>：${e(s.checked)}${s.checkedThisTurn?'（本轮查阅）':'（继承参考，本轮未逐项复核）'}</p>`).join('')}
<p class="hold">探索验证 → EVT工程样机 → DVT设计验证 → PVT小批生产。每阶段样本数量、预算、日程由供应商能力与风险确定；不得把本包的文件数量或测试计数当作量产放行依据。</p></main></html>`;
write('index.html',html);
console.log(JSON.stringify({drawings:drawings.length,index:path.join(root,'index.html')}));
