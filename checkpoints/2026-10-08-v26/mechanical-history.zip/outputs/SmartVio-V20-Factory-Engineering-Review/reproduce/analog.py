"""Ideal small-signal nodal model, NOT transistor SPICE or hardware measurement."""
import json
from pathlib import Path
import numpy as np

root = Path('outputs/SmartVio-V20-Factory-Engineering-Review').resolve()
def response(f, corrected=True, c1=1e-6, c2=10e-6, r1=15e3, r2=10e3, load=10e3):
    s=2j*np.pi*f
    rp=1/(1/load+1/100e3)
    gl=1/(220+rp)
    if corrected:
        a=np.array([[s*c1+1/r1,-1/r1,0],[-1/r1,1/r1+1/r2,0],[0,-s*c2,s*c2+gl]],complex)
        b=np.array([s*c1,0,0],complex)
        return np.linalg.solve(a,b)[2]*rp/(220+rp)
    a=np.array([[s*(c1+c2)+1/r1+gl,-s*c2-1/r1],[-1/r1,1/r1+1/r2]],complex)
    return np.linalg.solve(a,np.array([s*c1,0],complex))[0]*rp/(220+rp)

rows=[{'hz':float(f),'oldGain':abs(response(f,False)),'newGain':abs(response(f,True))} for f in np.geomspace(20,20000,161)]
rng=np.random.default_rng(20261002)
trials=[]
for _ in range(2000):
    r1=15e3*rng.uniform(.99,1.01);r2=10e3*rng.uniform(.99,1.01)
    c1=1e-6*rng.uniform(.8,1.2);c2=10e-6*rng.uniform(.8,1.2)
    trials.append(abs(response(1000,True,c1,c2,r1,r2)))
low,high=float(min(trials)),float(max(trials))
assert high<.41 and low>.37
checks=[{'id':'AC01','result':'PASS','meaning':'Corrected ideal LINE transfer at 1kHz is between0.37 and0.41 for 2000 assumed R/C tolerance draws; not yield evidence'},
 {'id':'AC02','result':'PASS' if abs(response(1000,True))>2*abs(response(1000,False)) else 'FAIL','meaning':'Old network-name collision materially changes intended gain in the model'}]
spk=[{'choice':'original wing','stackMm':.8+5.8+.3+1.2,'limitMm':5,'status':'FAIL'},
 {'choice':'thin-driver study','stackMm':.8+2.9+.3+1.2,'limitMm':5,'status':'FAIL nominal with current 1.2mm lid; grille/structure change required'},
 {'choice':'speaker relocated to cavity','status':'UNVERIFIED: repack full component volumes and acoustic chamber'}]
# Candidate currents, capacity and efficiency are assumptions, not part specifications or predictions.
power=[]
for name,i3,speaker in [('local/headphone',.20,0),('wireless',.32,0),('speaker study',.22,.3)]:
    watts=3.3*i3/.85+speaker/.8+.04
    for mah in [300,600,1000]:
        power.append({'mode':name,'capacityScenarioMah':mah,'assumedPowerW':round(watts,3),'idealDeratedHours':round(3.7*(mah/1000)*.8/watts,2),'fitsPackage':None})
result={'type':'Linear nodal AC calculation + scenario arithmetic; NOT SPICE',
 'assumptions':['Ideal unity-gain buffer; VMID is AC ground','Input source is ideal; ignores upstream470ohm filter, headphone branch, op-amp bandwidth/noise/rail limits and protection','1uF input coupling;10uF output coupling;15k/10k divider;220ohm source;10kohm load parallel100kohm','Monte Carlo uses assumed independent R +/-1%, C +/-20%; not manufacturing distribution or validation'],
 'at1kHz':{'old':abs(response(1000,False)),'corrected':abs(response(1000,True)),'min2000':low,'max2000':high},'sweep':rows,'checks':checks,'speakerStack':spk,
 'powerScenarios':power,'powerCaution':'No battery selected. These runtime scenarios omit verified duty cycles, cell cutoff/capacity at temperature, USB budget and enclosure thermal model. Not advertised battery life.',
 'excluded':['ESD/transients','Battery chemistry or charging safety','Acoustic response','Thermal/structural FEA','Signal integrity','Full circuit SPICE']}
(root/'simulation/analog-model.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'at1kHz':result['at1kHz'],'checks':checks,'speaker':spk}))
