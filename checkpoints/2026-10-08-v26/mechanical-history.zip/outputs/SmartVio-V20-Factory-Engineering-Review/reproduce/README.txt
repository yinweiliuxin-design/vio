Portable tests: run node reproduce/test.cjs from the extracted package (Node.js required).
model.cjs is a host reference, not firmware.
Other builders are archival workspace scripts and require the original V18/V19 workspace, bundled dependencies and Windows fonts; do not treat them as a standalone CAD toolchain.
No actual EDA routing, SPICE, shell CAD compilation or hardware test is included.
