import json
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4,A3,landscape
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from pypdf import PdfReader

root=Path('outputs/SmartVio-V20-Factory-Engineering-Review').resolve()
def read(f):return json.loads((root/f).read_text(encoding='utf-8'))
pdfmetrics.registerFont(TTFont('YaHei','C:/Windows/Fonts/msyh.ttc',subfontIndex=0))
styles={k:ParagraphStyle(k,fontName='YaHei',fontSize=n,leading=leading,wordWrap='CJK',textColor=HexColor('#243739')) for k,n,leading in [('body',10,16),('small',8,11.5),('title',22,30),('sub',12,19)]}
pdf=root/'SmartVio-V20-Review.pdf';c=canvas.Canvas(str(pdf),pagesize=A4);c.setTitle('智能电子小提琴 V20 全链路工程评审与工厂作业要求');c.setAuthor('SmartVio engineering review')
number=0;layout=[]
def para(s,x,y,w,style='body'):
    p=Paragraph(escape(str(s)).replace('\n','<br/>'),styles[style]);_,h=p.wrap(w,10000);p.drawOn(c,x,y-h);return y-h
def start(title,size=A4):
    global number
    number+=1;w,h=size;c.setPageSize(size);c.setFillColor(HexColor('#17695f'));c.rect(32,h-37,w-64,3,fill=1,stroke=0);c.setFont('YaHei',8);c.drawString(32,h-24,'SmartVio V20 | 2026-10-02 | ENGINEERING REVIEW | HOLD');c.setFillColor(HexColor('#a43e32'));c.drawString(32,23,'非生产放行 / 未完成PCB布线、保护安全、扭矩及实物验证');c.drawRightString(w-32,23,str(number));return w,h,para(title,32,h-53,w-64,'title')-15
def finish(y=60):
    assert y>=43,(number,y)
    layout.append({'page':number,'bodyBottom':y});c.showPage()
def prose(title,items):
    w,h,y=start(title)
    for head,text in items:
        y=para(head,32,y,w-64,'sub')-4;y=para(text,32,y,w-64)-17
    finish(y)
prose('一体机工厂工程评审包',[
 ('首先明确交付性质','本包不是可以直接生产样机的最终图纸。它是在最新V19效果图与用户尺寸之上，对电路数据、结构约束、通信参考模型、工序与验收进行的V20深化。工厂可用于工程评审、询价和分阶段研发，不可直接据此投板、开模或批量采购。'),
 ('本轮确实完成','修正7项已发现的数据/连接问题；更新14个电路章节；建立226条物理元件候选记录、797条逻辑引脚记录和159个逐网要求。建立可重复主机模型测试与理想运放AC模型，并生成可编辑JSON、SVG、尺寸研究DXF/SCAD。'),
 ('本轮没有完成','没有真实铜走线、批准封装、Gerber、钻孔、贴片坐标、最终卡扣实体配合、螺丝扭矩、完整保护电路、可烧录固件或实物测试。逻辑网络图不是通过ERC的EDA原理图；测试通过不等于样机可用。'),
 ('快速阅读顺序','先看第2页约束与后续修复/风险；结构图后是全部电路连接图；最后附物料、逐网连接、工厂工序、线材、DVP和来源。index.html提供完整图纸及JSON入口。')])
prose('01 / 最新约束及坐标基准',[
 ('保留项','原黑色琴体、原琴码拾音器、原穿线孔。原腔净尺寸78×47×22mm；不得新增开腔。不设DOCK、话筒或48V。'),
 ('用户确认的接口与连接','四个3.5mm接口：PHONES、LINE OUT、FX SEND、AUX/RETURN，另加USB-C，全部控制正面。五键FX/MODE/MIX/BT/PWR。上盖四角螺丝仅与琴体连接；上下壳仅卡扣，下壳无装配螺丝孔。'),
 ('高度要求','非滚轮最高外凸≤5mm；整机总厚≤25mm。总厚暂按包括滚轮更严格处理，仍需用户最终确认。插头为外部附件另计。'),
 ('定位推导','同一琴尾金属固定件基准向琴头为正：原腔近端145、远端223mm。上盖148mm候选范围110..258；下沉舱76mm候选146..222；浅框140mm候选114..254。旧10..160安装段与原腔仅重叠15mm，已弃用。'),
 ('数据等级','78×47×22及145为用户报告，未记录量具/公差；148×49、140×43、76×43×18及孔位/壁厚均为候选设计。不得从效果图像素比例推导加工尺寸。')])
changes=read('verification/changes.json')
for i in range(0,len(changes),3):prose('02 / 已发现问题与修正 '+str(i//3+1),[(x['id']+' '+x['problem'],x['action']+'。验证：'+x['proof']+'。仍待：'+x['remaining']) for x in changes[i:i+3]])
prose('03 / 上下壳与真实堆叠',[
 ('壳体研究输入','上盖148×49，研究板厚1.2mm；下壳浅框140×43；仅76×43中央杯体下沉18。杯体壁/底研究1.2mm；浅翼底0.8mm。SCAD未编译且未建成最终卡扣配合，不可直接打印作为装机样件。'),
 ('为什么当前效果图不能直接转生产','原18mm候选喇叭厚5.8mm，浅翼底0.8+喇叭5.8+间隙0.3+上盖1.2=8.1mm，违反外凸5mm。薄型10mm喇叭厚2.9，按同一壳体仍为5.2mm；需局部薄网/结构重新验证，不能直接替换即判合格。'),
 ('可选修正路线','A：将喇叭移到原腔投影内，调整面板开孔并重新排布四插座、USB、电池和PCB。B：保留左侧外观，改薄型喇叭及局部网面结构；声压、低音、失真与材料强度可能下降。两案尚未确认；本包不输出虚假的最终内布置。'),
 ('完整公差链','必须录入外壳翘曲、上盖厚度、板支撑、板厚、元件最大高、插座焊脚、线束、胶垫、喇叭振膜行程、电池最大鼓胀尺寸以及木腔曲率/涂层。名义24mm不能代替最坏公差≤25mm。')])
prose('04 / 固定与插口承力',[
 ('力传递','插头轴向力/弯矩先由插座承力结构传至上盖刚性框，再经四个琴体螺丝传到胶合板。不能仅靠插座信号焊脚抗插拔，也不能让下壳卡扣独自承受外部端口全部载荷。'),
 ('四孔与螺钉','上盖局部(8,6)、(140,6)、(8,43)、(140,43)，Ø2.6仅为研究坐标。ST2.2系列可作试验起点，但长度、头部、导孔、涂层与扭矩全未批准。没有真实实心厚度时不填写可施工螺丝长度。'),
 ('扭矩取得方法','使用同批层压板试块，覆盖含水率、层向、孔距、实际螺钉批次；记录坐实扭矩、滑牙扭矩、劈裂/拔出与复紧结果。根据离散度建立工艺窗口；最坏穿入深度必须小于局部实心厚度减已批准残留厚度。试验数量和步进由ME决定。'),
 ('卡扣','研究四扣、梁长6/梁厚0.7/挠度0.3mm，理想梁应变约0.875%。该值不含根部应力集中、装配公差、老化、蠕变和冲击；材料容许值未定，不能称强度通过。必须形成最终钩面/扣槽、拔模、圆角与拆卸工具方案。')])
prose('05 / 整机电路与保护责任',[
 ('已有连接架构','拾音高阻缓冲及独立SEND；三路ADC、DSP、DAC、耳放、线路输出、AUX/RETURN、USB接口与电源输入、充电电源路径、升降压、射频模块、BTL功放、指示灯及按键。所有图页均为候选连接。'),
 ('必须补齐的保护','拾音峰值/ESD钳位需要同时满足漏电与噪声；音频口需关机反灌、双输出误接、持续过压/短路保护；USB需CC/SBU误接保护及电流协商；电池需批准保护包/NTC/授权充电；掉电、CPU卡死与失钟需独立硬件静音/关断。不能用软件模型替代这些电路。'),
 ('有意不假装解决','候选TVS不等于把电压钳至3.3V安全范围；PhotoMOS也不使共地线路成为电气隔离。R905的2k只对应功放SD_MODE注入限制，不能代替硬件安全联锁。'),
 ('当前安全策略','充电保持禁止；未签审不得接裸电芯或将整机接高能量源测试。实物上电按批准的分板试验、限流电源和合格人员流程进行。模型中charge=false不是产品充电功能完成。')])
prose('06 / PCB与每个焊接点如何落地',[
 ('本包的精度边界','electrical/pin-net-register.json记录每个逻辑引脚；net-routing-register.json逐网列出全部端点及布线类别。footprintPad、padXmm、padYmm、copperPath、vias均为null，因为尚无真实布线PCB；这些空值不会伪装成已完成路径。'),
 ('必须由正式EDA补齐','核对每颗器件确切订货号、引脚方向与封装；建立真实焊盘和机械孔；修复DA/DB/SH别名；合并U801多单元后做ERC。选板厂叠层，计算阻抗/载流/压降与热预算，再进行全部布线及DRC、网络一致性和机械碰撞检查。'),
 ('布局优先级','先锁定原腔与端口承力，再冻结拾音低噪区、数字时钟、RF天线、电源开关回路、Class D与电池隔离。不能先平均摆芯片再强行挤入插座。音频地采用连续参考平面，不能随意开槽切断返回路径。'),
 ('真正可制造文件','EDA源、批准库、BOM/AVL、全部铜层Gerber或工厂接受的ODB++、钻孔/槽、叠层与阻抗、阻焊/丝印/钢网、贴片坐标、装配正背图、极性、焊接曲线、ICT/FCT测试点/固件、版本哈希及DFM签字。缺任一关键项不放行。')])
prose('07 / 通信与用户模式',[
 ('链路分工','STM32负责低延迟本地采集/处理；ESP32候选负责BLE控制与A2DP音响源端。ADC/DAC/功放/蓝牙音频按主机时钟设计；UART只传控制，不传48kHz立体声音频。'),
 ('协议模型','帧53 56、版本、命令、u16序号、u16长度、最多256字节负载、CRC16。参考实现测试分包/粘包/校验/长度/重放/错误命令。CRC没有安全认证能力，authorize()只是单元测试注入的授权状态。真实BLE身份/加密尚未实现。'),
 ('工作状态','默认静音；无有效电源或时钟或故障时输出禁止。拔耳机不会自动开启喇叭，需要用户确认。BT配对须由实体按键授权并限时；自动重连、清除配对、权限、签名升级与回滚仍待固件设计。'),
 ('平台与角色边界','普通A2DP外置音响不承诺低延迟演奏监听；本地音准计时不依赖蓝牙往返。A2DP源/汇同时运行未验证。USB音频描述符/时钟反馈/宿主模式和各品牌手机、平板、电脑兼容性未完成，不能宣称全平台即插即用。')])
prose('08 / 音乐算法与效果测试范围',[
 ('本轮参考模型','20Hz直流抑制、可调低通音色、短延时、简化反馈空间效果、干湿混合、20ms音量渐变及数字幅度约束。SEND模型严格独立于RETURN与DSP。它不是完整产品音色库或已经移植到MCU的DSP引擎。'),
 ('已执行','43项主机模型/规则检查通过，其中包括错误帧、随机噪声输入、序号回绕、未授权指令、危险模式、耳机插拔、NaN/Inf音频、左右独立、反馈衰减及静音渐变。另有2项理想运放AC断言。'),
 ('结果解释','LINE OUT旧重名网络在模型1kHz增益约0.1395，修正后约0.3905。2000组假设阻容容差计算约0.3860..0.3950；它不是实际良率或真实声卡指标。WAV为合成440Hz信号，不是小提琴或内置喇叭录音。'),
 ('未完成算法/体验','未复测V16调音/练习评分/视频/社区/商城。多音、揉弦、弓噪、泛音、真实乐曲对齐、乐谱版权、视频隐私、端侧延迟均需另外评审。所谓全功能不能仅靠43项模型测试代表。')])
prose('09 / 电池、温升与声学预算',[
 ('电池不能用占位盒代替','必须提供完整保护电池包MPN、外形含引线/保护板、额定/最低容量、充放电/温度限制、NTC曲线、循环最大厚度、运输与合规文件；未取得前，不写续航承诺、不设置最终充电电流。'),
 ('预算必须分模式','本地耳机、线路+蓝牙、扬声器、USB边充边用、关机漏电分别测量。文件仅给假设300/600/1000mAh、效率0.85等数学场景；不证明任一种电池能够装入。充电输入预算须包括系统与电池两部分。'),
 ('温升不是功耗表','充电器线性压差损耗、升降压效率、RF峰值、功放效率与封闭木琴传热需在实际板/壳/环境下验证。先列热源与测温点，不把芯片裸板热阻套成整机表面温度。'),
 ('练习扬声器','用途已限定个人练习，演出接外置音响。18mm与10mm候选喇叭的频响差异明显，不能承诺重放完整小提琴低音或用软件低频增益补偿结构不足。须试听、测失真/反馈、设置实际功率与位移保护。')])
prose('10 / 验证和供应商签审',[
 ('探索验证','取得琴体量测、器件样品、电池包和分板方案，关闭基本空间与安全冲突。样本数、预算及周期由具体风险和供应商能力决定，不伪造固定数量。'),
 ('EVT工程样机','正式原理图/PCB及机械原型完成并经负责人签审后，分级上电，验证全部接口、时钟、保护、基本声学与装配；保留失败日志。'),
 ('DVT设计验证','冻结候选设计后开展电气/机械/环境/EMC/RF/电池及软件隐私验证。零件RoHS或无线模块证书不能直接等于整机在英德美日可销售。具体要求由合规负责人和实验室确认。'),
 ('PVT小批生产','验证工装、工艺窗口、良率、产线测试、序列追溯、包装、维修及售后。所有关键OPEN项关闭并批准变更后，才形成生产放行版本。')])

def tables(title,headers,rows,widths,batch=12,size=landscape(A4)):
    for startrow in range(0,len(rows),batch):
        w,h,y=start(title+f' / {startrow+1}-{min(startrow+batch,len(rows))}',size)
        data=[[Paragraph(escape(str(v)),styles['small']) for v in row] for row in [headers]+rows[startrow:startrow+batch]]
        t=Table(data,colWidths=widths);t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),HexColor('#dcebe7')),('ROWBACKGROUNDS',(0,1),(-1,-1),[HexColor('#ffffff'),HexColor('#f2f6f5')]),('GRID',(0,0),(-1,-1),.3,HexColor('#c8d4d0')),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));_,th=t.wrap(w-64,10000);assert y-th>=45,(title,startrow,y-th);t.drawOn(c,32,y-th);finish(y-th)

tables('关键未完成项',['编号','责任','问题','关闭证据'],[[r['id'],r['owner'],r['reason'],r['closure']] for r in read('verification/open-items.json')],[42,105,350,280],5)
for d in read('verification/drawings.json'):
    w,h,y=start(d['title'],landscape(A3));scale=min((w-64)/1600,(y-48)/1120);dw,dh=1600*scale,1120*scale;c.drawImage(str(root/d['file'].replace('.svg','.png')),(w-dw)/2,y-dh,dw,dh);finish(y-dh)
tables('候选物料记录 / 非采购BOM',['位号','值/功能','候选型号','封装/批准状态'],[[r['ref'],r['value'],r['mpn'] or '未定，禁止采购放行',r['package']+' / 未批准'] for r in read('electrical/component-register.json')],[60,200,185,332],14)
routes=read('electrical/net-routing-register.json')
tables('逐网连接 / 无实际铜路径',['网络编号','网络名称','全部逻辑端点','布线类别'],[[r['id'],r['net'],'; '.join(p['ref']+'.'+p['pin'] for p in r['endpoints']),r['netClass']+' / 铜路径未布'] for r in routes],[55,155,420,147],10)
tables('工厂工艺流转 / 全部未执行',['工序','操作','逐步要求','保留证据'],[[s['id'],s['operation'],s['instruction'],s['evidence']] for s in read('assembly/process-traveler.json')],[40,100,440,197],5)
tables('C01-C07线束工程定义 / 待放行',['编号/名称','两端','对应引脚','制造/测试限制'],[[s['id']+' '+s['name'],' → '.join(s['ends']),'; '.join(' → '.join(n) for n in s['nets']),s.get('note',s.get('process',''))] for s in read('assembly/cable-register.json')],[115,180,240,242],4)
tables('DVP / 尚未执行',['编号/对象','方法','验收要求','责任'],[[s['id']+' '+s['item'],s['method'],s['acceptance'],s['owner']] for s in read('verification/dvp.json')],[130,220,337,90],5)
tables('全功能完成度 / 非验收通过',['编号/功能','当前完成范围','尚需完成'],[[s['id']+' '+s['name'],s['now'],s['remaining']] for s in read('verification/feature-matrix.json')],[220,220,337],6)
for i in range(0,len(read('sources/index.json')),7):prose('原厂来源索引 / '+str(i//7+1),[(s['id']+(' / 本轮查阅' if s.get('checkedThisTurn') else ' / 继承参考'),s['url']) for s in read('sources/index.json')[i:i+7]])
c.save();r=PdfReader(str(pdf));assert len(r.pages)==number
(root/'verification/pdf-build.json').write_text(json.dumps({'pages':number,'layout':layout,'file':pdf.name,'release':'HOLD'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pages':number,'pdf':str(pdf),'bytes':pdf.stat().st_size}))
