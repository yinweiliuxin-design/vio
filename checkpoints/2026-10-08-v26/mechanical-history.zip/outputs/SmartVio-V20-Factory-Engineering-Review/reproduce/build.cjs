const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve('outputs/SmartVio-V20-Factory-Engineering-Review');
const previous = path.resolve('outputs/SmartVio-V18-System-Review-20261002');
for (const d of ['electrical','mechanical','assembly','communication','simulation','verification','sources','reference','reproduce']) fs.mkdirSync(path.join(root,d),{recursive:true});
const write = (p,v) => fs.writeFileSync(path.join(root,p),typeof v === 'string' ? v : JSON.stringify(v,null,2));
const esc = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const circuits = JSON.parse(fs.readFileSync(path.join(previous,'schematics/circuits.json')));
const get = ref => circuits.flatMap(s=>s.components).find(c=>c.ref===ref);
const pin = (ref,n) => get(ref).pins.find(p=>p.number===String(n));
const changes = [];
function fix(id,problem,action,proof,remaining) { changes.push({id,problem,action,proof,remaining}); }
// Separate AC input and AC output. The inherited same-name nets fed a buffer output back to its input divider.
for (const [i,ch] of ['L','R'].entries()) {
  pin('C'+(211+i),2).net='LINE_OUT_AC_'+ch;
  pin('R'+(211+i),1).net='LINE_OUT_AC_'+ch;
}
fix('E01','LINE_AC_L/R同时用于DAC输入衰减和缓冲器输出隔直，产生非预期反馈','输出隔直后独立命名LINE_OUT_AC_L/R；输入仍为LINE_AC_L/R','网络端点断言 + 理想运放小信号AC模型','未验证真实运放负载稳定性、THD与噪声');
pin('R403',2).net='USB_DP_MCU'; pin('R404',2).net='USB_DM_MCU';
fix('E02','USB_DP/DM_PHY与MCU页USB_DP/DM_MCU不连通','统一R403/R404后的网络名，与U801.71/.70相连','逐网连通断言','尚无USB布线阻抗、枚举固件或兼容性实测');
function add(sheet,ref,type,value,pins,mpn='',pkg='',source='',note='') {
 const c={ref,type,value,mpn,package:pkg,source,note,pins:pins.map(([number,name,net])=>({number:String(number),name,net})),release:'HOLD / NOT FOR FAB'};
 circuits.find(s=>s.id===sheet).components.push(c);return c;
}
function pass(sheet,ref,value,a,b) { return add(sheet,ref,ref[0],value,[[1,'1',a],[2,'2',b]],'',ref[0]==='C'?'0603 / exact rating and bias TBD':'0603 / 1% / exact MPN TBD'); }
pin('U801S',15).name='PC0_KEY_BT'; pin('U801S',15).net='KEY_BT';
add('A18','SW814','SW','BT momentary / active low',[[1,'A','KEY_BT'],[2,'B','GND']],'','low-profile; exact MPN TBD','MCU');
pass('A18','R824','10k','V3D','KEY_BT');pass('A18','C825','10nF','KEY_BT','GND');
fix('E03','面板已有BT按键，电路仍只有四键','新增SW814、R824、C825，候选GPIO PC0 / U801.15','原厂LQFP100引脚图 + 五键唯一网络检查','按键型号、去抖固件与实体高度待冻结');
// A resistance limits possible injection when the amplifier supply is below 3.3 V. It is not an independent shutdown interlock.
pin('U902',4).net='SPK_SD_PIN';pin('R904',1).net='SPK_SD_PIN';
pass('A19','R905','2k','SPK_ENABLE','SPK_SD_PIN');
fix('E04','MAX98357A SD_MODE直接接3.3V控制，SYS低于逻辑电压时存在注入风险','按原厂说明增加2k串阻R905；默认下拉移至芯片侧','原厂SD_MODE说明 + 网络检查','不代替低电压锁存、时钟丢失硬件关断或反灌实测');
add('A19','J902','TEST','RF factory pads - not user connector',[[1,'3V3','V3D'],[2,'GND','GND'],[3,'RX_IN','RF_PROG_RX'],[4,'TX_OUT','RF_PROG_TX'],[5,'BOOT','RF_BOOT'],[6,'EN','RF_ENABLE']],'','pogo layout TBD');
fix('E05','RF_PROG_RX/TX只存在于芯片端，无制造测试端点','增加J902测试点定义，3.3V逻辑，禁止5V UART','单端网络检查','未分配实体焊盘坐标，BOOT/EN夹具隔离仍待设计');
// Three low-current indicator zones use ordinary GPIO, avoiding an unreviewed high-current addressable strip.
circuits.push({id:'A23',title:'分段指示灯候选 / 默认灭灯',notes:['三段独立灯光区，不是已验证的灯条组件。每区一颗青色LED，整条外观由导光件形成。','PC6/PC7/PC8各自串1k，器件Vf、亮度、GPIO电流及导光均待验证；不以高电流RGB灯带替代。','开机GPIO低；PWM可听噪声、相机条纹与省电待测；颜色不是唯一故障指示，客户端同步文字。'],components:[]});
for (const [i,p] of [63,64,65].entries()) {
 const n='LED_ZONE_'+(i+1);pin('U801S',p).name='PC'+(6+i);pin('U801S',p).net=n;
 pass('A23','R'+(850+i),'1k',n,n+'_A');
 add('A23','D'+(850+i),'LED','CYAN / low current candidate',[[1,'A',n+'_A'],[2,'K','GND']],'','0603 envelope; pin polarity depends on approved MPN');
}
fix('E06','科技灯条只有外观，没有驱动端点','新增三路限流LED电路和MCU候选GPIO；导光件作为机械待定件','GPIO唯一性与电阻电流上界模型','灯珠、导光材料、亮度与EMI尚未验证');
circuits.find(s=>s.id==='A11').notes.push('V20：修正LINE输入/输出网络重名。所有物理封装、端口保护和样机验证仍未放行。');
circuits.find(s=>s.id==='A18').notes.push('V20新增BT按键PC0及三路指示灯PC6/7/8；仍需CubeMX复用与启动固件审核。');
for(const s of circuits)for(const c of s.components){c.release='HOLD / NOT FOR FAB';c.verificationScope='Inherited candidate plus V20 documented deltas; NOT full datasheet/EDA audit';}
const comps=circuits.flatMap(s=>s.components.map(c=>({...c,sheet:s.id,physicalRef:c.ref.startsWith('U801')?'U801':c.ref})));
const nets={}; const pins=[];
for(const c of comps)for(const p of c.pins){const row={sheet:c.sheet,ref:c.physicalRef,unit:c.ref,pin:p.number,function:p.name,net:p.net,footprintPad:null,padXmm:null,padYmm:null,solderProcess:'UNRELEASED',status:'logical pin only; verify symbol/package/pad first'};pins.push(row);if(p.net)(nets[p.net]??=[]).push({ref:c.physicalRef,unit:c.ref,pin:p.number});}
const bom=Object.values(comps.reduce((a,c)=>{if(!a[c.physicalRef])a[c.physicalRef]={ref:c.physicalRef,value:c.value,mpn:c.mpn||null,package:c.package,source:c.source,qty:1,approved:false,placement:null};return a;},{}));
function netclass(n){if(/USB_D[PM]/.test(n))return'USB2';if(/ADC_(SCK|BCK|FS|DATA)|PLAY_(BCK|FS|DATA)/.test(n))return'CLOCK_AUDIO';if(/PZ_|PU_BIAS/.test(n))return'HI_Z';if(/BUCK_L[12]/.test(n))return'SWITCHING';if(/^SPK_[PN]$/.test(n))return'BTL';if(/^(VBUS|USB_5V|SYS|PACK|V3)/.test(n))return'POWER';if(/HP_|LINE_|SEND_|RETURN_|RET_|VMID|DAC_[LR]/.test(n))return'ANALOG';return'CONTROL';}
const routingRules={
 USB2:'D+/D-同层紧耦合连续地参考，目标90Ω差分由板厂叠层计算；无长支路、无跨地缝；连接器与PHY之间ESD就近。线宽/间距/等长容差尚未批准。',
 CLOCK_AUDIO:'源端串阻紧邻MCU；短支路、连续地参考；远端负载扇出与49.152MHz边沿做SI核验。禁止两个时钟主机直接相连。',
 HI_Z:'JPU、R101、C101、运放靠近；漏电清洁、干燥、低寄生；与射频、开关电感、BTL及灯PWM隔离。保护器件漏电未闭合。',
 SWITCHING:'按原厂参考布局缩小电感/功率回路；不穿模拟区或电池下热敏区，禁用任意细线；铜宽依峰值电流和叠层计算。',
 BTL:'SPK+与SPK-成对走线到独立喇叭，均不接地；与拾音线分离；滤波/辐射测试后决定EMI件。',
 POWER:'按最大持续/峰值、铜厚、温升和压降计算；去耦靠供电脚；充电/保护/NTC/电池件未冻结，不允许合并安全地线旁路。',
 ANALOG:'远离时钟与开关节点，连续地参考；核对隔直极性、DC偏置、短路/反灌/热插拔保护；不把TRS立体声当作平衡接口。',
 CONTROL:'逻辑域3.3V；检查默认态、未供电注入、上拉及输入滤波；低频控制与保护联锁不能互相替代。'
};
write('electrical/circuits.json',circuits);write('electrical/component-register.json',bom);write('electrical/pin-net-register.json',pins);
write('electrical/net-routing-register.json',Object.entries(nets).map(([net,endpoints],i)=>({id:'N'+String(i+1).padStart(3,'0'),net,endpoints,netClass:netclass(net),rule:routingRules[netclass(net)],copperPath:null,vias:null,lengthMm:null,status:'UNROUTED - connectivity requirement, not copper'})));
write('electrical/routing-rules.json',routingRules);write('verification/changes.json',changes);
const c19=JSON.parse(fs.readFileSync('outputs/SmartVio-V19-Mount-Pickup-Study/design-candidate.json'));
write('mechanical/requirements.json',{...c19,revision:'V20 / HOLD',drawingBasis:'Newest V19 raster is style only; dimensions come from user reports and explicitly proposed geometry',detailStudy:{coverThickness:1.2,cupWall:1.2,cupFloor:1.2,wingFloor:.8,coverHoles:[[8,6],[140,6],[8,43],[140,43]],coverHoleDiameter:2.6,screwCandidate:'ST2.2 family; length, pilot diameter, head geometry, torque NOT RELEASED',clips:{count:4,beamLength:6,beamThickness:.7,deflection:.3,materialGrade:null},status:'ALL detailStudy values are proposed analysis inputs, not measured or manufacturing approved'}});
const blockers=[
 ['G01','机械','重新定位后的110..258mm区域宽度、曲率、实心厚度、四点边距和旧孔关系未测','琴厂','带基准的量测图、截面/超声测厚与样件复核'],
 ['G02','声学/结构','18×18×5.8mm喇叭不能直接置于5mm外凸的浅翼；薄喇叭不是等音质替代','ME/声学','深舱重排或薄喇叭声学样件，两案选型签审'],
 ['G03','电池/结构','无电芯型号、容量、最大厚度、膨胀/保护板/NTC及认证文件；叠装不能定稿','电池供应商/ME/EE','完整受保护电池包与3D、规格、温升及运输文件'],
 ['G04','电路','拾音及音频带电误接、CC/SBU过压、电池保护、硬关机和失钟硬联锁未闭合','EE','逐引脚原厂复核、仿真与风险试验'],
 ['G05','接口','1503 18检测触点DA/DB尚未映射实焊脚；USB外壳脚SH是逻辑合并名','EE/ME','原厂图、1:1样品通断、每个焊脚与固定脚封装确认'],
 ['G06','PCB','没有经过导入/ERC的正式EDA工程、封装库、布线PCB、DRC或Gerber','EE/PCB厂','全器件封装+原理图ERC+布线DRC+装配3D+DFM签审'],
 ['G07','固件','模型不是STM32/ESP32可烧录固件；USB音频、BLE、A2DP与安全启动未上板','固件工程师','构建可重复、烧录、时钟寄存器和真实设备联调'],
 ['G08','结构工艺','卡扣材料/根部圆角/脱模/受力、螺丝长度/扭矩无试验依据','ME/琴厂','材料与实物扭矩破坏/拔出/循环试验'],
 ['G09','整机验证','无实体音质/延迟/热/续航/机械/ESD/EMC/RF与电池测试','测试/实验室','DVP原始记录及不符合项闭环'],
 ['G10','软件/商业','客户端/后台保持V16；本轮没有实现全站功能、正式支付或上架','软件/运营','独立代码审查、安全与平台/地区合规验收']
].map(([id,area,reason,owner,closure])=>({id,area,reason,owner,closure,status:'OPEN'}));
write('verification/open-items.json',blockers);
const sources=JSON.parse(fs.readFileSync(path.join(previous,'sources/sources.json')));
for(const s of sources)s.checkedThisTurn=false;
for(const id of ['MCU','SPKAMP','BUCK','CHG','ADC','USB','SPK'])sources.find(s=>s.id===id).checkedThisTurn=true;
sources.find(s=>s.id==='JACK').url='https://downloads.lumberg.com/datenblaetter/en/1503_18.pdf';sources.find(s=>s.id==='JACK').checkedThisTurn=true;
sources.push({id:'THIN_SPK',url:'https://puiaudio.com/product/speakers-and-receivers/AS01008MR-2-R',checked:'10x10x2.9mm / 8ohm / 0.3W candidate, not equal acoustic replacement',checkedThisTurn:true},{id:'A2DP',url:'https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/bluetooth/esp_a2dp.html',checked:'source/sink are separate roles; simultaneous operation not validated',checkedThisTurn:true});
write('sources/index.json',sources);
const cables=JSON.parse(fs.readFileSync(path.join(previous,'cables/cable-specs.json')));
const usb=cables.find(c=>c.id==='C05');usb.qc={method:'Purchase qualified finished USB2 cable; vendor report and 100% functional continuity/enumeration according to agreed spec',forbidden:'Do not apply analog cable insulation test to USB electronics',testStatus:'NOT RUN'};usb.wire='Finished compliant USB2 Type-C cable, exact vendor/MPN required';usb.molding='Certified mating dimensions; not governed by analog 8mm plug diameter';
cables.push({id:'C07',name:'旧拾音器至JPU屏蔽线',length:null,tol:null,ends:['old pickup via existing hole','internal JPU'],nets:[['signal after tracing','JPU.1 PZ_RAW'],['return/shield after tracing','JPU.2 GND']],status:'POLARITY / CONNECTOR / LENGTH NOT RELEASED',process:'断开所有电源后查线；不得先按线色推定极性；保留旧孔，软护套与独立应力释放；不得夹入卡扣或螺丝路径；不得直接焊接电芯。'});
write('assembly/cable-register.json',cables);
fix('E07','USB成品线错误继承模拟线100V绝缘试验字段','C05单独定义成品USB验收，不使用模拟线耐压工序','JSON字段断言','线厂报告、USB实插与数据传输仍未测试');write('verification/changes.json',changes);
const steps=[
 ['01','需求及图纸冻结','核对本版约束与变更表，确认接口/按钮/尺寸基准；不混用V18旧高度及旧孔位。','PM/EE/ME','签署版本、哈希与偏差清单'],
 ['02','琴体量测','测新覆盖段宽度/曲率；原腔四角/底部净尺寸与圆角；四个拟固定点的层压板实心厚度。','琴厂','每点坐标、测具、读数、照片、测量人'],
 ['03','器件冻结','取得每个MPN规格、包装方向、焊接耐热、生命周期、合规声明、STEP和真样。空料号不得用随意相似品代换。','采购/EE','AVL签审，电池完整包型号'],
 ['04','原理图与封装','逐物理引脚核对本包逻辑表，DA/DB/SH不能当作已批准焊盘；U801两个单元合并一颗实物。','EE','EDA原生工程、ERC报告、封装对照'],
 ['05','PCB叠层布线','按逐网表布线；填入所有焊盘坐标、铜层、线宽、过孔及测试点。板厂确认阻抗与电源载流；不从SVG反推Gerber。','PCB工程师','DRC、网络比较、Gerber/钻孔/IPC356/坐标/叠层'],
 ['06','1:1装配干涉','代入连接器、滚轮、喇叭、电池及胶垫最大公差；检查全部插头同时插入和反向装配。','ME/EE','无负间隙，卡扣/线束/天线/鼓胀区记录'],
 ['07','小板验证授权','在全板之前分别验证拾音前级、电源、端口、codec时钟；本包本身不授权把裸电芯接入。','EE负责人','上电评审、受限电源和测试夹具记录'],
 ['08','来料及ESD','核对卷盘批次/烘烤与MSL要求，使用工厂ESD控制；测阻容样品；电池隔离储存。','IQC','物料追溯及不合格隔离'],
 ['09','锡膏与钢网','依据实际PCB焊盘及每个器件推荐图设计钢网，含裸露焊盘分窗；不能统一按100%开孔。','工艺','钢网版本、锡膏批次、SPI首件'],
 ['10','贴片与方向','按已批准坐标放置每个位号；核对IC 1脚、二极管极性、电解极性、QFN暴露焊盘。','SMT','首件照片、程序与坐标版本'],
 ['11','回流','依据锡膏和最弱耐热器件确定曲线，用实板热电偶测峰值/液相以上时间；禁止本包指定一个温度套用全部器件。','工艺','每炉温曲线、批次、AOI结果'],
 ['12','通孔/线材焊接','塑胶插座与线束分批按厂家工艺焊接；控制浸锡/手焊温度与时间，助焊剂清洗不损伤高阻输入；电池用认证引出线连接，不烙铁焊电芯。','工艺','每焊点照片/首件、拉力、残留检查'],
 ['13','焊点检验','AOI全部可见焊点，X-ray抽样方案由风险确定，关注QFN底焊盘和桥连；接地/电源短路检查。','QC','缺陷坐标、返修记录、复验签名'],
 ['14','分级首次上电','仅在EE放行后，电池/扬声器先不接，使用受限电源逐电源域验证；异常电流、异味或发热立即断电并隔离。','EE测试','实际电压/电流/纹波/温度，不填预期为实测'],
 ['15','下载及标定','写入签名可追溯固件，记录CRC/版本、序列号、时钟实测、ADC零点及音频增益；禁用量产调试权限策略须审核。','固件/测试','烧录日志与标定数据'],
 ['16','线束/电池/扬声器','按C07极性接拾音，BTL双线仅到喇叭；电池与尖角/热源隔离并保留供应商膨胀区；线束不穿过卡扣。','装配','布线照片、应力释放、连接器锁止'],
 ['17','卡扣合壳','上下壳只用卡扣；先走线再均匀闭合，检查夹线；下壳不加装配螺丝；插拔力传至上盖承力框，不靠信号焊点。','装配/ME','卡扣完全就位、间隙和重复拆装'],
 ['18','琴体固定','四螺丝只连接上盖与琴体；必须用已实测批准的长度、导孔、顺序与扭矩。未取得扭矩窗口不得拿候选值施工。','琴厂','实际扭矩曲线、无穿透/开裂/松脱'],
 ['19','全端口与场景测试','按DVP进行耳机/线路/效果器/USB/蓝牙/内置喇叭联动，含热插拔和故障；高风险浪涌试验交实验室。','测试','原始数据和失败闭环'],
 ['20','出厂放行','型号/软件/图纸一致；序列号、合规标签、线材及说明书齐套。全部关键OPEN关闭前不得标为量产合格。','质量负责人','签署放行单、留样、版本归档']
].map(([id,operation,instruction,owner,evidence])=>({id,operation,instruction,owner,evidence,status:'NOT EXECUTED'}));
write('assembly/process-traveler.json',steps);
const features=[
 ['F01','原拾音/高阻前级','逻辑设计+AC数学模型','保护漏电、峰值、噪声与琴码实录'],['F02','耳机/线路/发送/返回','连接修正+路由模型','插座焊盘、电平、插拔、误接与隔离'],
 ['F03','VOL/TONE/FX五键灯光','电路端点候选+行为模型','器件/电流/机械行程与固件'],['F04','EQ/延时/混响/限幅','主机参考DSP+数字测试','MCU性能、真实失真/音色与旁路'],
 ['F05','调音/练习评分','保留需求；本轮未改V16算法','音高库/弓噪/泛音/双音及多设备样本'],['F06','内置扬声器','两种尺寸方案均待选','琴上声学与反馈测试，不能保证完整低音'],
 ['F07','USB音频/控制/充电','连接修正+协议模型','UAC描述符、宿主适配、电流协商和安全充电'],['F08','BLE控制/A2DP音响','协议模型+角色约束','RF固件、天线、延迟、重连与共存'],
 ['F09','电池/关机/故障保护','安全需求+状态机模型','独立硬件保护、NTC、充电与滥用测试'],['F10','手机/平板/电脑','接口协议候选','Android/iOS/Huawei/Windows/macOS实机，不代表商店上架'],
 ['F11','练习录像/社区视频/曲库','V16演示保留；本轮未验证','完整软件、内容版权、隐私、审核与存储'],['F12','商城/购物车/退款/商家','V16沙盒目标；本轮未改','正式支付主体、密钥、税务/物流/安全审查']
].map(([id,name,now,remaining])=>({id,name,now,remaining,status:'PARTIAL / NOT PRODUCT ACCEPTED'}));write('verification/feature-matrix.json',features);
const dvp=[
 ['D01','尺寸/定位','量原腔与新覆盖段、四固定点','不新增开腔；零件不得越琴中柱边界；净空按最大公差仍为正','ME'],
 ['D02','高度/堆叠','实际最坏零件与线束装配','非滚轮最高≤5mm；总厚≤25mm暂按含滚轮；无顶压电池','ME'],
 ['D03','卡扣/固定','按插座上限插拔力、插头弯矩、琴体材料建立受力试验','无脱扣/裂纹/焊点受力；扭矩窗口由试验与可靠性余量确定','ME'],
 ['D04','电源/电池','分域电源、欠压、关机、USB拔插、传感器开短路','各域在器件规格内；故障默认静音/禁充；不超电池额定','EE'],
 ['D05','输入与线路','扫频、不同拾音峰值、短路/误接与关机反灌','电平/噪声/THD目标签审后测；无危险直流，保护状态正确','Audio'],
 ['D06','耳机','32/64/300Ω假负载，再分级真人试听','无开关爆音危险、左右正确、限幅有效；不把假负载功率当听力安全','Audio'],
 ['D07','效果器环路','SEND/RETURN、单声道/双声道、线路与乐器输入切换','RETURN不回灌SEND；增益/相位与外设可用，无自激','Audio'],
 ['D08','扬声器','琴上声压/THD、弓奏、握持及距离变化','安静个人练习接受度由用户听测；限幅不超选定喇叭，反馈不自激','Acoustic'],
 ['D09','USB','正反插、不同线、电脑/手机平板、枚举/挂起/热插拔','不超主机授权电流，录放正确；不中断保护，无未供电反灌','Firmware'],
 ['D10','蓝牙','BLE配对/权限/A2DP源端/断线/多设备干扰','未授权写入拒绝；本地演奏不等待无线；不宣称通用低延迟','RF'],
 ['D11','时钟故障','ADC/DAC/amp时钟停止与CPU卡死故障注入','独立硬件静音先于有害输出，软件重启不能代替保护','EE'],
 ['D12','温升/续航','选定电池与最终封闭壳体在组合最大负载下测量','皮肤接触/电池/IC各温度限值由适用规范及规格确定；无模型冒充实测','Thermal'],
 ['D13','ESD/EMC/RF','正式PCB天线壳体在线缆全插状态测试','实验室选定适用标准/等级并通过；元件合规不等于整机合规','Lab'],
 ['D14','环境/耐久','汗液/湿热/跌落/振动/线材弯折按使用风险定方案','无危险、无松脱；不标IP等级或寿命直到验证','Reliability'],
 ['D15','软件/隐私','身份认证、数据删除、录像默认本地、权限/升级回滚','无未经允许上传；签名更新与故障恢复；平台政策另审','Software']
].map(([id,item,method,acceptance,owner])=>({id,item,method,acceptance,owner,sampleSize:null,budget:null,schedule:null,status:'NOT RUN',measured:null,evidence:null}));write('verification/dvp.json',dvp);
write('verification/release.json',{version:'V20',date:'2026-10-02',release:'HOLD',purpose:'engineering review / RFQ / staged development; NOT sample fabrication release',completeSchematic:false,routedPCB:false,gerber:false,approvedFootprints:false,approvedFasteners:false,fullFunctionSimulation:false,hardwareTests:0,physicalComponents:bom.length,logicalPinRecords:pins.length,logicalNets:Object.keys(nets).length,openItems:blockers.length});
fs.copyFileSync('outputs/SmartVio-V19-Overall-Concept-Final.png',path.join(root,'reference/latest-style-only.png'));
write('README.txt','V20 工程深化与工厂评审包。请先打开 index.html 或 SmartVio-V20-Review.pdf。\n禁止直接投板、开模、上电或采购整批物料。包含逻辑连接/逐引脚/逐网要求，但没有真实PCB路径、Gerber或完整生产封装。所有工序及DVP均未实际执行。\n本轮修复记录见verification/changes.json；软件模型测试不等于硬件合格。\n');
module.exports={root,write,esc,circuits,comps,bom,pins,nets,changes,blockers,features,dvp,steps,sources};
console.log(JSON.stringify({root,components:bom.length,pins:pins.length,nets:Object.keys(nets).length,changes:changes.length}));
