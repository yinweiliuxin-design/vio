// Host-side reference models only. No GPIO driver, radio stack or safety-certified firmware.
const TYPES={SET_GAIN:1,SET_MODE:2,BT_PAIR:3,GET_STATUS:4};
function crc16(data){let crc=0xffff;for(const b of data){crc^=b<<8;for(let i=0;i<8;i++)crc=crc&0x8000?((crc<<1)^0x1021)&0xffff:(crc<<1)&0xffff;}return crc;}
function encode(type,seq,payload=Buffer.alloc(0)){
 if(!Object.values(TYPES).includes(type)||!Number.isInteger(seq)||seq<0||seq>65535||payload.length>256)throw Error('Invalid frame');
 const b=Buffer.alloc(10+payload.length);b[0]=0x53;b[1]=0x56;b[2]=1;b[3]=type;b.writeUInt16LE(seq,4);b.writeUInt16LE(payload.length,6);payload.copy(b,8);b.writeUInt16LE(crc16(b.subarray(2,b.length-2)),b.length-2);return b;
}
class Parser{
 constructor(){this.buffer=Buffer.alloc(0);this.errors=0;}
 push(chunk){const out=[];for(const byte of chunk){this.buffer=Buffer.concat([this.buffer,Buffer.from([byte])]);
  while(this.buffer.length>=2){if(this.buffer[0]!==0x53||this.buffer[1]!==0x56){this.buffer=this.buffer.subarray(1);continue;}if(this.buffer.length<8)break;
   const n=this.buffer.readUInt16LE(6);if(this.buffer[2]!==1||n>256){this.errors++;this.buffer=this.buffer.subarray(1);continue;}const total=n+10;if(this.buffer.length<total)break;
   const b=this.buffer.subarray(0,total);if(crc16(b.subarray(2,total-2))!==b.readUInt16LE(total-2)){this.errors++;this.buffer=this.buffer.subarray(1);continue;}
   out.push({type:b[3],seq:b.readUInt16LE(4),payload:Buffer.from(b.subarray(8,total-2))});this.buffer=this.buffer.subarray(total);
  }
 }return out;}
 // A transport timeout abandons incomplete frames. CRC is NOT authentication.
 timeout(){if(this.buffer.length)this.errors++;this.buffer=Buffer.alloc(0);}
}
class Device {
 constructor(){this.auth=false;this.lastSeq=null;this.gain=0;this.mode='MUTE';this.powerGood=false;this.clockGood=false;this.fault=false;this.headphones=false;this.speakerAcknowledged=false;this.pairing=false;this.chargeEnabled=false;}
 authorize(){this.auth=true;this.lastSeq=null;}
 disconnect(){this.auth=false;this.lastSeq=null;this.pairing=false;}
 execute(f){if(!this.auth)return'AUTH_REQUIRED';const d=this.lastSeq===null?1:(f.seq-this.lastSeq+65536)%65536;if(d===0||d>=32768)return'REPLAY';
  let action;
  if(f.type===TYPES.SET_GAIN){if(f.payload.length!==2)return'LENGTH';const v=f.payload.readInt16LE();if(v< -600||v>0)return'RANGE';action=()=>{this.gain=10**(v/200);};}
  else if(f.type===TYPES.SET_MODE){if(f.payload.length!==1||f.payload[0]>3)return'RANGE';action=()=>{this.mode=['MUTE','HEADPHONE','LINE','SPEAKER'][f.payload[0]];this.speakerAcknowledged=this.mode==='SPEAKER';};}
  else if(f.type===TYPES.BT_PAIR){if(f.payload.length!==0)return'LENGTH';action=()=>{this.pairing=true;};}
  else if(f.type===TYPES.GET_STATUS){if(f.payload.length!==0)return'LENGTH';action=()=>{};}
  else return'COMMAND';
  action();this.lastSeq=f.seq;return'OK';
 }
 headphoneEvent(inserted){this.headphones=inserted;this.mode='MUTE';this.speakerAcknowledged=false;}
 outputs(){const safe=this.powerGood&&this.clockGood&&!this.fault;return {hp:safe&&this.headphones&&this.mode==='HEADPHONE',line:safe&&this.mode==='LINE',speaker:safe&&!this.headphones&&this.mode==='SPEAKER'&&this.speakerAcknowledged,charge:false};}
}
function finite(x){return Number.isFinite(x)?x:0;}
class AudioModel{
 constructor(fs=48000){this.fs=fs;this.gain=0;this.dcX=0;this.dcY=0;this.delay=new Float64Array(Math.round(.12*fs));this.di=0;this.room=new Float64Array(Math.round(.0297*fs));this.ri=0;this.tone=0;}
 process(pickup,returnL,returnR,{targetGain=.5,wet=.2,feedback=.35,toneHz=3500,mute=false}={}){
  if(pickup.length!==returnL.length||pickup.length!==returnR.length)throw Error('Frame length mismatch');
  targetGain=Math.min(1,Math.max(0,finite(targetGain)));wet=Math.min(1,Math.max(0,finite(wet)));feedback=Math.min(.7,Math.max(0,finite(feedback)));toneHz=Math.min(10000,Math.max(300,finite(toneHz)));
  const out={left:new Float64Array(pickup.length),right:new Float64Array(pickup.length),send:new Float64Array(pickup.length)};
  const a=Math.exp(-2*Math.PI*toneHz/this.fs),r=Math.exp(-2*Math.PI*20/this.fs),step=1/(.02*this.fs);
  for(let i=0;i<pickup.length;i++){
   const x=finite(pickup[i]);out.send[i]=x; // Analog dry-send model deliberately excludes return and DSP.
   const h=x-this.dcX+r*this.dcY;this.dcX=x;this.dcY=h;this.tone=(1-a)*h+a*this.tone;
   const d=this.delay[this.di];this.delay[this.di]=this.tone+feedback*d;this.di=(this.di+1)%this.delay.length;
   const rv=this.room[this.ri];this.room[this.ri]=this.tone+.5*rv;this.ri=(this.ri+1)%this.room.length;
   const desired=mute?0:targetGain;this.gain+=Math.max(-step,Math.min(step,desired-this.gain));
   const v=(1-wet)*this.tone+wet*(.6*d+.4*rv);
   out.left[i]=Math.max(-.8,Math.min(.8,this.gain*(v+.5*finite(returnL[i]))));
   out.right[i]=Math.max(-.8,Math.min(.8,this.gain*(v+.5*finite(returnR[i]))));
  }return out;
 }
}
module.exports={TYPES,crc16,encode,Parser,Device,AudioModel};
