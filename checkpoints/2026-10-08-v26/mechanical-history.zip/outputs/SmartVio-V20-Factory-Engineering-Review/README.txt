V20 工程深化与工厂评审包。请先打开 index.html 或 SmartVio-V20-Review.pdf。
禁止直接投板、开模、上电或采购整批物料。包含逻辑连接/逐引脚/逐网要求，但没有真实PCB路径、Gerber或完整生产封装。所有工序及DVP均未实际执行。
本轮修复记录见verification/changes.json；软件模型测试不等于硬件合格。
