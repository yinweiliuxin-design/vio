// V20 HOLD. Parametric geometry study only; not compiled or validated for printing/molding.
// Units mm. Top cover alone takes four violin-body screws; lower shell has reliefs, no screw holes.
// Clips are deliberately separate coupons: final hook/mating pocket and material are NOT released.
$fn=40;
show="exploded"; // cover, lower, exploded, clip_coupon
module cover(){difference(){translate([0,0,3.8])cube([148,49,1.2]);for(p=[[8,6],[140,6],[8,43],[140,43]])translate([p[0],p[1],3])cylinder(d=2.6,h=4);
for(p=[[56,22],[80,22],[56,35],[80,35]])translate([p[0],p[1],3])cylinder(d=6,h=4);
translate([96.5,27.2,3])cube([9,3.6,4]);for(x=[57,78,98])translate([x-5,8,3])cube([10,3,4]);
for(x=[51,67,83,99,115])translate([x,43,3])cylinder(d=4,h=4);
// Speaker aperture intentionally omitted until deep-cavity or thin-driver variant is approved.
}}
module lower(){difference(){union(){translate([4,3,0])cube([140,43,3.8]);translate([36,3,-18])cube([76,43,18.1]);}
translate([5.2,4.2,.8])cube([137.6,40.6,5]);translate([37.2,4.2,-16.8])cube([73.6,40.6,22]);
for(p=[[4,3],[144,3],[4,46],[144,46]])translate([p[0],p[1],-.1])cylinder(r=4.5,h=5);
// C07 cable slot, position/diameter unapproved. No cut into violin.
translate([35,20,-6])cube([3,4,3]);}}
module clip_coupon(){cube([4,4,2]);translate([4,1.5,0])cube([6,1,.7]);translate([9.3,1.5,.7])linear_extrude(height=.3)polygon([[0,0],[.7,0],[.7,1],[0,1]]);}
if(show=="cover")cover();else if(show=="lower")lower();else if(show=="clip_coupon")clip_coupon();else{color("gray")lower();color("silver")translate([0,0,14])cover();translate([155,0,0])clip_coupon();}
