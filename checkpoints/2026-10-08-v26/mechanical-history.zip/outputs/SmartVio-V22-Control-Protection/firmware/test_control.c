#include "sv_control.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks, cases;
#define CHECK(x) do { checks++; if(!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); exit(1); } } while(0)
#define CASE(name) do { cases++; printf("PASS_GROUP_PENDING %s\n",name); } while(0)
static sv_inputs good(void) {
    sv_inputs i={0}; i.power_good=true;i.clocks_good=true;i.codec_ready=true;
    i.usb_phy_ready=true;i.speaker_calibrated=true;
    i.usb_present=true;i.usb_mv=5000;i.usb_budget_ma=100;
    i.battery_present=true;i.battery_mv=3700;i.temperature_valid=true;
    i.temperature_deci_c=250; i.board_usb_budget_ma=70;
    i.usb_measurement_valid=true; i.board_budget_valid=true;
    return i;
}
static void step(sv_control *c, sv_inputs *i, uint32_t ms) {
    while(ms) { uint32_t d=ms>10?10:ms;sv_tick(c,c->last_tick+d,i);ms-=d; }
}
static void ready(sv_control *c, sv_inputs *i) { *i=good();sv_init(c,0,NULL);step(c,i,10);CHECK(c->state==SV_READY); }
static size_t encode(uint8_t *b,uint8_t type,uint16_t seq,const uint8_t *p,uint16_t n) {
    b[0]=0x53;b[1]=0x56;b[2]=2;b[3]=type;b[4]=(uint8_t)seq;b[5]=(uint8_t)(seq>>8);
    b[6]=(uint8_t)n;b[7]=(uint8_t)(n>>8);if(n)memcpy(b+8,p,n);
    uint16_t crc=sv_crc16(b+2,(size_t)n+6);b[n+8]=(uint8_t)crc;b[n+9]=(uint8_t)(crc>>8);return (size_t)n+10;
}
static bool parse(sv_parser *p,const uint8_t *b,size_t n,uint32_t now,sv_frame *f) {
    bool ok=false;for(size_t j=0;j<n;j++)if(sv_parser_byte(p,b[j],now,f))ok=true;return ok;
}
static uint32_t rng=0x16378a2;
static uint32_t random32(void) {rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
int main(int argc,char **argv) {
    sv_control c;sv_inputs i;sv_parser p;sv_frame f;sv_session s={0};uint8_t b[266],data[256]={0};size_t n;
    if(argc==3 && strcmp(argv[1],"--decode")==0) {
        FILE *fp=fopen(argv[2],"rb");if(!fp)return 2;
        sv_parser_reset(&p);int ch;while((ch=fgetc(fp))!=EOF)if(sv_parser_byte(&p,(uint8_t)ch,0,&f))
            printf("{\"type\":%u,\"seq\":%u,\"length\":%u}\n",f.type,f.seq,f.length);
        fclose(fp);return 0;
    }
    CASE("cold_boot_muted_hold");sv_init(&c,0,NULL);CHECK(c.out.boot_hold);CHECK(!c.out.dac_unmute);CHECK(!c.out.charge_allow);
    CASE("boot_timeout");i=good();i.codec_ready=false;step(&c,&i,3000);CHECK(c.state==SV_FAULT);CHECK(c.faults&SV_F_BOOT);
    CASE("parallel_routes");ready(&c,&i);CHECK(sv_set_routes(&c,SV_LINE|SV_SPK|SV_BT));CHECK(c.out.active_routes==14);
    CASE("headphone_edge_mutes_speaker");i.headphones_raw=true;step(&c,&i,1);CHECK(!c.out.speaker_enable);CHECK(c.out.active_routes==(SV_LINE|SV_BT));
    CASE("debounce_no_early_headphone");CHECK(!sv_set_routes(&c,SV_HP));step(&c,&i,30);CHECK(sv_set_routes(&c,SV_HP|SV_LINE));CHECK(c.out.hp_enable);
    CASE("unplug_never_auto_speaker");i.headphones_raw=false;step(&c,&i,40);CHECK(!c.out.hp_enable&&!c.out.speaker_enable);CHECK(c.out.active_routes==SV_LINE);
    CASE("uncalibrated_speaker_rejected");i.speaker_calibrated=false;step(&c,&i,10);CHECK(!sv_set_routes(&c,SV_SPK));
    CASE("clock_fault_latches");i.clocks_good=false;step(&c,&i,10);CHECK(c.state==SV_FAULT);CHECK(!c.out.port_enable);CHECK(!c.out.feed_watchdog);
    CASE("healthy_not_automatic_recovery");i.clocks_good=true;step(&c,&i,150);CHECK(c.state==SV_FAULT);CHECK(sv_ack_fault_local(&c,c.last_tick));CHECK(c.out.active_routes==0);
    CASE("ack_cannot_clear_active_fault");i.external_fault=true;step(&c,&i,10);CHECK(!sv_ack_fault_local(&c,c.last_tick));
    CASE("stale_tick_fault");ready(&c,&i);sv_tick(&c,c.last_tick+101,&i);CHECK(c.faults&SV_F_TIMING);step(&c,&i,200);CHECK(!sv_ack_fault_local(&c,c.last_tick));
    CASE("timer_wrap");sv_init(&c,UINT32_MAX-10,NULL);i=good();sv_tick(&c,5,&i);CHECK(c.state==SV_READY);
    CASE("backwards_clock_rejected");sv_tick(&c,4,&i);CHECK(c.state==SV_FAULT);
    CASE("shutdown_order");ready(&c,&i);CHECK(sv_set_routes(&c,SV_LINE));i.power_interrupt=true;step(&c,&i,10);CHECK(c.state==SV_STOPPING);CHECK(c.out.boot_hold&&!c.out.port_enable);step(&c,&i,50);CHECK(c.state==SV_OFF&&!c.out.boot_hold);
    CASE("null_input_fault");ready(&c,&i);sv_tick(&c,20,NULL);CHECK(c.faults&SV_F_INPUT);
    CASE("pair_requires_physical_action");ready(&c,&i);CHECK(!sv_take_pair_window(&c,c.last_tick));
    CASE("pair_button_long_press");i.bt_button_raw=true;step(&c,&i,1540);CHECK(c.pair_open);CHECK(sv_take_pair_window(&c,c.last_tick));CHECK(!sv_take_pair_window(&c,c.last_tick));
    CASE("held_button_no_rearm");step(&c,&i,61000);CHECK(!c.pair_open);i.bt_button_raw=false;step(&c,&i,40);i.bt_button_raw=true;step(&c,&i,1540);CHECK(c.pair_open);
    CASE("pair_window_expires");step(&c,&i,60000);CHECK(!sv_take_pair_window(&c,c.last_tick));
    CASE("before_usb_config_no_input_request");ready(&c,&i);CHECK(c.out.chg_en1&&c.out.chg_en2);
    CASE("charge_off_without_pack_approval");ready(&c,&i);i.usb_configured=true;i.usb_budget_ma=500;step(&c,&i,10);CHECK(!c.out.charge_allow);CHECK(!c.out.chg_en1&&c.out.chg_en2);
    CASE("qualified_charge_fixture");sv_config cfg={true,true,198,20,50,400};sv_init(&c,0,&cfg);i=good();i.usb_configured=true;i.usb_budget_ma=500;step(&c,&i,10);CHECK(c.out.charge_allow);
    CASE("suspend_stops_input_and_charge");i.usb_suspended=true;step(&c,&i,10);CHECK(c.out.chg_en1&&c.out.chg_en2&&!c.out.charge_allow);i.usb_suspended=false;
    CASE("charge_total_budget");i.board_usb_budget_ma=300;step(&c,&i,10);CHECK(!c.out.charge_allow);i.board_usb_budget_ma=70;
    CASE("unknown_budget_not_zero");i.board_budget_valid=false;step(&c,&i,10);CHECK(!c.out.charge_allow);i.board_budget_valid=true;
    CASE("stale_usb_sample_not_valid");i.usb_measurement_valid=false;step(&c,&i,10);CHECK(!c.out.usb_enable&&!c.out.charge_allow);i.usb_measurement_valid=true;
    CASE("charge_temperature_and_voltage");i.temperature_valid=false;step(&c,&i,10);CHECK(!c.out.charge_allow);i.temperature_valid=true;i.temperature_deci_c=401;step(&c,&i,10);CHECK(!c.out.charge_allow);i.temperature_deci_c=250;i.battery_mv=2900;step(&c,&i,10);CHECK(!c.out.charge_allow);
    CASE("usb_voltage_interlock");i.usb_mv=4400;step(&c,&i,10);CHECK(!c.out.usb_enable&&!c.out.charge_allow);
    CASE("crc_reference");CHECK(sv_crc16((const uint8_t*)"123456789",9)==0x29b1);
    CASE("parser_roundtrip");sv_parser_reset(&p);data[0]=10;n=encode(b,5,65535,data,1);CHECK(parse(&p,b,n,0,&f));CHECK(f.seq==65535&&f.length==1&&f.payload[0]==10);
    CASE("parser_max_payload");n=encode(b,4,0,data,256);CHECK(parse(&p,b,n,0,&f));CHECK(f.length==256);
    CASE("bad_crc_rejected");b[n-1]^=1;CHECK(!parse(&p,b,n,0,&f));sv_parser_reset(&p);
    CASE("partial_deadline");n=encode(b,4,0,data,0);CHECK(!parse(&p,b,5,0,&f));sv_parser_poll(&p,250);CHECK(p.count==0&&p.errors==1);
    CASE("oversize_rejected");b[6]=1;b[7]=1;CHECK(!parse(&p,b,n,260,&f));CHECK(p.count<8);
    CASE("session_auth_and_replay");ready(&c,&i);f=(sv_frame){.type=4,.seq=65535};CHECK(sv_execute(&c,&s,&f,10)==SV_AUTH);CHECK(sv_session_begin_trusted(&s,1));CHECK(sv_execute(&c,&s,&f,10)==SV_OK);CHECK(sv_execute(&c,&s,&f,10)==SV_REPLAY);CHECK(!sv_session_begin_trusted(&s,2));
    CASE("sequence_wrap_and_half_range");f.seq=0;CHECK(sv_execute(&c,&s,&f,10)==SV_OK);f.seq=32768;CHECK(sv_execute(&c,&s,&f,10)==SV_REPLAY);
    CASE("malformed_command_no_seq_consumption");f.seq=1;f.type=1;f.length=1;CHECK(sv_execute(&c,&s,&f,10)==SV_LENGTH);CHECK(s.last_seq==0);f.length=2;f.payload[0]=1;f.payload[1]=0;CHECK(sv_execute(&c,&s,&f,10)==SV_RANGE);f.payload[0]=0;CHECK(sv_execute(&c,&s,&f,10)==SV_OK);
    CASE("unknown_command");f.type=99;CHECK(sv_execute(&c,&s,&f,10)==SV_FRAME);
    CASE("session_disconnect");sv_session_end(&s);CHECK(!s.authorized&&sv_execute(&c,&s,&f,10)==SV_AUTH);
    CASE("parser_random_stream_1m");sv_parser_reset(&p);for(unsigned j=0;j<1000000;j++){sv_parser_byte(&p,(uint8_t)random32(),j/10,&f);CHECK(p.count<=266);}
    CASE("random_control_safety_100k");ready(&c,&i);for(unsigned j=0;j<100000;j++) {
        uint32_t r=random32();i.headphones_raw=(r&1)!=0;i.clocks_good=(r&31)!=0;i.usb_suspended=(r&2)!=0;
        step(&c,&i,10);sv_set_routes(&c,(uint8_t)(r&15));sv_ack_fault_local(&c,c.last_tick);
        if(c.state!=SV_READY)CHECK(c.out.active_routes==0&&!c.out.charge_allow);
        if(i.headphones_raw)CHECK(!c.out.speaker_enable);
        CHECK(!c.out.charge_allow);
    }
    printf("{\"groups\":%u,\"assertions\":%u,\"failed\":0,\"hardwareTests\":0}\n",cases,checks);
    return 0;
}
