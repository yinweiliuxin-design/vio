智能电子小提琴 V22 控制与保护增补
日期：2026-10-02
状态：HOLD。用于审图、主机软件验证与供应商补测，不能直接投板或生产。

从 index.html 查看全部内容；V22-Engineering-Supplement.pdf为本轮增补报告。
旧V21包未覆盖。本轮沿用其结构约束，V16客户端与商家后台未改动。

新增内容
1. USB数据过压隔离候选A26，修正低压ESD路径与模式电阻公差。
2. 充电CE门控、EN1/EN2控制，RISET与ILIM最坏电流计算；默认禁充。
3. 可移植C控制核心与V2协议解析；41组真实主机测试、17项数据检查、100帧跨语言解析比对。
4. 全量逻辑电路图、引脚/网络表、HAL接入约束和工厂补测表。

不是本轮完成的内容
原生EDA和ERC、PCB与DRC、Gerber、贴片坐标、真实焊盘及铜线走径、生产螺丝/扭矩、ARM交叉编译、可烧录镜像、SPICE、实物测试、认证和商店上线均未完成。

复现方法（在本目录打开终端）
node reproduce/build.cjs
$env:SV_CC='已安装的tcc.exe绝对路径'
node reproduce/verify.cjs
node reproduce/render.cjs

verify.cjs当前参数按TinyCC设计。其他编译器需调整参数，不能把未运行的构建视为通过。
编译器采用TinyCC 0.9.27 Windows x64，官方发布：
https://download-mirror.savannah.gnu.org/releases/tinycc/tcc-0.9.27-win64-bin.zip
本次下载归档SHA256：34a721949a2583fdff725312da092fa0f5f1f284b702e6f811c6954714faabb2
此值记录本次HTTPS下载内容，不声称厂商签名认证。工具链未随包分发，不改动系统PATH。
verification/test-control-host.exe是本机测试程序，无网络、无硬件访问；不是设备固件。

数据约定
net-register中的copperPath=null代表未布线；pin-net-register的physicalPad和坐标=null代表未审批。逻辑别名不是实体焊盘。
所有BOM条目仍approved=false；具体采购、封装、供货、工艺和测试需要电子厂审核。
sources/index.json提供原厂链接，部分原厂引脚/名称事实用于候选设计，不能等同于整机通过。

先执行的工厂动作
琴厂填 assembly/factory-checklist.html 的安装区测量与四点木厚；电子厂完成插座脚位通断确认和完整EDA；电池厂提供真实包规格/NTC/保护参数；随后制作工程样板与结构试装件。
未冻结这些数据前，不得为了“能生产”填写虚构螺丝扭矩、元件坐标或测试通过结果。
