const fs=require('node:fs'),path=require('node:path');
const packaged=path.basename(__dirname)==='reproduce';
const root=packaged?path.resolve(__dirname,'..'):path.resolve('outputs/SmartVio-V22-Control-Protection');
const read=f=>JSON.parse(fs.readFileSync(path.join(root,f)));
const write=(f,v)=>fs.writeFileSync(path.join(root,f),typeof v==='string'?v:JSON.stringify(v,null,2));
const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=(x,y,s,size=19,fill='#233b3a')=>`<text x="${x}" y="${y}" fill="${fill}" font-size="${size}">${e(s)}</text>`;
const line=(x,y,a,b)=>`<path d="M${x},${y} L${a},${b}" fill="none" stroke="#376f63" stroke-width="2"/>`;
const rect=(x,y,w,h,fill='#eef4f2')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" stroke="#376f63" stroke-width="2"/>`;
const drawings=[];
function wrap(s,max){let out=[],a='',n=0;for(const c of String(s)){const k=c.charCodeAt(0)>255?2:1;if(n+k>max){out.push(a);a='';n=0;}a+=c;n+=k;}if(a)out.push(a);return out;}
function save(id,title,body,scope='同名网络相连 / 逻辑连接图 / 不是通过ERC的EDA原理图'){
 const file=`drawings/${id}.svg`;
 write(file,`<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1120" viewBox="0 0 1600 1120"><rect width="1600" height="1120" fill="white"/><g font-family="Microsoft YaHei,Arial,sans-serif" letter-spacing="0">${text(45,50,title,27)}${text(45,89,'V22 / HOLD / '+scope,18,'#a04430')}${line(45,110,1555,110)}${body}${line(45,1060,1555,1060)}${text(45,1093,'未完成真实PCB、封装审核、焊接工艺和实物验证；不得直接投板、开模、钻琴体或接电芯。',18,'#a04430')}</g></svg>`);
 drawings.push({id,title,file});
}
const box=(x,y,w,title,subtitle)=>rect(x,y,w,100)+text(x+18,y+33,title,22)+text(x+18,y+72,subtitle,17);
let b=box(65,180,360,'USB-C 数据触点','D+/D-，不是音频模拟口')+box(500,180,420,'A26 / TPD2S703','共模 + 10nH → 过压隔离')+box(1000,180,515,'系统侧 / MCU','USBLC6 → R403/R404 → PA11/12');
b+=line(425,230,500,230)+line(920,230,1000,230);
b+=box(65,405,360,'USB_5V_SAFE','已有eFuse后的电源')+box(500,405,420,'VPWR / VREF','5V受保护电源 / V3D')+box(1000,405,515,'MCU 控制与故障','PE10禁用 / PE9故障低有效');
b+=line(425,455,500,455)+line(710,405,710,280)+line(1000,455,920,455);
const notes=['1. U1501的1/2脚为端口侧，10/9脚为系统侧；不能将低压ESD跨接到端口侧形成旁路。',
'2. MODE=2.20k±1%到地，VREF=3.3V；VPWR低于4.5V时不保证数据通信，软件关闭数据路径。',
'3. EN_N用100k上拉3.3V，复位默认禁用；没有3.3V/5V时仍须核对器件掉电隔离与反灌。',
'4. 该候选不能直接证明保护STM32：短接电源时系统侧仍有瞬态，钳位协调与板级ESD未完成。',
'5. FL1501实体封装脚位尚未批准；本图中的1~4是逻辑脚，不是可以复制下单的PCB焊盘。',
'6. 无PD升压。18V是器件研究上界，不是整机容许插入20V/48V电源的声明。'];
notes.forEach((s,i)=>b+=text(65,650+i*59,s,21));save('E26-flow','E26 / USB数据保护新增路径',b,'工程说明 / 非保护认证');
b=box(65,170,420,'BQ24074 / U501','RISET 4.99k / RILIM 4.42k')+box(600,170,410,'CE禁充逻辑','SYS → 10k → CE；Q1601下拉')+box(1100,170,430,'MCU / PE14','CHARGE_ALLOW → 1k → MOS G');
b+=line(600,220,485,220)+line(1100,220,1010,220);
const rows=[['阶段','EN1','EN2','CE','说明'],['硬件复位','0','0','高','100mA模式；复位窗口及浪涌未验证'],['核心初始化 / 枚举前','1','1','高','暂停从BQ输入取电；空电池启动未实现'],['已配置且授权≥500mA','0','1','高/低','ILIM候选约298~393mA；另核上游耗流'],['USB挂起 / 故障 / 关机','1','1','高','先禁充、静音；不等于电池物理断开']];
let yy=340;for(const r of rows){b+=rect(65,yy,1470,68,r===rows[0]?'#e1ece8':'#fff');[85,510,610,710,820].forEach((xx,i)=>b+=text(xx,yy+42,r[i],i===4?20:21));yy+=68;}
['RISET解析估算158~197.4mA；输入ILIM解析估算298~393.1mA。实际充电可能被DPPM/热限流降低。',
'只有批准电池包、温度有效、USB采样有效、功耗预算有效且总预算≤295mA，C核心才允许禁充解除。',
'未知预算不是0；工厂默认配置全零，充电保持关闭。TMR/ITERM有意悬空，采用内部默认，不接地。',
'缺项仍包括：NTC真实型号/标定、USB电压采集电路、启动复位窗口、死电池恢复、热与单故障测试。'].forEach((s,i)=>b+=text(65,760+i*63,s,20));
save('E27-sequence','E27 / 充电使能与USB输入控制',b,'电路候选与软件状态；不是充电安全验收');
b=box(80,170,400,'BOOT / 默认全部静音','先置BOOT_OK；实际启动须<400ms')+box(600,170,400,'READY / 条件就绪','电源、时钟、codec状态均正常')+box(1120,170,390,'路由请求','耳机 / LINE / 喇叭 / BT');
b+=line(480,220,600,220)+line(1000,220,1120,220)+box(80,480,400,'FAULT / 锁存','静音、禁充、停止喂看门狗')+box(600,480,400,'本地复核','健康持续100ms且故障允许清除')+box(1120,480,390,'STOPPING → OFF','先静音；50ms研究延时再释放电源');
b+=line(800,270,800,380)+line(800,380,280,380)+line(280,380,280,480)+line(480,530,600,530);
['耳机原始插拔边沿立即取消耳机/喇叭路由；30ms消抖后需重新选择。拔出耳机不自动外放。',
'BT按键消抖30ms、长按1.5s打开60s一次性配对窗口；通信会话仍须真实认证链路授权。',
'主循环允许间隔≤100ms；超时/时间倒退锁存故障。C函数不能替代独立硬件静音或看门狗。',
'41组主机C测试、17项数据检查、100帧跨语言协议比对通过；没有在STM32板上执行。',
'未实现：HAL、USB声卡、DMA/cache、音频DSP迁移、RF驱动、FX/MODE/MIX按键动作及滚轮ADC。'].forEach((s,i)=>b+=text(65,730+i*59,s,20));
save('F01-state','F01 / 可移植控制核心与联调边界',b,'Windows本机C测试；非可烧录固件');
for(const sh of read('electrical/circuits.json')){
 const pieces=[];for(const c of sh.components)for(let j=0;j<c.pins.length;j+=17)pieces.push({...c,pins:c.pins.slice(j,j+17),continued:j>0});
 let pg=1,body='',col=0,Y=153;
 const flush=()=>{if(body){save(`${sh.id}-${String(pg++).padStart(2,'0')}`,`${sh.id} / ${sh.title}`,body);body='';col=0;Y=153;}};
 for(const c of pieces){
  const labels=wrap(c.ref+' | '+c.value+(c.continued?' [continued]':''),66),head=26*labels.length+10,h=head+(c.pins.length===2?91:36*c.pins.length+25);
  if(Y+h>1030){if(col===0){col=1;Y=153;}else flush();}
  const X=50+col*790;labels.forEach((s,j)=>body+=text(X,Y+j*26,s,16));const cy=Y+head;
  if(c.pins.length===2){body+=line(X+10,cy+20,X+260,cy+20)+line(X+310,cy+20,X+680,cy+20);
   if(c.type==='C')body+=line(X+273,cy+4,X+273,cy+36)+line(X+297,cy+4,X+297,cy+36)+line(X+260,cy+20,X+273,cy+20)+line(X+297,cy+20,X+310,cy+20);
   else body+=rect(X+260,cy+8,50,24,'white')+(c.type==='R'?'':text(X+273,cy+26,c.type,12));
   body+=text(X+10,cy+54,c.pins[0].number+': '+(c.pins[0].net||'NC'),15)+text(X+310,cy+77,c.pins[1].number+': '+(c.pins[1].net||'NC'),15);
  }else{body+=rect(X+5,cy-6,260,36*c.pins.length+8);c.pins.forEach((p,j)=>{const yy=cy+20+j*36;body+=text(X+12,yy,p.name,12)+line(X+265,yy-5,X+345,yy-5)+text(X+285,yy-13,p.number,12)+text(X+360,yy,p.net||'NC (review required)',14);});}
  Y+=h+15;
 }flush();
}
write('verification/drawings.json',drawings);
const tests=read('verification/test-results.json'),issues=read('verification/backlog.json'),changes=read('electrical/changes.json');
const table=(head,rows)=>`<div class="scroll"><table><thead><tr>${head.map(s=>`<th>${e(s)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(s=>`<td>${e(s)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
let html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>V22 控制与保护增补</title><style>*{box-sizing:border-box}body{margin:0;background:#fff;color:#263c37;font:16px/1.7 "Microsoft YaHei",Arial,sans-serif;letter-spacing:0}header,main{max-width:1200px;margin:auto;padding:24px}header{border-bottom:3px solid #267866}h1{font-size:28px;line-height:1.4}h2{font-size:22px;margin-top:38px}h3{font-size:18px}a{color:#166c57;overflow-wrap:anywhere}nav{display:flex;gap:20px;flex-wrap:wrap}.hold{color:#a04430;font-weight:bold}.facts{border-left:4px solid #267866;padding:12px 20px;background:#f3f6f5}img{display:block;max-width:100%;height:auto}figure{margin:18px 0}figcaption{font-size:14px}table{border-collapse:collapse;width:100%;min-width:600px;font-size:14px}th,td{border:1px solid #c9d9d1;padding:10px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#eaf2ef}.scroll{overflow:auto}details{border-bottom:1px solid #c9d9d1;padding:14px 0}summary{cursor:pointer;font-weight:bold}code{font-size:14px;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f6f5;padding:15px}footer{max-width:1200px;margin:auto;padding:24px;border-top:1px solid #c9d9d1}@media(max-width:600px){header,main{padding:16px}h1{font-size:23px}}</style><header><div class="hold">V22 · 工程增补 · 尚不能直接生产</div><h1>智能电子小提琴：控制核心与接口保护</h1><p>保留 V21 外观与结构基线；继续闭合电路和联调逻辑，不修改原腔和安装要求。</p><nav><a href="#progress">本轮进展</a><a href="#drawings">图纸</a><a href="#firmware">控制程序</a><a href="#factory">工厂补测</a><a href="#pending">待完成</a><a href="V22-Engineering-Supplement.pdf">增补报告 PDF</a></nav></header><main><section class="facts"><strong>实际验证范围</strong><p>${tests.c.groups} 组 C 主机测试，${tests.dataChecks.length} 项数据/连接检查，${tests.interopFrames} 帧 V21→C 通信解析比对通过。硬件测试 0 项；未执行 ARM 交叉编译、SPICE、ERC、DRC。重复断言总数不等于独立硬件测试数量。</p><p>251 个物料候选、872 条逻辑引脚记录、183 个网络；焊盘、坐标和铜线走径仍未批准。不能将此包改名为投产图。</p></section><h2 id="progress">01 / 新增与修订</h2>`;
html+=table(['编号','本轮动作','完成范围','未闭合'],changes.map(x=>[x.id,x.change,x.closed,x.open]));
html+='<p>补充：R1501改为2.20k±1%；R502改为4.42k±1%并使用ILIM模式；未知功耗预算或无效USB测量不会当作0或正常值放行。TMR/ITERM标注为有意不接，保留内部默认定时与终止功能。</p>';
html+='<h2 id="drawings">02 / 全量逻辑电路图与增补说明</h2>';
for(const d of drawings.slice(0,3))html+=`<figure><a href="${d.file}"><img src="${d.file}" alt="${e(d.title)}"></a><figcaption>${e(d.title)}</figcaption></figure>`;
for(const sh of read('electrical/circuits.json')){html+=`<details><summary>${e(sh.id+' / '+sh.title)}</summary><ul>${sh.notes.map(n=>`<li>${e(n)}</li>`).join('')}</ul>`;for(const d of drawings.filter(x=>x.id.startsWith(sh.id+'-')))html+=`<a href="${d.file}"><img loading="lazy" src="${d.file}" alt="${e(d.title)}"></a>`;html+='</details>';}
html+=`<h2 id="firmware">03 / 可移植 C 核心</h2><p>包含开关机状态、插拔消抖、故障锁存、一次性配对窗口、充电许可和V2帧解析；没有芯片驱动、音频处理实现或可烧录镜像。</p><p><a href="firmware/sv_control.c">核心 C 源码</a> · <a href="firmware/sv_control.h">数据与接口定义</a> · <a href="firmware/test_control.c">测试代码</a> · <a href="firmware/HAL-integration.txt">HAL 接入顺序</a> · <a href="verification/test-results.json">真实测试记录</a></p>`;
html+=table(['软件输出/输入','STM32 GPIO / 物理脚','网络','接入约束'],read('firmware/pin-contract.json').map(x=>[x.software,x.gpio+' / '+x.pin,x.net,x.note]));
html+=`<p>通信授权函数仅接受已由可信连接层验证的会话。CRC和序号不是加密认证；BLE配对、密钥保存、权限绑定与固件签名仍待实现。</p><h2 id="factory">04 / 工厂交接与补测</h2><p><a href="assembly/factory-checklist.html">可打印补测/签审表</a> · <a href="assembly/jack-continuity-procedure.json">插座通断识别步骤</a> · <a href="mechanical/requirements.json">既定尺寸与待测项</a> · <a href="electrical/pin-net-register.json">全量引脚网络表</a></p><p>旧腔78×47×22mm、近端距琴尾金属基准145mm不变；不新增开腔。上盖四孔固定琴体，上下壳只卡扣；外凸≤5mm（调节滚轮除外），总厚≤25mm。原拾音器与原穿线孔保留。</p><figure><img src="reference/appearance-reference.png" alt="沿用外观参考，非实物样机"><figcaption>沿用的外观参考，未重新生成为实物；图像不替代尺寸与结构验收。</figcaption></figure><h2 id="pending">05 / 仍需完成</h2>`;
html+=table(['优先级','项目','剩余工作','责任方','状态'],issues.map(x=>[x.priority,x.area,x.remaining,x.owner,x.status]));
html+='<h2>06 / 原厂依据与复现</h2><ul>'+read('sources/index.json').map(s=>`<li><a href="${e(s.url)}">${e(s.id)}</a>：${e(s.scope)}</li>`).join('')+'</ul><p>编译、运行与数据检查命令见 <a href="README.txt">README.txt</a>。软件默认禁充，不允许为演示效果直接解除电池或喇叭标定限制。</p></main><footer>2026-10-02 · 原包保留 · V16客户端/商家后台本轮未修改 · 仅用于工程审图、软件逻辑验证和供应商补测。</footer></html>';
write('index.html',html);
if(!packaged)fs.copyFileSync(__filename,path.join(root,'reproduce/render.cjs'));
console.log(JSON.stringify({drawings:drawings.length}));
