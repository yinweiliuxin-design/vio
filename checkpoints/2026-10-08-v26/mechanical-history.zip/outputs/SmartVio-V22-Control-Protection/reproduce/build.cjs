const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const packaged=path.basename(__dirname)==='reproduce';
const root=packaged?path.resolve(__dirname,'..'):path.resolve('outputs/SmartVio-V22-Control-Protection');
const prior=path.resolve('outputs/SmartVio-V21-Corrected-Design');
for(const d of ['electrical','verification','drawings','assembly','sources','reproduce','firmware','reference','mechanical'])fs.mkdirSync(path.join(root,d),{recursive:true});
const write=(p,x)=>fs.writeFileSync(path.join(root,p),typeof x==='string'?x:JSON.stringify(x,null,2));
const baseline=path.join(root,'reproduce/v21-circuits.json');
if(!fs.existsSync(baseline))fs.copyFileSync(path.join(prior,'electrical/circuits.json'),baseline);
const circuits=JSON.parse(fs.readFileSync(baseline));
const find=ref=>circuits.flatMap(s=>s.components).find(c=>c.ref===ref);
const pin=(ref,p)=>find(ref).pins.find(x=>x.number===String(p));
const add=(sheet,ref,type,value,pins,mpn=null,pkg=null,source=null)=>{
 const c={ref,type,value,mpn,package:pkg,source,pins:pins.map(([number,name,net])=>({number:String(number),name,net})),release:'HOLD',verificationScope:'Candidate connectivity; no ERC, PCB or hardware validation'};
 circuits.find(s=>s.id===sheet).components.push(c);return c;
};
const passive=(sh,ref,v,a,b)=>add(sh,ref,ref[0],v,[[1,'1',a],[2,'2',b]],null,'0603 candidate; exact part and derating pending');
function gpio(n,name,net){Object.assign(pin('U801S',n),{name,net});}
circuits.push({id:'A26',title:'USB数据持续过压隔离候选',notes:[
 'TPD2S703QDGSRQ1 / DGS10；Mode0，MODE经2.20k±1%接地，VREF=V3D。按6.5推荐表2..2.6k取中间值；9.2.2.2.1还允许直接接地，采用此电阻方案避免边界歧义。',
 '数据线端口侧与MCU侧分网；原USBLC6移到系统侧，避免持续高压从其二极管绕过隔离开关灌入低压电源。',
 '支持范围按原厂18V上限研究，不宣称耐受20V/48V或所有USB-PD误接。VPWR取USB_5V_SAFE；低于4.5V不保证数据功能。',
 '原厂ESD测试网络含共模电感及10nH串联电感。候选FL/L未选定，不能直接用器件ESD额定代替整机结果。',
 '系统侧故障瞬态可高于MCU额定；必须验证钳位配合、反灌与信号完整性。该项仍未关闭。'
 ],components:[]});
add('A26','U1501','IC','TPD2S703QDGSRQ1',[
 [1,'VD_MINUS','USB_DM_OVP_IN'],[2,'VD_PLUS','USB_DP_OVP_IN'],[3,'GND','GND'],[4,'FLT_N','USB_DATA_FAULT_N'],
 [5,'EN_N','USB_DATA_DISABLE'],[6,'MODE','USB_OVP_MODE'],[7,'VPWR','USB_5V_SAFE'],[8,'VREF','V3D'],
 [9,'D_PLUS','USB_DP_SYS'],[10,'D_MINUS','USB_DM_SYS']
],'TPD2S703QDGSRQ1','DGS10 VSSOP; 0.5mm pitch; land pattern unapproved','TPD2S703');
add('A26','FL1501','CMC','90 ohm at 100MHz candidate',[[1,'DP_IN','USB_DP_CONN'],[2,'DP_OUT','USB_DP_CMC'],[3,'DM_IN','USB_DM_CONN'],[4,'DM_OUT','USB_DM_CMC']],null,'MPN/pin numbers are placeholders; NOT a released footprint',null);
passive('A26','L1501','10nH matched candidate','USB_DP_CMC','USB_DP_OVP_IN');
passive('A26','L1502','10nH matched candidate','USB_DM_CMC','USB_DM_OVP_IN');
passive('A26','R1501','2.20k 1%','USB_OVP_MODE','GND');
passive('A26','R1502','100k','USB_DATA_DISABLE','V3D');
passive('A26','R1503','100k','USB_DATA_FAULT_N','V3D');
passive('A26','C1501','2.2uF 16V X7R; effective 1..10uF','USB_5V_SAFE','GND');
passive('A26','C1502','1uF 10V X7R; effective 0.3..3uF','V3D','GND');
pin('R403',1).net='USB_DP_SYS';pin('R404',1).net='USB_DM_SYS';
for(const n of [1,6])pin('U401',n).net='USB_DP_SYS';
for(const n of [3,4])pin('U401',n).net='USB_DM_SYS';
gpio(39,'PE9_USB_DATA_FAULT_N','USB_DATA_FAULT_N');
gpio(40,'PE10_USB_DATA_DISABLE','USB_DATA_DISABLE');
circuits.find(s=>s.id==='A13').notes=circuits.find(s=>s.id==='A13').notes.map(n=>n.includes('USBLC6-2SC6靠近')?'V22：USBLC6位于A26的系统侧，R403/R404为PHY端0R调试位；端口侧不得旁路OVP回灌低压电源。':n.includes('D+/D-持续过压')?'V22：数据路径加入A26持续过压隔离候选，系统侧残余瞬态和板级ESD未验证。':n);
circuits.find(s=>s.id==='A25').notes=circuits.find(s=>s.id==='A25').notes.map(n=>n.includes('D+/D-持续')?'SBU不用；数据隔离候选见A26，过压/ESD不等于整机通过。':n);

circuits.push({id:'A27',title:'充电授权与输入电流控制',notes:[
 'CE经10k上拉SYS，PMV30UN2低侧开漏拉低使能；MCU复位或未批准电池时保持禁充。',
 'EN1/EN2通过各1k接3.3V GPIO，保留对地下拉；不能将5V状态线直接接MCU。',
 '硬件复位缺省EN1/EN2=00。C核心初始化后置11挂起；这两种状态不同，启动/看门狗/USB挂起电流尚未验证。',
 'RISET改4.99k±1%：设计计算约158..197.4mA，不是实测；电池包尚未选定，仍不得打开充电。',
 '固件不选USB500：配置完成且授权500mA后使用EN1/EN2=01的ILIM模式；R502=4.42k±1%，输入限流约298..393mA；上游耗流仍须实测。',
 'C核心在枚举前请求11挂起，不宣称空电池启动已实现；硬件复位00窗口与总线浪涌仍待修订/测试。',
 '电池耗尽自恢复、关机充电、NTC采集与许可门禁、预充和完整硬件故障联锁尚未完成。'
],components:[]});
find('R501').value='4.99k 1% / nominal 178mA; worst approx197.4mA';
find('R502').value='4.42k 1% / ILIM approx298..393mA';
pin('U501',14).noConnectReason='Intentional NC: internal default safety timers; not a ground connection. Battery matching pending.';
pin('U501',15).noConnectReason='Intentional NC: internal default termination; battery matching pending.';
pin('R503',1).net='SYS';
add('A27','Q1601','MOS','PMV30UN2',[[1,'G','CHARGE_GATE'],[2,'S','GND'],[3,'D','CHARGE_DISABLE']],'PMV30UN2','SOT23; pin1 G / pin2 S / pin3 D','PMV30UN2');
passive('A27','R1601','1k','CHARGE_ALLOW','CHARGE_GATE');
passive('A27','R1602','100k','CHARGE_GATE','GND');
passive('A27','R1603','1k','CHG_EN1_MCU','CHG_EN1');
passive('A27','R1604','1k','CHG_EN2_MCU','CHG_EN2');
gpio(42,'PE12_CHG_EN1','CHG_EN1_MCU');gpio(43,'PE13_CHG_EN2','CHG_EN2_MCU');gpio(44,'PE14_CHARGE_ALLOW','CHARGE_ALLOW');
circuits.find(s=>s.id==='A14').notes=circuits.find(s=>s.id==='A14').notes.map(n=>n.includes('默认禁充')||n.includes('充电授权电路')?'V22：充电授权候选见A27，电池包、NTC、死电池启动和板级充电测试仍未闭合。':n);
circuits.find(s=>s.id==='A14').notes=circuits.find(s=>s.id==='A14').notes.map(n=>n.includes('7.5k')?'V22：R502=4.42k；仅EN1/EN2=01时控制限流。硬件复位00的USB100窗口尚未验证。':n);
write('electrical/circuits.json',circuits);
const rows=circuits.flatMap(s=>s.components.flatMap(c=>c.pins.map(p=>({sheet:s.id,ref:c.ref.startsWith('U801')?'U801':c.ref,unit:c.ref,pin:p.number,function:p.name,net:p.net,noConnectReason:p.noConnectReason||null,physicalPad:null,padXmm:null,padYmm:null,solderProcess:null,status:'UNRELEASED'}))));
write('electrical/pin-net-register.json',rows);
const netMap={};for(const p of rows)if(p.net)(netMap[p.net]??=[]).push({ref:p.ref,pin:p.pin});
write('electrical/net-register.json',Object.entries(netMap).map(([net,endpoints])=>({net,endpoints,copperPath:null,status:'UNROUTED'})));
const byRef={};for(const s of circuits)for(const c of s.components){const ref=c.ref.startsWith('U801')?'U801':c.ref;byRef[ref]??={ref,mpn:c.mpn,value:c.value,package:c.package,approved:false,placement:null};}
write('electrical/component-register.json',Object.values(byRef));
write('electrical/changes.json',[
 {id:'E01',change:'新增A26数据过压隔离；USBLC6移到系统侧',closed:'逻辑连接与脚位候选',open:'低压钳位配合/ESD/USB时序/实板'},
 {id:'E02',change:'新增A27充电CE控制及EN1/EN2 GPIO',closed:'控制接口与默认禁充电路候选',open:'死电池恢复/NTC/预充/关机充电/温升'},
 {id:'E03',change:'RISET 4.42k改4.99k，补最坏电流计算',closed:'规格公差算术',open:'真实电池包和安全验证'},
 {id:'F01',change:'新增C控制与V2协议解析',closed:'以本轮编译报告为准',open:'MCU启动文件/驱动/烧录/无线音频/联调'}
]);
write('electrical/calculations.json',{method:'Analytical only; not SPICE or measurement',iset:{resistance:4990,tolerance:0.01,kmin:797,ktyp:890,kmax:975,minMa:797/(4990*1.01)*1000,typMa:890/4990*1000,maxMa:975/(4990*.99)*1000},ilim:{resistance:4420,tolerance:.01,kmin:1330,ktyp:1525,kmax:1720,minMa:1330/(4420*1.01)*1000,typMa:1525/4420*1000,maxMa:1720/(4420*.99)*1000,firmwareChargeBudgetMa:295,notUSBcertified:true},ce:{sysMaxV:4.5,pullup:10000,maxPullupMa:.45,warning:'Gate drive, leakage, discharge time and GPIO boot sequencing require measurement'},usb:{preferredTestSupply:'5.00V current-limited laboratory supply',dataProtectionResearchMaxV:18,wholeProductCertified:false}});
write('firmware/pin-contract.json',[
 [37,'PE7','PWR_BOOT_OK','boot_hold','HIGH within 400ms minimum LTC window; board boot unverified'],
 [22,'PA0','DAC_UNMUTE','dac_unmute','LOW before clock/codec setup'],
 [23,'PA1','HP_EN_VALIDATED','hp_enable','LOW during insertion/removal'],
 [24,'PA2','SPK_ENABLE','speaker_enable','LOW until speaker calibration'],
 [25,'PA3','PORT_ENABLE','port_enable','LOW first on fault; analog latency unmeasured'],
 [40,'PE10','USB_DATA_DISABLE','!usb_enable','HIGH default; active-low U1501.EN'],
 [42,'PE12','CHG_EN1_MCU','chg_en1','initialize HIGH; hardware reset pulldown LOW'],
 [43,'PE13','CHG_EN2_MCU','chg_en2','initialize HIGH; hardware reset pulldown LOW'],
 [44,'PE14','CHARGE_ALLOW','charge_allow','LOW always until factory config approved'],
 [39,'PE9','USB_DATA_FAULT_N','usb_data_fault','input inverted; no test can assume high means rail valid'],
 [38,'PE8','CC_FAULT_N','cc_fault','input inverted'],[28,'PA4','HP_DETECT_GPIO','headphones_raw','physical jack detect polarity still unresolved'],
 [15,'PC0','KEY_BT','bt_button_raw','physical button polarity/debounce adaptation'],[32,'PC4','KEY_PWR','power_interrupt','LTC INT_N; not raw push button']
].map(([pin,gpio,net,software,note])=>({pin,gpio,net,software,note,hardwareVerified:false})));
write('assembly/jack-continuity-procedure.json',{
 status:'NOT EXECUTED; no numeric switch pin assigned',part:'Lumberg 1503 18 candidate',
 steps:['只用未通电且脱离主板的插座试样，照片标记顶视与焊接侧。','记录每个实体脚的编号、坐标和照片；不把焊接侧图直接镜像到顶视。','用标准3.5mm TRS裸尾测试插头确认TIP/RING/SLEEVE，每路单独通断。','空插与全插各测全部脚对；区分音频常闭触点与独立机械检测。','测试半插、慢插、3.5mm TS和TRRS机械兼容；TRRS不作为话筒功能。','耳机检测必须确定独立检测触点，不能把音频TIP/RING直接接GPIO。','双人复核原厂图中6/8标注差异；结果未关闭不得发插座封装/Gerber。'],
 results:[],acceptance:{contactMapSigned:false,detectPolaritySigned:false,bodyStepMatched:false}
});
write('sources/index.json',[
 ['TPD2S703','https://www.ti.com/lit/ds/symlink/tpd2s703-q1.pdf','Mode0 pin map; operating ranges; ESD application caveat'],
 ['BQ24074','https://www.ti.com/lit/ds/symlink/bq24072.pdf','CE/EN states and ISET tolerance'],
 ['PMV30UN2','https://assets.nexperia.com/documents/data-sheet/PMV30UN2.pdf','SOT23 pins and low-voltage gate drive'],
 ['STM32','https://www.st.com/resource/en/datasheet/stm32h743vi.pdf','LQFP100 GPIO candidate assignments'],
 ['JACK','https://downloads.lumberg.com/datenblaetter/en/1503_18.pdf','Switch pin ambiguity remains; not newly resolved'],
 ['TCC','https://bellard.org/tcc/','Portable host C compiler; not an ARM board toolchain']
].map(([id,url,scope])=>({id,url,scope,date:'2026-10-02',wholeDeviceApproved:false})));
write('verification/backlog.json',[
 ['P0','USB保护','A26候选补齐；残余尖峰可能超MCU额定；需钳位协调与ESD网络','EE + EMC实验室','未实测'],
 ['P0','电池与充电','型号/尺寸/保护板/NTC/容量；死电池自恢复和关机充电仍缺','电池厂 + EE','未完成'],
 ['P0','音频口','6/8脚歧义未消除；不能发布封装；直流误接与硬件失时钟静音未闭合','连接器供应商 + EE','未完成'],
 ['P0','PCB','原生EDA全图、审核封装、板框/叠层、布线、ERC/DRC、Gerber、贴片坐标','EE + PCB厂','未完成'],
 ['P0','结构','安装区曲率、孔处木厚、旧孔位置；螺丝长度/扭矩与卡扣试样','琴厂 + ME','未完成'],
 ['P0','喇叭','薄型候选声压、频响、回授啸叫、振膜净空、薄盖强度','声学 + ME','未完成'],
 ['P1','固件','本轮可移植控制核心；HAL、USB声卡、DMA/cache、BT源端/配对、升级仍缺','固件工程','以编译测试报告为准'],
 ['P1','产品应用','V16客户端/商家后台未在本轮改动；正式支付/视频转码/应用市场上线未完成','软件 + 运营','保留原任务'],
 ['P1','认证与试产','EVT/DVT/PVT及英德美日整机合规须按实际BOM开展','工厂 + 合规实验室','未执行']
].map(([priority,area,remaining,owner,status])=>({priority,area,remaining,owner,status})));
write('verification/scope.json',{revision:'V22',release:'HOLD',hardwareTests:0,edaERC:false,pcbDRC:false,spice:false,flashableFirmware:false,notes:['Native C compilation is not target execution.','No physical fit, solder process or copper path is approved.','V21 remains the mechanical baseline. V16 application not modified.']});
if(!packaged){
 fs.copyFileSync(path.join(prior,'reference/appearance-reference.png'),path.join(root,'reference/appearance-reference.png'));
 fs.copyFileSync(path.join(prior,'mechanical/requirements.json'),path.join(root,'mechanical/requirements.json'));
 fs.copyFileSync(path.join(prior,'reproduce/model.cjs'),path.join(root,'reproduce/v21-protocol-model.cjs'));
 fs.copyFileSync(__filename,path.join(root,'reproduce/build.cjs'));
}
console.log(JSON.stringify({components:Object.keys(byRef).length,pins:rows.length,nets:Object.keys(netMap).length,release:'HOLD'}));
