import json
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4, A3, landscape
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from pypdf import PdfReader

packaged_root = Path(__file__).resolve().parent.parent
root = packaged_root if (packaged_root/'electrical/circuits.json').exists() else Path('outputs/SmartVio-V22-Control-Protection').resolve()
read = lambda p: json.loads((root / p).read_text(encoding='utf-8'))
pdfmetrics.registerFont(TTFont('YaHei', 'C:/Windows/Fonts/msyh.ttc', subfontIndex=0))
styles = {k: ParagraphStyle(k, fontName='YaHei', fontSize=n, leading=l, wordWrap='CJK', textColor=HexColor('#243b36')) for k,n,l in [('body',10,16),('small',8,12),('title',21,29),('sub',12,19)]}
out = root / 'V22-Engineering-Supplement.pdf'
c = canvas.Canvas(str(out), pagesize=A4)
c.setTitle('智能电子小提琴 V22 控制核心与保护电路增补')
number = 0
layout = []
def para(s,x,y,w,kind='body'):
    p=Paragraph(escape(str(s)).replace('\n','<br/>'),styles[kind]); _,h=p.wrap(w,10000);p.drawOn(c,x,y-h);return y-h
def start(title,size=A4):
    global number
    number+=1;w,h=size;c.setPageSize(size);c.setFillColor(HexColor('#237a61'));c.rect(32,h-38,w-64,3,fill=1,stroke=0)
    c.setFont('YaHei',8);c.drawString(32,h-24,'SmartVio V22 | 2026-10-02 | ENGINEERING SUPPLEMENT | HOLD')
    c.setFillColor(HexColor('#a04430'));c.drawString(32,23,'不可直接生产 / 主机测试不等于硬件验证');c.drawRightString(w-32,23,str(number))
    return w,h,para(title,32,h-53,w-64,'title')-14
def finish(y=60):
    assert y>=45,(number,y)
    layout.append({'page':number,'bottom':y});c.showPage()
def prose(title,items):
    w,h,y=start(title)
    for head,body in items:
        y=para(head,32,y,w-64,'sub')-3;y=para(body,32,y,w-64)-17
    finish(y)
def table(title,headers,rows,widths,lead=None):
    w,h,y=start(title,landscape(A4))
    if lead:y=para(lead,32,y,w-64,'small')-12
    data=[[Paragraph(escape(str(v)),styles['small']) for v in r] for r in [headers]+rows]
    t=Table(data,colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#e8f1ed')),('GRID',(0,0),(-1,-1),.4,HexColor('#b8ccc2')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8)]))
    _,th=t.wrap(w-64,y-45);assert y-th>=45,(title,y-th);t.drawOn(c,32,y-th);finish(y-th)
def drawing(id):
    d=next(d for d in read('verification/drawings.json') if d['id']==id)
    w,h,y=start(d['title'],landscape(A3));iw=w-64;ih=iw*1120/1600
    if ih>y-45:ih=y-45;iw=ih*1600/1120
    c.drawImage(str(root/d['file'].replace('.svg','.png')),(w-iw)/2,y-ih,width=iw,height=ih);finish(y-ih)
t=read('verification/test-results.json')
prose('V22 未完成工作增补',[
 ('本轮实际推进','补入USB数据持续过压隔离候选、充电CE与输入限流控制；编写并实际编译运行可移植C控制核心。重新生成42张逻辑电路和说明图，并提供工厂补测表。V21原包保留，外观/结构约束未改。'),
 ('测试结果',f'{t["c"]["groups"]}组C主机回归、{len(t["dataChecks"])}项数据/连接检查、100帧跨语言解析比对通过。含100万随机输入字节和10万轮控制扰动；累计断言{t["c"]["assertions"]}次，不代表同数量的独立测试。硬件测试0项。'),
 ('修复的具体问题','模式电阻从边界取值改为2.20k±1%；USB低压ESD移到隔离后的系统侧；CE上拉改为SYS；充电电流与USB输入电流分开预算；未知功耗/失效采样不能当作0或正常值放行。'),
 ('交付边界','251个物料候选、872条逻辑引脚记录、183个网络。没有原生EDA、PCB铜线、已批准封装、Gerber或焊接工艺。C核心不是可烧录固件；未做ARM交叉编译、SPICE、ERC、DRC或实物测试。'),
 ('工厂如何使用','先按assembly/factory-checklist.html执行测量/审图并提交证据；完成物料、结构与EDA签审后才做工程试板和EVT。不得直接把本包用于批量投板、开模、在琴体钻孔或接裸电芯。')])
table('01 / 本轮电气修订', ['项目','新增设计','计算或检查','仍需完成'],[
 ['USB数据保护','U1501 TPD2S703QDGSRQ1；DGS10；端口/系统分网','MODE电阻2.20k±1%，约2.178~2.222k；没有依靠原ESD直接承受持续高压','残余瞬态与MCU钳位协调、CMC实体脚位、USB信号质量与板级ESD'],
 ['充电授权','Q1601 PMV30UN2；SYS上拉CE；门极下拉','复位/未批准电池时禁充；MOS物理1/2/3对应G/S/D','驱动与漏电、NTC、断短路、硬件联锁、关机充电'],
 ['电流设定','RISET=4.99k±1%；RILIM=4.42k±1%','充电解析约158~197.4mA；输入ILIM约298~393.1mA；均非实测','真实电池允许电流、总线负载、压降与热预算'],
 ['输入模式','MCU核心枚举前/故障为11；获500mA授权后01','不选择USB500档；预算有效且总量≤295mA才考虑解除禁充','硬件复位00仍存在；死电池恢复、USB挂起总电流与浪涌'],
 ['NC说明','TMR/ITERM有意不接，使用内部默认','区别“按原厂可悬空”与“漏连引脚”','内部默认时间/终止阈值是否匹配最终电池']
 ],[100,245,230,202],lead='依据：TI TPD2S703-Q1 6.5/9.2、BQ2407x 7/8/9.3；Nexperia PMV30UN2引脚/电气表。完整链接见末页。')
for d in ['E26-flow','A26-01','E27-sequence','A27-01','F01-state']:drawing(d)
prose('02 / 软件接入与真实限制',[
 ('已编译的代码','firmware/sv_control.c / .h为C99无动态分配控制核心；test_control.c为主机测试。编译器TinyCC 0.9.27，Windows x64；编译日志、源码哈希和测试记录均保留在verification。'),
 ('实现的逻辑','默认静音、启动超时、时钟/电源故障锁存、本地确认恢复、耳机边沿禁外放、30ms消抖、BT长按配对窗口、USB状态和充电许可、V2分片帧解析、CRC及会话内序号校验。'),
 ('不能跳过的HAL','真实GPIO、ADC电压/NTC采集、codec健康、独立看门狗、DMA/cache、静音斜坡和电源启动时序仍需实现。软件布尔量必须来自真实状态，不得复制测试中的good()夹具。BOOT_OK的400ms要求需上板示波器验证。'),
 ('通信不是认证','授权接口只接受已经由连接层认证的会话。CRC/序号不是加密认证；BLE绑定、密钥、A2DP源端、状态回包、ACK及签名升级尚未实现。BT按钮通过不等于蓝牙音响已连接。'),
 ('音乐与客户端未闭合','FX/MODE/MIX按键动作、三滚轮ADC、音频DSP迁移、校音算法、USB声卡及实际低延迟演奏尚未完成。本轮未修改V16客户端、视频社区、商城或商家后台，不宣称其完成。')])
prose('03 / 结构、旧拾音器与工厂前置条件',[
 ('不变的约束','旧腔78×47×22mm；琴尾金属基准向琴头145~223mm为旧腔纵向区间。禁止新增/加深琴体腔；原拾音器与穿线孔保留。上盖四螺丝接琴体，上下壳仅卡扣。'),
 ('候选包络','上盖148×49位于X110~258；浅框140×43；下沉舱76×43×18。非滚轮外凸≤5mm；整体≤25mm。名义几何和薄喇叭4.65mm层厚预算不是实体试装通过。'),
 ('无法代填的数据','安装区净宽和曲率、四点木厚、旧孔、腔体圆角/斜度、材料公差、卡扣参数、螺丝底孔/长度/扭矩必须实测/试样确认。“可以生产”不等于已提交这些数值。'),
 ('旧拾音连接','保留C07内部拾音线，经JPU候选接高阻前置；先查屏蔽、通断和线长。不得接48V、话筒偏置或电池电压，也不得直接接MCU ADC。拾音正反线和连接器实体料号仍待确认。'),
 ('工厂表格','assembly/factory-checklist.html含9项结构测量与13项电子/功能测试工作单，结果为空。插座DA/DB不是正式焊盘；工厂须用未通电插座完成开关/音频通断映射再建封装。')])
issues=read('verification/backlog.json')
for offset in [0,5]:
    table('04 / 尚未关闭的交付事项'+('（续）' if offset else ''),['优先级','项目','剩余工作','责任方'],[[x['priority'],x['area'],x['remaining'],x['owner']] for x in issues[offset:offset+5]],[60,110,440,167])
prose('05 / 文件索引与原厂依据',[
 ('查看与复现','index.html为全量浏览入口；drawings包含42张SVG/PNG。electrical保存全量候选电路/物料/网络；firmware保存C源码；reproduce包含生成与测试脚本。README列出复现命令。'),
 ('新增器件原厂资料','TI数据保护：https://www.ti.com/lit/ds/symlink/tpd2s703-q1.pdf\nTI充电管理：https://www.ti.com/lit/ds/symlink/bq24072.pdf\nNexperia MOS：https://assets.nexperia.com/documents/data-sheet/PMV30UN2.pdf'),
 ('引脚与连接器依据','ST主控：https://www.st.com/resource/en/datasheet/stm32h743vi.pdf\nLumberg插座：https://downloads.lumberg.com/datenblaetter/en/1503_18.pdf\n资料脚位事实不替代封装批准，连接器开关编号歧义仍保留。'),
 ('编译与证据','TinyCC官网：https://bellard.org/tcc/\n本轮使用便携主机编译器，不安装驱动、不改系统PATH。Zig下载过慢已取消，未将其列为成功的ARM编译验证。源码哈希与主机编译日志见verification/test-results.json与compiler-log.json。'),
 ('最终状态','设计继续HOLD。下一步是供应商补测和完整EE/ME实施，不是给当前文件加“最终版”三个字。完成EDA、真实BOM、结构和样机DVP后才能分别申请工程试板、EVT组装及后续DVT/PVT放行。')])
c.save()
data={'pages':len(PdfReader(out).pages),'layout':layout,'path':str(out),'renderedReviewRequired':True}
(root/'verification/pdf-layout.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(data,ensure_ascii=False))
