const fs=require('node:fs'),path=require('node:path');
const packaged=path.basename(__dirname)==='reproduce',root=packaged?path.resolve(__dirname,'..'):path.resolve('outputs/SmartVio-V22-Control-Protection');
const measurements=[
 ['M01','基准定位','标记琴尾金属件基准边X0、旧腔近边145和远边223；带尺垂直照片；避免斜拍读数。','基准有标记且与本琴对应'],
 ['M02','安装范围','X110至258，每10mm记录可支撑净宽；记录侧边连接过渡和是否悬空。','148×49候选上盖不得悬越空区；未满足须重排'],
 ['M03','背部曲率','用平尺/塞尺记录上盖四边、中央、喇叭区的最高/最低点及装配压缩量。','纳入≤5mm实际高度链，不能用夹紧变形掩盖'],
 ['M04','原腔轮廓','78×47×22净尺寸，另记圆角、拔模斜度、底平度、突出物和穿线口。','下沉舱76×43×18只是候选，须实物套合'],
 ['M05','四个安装点','记录每点X/Y、最薄剩余实心木厚、到旧孔/腔壁/边缘距离、层间损伤。','数据完整后ME批准螺钉长度、底孔和扭矩'],
 ['M06','拾音线','原拾音器位置、信号/回线通断、屏蔽和自由线长；不得量通电阻值。','原孔可穿、无拉扯、无短路、线不夹在卡扣'],
 ['M07','插头空间','四口同时插入标准TRS、USB-C；再检查拟配无线发射器外壳/方向。','不得挡滚轮/按键、压琴体或超载插座支架'],
 ['M08','壳体固定','卡扣接合/拆卸、上盖螺丝压紧、下盖避让、喇叭网罩刚度。','禁止增加下壳装配螺钉；参数由试样确认'],
 ['M09','实装厚度','记录z最低/最高、非滚轮最高、滚轮最高，包含公差、胶层与线束。','非滚轮外凸≤5mm；整机≤25mm；不挖深旧腔']
];
const tests=[
 ['E01','插座实体脚位','未通电独立插座；TRS测试插头、万用表、显微照片。','逐一测TIP/RING/SLEEVE及检测开关；空插/全插/半插记录。','供应商图与实物一致；DA/DB改成批准物理焊盘。'],
 ['E02','EDA复核','原厂符号/封装版本、独立EE审图。','审核全部引脚、电源、NC、测试点、器件额定及网络；执行ERC。','无未解释ERC错误，签审完成；本包未执行。'],
 ['E03','PCB可制造','板厂叠层/阻抗/线距工艺文件。','板框、铜皮、差分USB、地回流、天线净空、机械避让、DRC。','Gerber/钻孔/贴片坐标由批准EDA导出；不可由本表代造。'],
 ['E04','首次上电','完整原理图和封装审核后；实验电源限流；不接裸电芯、不接昂贵外设。','按EE批准的限流值逐电源轨验证静态电流、3.3V、SYS及负载。','无异常电流/温升；数值限值由真实BOM功耗表批准。'],
 ['E05','开关机与复位','示波器同时采电源使能、BOOT_OK、静音和音频输出。','上电、短按、长按、看门狗、棕断；检查400ms启动与候选50ms关断序。','不失控外放、不反复重启；BOOT_OK实测满足器件窗口。'],
 ['E06','USB枚举/挂起','USB分析仪或合适电流测量；不同C-C/C-A供电、计算机和手机。','未配置、配置、挂起、恢复、反插、掉电；测总取流/浪涌/反灌。','满足最终USB方案和目标主机要求；不是仅看CE=高。'],
 ['E07','接口电源故障保护','仅由EE/EMC实验室使用限能故障夹具；不直接连接用户计算机。','验证CC/D±短电源、掉电、静电、残余尖峰与低压钳位。','PHY引脚/电源未越批准限值；不得据此表自行施加18V。'],
 ['E08','电池充电','批准的带保护1S电池包、NTC曲线、供方规格与热电偶。','先校验断短路/温度门禁；按电池厂规程测CC/CV、终止、预充及温升。','CE默认禁用；真实电池参数与测试签署后才可使能。'],
 ['E09','音频功能','音频分析仪、限功率假负载、信号源；初始不戴耳机。','拾音输入、干声SEND、RETURN、LINE/HP、扬声器分别扫频/噪声/失真/串扰。','RETURN不回灌SEND；声级/失真等目标先与音频工程确认。'],
 ['E10','插拔与误接','批准保护电路和负载夹具。','快慢插、半插、TS/TRS/TRRS、两个输出误接、断电插入。','无危险输出/损坏；TRRS不代表支持MIC；保护未完成不能跳过。'],
 ['E11','薄喇叭与装琴反馈','最终网罩、托圈、薄喇叭、实际琴体。','不同音量/姿态/弓法测试振膜净空、共振、啸叫、频响与可听声压。','用于个人练习；不能据几何厚度通过承诺演出音量。'],
 ['E12','无线与手机','真实RF固件、受控配对设备、批准区域射频配置。','BLE控制/A2DP发射分开测，重连、干扰、未授权、时延与断连。','反馈设备身份；无授权不可改路由/配对；时延实测。'],
 ['E13','环境与装配','EVT样机、最终材料及供应商能力。','落摔、振动、温湿、插拔寿命、螺丝抗拔/滑牙与卡扣循环。','先制定DVP数值与样本量，未定不得填写PASS。']
];
fs.writeFileSync(path.join(root,'assembly/factory-work-items.json'),JSON.stringify({physicalTests:0,measurements:measurements.map(([id,name,method,acceptance])=>({id,name,method,acceptance,result:null,evidence:null,operator:null})),tests:tests.map(([id,name,fixture,method,acceptance])=>({id,name,fixture,method,acceptance,result:null,evidence:null,operator:null}))},null,2));
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const table=(head,rows)=>`<table><thead><tr>${head.map(x=>'<th>'+esc(x)+'</th>').join('')}</tr></thead><tbody>${rows.map(r=>'<tr>'+r.map(x=>'<td>'+esc(x)+'</td>').join('')+'<td class="blank">记录/证据/签名：<br><br><br></td></tr>').join('')}</tbody></table>`;
const html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>V22 工厂补测与签审</title><style>*{box-sizing:border-box}body{font:14px/1.65 "Microsoft YaHei",sans-serif;color:#203a34;margin:24px;letter-spacing:0}h1{font-size:25px}h2{font-size:21px;margin-top:30px}table{width:100%;border-collapse:collapse;min-width:900px}th,td{border:1px solid #8ca79b;padding:10px;text-align:left;vertical-align:top}th{background:#ecf2ef}td.blank{min-width:150px}section{overflow:auto}.warn{color:#a04430}p{overflow-wrap:anywhere}@media print{body{margin:10mm;font-size:10px}table{min-width:0}tr{break-inside:avoid}h2{break-before:page}td.blank{min-width:100px}section{overflow:visible}@page{size:A4 landscape;margin:10mm}}</style><h1>V22 工厂补测、审图与签审记录</h1><p class="warn">当前实物测试0项，所有结果留空。此表是待执行工作单，不是合格证；不允许为通过审查填入未测结果。</p><p>琴体编号：________　工厂：________　负责人：________　日期：________　图纸版本：________</p><h2>1. 琴厂 / 结构测量</h2><section>${table(['编号','项目','操作与记录','要求','实测记录'],measurements)}</section><h2>2. 电子厂 / 联调验证</h2><p class="warn">电气故障/电池测试须由具备资质的工程人员使用保护夹具执行；不能直接接用户手机/电脑作故障负载。每一步须先签审上一步。</p><section>${table(['编号','项目','前提/工装','执行内容','通过依据','测试记录'],tests)}</section><h2>3. 制造放行门槛</h2><p>必须具备：签审原理图、ERC；PCB/叠层/DRC；批准BOM与备选；Gerber/钻孔/钢网/贴片坐标；焊接工艺；固件构建及烧录；结构/线束图；四点螺丝底孔长度扭矩；样机DVP记录及风险闭环。任何一项空缺不得称为最终生产包。</p><p>电子负责人：________　结构负责人：________　工艺负责人：________　质量负责人：________</p><p>结论：继续研究 / 允许工程试板 / 允许EVT组装 / 退回修订（分别签审，不自动递进）</p></html>`;
fs.writeFileSync(path.join(root,'assembly/factory-checklist.html'),html);
if(!packaged)fs.copyFileSync(__filename,path.join(root,'reproduce/factory.cjs'));
