const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
function scan(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?scan(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const files=scan(root).filter(f=>path.basename(f)!=='manifest.json').sort().map(f=>({file:path.relative(root,f).replaceAll('\\','/'),bytes:fs.statSync(f).size,sha256:crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')}));
fs.writeFileSync(path.join(root,'manifest.json'),JSON.stringify({revision:'V23',issued:'2026-10-04',release:'HOLD / engineering supplement only',files},null,2));
console.log(JSON.stringify({files:files.length,totalBytes:files.reduce((a,f)=>a+f.bytes,0)}));
