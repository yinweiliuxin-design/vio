const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const write=(p,x)=>fs.writeFileSync(path.join(root,p),typeof x==='string'?x:JSON.stringify(x,null,2));
const circuits=JSON.parse(fs.readFileSync(path.join(__dirname,'v22-circuits.json')));
const get=r=>circuits.flatMap(s=>s.components).find(c=>c.ref===r);
const pin=(r,n)=>get(r).pins.find(p=>p.number===String(n));
const sheet=(id,title,notes)=>circuits.push({id,title,notes,components:[]});
function add(s,ref,type,value,pins,mpn=null,pkg=null,source=null){
 const c={ref,type,value,mpn,package:pkg,source,pins:pins.map(([n,name,net])=>({number:String(n),name,net})),release:'HOLD',verificationScope:'Logical candidate only; no footprint, routing or sample release'};
 circuits.find(x=>x.id===s).components.push(c);return c;
}
function passive(s,r,v,a,b){return add(s,r,r[0],v,[[1,'1',a],[2,'2',b]],null,'0603 candidate; exact MPN and derating pending');}
function gpio(n,name,net){if(pin('U801S',n).net)throw Error('GPIO already assigned');Object.assign(pin('U801S',n),{name,net});}
sheet('A28','四路电压监测：隔离、缓冲与独立ADC',[
 '测量USB_5V_SAFE、PACK_PLUS、SYS、V3D；仅低压保护后节点，不测VBUS_RAW；不可把USB误接高压范围套到采样电路。',
 '每路15k/10k分压，经过TMUX1511后有100k下拉，合成名义倍率2.65，不是2.5；软件采用0.33125mV/LSB。电阻0.1%候选。',
 'TMUX1511PWR为14脚TSSOP，不能沿用16脚QFN脚号。PB10 MON_ENABLE缺省下拉；必须在V3D稳定后使能并等待至少10ms。',
 '100k下拉用于掉电泄漏控制；以2uA估算0.2V，仅规定条件的解析值；掉电/慢斜坡/瞬态和开关失效仍需实板测试。',
 'OPA4330四路电压跟随器隔离ADC采样负载，输出经100R/10nF；稳定性、近零点输出误差和电源纹波待测。',
 'ADC地址0x48，温度地址0x49，PCM1864现有AD接地对应0x4A；沿用R602/R603上拉，不重复并联上拉。',
 '本页新增器件尚未放入真实PCB；需重新做面积/堆叠和电流预算，不能说仍已全部装下。'
]);
const ain=['MON_USB_ADC','MON_BAT_ADC','MON_SYS_ADC','MON_3V3_ADC'];
add('A28','U1701','IC','ADS1115IDGSR',[[1,'ADDR','GND'],[2,'ALERT_RDY',null],[3,'GND','GND'],[4,'AIN0',ain[0]],[5,'AIN1',ain[1]],[6,'AIN2',ain[2]],[7,'AIN3',ain[3]],[8,'VDD','V3D'],[9,'SDA','I2C_SDA'],[10,'SCL','I2C_SCL']],'ADS1115IDGSR','DGS10 VSSOP; envelope 3.0 x 4.9mm nominal','ADS1115');
pin('U1701',2).noConnectReason='Comparator disabled; polling configuration OS bit; intentional NC';
const sig=['USB','BAT','SYS','3V3'],rails=['USB_5V_SAFE','PACK_PLUS','SYS','V3D'];
const sw=add('A28','U1702','IC','TMUX1511PWR',[[1,'SEL1','MON_ENABLE'],[2,'S1','MON_USB_DIV'],[3,'D1','MON_USB_BUF_IN'],[4,'SEL2','MON_ENABLE'],[5,'S2','MON_BAT_DIV'],[6,'D2','MON_BAT_BUF_IN'],[7,'GND','GND'],[8,'D3','MON_SYS_BUF_IN'],[9,'S3','MON_SYS_DIV'],[10,'SEL3','MON_ENABLE'],[11,'D4','MON_3V3_BUF_IN'],[12,'S4','MON_3V3_DIV'],[13,'SEL4','MON_ENABLE'],[14,'VDD','V3D']],'TMUX1511PWR','PW14 TSSOP; envelope 5.0 x 6.4mm nominal','TMUX1511');
const op=add('A28','U1703','IC','OPA4330AIPWR',[[1,'OUT_A','MON_USB_BUF'],[2,'IN_A_MINUS','MON_USB_BUF'],[3,'IN_A_PLUS','MON_USB_BUF_IN'],[4,'V_PLUS','V3D'],[5,'IN_B_PLUS','MON_BAT_BUF_IN'],[6,'IN_B_MINUS','MON_BAT_BUF'],[7,'OUT_B','MON_BAT_BUF'],[8,'OUT_C','MON_SYS_BUF'],[9,'IN_C_MINUS','MON_SYS_BUF'],[10,'IN_C_PLUS','MON_SYS_BUF_IN'],[11,'V_MINUS','GND'],[12,'IN_D_PLUS','MON_3V3_BUF_IN'],[13,'IN_D_MINUS','MON_3V3_BUF'],[14,'OUT_D','MON_3V3_BUF']],'OPA4330AIPWR','PW14 TSSOP; envelope 5.0 x 6.4mm nominal','OPA4330');
for(let n=0;n<4;n++){
 const k=1701+n*4,net='MON_'+sig[n];
 passive('A28','R'+k,'15k 0.1% 25ppm/C',rails[n],net+'_DIV');
 passive('A28','R'+(k+1),'10k 0.1% 25ppm/C',net+'_DIV','GND');
 passive('A28','R'+(k+2),'100k 0.1% 25ppm/C',net+'_BUF_IN','GND');
 passive('A28','R'+(k+3),'100R 1%',net+'_BUF',ain[n]);
 passive('A28','C'+(1701+n*2),'10nF 10V X7R',net+'_BUF_IN','GND');
 passive('A28','C'+(1702+n*2),'10nF 10V X7R',ain[n],'GND');
}
for(let n=1709;n<=1711;n++)passive('A28','C'+n,'100nF 10V X7R','V3D','GND');
passive('A28','R1717','100k 1%','MON_ENABLE','GND');
gpio(46,'PB10_MON_ENABLE','MON_ENABLE');
sheet('A29','电池表面独立测温候选：不并接原NTC',[
 'V22方案中J501三线1S候选电池及PACK_NTC到BQ24074.TS保持不变，不向TS增加ADC负载。这不是老款实物的9V电池，真实新电池仍未选定。',
 'TMP117放置于独立绝缘温感小板/柔性区域，贴近电池表面；热耦合材料、压力、绝缘和装配重复性必须由电池厂审核。不得直接焊接电芯铝塑膜或挤压电芯。',
 '温感芯片读数不是电芯内部温度。thermal_attachment_approved默认false，热响应/脱落故障验证前不能作为充电许可。',
 'J1801/J1802为内部四线逻辑连接，非外部接口，物理连接器型号与脚方向未批准，不是DOCK。',
 'WSON6封装本体2x2mm、最大高0.8mm；7为底部热焊盘，当前留空不焊，不套用裸焊盘必须接地规则。',
 'TMP117 ADD0接V3D，ALERT暂不接；软件使用配置寄存器Data_Ready，EEPROM保持锁定。'
]);
add('A29','U1801','IC','TMP117AIDRVR',[[1,'SCL','TEMP_SCL'],[2,'GND','GND'],[3,'ALERT',null],[4,'ADD0','V3D'],[5,'V_PLUS','V3D'],[6,'SDA','TEMP_SDA'],[7,'THERMAL_PAD',null]],'TMP117AIDRVR','DRV6 WSON; 2.0 x 2.0 x 0.8mm max height','TMP117');
pin('U1801',3).noConnectReason='Polling only; intentional NC';
pin('U1801',7).noConnectReason='Thermal pad unsoldered candidate per manufacturer; assembly verification pending';
passive('A29','C1801','100nF 10V X7R','V3D','GND');
passive('A29','R1801','33R 1%','I2C_SCL','TEMP_SCL');
passive('A29','R1802','33R 1%','I2C_SDA','TEMP_SDA');
for(const r of ['J1801','J1802'])add('A29',r,'J','Internal thermal sensor harness endpoint',[[1,'3V3','V3D'],[2,'GND','GND'],[3,'SCL','TEMP_SCL'],[4,'SDA','TEMP_SDA']],null,'4-wire endpoint; physical pinout/MPN/height NOT approved');
sheet('A30','电源故障及充电状态送回主控',[
 'R505/R506由SYS上拉改为V3D上拉；PGOOD/CHG为开漏状态，不把约4.4V直接送入3.3V采集接口。',
 'PGOOD低仅表示输入条件满足，不能证明USB主机授权500mA；USB协议授权必须另行获取。',
 'CHG高可能代表未充电/充满/断电/无电池，不能直接显示为充满；闪烁诊断尚未实现。',
 'eFuse FLT送PE15，经过1k串阻；现有R1006上拉V3D保留。软件低电平触发端口故障。',
 '本页只是状态采样，不是新增独立硬件安全联锁；仍需失电默认、GPIO启动和掉电反灌验证。'
]);
pin('R505',1).net='V3D';pin('R506',1).net='V3D';
passive('A30','R1901','1k 1%','USB_FLT','USB_FLT_MCU');
passive('A30','R1902','1k 1%','PGOOD_TP','CHG_PGOOD_N');
passive('A30','R1903','1k 1%','CHG_TP','CHG_STATUS_N');
gpio(45,'PE15_USB_FLT','USB_FLT_MCU');gpio(47,'PB11_CHG_PGOOD','CHG_PGOOD_N');gpio(57,'PD10_CHG_STATUS','CHG_STATUS_N');
const s27=circuits.find(s=>s.id==='A27');s27.notes.push('V23：软件采集候选见A28/A29，电源状态见A30；已加入C驱动和单次充电会话锁定，实际电池/传感器装配/板级联调仍未通过。');
write('electrical/circuits.json',circuits);
const pins=circuits.flatMap(s=>s.components.flatMap(c=>c.pins.map(p=>({sheet:s.id,ref:c.ref.startsWith('U801')?'U801':c.ref,unit:c.ref,...p,physicalPad:null,copperPath:null,solderProcess:null,release:'HOLD'}))));
const nets={};for(const p of pins)if(p.net)(nets[p.net]??=[]).push({ref:p.ref,pin:p.number});
write('electrical/pin-net-register.json',pins);
write('electrical/net-register.json',Object.entries(nets).map(([net,endpoints])=>({net,endpoints,copperPath:null,approved:false})));
const parts={};for(const s of circuits)for(const c of s.components){const r=c.ref.startsWith('U801')?'U801':c.ref;parts[r]??={ref:r,sheet:s.id,mpn:c.mpn,value:c.value,package:c.package,physicalPlacement:null,approved:false};}
write('electrical/component-register.json',Object.values(parts));
write('electrical/new-components.json',Object.values(parts).filter(p=>['A28','A29','A30'].includes(p.sheet)));
const ratio=(rt,rb,rp,ron=0)=>1+rt/rb+(rt+ron*(1+rt/rb))/rp;
let ratios=[];for(const a of [.999,1.001])for(const b of [.999,1.001])for(const c of [.999,1.001])for(const r of [0,4.5])ratios.push(ratio(15000*a,10000*b,100000*c,r));
write('electrical/analytical-checks.json',{method:'Closed-form DC/tolerance calculations only. NOT SPICE, measurement or certification.',divider:{topOhm:15000,bottomOhm:10000,postSwitchPulldownOhm:100000,tolerance:.001,nominalRatio:2.65,cornerCases:ratios.length,minimumRatio:Math.min(...ratios),maximumRatio:Math.max(...ratios),adcLsbUv:125,inputReferredLsbUv:331.25,resistorOnlyWorstErrorAt5500mV:Math.max(...ratios.map(r=>Math.abs(5500*2.65/r-5500)))},leakage:{assumedOffMaxUa:2,pulldownOhm:100000,calculatedOffNodeV:.2,verifiedOnBoard:false},batteryDrain:{at4V2_switchOffMicroA:4.2/25000*1e6,at4V2_switchOffmAhPerDay:4.2/25000*1000*24,warning:'Additional always-connected divider drain; excludes all existing circuits. Optimization pending.'},i2c:{existingPullupOhm:4700,chosenHz:100000,assumingBusPf:200,riseTimeNs:.8473*4700*200e-12*1e9,measuredBusPf:null},temperature:{quantizationMilliC:7.8125,wholeAssemblyErrorC:null,thermalLagMs:null}});
write('electrical/i2c-contract.json',{addressFormat:'7-bit; do not pass shifted wire bytes to core',busHz:100000,sharedBusMutexRequired:true,readTransaction:'START addrW ACK reg ACK RESTART addrR ACK MSB ACK LSB NACK STOP',registerEndian:'big',devices:[{ref:'U1701',address:'0x48',strap:'ADDR=GND',configurationByChannel:['0xC383','0xD383','0xE383','0xF383']},{ref:'U1801',address:'0x49',strap:'ADD0=V3D',configuration:'0x0100',idMask:'0x0FFF',idValue:'0x0117',eeprom:'No writes; reject busy/unlocked state'},{ref:'U601',address:'0x4A',strap:'MS_AD=GND',driver:'Not added this revision'}],gpio:[{pin:46,gpio:'PB10',net:'MON_ENABLE',reset:'LOW',direction:'OUT'},{pin:45,gpio:'PE15',net:'USB_FLT_MCU',active:'LOW',direction:'IN'},{pin:47,gpio:'PB11',net:'CHG_PGOOD_N',active:'LOW',direction:'IN'},{pin:57,gpio:'PD10',net:'CHG_STATUS_N',active:'LOW',direction:'IN'}]});
write('electrical/calibration-unapproved.json',{schema:1,boardSerial:null,electrical_calibration_approved:false,thermal_attachment_approved:false,gain_ppm:[1000000,1000000,1000000,1000000],offset_mv:[0,0,0,0],testEquipment:null,operator:null,reviewer:null,date:null,signature:null});
write('verification/scope.json',{revision:'V23',status:'ENGINEERING SUPPLEMENT / HOLD',hardwareTests:0,spice:false,erc:false,drc:false,gerber:false,flashableFirmware:false,mechanicalFitVerified:false,applicationChanged:false,includesFullLogicalCircuitBaseline:true,notFullProductionPackage:true});
write('sources.json',[
 ['ADS1115','https://www.ti.com/lit/ds/symlink/ads1115.pdf','Rev E; pin map, PGA, configuration/readiness'],
 ['TMUX1511','https://www.ti.com/lit/ds/symlink/tmux1511.pdf','Rev B; TSSOP14 map and powered-off conditions'],
 ['OPA4330','https://www.ti.com/lit/ds/symlink/opa4330.pdf','Rev G; TSSOP14 buffer map and limits'],
 ['TMP117','https://www.ti.com/lit/ds/symlink/tmp117.pdf','Rev D; WSON6, thermal pad, I2C and EEPROM'],
 ['PCM1864','https://www.ti.com/lit/ds/symlink/pcm1864.pdf','Rev D; section9.5.1.4.1 address'],
 ['BQ24074','https://www.ti.com/lit/ds/symlink/bq24074.pdf','Rev N; TS independent protection and CE timer resets'],
 ['STM32H743','https://www.st.com/resource/en/datasheet/stm32h743vi.pdf','Local datasheet crosscheck of LQFP100 spare GPIO']
].map(([id,url,evidence])=>({id,url,evidence,checked:'2026-10-02',productCertification:false})));
write('assembly/thermal-harness.json',{status:'INTERNAL CANDIDATE; NOT A MANUFACTURING RELEASE',from:'J1801 mainboard',to:'J1802 thermal island',lengthMm:null,routeConstraint:'Inside cover/cup; no crossing snap hooks or screw columns; no compression against pouch cell',conductors:[{pin:1,net:'V3D',colorCandidate:'red'},{pin:2,net:'GND',colorCandidate:'black'},{pin:3,net:'TEMP_SCL',colorCandidate:'yellow'},{pin:4,net:'TEMP_SDA',colorCandidate:'white'}],pinDirectionVerified:false,wireGauge:null,connectorMpn:null,insulationMaterial:null,adhesiveMpn:null,pcbThicknessMm:null,warning:'Do not use these logical pin numbers to crimp an unapproved connector.'});
console.log(JSON.stringify({parts:Object.keys(parts).length,pins:pins.length,nets:Object.keys(nets).length,newParts:Object.values(parts).filter(p=>['A28','A29','A30'].includes(p.sheet)).length}));
