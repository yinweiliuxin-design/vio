const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const text=(x,y,s,cls='')=>`<text x="${x}" y="${y}" class="${cls}">${esc(s)}</text>`;
const wire=(a,b,c,d)=>`<path class="wire" d="M${a} ${b} L${c} ${d}"/>`;
const box=(x,y,w,h,s)=>`<rect class="part" x="${x}" y="${y}" width="${w}" height="${h}"/>${text(x+12,y+30,s)}`;
const res=(x,y,s)=>`${wire(x,y,x+15,y)}<rect class="part" x="${x+15}" y="${y-9}" width="55" height="18"/>${wire(x+70,y,x+90,y)}${text(x+10,y-20,s,'small')}`;
function save(name,title,body,h=1000){fs.writeFileSync(path.join(root,'drawings',name+'.svg'),`<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="${h}" viewBox="0 0 1600 ${h}"><style>text{font-family:Arial,'Microsoft YaHei',sans-serif;font-size:20px;fill:#172b31}.title{font-size:34px;font-weight:700}.sub{font-size:18px;fill:#48636c}.small{font-size:16px}.wire{fill:none;stroke:#225664;stroke-width:3}.part{fill:white;stroke:#225664;stroke-width:2}.warn{fill:#a6362a}</style><rect width="1600" height="${h}" fill="white"/>${text(45,55,title,'title')}${text(45,90,'V23 | 工程候选连接图 | 非PCB布线图 | 未经硬件验证，不可直接投产','sub')}${body}${text(45,h-30,'2026-10-04 · 脚位以元件表与原厂资料为准 · HOLD','small')}</svg>`);}
let b='';const ns=['USB_5V_SAFE','PACK_PLUS','SYS','V3D'];
for(let n=0;n<4;n++){
 const y=175+n*160,k=1701+n*4,c=1701+n*2;
 b+=text(40,y+6,ns[n],'small')+wire(175,y,205,y)+res(205,y,`R${k} 15k`)+wire(295,y,515,y);
 b+=wire(350,y,350,y+30)+box(320,y+30,60,34,'10k')+wire(350,y+64,350,y+98)+text(390,y+58,`R${k+1}`,'small')+text(329,y+123,'GND','small');
 b+=box(515,y-28,160,56,`U1702 CH${n+1}`)+wire(675,y,940,y);
 b+=wire(755,y,755,y+30)+box(711,y+30,88,34,'100k')+wire(755,y+64,755,y+98)+text(814,y+58,`R${k+2}`,'small')+text(731,y+123,'GND','small');
 b+=box(940,y-28,166,56,`U1703 ${'ABCD'[n]} x1`)+wire(1106,y,1130,y)+res(1130,y,`R${k+3} 100R`)+wire(1220,y,1310,y)+box(1310,y-28,235,56,`U1701 AIN${n} (${n+4})`);
 b+=text(865,y+94,`C${c} 10nF: 缓冲输入→GND`,'small')+text(1150,y+123,`C${c+1} 10nF: ADC输入→GND`,'small');
}
b+=text(45,844,'四路：15k / (10k并联100k)，名义倍率2.65；ADC每LSB折算输入0.33125mV。')+text(45,884,'U1703均为电压跟随器：OUT接负输入；监测芯片VDD=V3D。')+text(45,924,'PB10 → MON_ENABLE → 四路SEL；R1717 100k下拉，电源稳定并等待10ms后采集。');
save('01-voltage-circuit','A28 · 电压采集四通道',b);
b=box(70,155,325,160,'新款候选1S电池 J501')+text(95,220,'1 PACK+   2 GND   3 NTC')+text(95,265,'不是老款9V电池','warn');
b+=wire(395,230,570,230)+text(408,210,'PACK_NTC')+box(570,165,335,145,'BQ24074 U501')+text(595,233,'TS pin1：独立温度保护')+text(595,274,'不并接软件ADC');
b+=box(1010,155,500,160,'J1801 → J1802 内部四线')+text(1030,219,'1 V3D / 2 GND / 3 SCL / 4 SDA')+text(1030,269,'连接器/线长/线径尚未批准','warn');
b+=box(70,400,530,215,'电池表面温感区域（候选）')+text(95,465,'绝缘层 → 温感小板 → 受控热接触')+text(95,505,'不得挤压、刺穿或在电芯外包装焊接')+text(95,548,'热响应未通过，禁充默认保留','warn');
b+=wire(600,505,730,505)+text(615,480,'内部线束','small')+box(730,395,430,225,'TMP117 U1801 / WSON6')+text(755,458,'1 SCL    2 GND    3 ALERT: NC')+text(755,503,'4 ADD0=V3D    5 V+=V3D')+text(755,548,'6 SDA    7 热焊盘: 暂不焊')+text(755,590,'C1801 100nF靠近5/2脚','small');
b+=wire(1160,505,1220,505)+box(1220,420,300,170,'STM32 I2C1')+text(1240,485,'PB8 SCL / PB9 SDA')+text(1240,530,'温度地址0x49');
b+=text(70,710,'传感器测到自身温度。热接触装配经验证后，才可授权为电池表面温度判断。')+text(70,758,'正常读数不证明NTC已接好，不证明电池已安装，也不替代电池保护板。')+text(70,806,'充电仍需：电池批准、总USB电流预算、USB主机授权、温度与电压校准。');
save('02-temperature-circuit','A29 · 双路径温度监测，保留V22的NTC保护设计',b,900);
b=box(60,150,405,150,'采样驱动 sv_mon_tick')+text(85,213,'地址/配置回读/转换完成检查')+text(85,255,'NACK、超时、异常码 → 锁定')+wire(465,225,570,225)+box(570,150,430,150,'sv_mon_apply')+text(595,213,'完整帧、时效、电压轨、校准许可')+text(595,255,'覆盖旧“有效”标志，禁止沿用')+wire(1000,225,1100,225)+box(1100,150,435,150,'sv_power_status_apply')+text(1125,213,'PGOOD / eFuse FLT / GPIO有效')+text(1125,255,'CHG高电平不等于充满');
b+=wire(1330,300,1330,400)+box(1100,400,435,150,'sv_tick + 命令处理')+text(1125,463,'充电、音频路由、物理按键状态')+text(1125,505,'不提前提交充电GPIO')+wire(1100,475,1000,475)+box(570,400,430,150,'最后执行 sv_guard_apply')+text(595,463,'启动锁定；物理拔线1秒后可重备')+text(595,505,'合格2秒才允许；故障不自动重试')+wire(570,475,465,475)+box(60,400,405,150,'唯一GPIO提交点')+text(85,463,'CHARGE_ALLOW / CE / EN1 / EN2')+text(85,505,'板级HAL尚未实现','warn');
b+=text(60,645,'会话重置必须有可靠物理拔线证据，不可用保护后掉压代替。该板级检测尚未闭合。','warn')+text(60,695,'上电锁定避免仅重启MCU就自动恢复充电；电池耗尽启动、关机充电仍未实现。')+text(60,745,'V22的4.18V保守禁充阈值暂保留，不宣称完成4.2V恒压充满与终止流程。')+text(60,795,'执行顺序和调用间隔须由目标板测试确认；此图不是独立硬件保护电路。');
save('03-control-chain','F23 · 采样到充电控制的执行顺序',b,900);
console.log('3 circuit/control SVG diagrams generated');
