const fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const {chromium}=require(process.env.SV_PLAYWRIGHT||'<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch({channel:'chrome',headless:true}),results=[];
 try{
  for(const [name,width,height] of [['desktop',1440,1080],['tablet',820,1180],['mobile',390,844]]){
   const page=await browser.newPage({viewport:{width,height}});
   await page.goto(pathToFileURL(path.join(root,'index.html')).href);await page.waitForLoadState('load');
   const state=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,images:[...document.images].map(i=>({src:i.getAttribute('src'),ok:i.complete&&i.naturalWidth>0})),links:[...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href'))}));
   if(state.scroll>width)throw Error(name+' horizontal overflow');
   if(state.images.some(i=>!i.ok))throw Error(name+' image failure');
   for(const l of state.links)if(!l.startsWith('#')&&!l.startsWith('https:')&&!fs.existsSync(path.join(root,l)))throw Error('Missing link '+l);
   await page.screenshot({path:path.join(root,'verification',name+'.png'),fullPage:false});
   await page.locator('details').first().evaluate(e=>{e.open=true;});
   await page.locator('details').first().scrollIntoViewIfNeeded();
   if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error(name+' expanded table overflow');
   await page.screenshot({path:path.join(root,'verification',name+'-pins.png')});
   results.push({name,...state,expandedTable:'PASS'});await page.close();
  }
  for(const f of fs.readdirSync(path.join(root,'drawings')).filter(f=>f.endsWith('.svg'))){
   const page=await browser.newPage({viewport:{width:1600,height:1000},deviceScaleFactor:1});
   await page.goto(pathToFileURL(path.join(root,'drawings',f)).href);
   const bounds=await page.evaluate(()=>{const svg=document.querySelector('svg'),v=svg.viewBox.baseVal;return [...svg.querySelectorAll('text')].map(e=>({text:e.textContent,b:e.getBBox()})).filter(({b})=>b.x<0||b.y<0||b.x+b.width>v.width||b.y+b.height>v.height).map(x=>x.text);});
   if(bounds.length)throw Error('SVG overflow '+f+JSON.stringify(bounds));
   await page.locator('svg').screenshot({path:path.join(root,'drawings',f.replace('.svg','.png'))});
   results.push({diagram:f,textOutsideCanvas:bounds});await page.close();
  }
  fs.writeFileSync(path.join(root,'verification/visual-qa.json'),JSON.stringify({date:new Date().toISOString(),scope:'Engineering document only, not app client/browser feature QA',results},null,2));
  console.log(JSON.stringify({viewports:3,diagrams:3,status:'PASS'}));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
