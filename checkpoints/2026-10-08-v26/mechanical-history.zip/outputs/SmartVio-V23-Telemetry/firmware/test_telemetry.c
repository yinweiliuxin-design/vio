#include "sv_telemetry.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned assertions, groups;
#define CHECK(x) do { assertions++; if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);exit(1);} } while(0)
typedef struct {
    unsigned transactions, fail_at, reads, writes;
    uint16_t adc_cfg, temp_cfg, raw[4], temp, id;
    bool adc_busy, temp_not_ready, wrong_adc, wrong_temp, eeprom_busy, eeprom_unlocked;
    unsigned channels_seen;
} mock_bus;
static bool access_ok(mock_bus *b,size_t n,uint32_t timeout){
    CHECK(n==2);CHECK(timeout==2); b->transactions++;
    return b->transactions!=b->fail_at;
}
static bool read_bus(void *ctx,uint8_t a,uint8_t r,uint8_t *d,size_t n,uint32_t t){
    mock_bus *b=ctx; uint16_t v=0;b->reads++;
    if(!access_ok(b,n,t))return false;
    if(a==0x48){
        CHECK(r==0 || r==1);
        unsigned ch=((b->adc_cfg>>12)&7)-4;CHECK(ch<4);
        if(r==1)v=(uint16_t)((b->adc_cfg&0x7fff)|(b->adc_busy?0:0x8000));
        else {v=b->raw[ch];b->channels_seen|=1u<<ch;}
        if(r==1 && b->wrong_adc)v^=0x1000;
    }else{
        CHECK(a==0x49);CHECK(r==0 || r==1 || r==4 || r==0x0f);
        if(r==0)v=b->temp;
        if(r==0x0f)v=b->id;
        if(r==4)v=(uint16_t)((b->eeprom_unlocked?0x8000:0)|(b->eeprom_busy?0x4000:0));
        if(r==1)v=(uint16_t)(b->temp_cfg|(b->temp_not_ready?0:0x2000)|(b->eeprom_busy?0x1000:0));
        if(r==1 && b->wrong_temp)v^=0x20;
    }
    d[0]=(uint8_t)(v>>8);d[1]=(uint8_t)v;return true;
}
static bool write_bus(void *ctx,uint8_t a,uint8_t r,const uint8_t *d,size_t n,uint32_t t){
    mock_bus *b=ctx;uint16_t v=(uint16_t)(((uint16_t)d[0]<<8)|d[1]);b->writes++;
    if(!access_ok(b,n,t))return false;
    CHECK(r==1);
    if(a==0x48){CHECK((v&0x8fff)==0x8383);b->adc_cfg=v;}
    else{CHECK(a==0x49);CHECK(v==0x0100);b->temp_cfg=v;}
    return true;
}
static uint16_t code(unsigned mv){return (uint16_t)((mv*4000u+662)/1325u);}
static void setup(mock_bus *b,sv_monitor *m,uint32_t now){
    memset(b,0,sizeof(*b));b->raw[0]=code(5000);b->raw[1]=code(3800);
    b->raw[2]=code(4400);b->raw[3]=code(3300);b->temp=0x0c80;b->id=0x0117;
    sv_mon_bus bus={b,read_bus,write_bus};sv_mon_init(m,now,bus,NULL);
}
static void run(sv_monitor *m,uint32_t start,unsigned duration){
    for(unsigned t=0;t<=duration;t+=5)sv_mon_tick(m,start+t,true);
}
static void first_frame(sv_monitor *m,uint32_t start){
    for(unsigned t=0;t<500 && !m->frame.valid && !m->fault;t+=5)sv_mon_tick(m,start+t,true);
}
static sv_inputs healthy(void){
    sv_inputs i;memset(&i,0,sizeof(i));
    i.power_good=i.clocks_good=i.codec_ready=i.usb_phy_ready=true;
    i.usb_present=i.usb_configured=i.battery_present=i.board_budget_valid=true;
    i.usb_budget_ma=500;i.board_usb_budget_ma=50;i.speaker_calibrated=true;
    return i;
}
static sv_config approved(void){
    sv_config c={true,true,198,20,50,400};return c;
}
int main(void){
    mock_bus b;sv_monitor m;sv_mon_frame f;sv_inputs i;
    setup(&b,&m,0);first_frame(&m,0);
    CHECK(sv_mon_snapshot(&m,m.last_tick,&f));CHECK(b.channels_seen==15);
    CHECK(f.mv[0]==5000 && f.mv[1]==3800 && f.mv[2]==4400 && f.mv[3]==3300);
    CHECK(f.temperature_deci_c==250);CHECK(f.generation==1);groups++;
    unsigned operations=b.transactions;
    for(unsigned op=1;op<=operations;op++){
        setup(&b,&m,0);b.fail_at=op;first_frame(&m,0);
        CHECK(m.fault==SV_MON_BUS);CHECK(!sv_mon_snapshot(&m,m.last_tick,&f));
        b.fail_at=0;run(&m,m.last_tick,50);CHECK(m.fault==SV_MON_BUS);
    }groups++;
    setup(&b,&m,0);b.wrong_adc=true;first_frame(&m,0);CHECK(m.fault==SV_MON_CONFIG);groups++;
    setup(&b,&m,0);b.wrong_temp=true;first_frame(&m,0);CHECK(m.fault==SV_MON_CONFIG);groups++;
    setup(&b,&m,0);b.adc_busy=true;first_frame(&m,0);CHECK(m.fault==SV_MON_TIMEOUT);groups++;
    setup(&b,&m,0);b.temp_not_ready=true;first_frame(&m,0);CHECK(m.fault==SV_MON_TIMEOUT);groups++;
    setup(&b,&m,0);b.eeprom_busy=true;first_frame(&m,0);CHECK(m.fault==SV_MON_CONFIG);groups++;
    setup(&b,&m,0);b.eeprom_unlocked=true;first_frame(&m,0);CHECK(m.fault==SV_MON_CONFIG);CHECK(b.writes==0);groups++;
    setup(&b,&m,0);b.id=0xffff;first_frame(&m,0);CHECK(m.fault==SV_MON_ID);groups++;
    setup(&b,&m,0);b.raw[1]=0x8000;first_frame(&m,0);CHECK(m.fault==SV_MON_RANGE);groups++;
    setup(&b,&m,0);b.raw[0]=0x7fff;first_frame(&m,0);CHECK(m.fault==SV_MON_RANGE);groups++;
    setup(&b,&m,0);b.raw[0]=0xfff8;first_frame(&m,0);CHECK(m.frame.valid && m.frame.mv[0]==0);groups++;
    setup(&b,&m,0);b.temp=0xff80;first_frame(&m,0);CHECK(m.frame.temperature_deci_c==-10);groups++;
    setup(&b,&m,0);b.temp=0x8000;first_frame(&m,0);CHECK(m.fault==SV_MON_RANGE);groups++;
    setup(&b,&m,0);first_frame(&m,0);CHECK(!sv_mon_snapshot(&m,m.last_tick+101,&f));CHECK(!f.valid);groups++;
    setup(&b,&m,0);first_frame(&m,0);m.last_tick=800;CHECK(!sv_mon_snapshot(&m,800,&f));groups++;
    setup(&b,&m,0);sv_mon_tick(&m,101,true);CHECK(m.fault==SV_MON_TIMING);groups++;
    setup(&b,&m,100);sv_mon_tick(&m,99,true);CHECK(m.fault==SV_MON_TIMING);groups++;
    setup(&b,&m,0xfffffff0u);first_frame(&m,0xfffffff0u);CHECK(m.frame.valid);groups++;
    setup(&b,&m,0);sv_mon_tick(&m,0,true);sv_mon_tick(&m,5,false);CHECK(m.fault==SV_MON_TIMING);groups++;
    setup(&b,&m,0);for(unsigned t=0;t<=1010;t+=10)sv_mon_tick(&m,t,false);CHECK(m.fault==SV_MON_TIMEOUT);groups++;
    setup(&b,&m,0);m.bus.read=NULL;sv_mon_tick(&m,0,true);CHECK(m.fault==SV_MON_BUS);groups++;
    setup(&b,&m,0);m.bus.write=NULL;sv_mon_tick(&m,0,true);CHECK(m.fault==SV_MON_BUS);groups++;
    setup(&b,&m,0);sv_mon_cal bad=m.cal;bad.gain_ppm[1]=0;
    sv_mon_bus bus={&b,read_bus,write_bus};sv_mon_init(&m,0,bus,&bad);CHECK(m.fault==SV_MON_CONFIG);groups++;
    setup(&b,&m,0);first_frame(&m,0);i=healthy();i.temperature_valid=i.usb_measurement_valid=true;
    sv_mon_apply(&m,m.last_tick,&i);CHECK(!i.temperature_valid && !i.usb_measurement_valid);groups++;
    m.cal.electrical_calibration_approved=true;sv_mon_apply(&m,m.last_tick,&i);
    CHECK(i.usb_measurement_valid && !i.temperature_valid);groups++;
    m.cal.thermal_attachment_approved=true;sv_mon_apply(&m,m.last_tick,&i);CHECK(i.temperature_valid);groups++;
    m.frame.mv[3]=2800;sv_mon_apply(&m,m.last_tick,&i);CHECK(!i.temperature_valid && !i.usb_measurement_valid);groups++;
    setup(&b,&m,0);first_frame(&m,0);i=healthy();i.battery_present=false;
    sv_mon_apply(&m,m.last_tick,&i);CHECK(!i.battery_present);groups++;
    i=healthy();i.usb_measurement_valid=true;sv_power_status_apply(&i,true,true,true);
    CHECK(!i.usb_measurement_valid && !i.external_fault);groups++;
    i=healthy();i.usb_measurement_valid=true;sv_power_status_apply(&i,false,false,true);
    CHECK(!i.usb_measurement_valid && !i.board_budget_valid);groups++;
    i=healthy();sv_power_status_apply(&i,true,false,false);CHECK(i.external_fault);groups++;
    /* Guard: boot with USB attached never clears a previous possible timer fault. */
    sv_control c;sv_config cfg=approved();sv_charge_guard g;
    sv_init(&c,0,&cfg);sv_guard_init(&g);
    c.out.charge_allow=true;sv_guard_apply(&g,&c,5000,true);CHECK(!c.out.charge_allow && g.locked);groups++;
    for(unsigned t=5000;t<6000;t+=10){c.out.charge_allow=true;sv_guard_apply(&g,&c,t,false);CHECK(g.locked);}
    c.out.charge_allow=true;sv_guard_apply(&g,&c,6000,false);CHECK(!g.locked);
    for(unsigned t=6001;t<8001;t+=10){c.out.charge_allow=true;sv_guard_apply(&g,&c,t,true);CHECK(!c.out.charge_allow);}
    c.out.charge_allow=true;sv_guard_apply(&g,&c,8001,true);CHECK(c.out.charge_allow && g.started);groups++;
    c.out.charge_allow=false;sv_guard_apply(&g,&c,8010,true);CHECK(g.locked);
    for(unsigned n=0;n<1000;n++){c.out.charge_allow=true;sv_guard_apply(&g,&c,8020+n,true);CHECK(!c.out.charge_allow);}groups++;
    sv_guard_init(&g);sv_guard_apply(&g,&c,0,false);sv_guard_apply(&g,&c,1001,false);CHECK(g.locked);groups++;
    /* End-to-end host simulation: accepted sensor frame -> control -> final guard. */
    setup(&b,&m,0);m.cal.electrical_calibration_approved=m.cal.thermal_attachment_approved=true;
    sv_init(&c,0,&cfg);sv_guard_init(&g);bool ever=false,stopped=false;
    for(uint32_t t=0;t<=5000;t+=5){
        sv_mon_tick(&m,t,true);i=healthy();i.usb_present=t>=1200;
        sv_mon_apply(&m,t,&i);sv_tick(&c,t,&i);sv_guard_apply(&g,&c,t,i.usb_present);
        if(t<3200)CHECK(!c.out.charge_allow);
        if(c.out.charge_allow)ever=true;
        if(t==3500)b.fail_at=b.transactions+1;
        if(t>3800){CHECK(!c.out.charge_allow);stopped=true;}
    }
    CHECK(ever && stopped && g.locked);CHECK(m.fault==SV_MON_BUS);groups++;
    /* Every signed temperature code outside allowed engineering range is rejected. */
    unsigned rejected=0;
    for(unsigned raw=0;raw<65536;raw+=17){
        setup(&b,&m,0);b.temp=(uint16_t)raw;first_frame(&m,0);
        int val=raw>=32768?(int)raw-65536:(int)raw;
        if(val < -5120 || val > 10880){CHECK(m.fault==SV_MON_RANGE);rejected++;}
        else CHECK(m.frame.valid);
    }CHECK(rejected>2000);groups++;
    printf("{\"groups\":%u,\"assertions\":%u,\"nack_injection_points\":%u,\"hardware_tests\":0}\n",groups,assertions,operations);
    return 0;
}
