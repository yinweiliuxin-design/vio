import json
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4, A3, landscape
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from pypdf import PdfReader

packaged_root=Path(__file__).resolve().parent.parent
root=packaged_root if (packaged_root/'electrical/circuits.json').exists() else Path('outputs/SmartVio-V21-Corrected-Design').resolve()
read=lambda f:json.loads((root/f).read_text(encoding='utf-8'))
pdfmetrics.registerFont(TTFont('YaHei','C:/Windows/Fonts/msyh.ttc',subfontIndex=0))
styles={k:ParagraphStyle(k,fontName='YaHei',fontSize=n,leading=l,wordWrap='CJK',textColor=HexColor('#243937')) for k,n,l in [('body',10,16),('small',8,12),('title',22,30),('sub',12,19)]}
file=root/'V21-Corrections.pdf';c=canvas.Canvas(str(file),pagesize=A4);c.setTitle('智能电子小提琴 V21 已知问题修订与制造前置条件');c.setAuthor('Engineering correction review')
number=0;layout=[]
def para(s,x,y,w,kind='body'):
    p=Paragraph(escape(str(s)).replace('\n','<br/>'),styles[kind]);_,h=p.wrap(w,10000);p.drawOn(c,x,y-h);return y-h
def start(title,size=A4):
    global number
    number+=1;w,h=size;c.setPageSize(size);c.setFillColor(HexColor('#24735e'));c.rect(32,h-37,w-64,3,fill=1,stroke=0);c.setFont('YaHei',8);c.drawString(32,h-24,'SmartVio V21 | 2026-10-02 | DESIGN CORRECTION | HOLD');c.setFillColor(HexColor('#a03d32'));c.drawString(32,23,'不可直接生产 / 未完成真实PCB、完整保护、固定规格与硬件验证');c.drawRightString(w-32,23,str(number));return w,h,para(title,32,h-53,w-64,'title')-14
def finish(y=60):
    assert y>=45,(number,y)
    layout.append({'page':number,'bottom':y});c.showPage()
def prose(title,items):
    w,h,y=start(title)
    for head,body in items:
        y=para(head,32,y,w-64,'sub')-3;y=para(body,32,y,w-64)-16
    finish(y)
def grid(title,headers,rows,widths,per=6,lead=None):
    for offset in range(0,len(rows),per):
        w,h,y=start(title+(' / '+str(offset//per+1) if len(rows)>per else ''),landscape(A4))
        if lead:y=para(lead,32,y,w-64,'small')-10
        data=[[Paragraph(escape(str(v)),styles['small']) for v in row] for row in [headers]+rows[offset:offset+per]]
        t=Table(data,colWidths=widths);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#e8f0ed')),('GRID',(0,0),(-1,-1),.4,HexColor('#bdcec6')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8)]));_,th=t.wrap(w-64,y-45);assert y-th>=45,(title,offset,y-th);t.drawOn(c,32,y-th);finish(y-th)
def drawing(id):
    d=next(x for x in read('verification/drawings.json') if x['id']==id)
    w,h,y=start(d['title'],landscape(A3));iw=w-64;ih=iw*1120/1600
    if ih>y-45:ih=y-45;iw=ih*1600/1120
    c.drawImage(str(root/d['file'].replace('.svg','.png')),(w-iw)/2,y-ih,width=iw,height=ih);finish(y-ih)

s=read('verification/scope.json');t=read('verification/model-tests.json')
prose('V21 已知问题修订包',[
 ('先给结论','已完成12项设计/模型修订，重新生成41张连接与结构研究图。不能把这一版称为“直接生产样机的最终图纸”：原生EDA、真实PCB布线、完整保护、电池包、实体安装与可烧录固件仍缺失。'),
 ('本次用户选择','保持现有效果图的外观风格与喇叭孔位置，比较薄型喇叭。不新增琴体开腔。“可以生产”作为工厂能力反馈记录，不替代新位置的实测宽度、曲率、木厚和孔位。'),
 ('验证的真实范围',f'{t["counts"]["pass"]}项主机模型、逻辑连接、坐标和尺寸算术检查通过，失败{t["counts"]["fail"]}项。实物硬件测试0项；未执行SPICE、ERC、DRC或声学/热/机械仿真。通过项包含对已知不可行方案的正确拦截，不代表整机合格。'),
 ('交付内容',f'{s["physicalComponents"]}条物料候选、{s["logicalPins"]}条逻辑引脚记录、{s["logicalNets"]}个网络。index.html可查看全部电路图；JSON保留未定焊盘、坐标和铜路径为空值。V20原包未覆盖，客户端/后台本轮未修改。'),
 ('使用界限','工厂可据此开展EE/ME审图与补测，不能直接投板、开模、接裸电芯或在琴体钻孔。量产放行也不能由主机脚本代替工程与质量负责人签署。')])
changes=read('verification/changes.json')
grid('01 / 本轮修订及未闭合条件',['编号','已定位问题','本轮修订','仍需验证'],[[x['id'],x['problem'],x['action'],x['remaining']] for x in changes],[70,195,277,235],per=6)
prose('02 / 冻结的用户约束与候选尺寸',[
 ('确认不变','旧琴体、旧拾音器与原穿线孔保留。旧腔净78×47×22mm。原腔近端距琴尾金属基准145mm、远端223mm；允许向琴头重新定位，不新增开腔。'),
 ('外壳与接口','上盖四角螺丝连接琴体；上下壳仅卡扣，下壳不加装配螺丝。四个正面3.5mm音频口加USB-C；不设DOCK、话筒、XLR、48V。VOL/TONE/FX低滚轮和FX/MODE/MIX/BT/PWR五键保持。'),
 ('候选包络，不是加工尺寸','上盖148×49，覆盖X=110..258；浅框140×43；下沉舱76×43×18，X=146..222。已知旧腔22mm只用于旧腔投影内，不能扩展到整块上盖。'),
 ('高度限制','嵌入后非滚轮部分外凸≤5mm，整机厚度≤25mm。本轮继续按含滚轮的更保守总厚研究；名义-18至+6共24mm，不代表已包含公差。'),
 ('坐标纠错','正视控制面时琴头左、琴尾右；u从上盖琴头边向琴尾，实物X从金属件向琴头，X=258-u。已消除图纸方向歧义，但实际基准边和木体量测仍待证据。')])
for id in ['M01-coordinate','M02-envelope','M03-thin-speaker']:drawing(id)
prose('03 / 薄型喇叭取舍与固定结构',[
 ('对比结果','原18mm方案名义堆叠8.1mm失败；直接换10mm薄喇叭而保留旧厚塑料结构仍为5.2mm，失败。S2采用局部薄金属网与薄托盘，名义4.05mm、最大层厚预算4.65mm。只有喇叭尺寸由原厂图确认，其余层厚为待批准工艺预算。'),
 ('候选不是最终选型','PUI AS01008MR-2-R为直径10±0.2mm、厚2.9±0.2mm、8Ω、0.3W候选。其原厂声压条件与整琴演奏不同；不能据此承诺低音、音色或练习音量。必须对原18mm方案与薄型样件做同条件琴声试听。'),
 ('声学与安装限制','不把振膜夹在盖板下；托圈不堵后通气孔；焊片和线材从侧面让位，不叠在喇叭背后。不能在薄喇叭下面再塞PCB。实际木面偏差超过预算时应重算，不挖琴体补偿。'),
 ('四颗固定螺丝','保留上盖四孔概念；ST2.2系列、Ø2.6通孔仅沿用研究输入。最终螺丝长度、头型、导孔和扭矩必须按四点剩余木厚、边距、同批压合板滑牙/破坏/拔出试验确定。不能使用钢螺栓扭矩表代替木体试验。'),
 ('卡扣与承力','卡扣材料牌号、梁根圆角、挂钩和配合槽尚未冻结。上盖框承担端口插拔载荷，信号焊点不能当结构支撑；壳体不增加下壳装配螺丝。')])
drawing('E00-chain')
grid('04 / 核心引脚修正',['位号.引脚','原连接','V21连接'],[[x['ref']+'.'+str(x['pin']),x['was'],x['now']] for x in read('electrical/pin-change-list.json')],[105,260,412],per=8,lead='这是逻辑引脚修改，不是焊盘坐标或铜线路径。全部物理封装待正式EDA核对。')
drawing('A24-01')
prose('05 / 电源键候选的真实边界',[
 ('修复了什么','旧版只把PWR接到MCU，3.3V断电后无法自启动。现在按键接常供电LTC2954-1的PB；EN经100k上拉SYS控制TPS63070；INT给PC4，PE7经电阻控制KILL。使用TS8编号，不混用DFN。'),
 ('启动时序是硬约束','上电固件必须在最短400ms KILL屏蔽窗口内置BOOT_OK。当前没有编译固件、启动测量和掉电恢复试验；增加芯片不等于功能已经闭环。'),
 ('关机不等于隔离电池','充电控制器和功放SYS支路仍有常供电。硬件失钟静音、欠压联锁及异常锁断尚需设计与测试，不能宣称按键已实现整机安全硬关断。'),
 ('电池与充电','新增内部三线电池包接口J501定义，实际连接器未选；删除JP501充电旁路。默认CE禁充保留。EN1/EN2=00是USB100模式，RILIM不在此模式决定输入电流。USB冷启动/功率预算及电池保护仍未完成。')])
drawing('A25-01')
prose('06 / 接口保护修正与剩余风险',[
 ('CC路径','增加TPD2S300候选：端口CC与系统CC分离，系统侧各自5.1k下拉；VBIAS采用100nF/50V候选电容，VPWR/VM接3.3V，FLT接PE8。死电池下拉切换必须用正反插和断电状态实测。'),
 ('USB数据静电路径','USBLC6的供电参考从VBUS_RAW改到受保护USB_5V_SAFE，补本地100nF旁路；原端口电容要求提升至50V。此改动不证明D+/D-持续误接VBUS、断电灌电和瞬态钳位已解决。'),
 ('3.5mm插座','原厂1503 18图的检测触点编号仍有歧义。DA/DB是逻辑标记，不能当焊盘编号。采购样件须按插入/未插入状态查线，并让厂家确认推荐封装；确认之前不投板。'),
 ('各国使用定义','PHONES是立体声TRS；LINE是双声道非平衡，不是平衡TRS；SEND为单声道干声；RETURN为双声道输入。不能把CTIA/OMTP带麦TRRS、平衡TRS和这些接口混为同一标准。线束C01..C07保留明确接法。'),
 ('不可缺的下一轮电路工作','持续外部直流误接、音频输出短路与反灌、拾音高阻端泄漏/静电、USB数据过压、全电池保护与失钟联锁均未完成。需风险工况、器件降额、正式电路及实验室验证。')])
grid('07 / 新增与改动主要器件',['位号','候选型号/规格','作用与未定项'],[
 ['U1301','LTC2954ITS8-1#TRPBF / TS8','常供电按键控制；启动/KILL/关机实测未做'],
 ['U1401','TPD2S300YFFR / YFF9','CC误接保护；焊球方向、封装和ESD未批准'],
 ['C1401','GRM188R71H104KA93D / 100nF 50V','原厂推荐候选；实际料号合规/降额须采购复核'],
 ['LS901','AS01008MR-2-R / Ø10×2.9 nominal','薄型喇叭对比候选，不是声学批准'],
 ['R906','33Ω，MPN未选','独立喇叭数据串联阻尼初值；按边沿/信号完整性调整'],
 ['J501','保护电池包+NTC，三线定义','实物插座、型号、额定电流、电池包未选'],
 ['R1103 / C403','100k上拉 / 100nF本地旁路','消除电源键/ESD供电旧逻辑；封装与工艺未批准'],
 ['U801 / U902','STM32H743VIT6 / MAX98357AETE+','改引脚与独立SAI2-B路径；时钟/DMA尚无固件验证']
],[80,280,417],per=8,lead='完整237条物料候选与833条引脚记录见electrical目录。没有批准BOM，也没有承诺全部器件可采购或可装下。')
prose('08 / 通信、DSP与回归范围',[
 ('通信修复','协议参考模型升V2，拒绝V1帧；校验序号、类型、长度和Buffer；重复authorize不能复位防回放状态。BT_PAIR需本机配对窗口且每窗口只消费一次。授权函数仍是测试入口，不是真实认证实现。'),
 ('路由与故障修复','新增并行路由位图，允许LINE与耳机/蓝牙并行。插入耳机关闭喇叭路由；拔出不自动外放。电源或时钟故障锁存，健康恢复后仍需确认故障并重新选路。'),
 ('DSP修复','限制输入幅度、采样率和块长，避免极大有限值造成状态溢出；AUX单声道回送可复制到左右。喇叭独立高通/峰值限制，缺标定参数默认静音；不改变耳机和LINE频带。800Hz仅模型探索默认，不是最终音色指标。'),
 ('测试数字不要误读',f'{t["counts"]["pass"]}项全部通过，包含负例、回归及算术。没有运行MCU、无线栈、USB主机或实琴；参考模型hardFault归零并不证明模拟SEND已被硬件切断。'),
 ('仍不能宣称','低延迟、稳定A2DP与BLE共存、可靠电池续航、真实喇叭保护、量产校准、全球合规，以及客户端完整功能均未得到本轮验证。')])
issues=read('verification/open-items.json')
grid('09 / 直接生产还缺什么',['编号/责任','未闭合项','需要的真实证据'],[[x['id']+' / '+x['owner'],x['reason'],x['closure']] for x in issues],[120,350,307],per=6)
grid('10 / 琴厂补测回填',['编号','项目','具体记录','实测值/证据'],[[x['id'],x['item'],x['method'],'待工厂测量并附图，不可填写“可以生产”代替数值'] for x in read('assembly/factory-measurements.json')],[50,130,390,207],per=6,lead='同包提供CSV/JSON表。没有重新定位区域的实测数据，无法给出可靠螺丝长度和孔位。')
grid('11 / 生产前工序与焊接数据缺口',['阶段','工厂执行要求','放行证据'],[
 ['EE/ME冻结','结合实测琴体和真器件3D重排；四插口完整包络、插头胶壳和滚轮避让，禁止新增开腔。','签署坐标系、公差链和完整装配STEP。'],
 ['逐焊点定义','每个器件确认厂家焊盘号/方向；每条网络关联实际铜层、线宽、过孔；每个焊点匹配工序。','正式EDA、ERC/DRC、Gerber/钻孔、坐标、BOM和钢网。'],
 ['SMT/焊接','先确认实际PCB、锡膏、钢网、MSL与最弱器件耐热；首件实板测温，不用一个固定烙铁温度代替所有工艺。','SPI、AOI、风险决定的X-ray、首件炉温和返修记录。'],
 ['初次上电','电池和扬声器先隔离；EE批准台架后逐电源域限流验证；异常立即停机。','电流/电压/纹波/温升原始记录。测试值不能用目标代填。'],
 ['固件与音频','完成启动窗口、时钟、DMA/cache、USB和蓝牙驱动；用实测电压标定分支增益与喇叭限制。','可复现固件构建、烧录记录、音频与安全故障报告。'],
 ['装琴与成品','旧拾音线查极性并应力释放；卡扣闭合不夹线；按批准四点导孔/螺丝/扭矩装琴。','无开裂穿透、插拔载荷和装拆试验；最终质量签署。']
],[105,380,292],per=6,lead='20步工艺流转清单见assembly/process-traveler.json，均未执行。这些是制造前置要求，不是已批准的焊接作业指导书。')
prose('12 / 推进顺序与交付文件',[
 ('探索验证','先用评估板/候选样件验证前级噪声、功耗、USB电源、CC、薄喇叭与壳体间隙；不为验证而先开量产模。补齐真实琴体数据，选择声音可接受且装得下的方案。'),
 ('EVT / DVT / PVT','EVT建立正式硬件、固件与工程样机；DVT执行声学、机械、电池、热、EMC/RF及法规设计验证；PVT验证工艺、测试治具、良率和追溯。样本数量、预算、日程由供应商能力与风险决定，不在本报告伪定。'),
 ('本版实际交付','index.html：全部41张研究图；drawings：SVG+PNG；electrical：连接、器件与网络JSON；mechanical：约束和薄喇叭预算；assembly：线材、补测及工艺表；communication：协议V2；reproduce：可重复主机测试。'),
 ('未交付的生产文件','没有可投板Gerber/钻孔、原生EDA、批准BOM/封装、钢网、贴片坐标、可加工机械STEP或每焊点作业卡。未定数据保留空值，不生成看似完整但错误的生产路径。'),
 ('版本与证据','所有补充图纸应带版本、日期、工程签名和散列；禁止混用V18旧高度、V20旧ADC/电源连接或未批准效果图。放行检查脚本只查证据存在与哈希，不认定报告技术正确。')])
src=read('sources/index.json')
fresh=[x for x in src if x.get('checkedThisRevision') is not False]
for offset in range(0,len(fresh),5):
    prose('原厂核对来源 / '+str(offset//5+1),[(x['id']+' / '+x['scope'],x['url']) for x in fresh[offset:offset+5]])
c.save();actual=len(PdfReader(str(file)).pages);assert actual==number
(root/'verification/pdf-build.json').write_text(json.dumps({'pages':number,'layout':layout,'file':file.name,'status':'HOLD'},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pages':number,'bytes':file.stat().st_size,'pdf':str(file)}))
