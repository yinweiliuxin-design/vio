主机模型重测：node reproduce/test.cjs
本脚本不连接硬件，不是MCU固件、SPICE或安全认证。
修改本包circuits.json后可运行node reproduce/render.cjs重生SVG/HTML；PDF需先把SVG渲染为同名PNG，再用Python运行reproduce/report.py，依赖reportlab、pypdf及Windows微软雅黑。
文件改动后应重新生成哈希与人工复核，不能直接沿用旧放行状态。V20增量构建脚本保留在原工作区work/v21，未作为独立生产工具交付。
