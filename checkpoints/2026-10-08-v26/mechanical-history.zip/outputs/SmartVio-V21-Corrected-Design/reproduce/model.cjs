// Host reference only. No authentication implementation, GPIO drivers or firmware binary.
const TYPES={SET_GAIN:1,SET_MODE:2,BT_PAIR:3,GET_STATUS:4,SET_ROUTES:5};
const ROUTES={HP:1,LINE:2,SPK:4,BT:8};
const KNOWN=new Set(Object.values(TYPES));
const seqOK=x=>Number.isInteger(x)&&x>=0&&x<=65535;
function crc16(data){let crc=0xffff;for(const b of data){crc^=b<<8;for(let i=0;i<8;i++)crc=crc&0x8000?((crc<<1)^0x1021)&0xffff:(crc<<1)&0xffff;}return crc;}
function encode(type,seq,payload=Buffer.alloc(0)){
 if(!KNOWN.has(type)||!seqOK(seq)||!Buffer.isBuffer(payload)||payload.length>256)throw Error('Invalid frame');
 const b=Buffer.alloc(10+payload.length);b[0]=83;b[1]=86;b[2]=2;b[3]=type;b.writeUInt16LE(seq,4);b.writeUInt16LE(payload.length,6);payload.copy(b,8);b.writeUInt16LE(crc16(b.subarray(2,b.length-2)),b.length-2);return b;
}
class Parser{
 constructor(){this.buffer=Buffer.alloc(0);this.errors=0;}
 push(chunk){
  if(!Buffer.isBuffer(chunk)||chunk.length>65536)throw Error('Bounded Buffer required');
  const out=[];
  for(const byte of chunk){this.buffer=Buffer.concat([this.buffer,Buffer.from([byte])]);
   while(this.buffer.length>=2){
    if(this.buffer[0]!==83||this.buffer[1]!==86){this.buffer=this.buffer.subarray(1);continue;}
    if(this.buffer.length<8)break;
    const n=this.buffer.readUInt16LE(6);
    if(this.buffer[2]!==2||!KNOWN.has(this.buffer[3])||n>256){this.errors++;this.buffer=this.buffer.subarray(1);continue;}
    const total=n+10;if(this.buffer.length<total)break;
    const b=this.buffer.subarray(0,total);
    if(crc16(b.subarray(2,total-2))!==b.readUInt16LE(total-2)){this.errors++;this.buffer=this.buffer.subarray(1);continue;}
    out.push({type:b[3],seq:b.readUInt16LE(4),payload:Buffer.from(b.subarray(8,total-2))});this.buffer=this.buffer.subarray(total);
   }
  }return out;
 }
 timeout(){if(this.buffer.length)this.errors++;this.buffer=Buffer.alloc(0);}
}
class Device{
 constructor(){this.auth=false;this.lastSeq=null;this.routes=0;this.gain=0;this.powerGood=false;this.clockGood=false;this.fault=true;this.headphones=false;this.speakerAcknowledged=false;this.pairUntil=-1;this.pairing=false;this.pairRequestUsed=false;this.lastTime=0;}
 authorize(){if(this.auth)return false;this.auth=true;this.lastSeq=null;return true;}
 disconnect(){this.auth=false;this.lastSeq=null;this.pairUntil=-1;this.pairing=false;}
 trip(){this.fault=true;this.routes=0;this.speakerAcknowledged=false;this.pairing=false;this.pairUntil=-1;}
 inputs({powerGood,clockGood,externalFault=false}){
  this.powerGood=powerGood===true;this.clockGood=clockGood===true;
  if(!this.powerGood||!this.clockGood||externalFault!==false)this.trip();
  this.externalFault=externalFault!==false;
 }
 acknowledgeFault(){if(!this.powerGood||!this.clockGood||this.externalFault)return false;this.fault=false;this.routes=0;return true;}
 time(now){if(!Number.isSafeInteger(now)||now<0||now<this.lastTime)throw Error('Monotonic time required');this.lastTime=now;if(now>=this.pairUntil)this.pairing=false;}
 physicalPairLongPress(now){this.time(now);if(this.fault||!this.powerGood)return false;this.pairUntil=now+60000;this.pairRequestUsed=false;return true;}
 headphoneEvent(inserted){if(typeof inserted!=='boolean')throw Error('Boolean required');if(this.headphones!==inserted){this.headphones=inserted;this.routes&=~(ROUTES.HP|ROUTES.SPK);this.speakerAcknowledged=false;}}
 execute(f,now=0){
  if(!this.auth)return 'AUTH_REQUIRED';
  if(!f||!seqOK(f.seq)||!Number.isInteger(f.type)||!Buffer.isBuffer(f.payload)||f.payload.length>256)return 'FRAME';
  if(!KNOWN.has(f.type))return 'COMMAND';
  try{this.time(now);}catch{return 'TIME';}
  const d=this.lastSeq===null?1:(f.seq-this.lastSeq+65536)%65536;if(d===0||d>=32768)return 'REPLAY';
  let action;
  if(f.type===TYPES.SET_GAIN){
   if(f.payload.length!==2)return 'LENGTH';const v=f.payload.readInt16LE();if(v< -600||v>0)return 'RANGE';action=()=>{this.gain=10**(v/200);};
  }else if(f.type===TYPES.SET_MODE||f.type===TYPES.SET_ROUTES){
   if(f.payload.length!==1)return 'LENGTH';const value=f.payload[0];if(value>(f.type===2?3:15))return 'RANGE';
   const bits=f.type===2?[0,1,2,4][value]:value;
   if(bits&&this.fault)return 'FAULT';if((bits&1)&&!this.headphones)return 'NO_HEADPHONE';if((bits&4)&&this.headphones)return 'HEADPHONE_PRESENT';
   action=()=>{this.routes=bits;this.speakerAcknowledged=!!(bits&4);};
  }else if(f.type===TYPES.BT_PAIR){
   if(f.payload.length)return 'LENGTH';if(this.fault)return 'FAULT';if(now>=this.pairUntil||this.pairRequestUsed)return 'PHYSICAL_REQUIRED';action=()=>{this.pairing=true;this.pairRequestUsed=true;};
  }else{if(f.payload.length)return 'LENGTH';action=()=>{};}
  action();this.lastSeq=f.seq;return 'OK';
 }
 outputs(){const safe=this.powerGood&&this.clockGood&&!this.fault;return {hp:!!(safe&&this.headphones&&(this.routes&1)),line:!!(safe&&(this.routes&2)),speaker:!!(safe&&!this.headphones&&this.speakerAcknowledged&&(this.routes&4)),bt:!!(safe&&(this.routes&8)),charge:false};}
}
function bounded(x,lo,hi,fallback=0){return Number.isFinite(x)?Math.max(lo,Math.min(hi,x)):fallback;}
const sample=x=>bounded(x,-1,1);
class AudioModel{
 constructor(fs=48000){if(![44100,48000,96000].includes(fs))throw Error('Unsupported sample rate');this.fs=fs;this.delay=new Float64Array(Math.round(.12*fs));this.room=new Float64Array(Math.round(.0297*fs));this.reset();}
 reset(){this.gain=0;this.dcX=0;this.dcY=0;this.di=0;this.ri=0;this.tone=0;this.spkX=0;this.spkY=0;this.delay.fill(0);this.room.fill(0);}
 process(pickup,returnL,returnR,controls={}){
  if(!controls||typeof controls!=='object'||Array.isArray(controls))throw Error('Controls object required');
  if(![pickup,returnL,returnR].every(a=>a instanceof Float32Array||a instanceof Float64Array)||pickup.length>96000||pickup.length!==returnL.length||pickup.length!==returnR.length)throw Error('Bounded matching audio buffers required');
  const n=pickup.length,out={left:new Float64Array(n),right:new Float64Array(n),send:new Float64Array(n),speaker:new Float64Array(n)};
  if(controls.hardFault===true){this.reset();return out;}
  const target=bounded(controls.targetGain??.5,0,1),wet=bounded(controls.wet??.2,0,1),feedback=bounded(controls.feedback??.35,0,.7),toneHz=bounded(controls.toneHz??3500,300,10000,3500);
  const a=Math.exp(-2*Math.PI*toneHz/this.fs),r=Math.exp(-2*Math.PI*20/this.fs),step=1/(.02*this.fs);
  const sh=Math.exp(-2*Math.PI*bounded(controls.speakerHighpassHz??800,300,3000,800)/this.fs);
  // voltsPerFullScale and peakVoltageBudget must come from bench measurements and speaker approval.
  const v=controls.speakerVoltsPerFullScale,b=controls.speakerPeakVoltageBudget;
  const calibrated=Number.isFinite(v)&&v>0&&v<=20&&Number.isFinite(b)&&b>0&&b<=2;
  const ceiling=calibrated?Math.min(.8,b/v):0;
  for(let i=0;i<n;i++){
   const x=sample(pickup[i]);out.send[i]=x;
   const h=x-this.dcX+r*this.dcY;this.dcX=x;this.dcY=h;this.tone=(1-a)*h+a*this.tone;
   const d=this.delay[this.di];this.delay[this.di]=bounded(this.tone+feedback*d,-8,8);this.di=(this.di+1)%this.delay.length;
   const rv=this.room[this.ri];this.room[this.ri]=bounded(this.tone+.5*rv,-8,8);this.ri=(this.ri+1)%this.room.length;
   const desired=controls.mute===true?0:target;this.gain+=Math.max(-step,Math.min(step,desired-this.gain));
   const voice=(1-wet)*this.tone+wet*(.6*d+.4*rv);
   const rl=sample(returnL[i]),rr=controls.monoReturn===true?rl:sample(returnR[i]);
   out.left[i]=bounded(this.gain*(voice+.5*rl),-.8,.8);out.right[i]=bounded(this.gain*(voice+.5*rr),-.8,.8);
   const mono=(out.left[i]+out.right[i])/2,hi=sh*(this.spkY+mono-this.spkX);this.spkX=mono;this.spkY=hi;
   out.speaker[i]=bounded(hi,-ceiling,ceiling);
  }return out;
 }
}
class SystemModel{
 constructor(fs=48000){this.device=new Device();this.audio=new AudioModel(fs);}
 process(pickup,left,right,calibration={}){
  const d=this.device,state=d.outputs();
  const a=this.audio.process(pickup,left,right,{...calibration,targetGain:d.gain,hardFault:d.fault||!d.powerGood||!d.clockGood});
  const gated=(values,on)=>on?values:new Float64Array(values.length);
  // This asserts desired routing only. Physical analog SEND isolation is an open hardware item.
  return {hpL:gated(a.left,state.hp),hpR:gated(a.right,state.hp),lineL:gated(a.left,state.line),lineR:gated(a.right,state.line),speaker:gated(a.speaker,state.speaker),btL:gated(a.left,state.bt),btR:gated(a.right,state.bt),send:a.send};
 }
}
module.exports={TYPES,ROUTES,crc16,encode,Parser,Device,AudioModel,SystemModel};
