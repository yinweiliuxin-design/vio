const fs=require('node:fs'),path=require('node:path');
const packagedRoot=path.resolve(__dirname,'..');
const root=fs.existsSync(path.join(packagedRoot,'electrical/circuits.json'))?packagedRoot:path.resolve('outputs/SmartVio-V21-Corrected-Design');
const read=f=>JSON.parse(fs.readFileSync(path.join(root,f)));const write=(f,x)=>fs.writeFileSync(path.join(root,f),typeof x==='string'?x:JSON.stringify(x,null,2));
const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const txt=(x,y,s,size=18,color='#203b3b',anchor='start')=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" text-anchor="${anchor}">${e(s)}</text>`;
const rect=(x,y,w,h,fill='#e6f1ef',stroke='#39716b')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
const line=(x,y,a,b,color='#39716b',dash='')=>`<line x1="${x}" y1="${y}" x2="${a}" y2="${b}" stroke="${color}" stroke-width="2" stroke-dasharray="${dash}"/>`;
const circle=(x,y,r,fill='#fff')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" stroke="#39716b" stroke-width="2"/>`;
const drawings=[];
function save(id,title,body,scope='工程修订研究 / 不是可加工生产图'){
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1120" viewBox="0 0 1600 1120"><rect width="1600" height="1120" fill="white"/><g font-family="Microsoft YaHei,Arial,sans-serif" letter-spacing="0">${txt(48,52,title,28)}${txt(48,88,'V21 | HOLD | '+scope,18,'#a03d32')}${line(48,110,1552,110)}${body}${line(48,1060,1552,1060)}${txt(48,1093,'无已布线PCB、Gerber、最终封装/扭矩或实物测试；禁止将本页当作投产依据',18,'#a03d32')}</g></svg>`;
 const file='drawings/'+id+'.svg';write(file,svg);drawings.push({id,file,title,width:1600,height:1120});
}
const m=read('mechanical/requirements.json');let b='';const k=8.4,x=u=>150+u*k,y=v=>210+v*k;
b+=txt(150,155,'琴头侧 / X较大',20)+txt(1394,155,'琴尾侧 / X较小',20,'#203b3b','end');
b+=rect(x(0),y(0),148*k,49*k,'#f5f8f7')+rect(x(35),y(1),78*k,47*k,'#fbefd8','#ad7434')+rect(x(36),y(3),76*k,43*k,'#dcece7');
for(const [u,v]of m.detailStudy.coverHoles)b+=circle(x(u),y(v),10)+txt(x(u),y(v)+(v<20?28:-20),'孔位候选',12,'#99432d','middle');
for(const [i,u]of [57,78,98].entries())b+=rect(x(u-5),y(8),10*k,3*k,'#333')+txt(x(u),y(6),['VOL','TONE','FX'][i],15,'#203b3b','middle');
for(const p of m.coordinateSystem.portCentersStudy){b+=(p.id==='USB-C'?rect(x(p.u-4.5),y(p.v-1.8),9*k,3.6*k,'#333'):circle(x(p.u),y(p.v),14))+txt(x(p.u),y(p.v+5),p.id,13,'#203b3b','middle');}
for(const [i,u]of [51,67,83,99,115].entries())b+=circle(x(u),y(43),9)+txt(x(u),y(47.5),['FX','MODE','MIX','BT','PWR'][i],12,'#203b3b','middle');
b+=circle(x(23),y(26),5*k,'#e3eceb')+txt(x(23),y(26)+5,'10mm',14,'#203b3b','middle');
b+=line(x(0),180,x(148),180)+txt(x(74),171,'148 × 49mm候选；局部u向琴尾增加',19,'#203b3b','middle');
b+=txt(70,680,'坐标定义：实物X从琴尾金属基准朝琴头增加；正视图u从上盖琴头端朝琴尾增加。X=258-u。',21);
b+=txt(70,725,'旧腔：X=145..223，对应u=113..35；下沉舱：X=146..222，对应u=112..36。',21);
b+=txt(70,770,'喇叭中心研究位置u=23 → X=235，位于旧腔外的实木上方。不能用22mm腔深为它计算空间。',21,'#a03d32');
b+=txt(70,815,'接口中心在原腔投影内，不等于插座全包络、焊脚、支架、插头外壳都能安装。',21);
b+=txt(70,860,'四孔仍仅在上盖；原研究Ø2.6与ST2.2系列不是采购/钻孔批准值。琴体四点木厚未提供。',21);
b+=txt(70,905,'正面风格保持；图中口、键与滚轮坐标沿用研究布局，待真实封装与插头干涉检查。',21);
b+=txt(70,950,'头尾方向已统一，实物基准边与左右侧支撑仍须工厂标记照片确认。',21);
save('M01-coordinate','M01 / 外观布局与坐标纠错',b);
b='';
const yy=z=>435-z*13;
b+=rect(90,yy(0),1400,22*13,'#e0e2dc','#707c72')+rect(430,yy(0),720,22*13,'#fff');
b+=rect(135,yy(4.65),1320,1.2*13,'#b8cfcb')+rect(445,yy(0),690,18*13,'#e0edf4');
b+=rect(790,yy(6),80,1.35*13,'#333');
b+=line(60,yy(0),1510,yy(0),'#a03d32','8 6');
b+=txt(95,160,'上盖148×49；浅框140×43；中央下沉舱76×43×18mm均为候选尺寸。',22);
b+=txt(95,205,'仅原腔上方的主体下沉；端部薄喇叭在实木上方。上下壳只卡扣，上盖四孔固定琴体。',21);
b+=txt(110,330,'非滚轮最高≤5mm',19)+txt(890,330,'滚轮研究最高+6mm',19);
b+=txt(480,610,'下沉舱外底 z=-18；旧腔底 z=-22',21);
b+=txt(480,662,'名义底部余量4mm，不代表已含线束、公差与底面翘曲',19);
b+=txt(95,795,'总厚名义24mm（-18至+6）；实际极限≤25mm是否满足仍取决于批准公差和装配。',21);
b+=txt(95,840,'插拔承力路径：插座机械支架 → 上盖刚性框 → 四颗琴体固定螺丝 → 胶合板；不依赖焊点承力。',21);
b+=txt(95,885,'下壳四角只做开放避让，不增加装配螺丝；卡扣梁、挂钩、配合槽和材料仍须CAD/试样冻结。',21);
b+=txt(95,930,'本剖面是高度包络示意，不表示电池和PCB已装下。不得加深旧腔，不得擅定螺丝长度/扭矩。',21,'#a03d32');
save('M02-envelope','M02 / 固定关系与嵌入高度包络',b);
b='';const s2=m.speakerOptions[2],colors=['#b7cfca','#e6cb9b','#bdd8e7','#f5f7f7','#929f9d','#e5c19b','#dadfd9'];
b+=txt(75,158,'保留原喇叭孔区：S0=8.1mm失败；S1=5.2mm失败；S2最大层厚预算=4.65mm。',22);
let yb=835;
for(let i=0;i<s2.layers.length;i++){const a=s2.layers[i],h=a.max*120;b+=rect(115,yb-h,430,h,colors[i]);yb-=h;}
b+=line(80,835-5*120,585,835-5*120,'#a03d32','8 6')+txt(95,217,'5.00mm限高',20,'#a03d32');
b+=txt(95,880,'高度预算累加示意；非实际零件层序',17);
for(const [i,a]of s2.layers.entries()){const Y=260+i*66;b+=rect(650,Y-20,18,18,colors[i])+txt(686,Y,a.name,20)+txt(1470,Y,a.nominal.toFixed(2)+' / '+a.max.toFixed(2)+' mm',20,'#203b3b','end');}
b+=txt(650,203,'各层：名义 / 最大预算',20);
b+=txt(650,765,'合计4.05 / 4.65；剩余0.35不是已验证余量。',21,'#a03d32');
b+=txt(650,810,'仅喇叭2.9±0.2mm来自原厂；其余为待批准工艺预算。',18);
b+=txt(75,935,'薄喇叭：PUI AS01008MR-2-R，Ø10±0.2mm；8Ω / 0.3W。独立托圈，不封后孔，不压振膜。',20);
b+=txt(75,978,'线从侧槽出；口袋Ø10.6±0.1仅研究值。必须做琴声试听、反馈啸叫、振膜净空和网罩强度验证。',20);
save('M03-thin-speaker','M03 / 薄型喇叭比较与尺寸链',b);
b='';
const box=(x,y,w,h,a,d)=>rect(x,y,w,h)+txt(x+20,y+32,a,21)+txt(x+20,y+63,d,16);
b+=box(65,170,410,94,'旧拾音器 / 原穿线孔','C07 → JPU → 高阻前置；保护未闭合');
b+=box(570,170,360,94,'ADC / STM32 DSP','独立RETURN混音；不回灌SEND');
b+=box(1020,170,490,94,'SAI2-A → DAC / A2DP源','耳机 / LINE / BT并行路由候选');
b+=box(65,425,410,94,'缓冲后的模拟干声','独立FX SEND → 效果器输入');
b+=box(570,425,360,94,'3.5mm AUX / RETURN','外部效果器回送 / 伴奏输入');
b+=box(1020,425,490,94,'SAI2-B → MAX98357A','独立喇叭高通/限幅 → BTL输出');
b+=box(65,750,410,94,'USB2设备 / BLE控制','无话筒、无DOCK；并非已联调');
b+=box(570,750,360,94,'协议V2参考模型','授权、配对窗口、故障锁存');
b+=box(1020,750,490,94,'10mm薄喇叭候选','无标定参数时数字分支保持静音');
b+=line(475,217,570,217)+line(930,217,1020,217)+line(250,264,250,425)+line(750,425,750,264)+line(930,250,975,250)+line(975,250,975,475)+line(975,475,1020,475)+line(1260,519,1260,750);
b+=txt(75,620,'SAI2-B与A共享时钟但分离数据；RM/CubeMX、DMA/cache与实际时序还没有固件验证。',21);
b+=txt(75,660,'原BTL负端禁止接地，禁止把喇叭输出接耳机。蓝牙音响延迟不能用主机模型证明。',21,'#a03d32');
b+=txt(75,940,'电源：USB → eFuse → BQ24074(SYS) → TPS63070；A24独立电源键；A25保护CC。',21);
b+=txt(75,980,'充电仍默认禁止；电池包未选。参考模型不等于实物功能已完成。',21,'#a03d32');
save('E00-chain','E00 / 修订后的拾音、音频、通信与电源链路',b);
function wrap(s,max){const out=[];let a='',w=0;for(const ch of String(s)){const n=ch.charCodeAt(0)>255?2:1;if(w+n>max){out.push(a);a='';w=0;}a+=ch;w+=n;}if(a)out.push(a);return out;}
for(const sh of read('electrical/circuits.json')){
 const pieces=[];for(const c of sh.components)for(let st=0;st<c.pins.length;st+=17)pieces.push({...c,pins:c.pins.slice(st,st+17),continued:st>0});
 let page=1,body='',col=0,Y=160;
 const flush=()=>{if(body){save(sh.id+'-'+String(page++).padStart(2,'0'),sh.id+' / '+sh.title,body,'同名网络相连；逻辑连接图，不是通过ERC的EDA原理图');body='';col=0;Y=160;}};
 for(const c of pieces){
  const titles=wrap(c.ref+' | '+c.value+(c.continued?' [续]':''),68),head=27*titles.length+12,h=head+(c.pins.length===2?91:36*c.pins.length+25);
  if(Y+h>1032){if(col===0){col=1;Y=160;}else flush();}
  const X=55+col*785;
  for(const [i,t]of titles.entries())body+=txt(X,Y+i*27,t,17);
  const cy=Y+head;
  if(c.pins.length===2){body+=line(X+10,cy+20,X+260,cy+20)+line(X+310,cy+20,X+680,cy+20);
   if(c.type==='C')body+=line(X+273,cy+4,X+273,cy+36)+line(X+297,cy+4,X+297,cy+36)+line(X+260,cy+20,X+273,cy+20)+line(X+297,cy+20,X+310,cy+20);
   else body+=rect(X+260,cy+8,50,24,'white')+(c.type==='R'?'':txt(X+285,cy+26,c.type,12,'#203b3b','middle'));
   body+=txt(X+10,cy+54,c.pins[0].number+': '+(c.pins[0].net||'NC'),15)+txt(X+680,cy+77,c.pins[1].number+': '+(c.pins[1].net||'NC'),15,'#203b3b','end');
  }else{body+=rect(X+5,cy-6,260,36*c.pins.length+8);for(const[i,p]of c.pins.entries()){const py=cy+20+i*36;body+=txt(X+250,py,p.name,12,'#203b3b','end')+line(X+265,py-5,X+345,py-5)+txt(X+285,py-13,p.number,12)+txt(X+360,py,p.net||'NC',15,p.net?'#146e5a':'#a03d32');}}
  Y+=h+15;
 }flush();
}
write('verification/drawings.json',drawings);
const changes=read('verification/changes.json'),tests=read('verification/model-tests.json'),parts=read('electrical/component-register.json'),issues=read('verification/open-items.json'),sources=read('sources/index.json');
function table(head,rows){return `<div class="table-wrap"><table><thead><tr>${head.map(x=>'<th>'+e(x)+'</th>').join('')}</tr></thead><tbody>${rows.map(r=>'<tr>'+r.map(x=>'<td>'+e(x)+'</td>').join('')+'</tr>').join('')}</tbody></table></div>`;}
let html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>V21 一体机工程修订</title><style>*{box-sizing:border-box}body{margin:0;font-family:"Microsoft YaHei",Arial,sans-serif;color:#253937;background:#fff;line-height:1.7;letter-spacing:0}header,main{max-width:1240px;margin:auto;padding:24px}header{border-bottom:4px solid #2e7967}h1{font-size:28px;line-height:1.4;margin:8px 0}h2{font-size:22px;margin:34px 0 12px}h3{font-size:17px}a{color:#126a59;overflow-wrap:anywhere}p,td,li{overflow-wrap:anywhere}nav{display:flex;flex-wrap:wrap;gap:20px}.status{color:#983a29;font-weight:bold}.summary{background:#f3f6f4;border-left:4px solid #2e7967;padding:16px}figure{margin:24px 0}figure img{width:100%;height:auto;border:1px solid #dce4df}figcaption{font-size:14px;color:#52605a}table{width:100%;border-collapse:collapse;min-width:600px;font-size:14px}th,td{text-align:left;vertical-align:top;padding:10px;border:1px solid #d5ded8}th{background:#edf3f1}.table-wrap{overflow:auto}details{border-bottom:1px solid #d4dcd8;padding:12px 0}summary{cursor:pointer;font-weight:bold}code{font-size:14px}footer{border-top:1px solid #d5ded8;padding:24px;font-size:13px}ul{padding-left:24px}@media(max-width:600px){header,main{padding:16px}h1{font-size:24px}}</style><header><div class="status">V21 / HOLD / 不可直接生产</div><h1>智能电子小提琴一体机：已知问题修订</h1><p>保持现有外观风格，比较薄型喇叭；上盖四孔固定琴体，上下壳仅卡扣，不新增琴体开腔。</p><nav><a href="#changes">修订</a><a href="#mechanical">结构</a><a href="#electrical">电路</a><a href="#factory">工厂资料</a><a href="#validation">验证</a><a href="V21-Corrections.pdf">PDF报告</a></nav></header><main><section class="summary"><strong>真实状态</strong><p>${changes.length}项设计/模型修订；${tests.counts.pass}项主机、连接和算术检查通过；实物测试0项。没有最终PCB/Gerber、完整保护、电池选型、螺丝扭矩或可烧录固件。此包用于纠错和工程签审，不能改名当作最终生产图。</p></section><h2 id="changes">01 / 修订记录</h2>`;
html+=table(['编号','问题','本次修改','仍待完成'],changes.map(x=>[x.id,x.problem,x.action,x.remaining]));
html+='<h2 id="mechanical">02 / 结构与薄型喇叭</h2>';
for(const d of drawings.filter(d=>d.id.startsWith('M')))html+=`<figure><a href="${d.file}"><img src="${d.file}" alt="${e(d.title)}"></a><figcaption>${e(d.title)}，研究图，不是钻孔/加工模板。</figcaption></figure>`;
html+=`<details><summary>上轮外观参考，不是本轮生产装配证明</summary><figure><img src="reference/appearance-reference.png" alt="用户要求保留的外观风格参考"><figcaption>V19效果图。内置喇叭、元件尺寸及实物装配以工程验证为准，不按此图制造。</figcaption></figure></details><h2 id="electrical">03 / 逐引脚电路连接</h2><p>下列图由修订后同一份 circuits.json 生成。网络名相同表示逻辑相连；不表示铜箔路径和封装已确认。DA/DB仍是待确认的插座检测触点，不是厂家焊盘号。</p>`;
html+=`<figure><img src="drawings/E00-chain.svg" alt="修订全链路"><figcaption>音频、通信与电源候选架构</figcaption></figure>`;
for(const sh of read('electrical/circuits.json')){html+=`<details><summary>${sh.id} / ${e(sh.title)}</summary><ul>${sh.notes.map(n=>'<li>'+e(n)+'</li>').join('')}</ul>`;for(const d of drawings.filter(d=>d.id.startsWith(sh.id+'-')))html+=`<figure><a href="${d.file}"><img loading="lazy" src="${d.file}" alt="${e(d.id)}"></a></figure>`;html+='</details>';}
html+=`<h2 id="factory">04 / 工厂数据交接</h2><p><a href="electrical/component-register.json">${parts.length}条物料候选记录</a> · <a href="electrical/pin-net-register.json">逐引脚连接</a> · <a href="electrical/net-register.json">逐网络端点</a> · <a href="assembly/cable-register.json">随琴线材定义</a> · <a href="assembly/factory-measurements.csv">工厂必测表CSV</a> · <a href="assembly/factory-measurements.json">必测表JSON</a> · <a href="communication/protocol.json">通信协议V2</a></p>`;
html+=table(['编号','未闭合项','关闭依据'],issues.map(x=>[x.id,x.reason,x.closure]));
html+=`<p class="status">“可以生产”未包含重新定位区域的数字测量记录。固定螺丝长度、扭矩、板上坐标和走线路径继续标为未定，不伪填。</p><h2 id="validation">05 / 验证范围</h2>`;
html+=table(['类别','结果'],[['主机模型/逻辑连接/算术',`${tests.counts.pass}通过 / ${tests.counts.fail}失败`],['实物硬件测试','0；没有样机上电、声学、热、无线或安装测试'],['EDA与电路仿真','未运行ERC/DRC/SPICE'],['客户端与后台','保持既有版本；本轮未测试或修改'],['制造放行','HOLD；证据检查脚本不自动签发生产批准']] );
html+='<p><a href="verification/model-tests.json">完整测试记录</a> · <a href="verification/release-result.json">放行阻断结果</a> · <a href="verification/dvp.json">未执行的DVP计划</a></p><h2>06 / 原厂资料与查阅范围</h2>';
html+='<ul>'+sources.map(s=>`<li><a href="${e(s.url)}">${e(s.id)}</a>：${e(s.scope)}${s.checkedThisRevision===false?'（继承V20，本轮未重新核对）':''}</li>`).join('')+'</ul></main><footer>2026-10-02 | 设计修订包，不构成制造、认证、声学或安全批准。完整交付以文件哈希清单为准。</footer></html>';
write('index.html',html);
console.log(JSON.stringify({drawings:drawings.length,html:path.join(root,'index.html')}));
