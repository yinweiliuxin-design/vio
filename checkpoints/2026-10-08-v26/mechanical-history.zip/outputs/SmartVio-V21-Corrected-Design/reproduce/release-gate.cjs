const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const REQUIRED=['nativeEda','approvedFootprints','routedPcb','erc','drc','gerberDrill','componentPlacement','completeProtection','approvedBattery','bodyMeasurements','mechanicalFit','approvedScrewsTorque','firmwareBinary','benchSafety'];
function evaluate(input,root){
 const base=fs.realpathSync(root),results=[];
 for(const id of REQUIRED){
  const g=input?.gates?.[id];let status='MISSING_EVIDENCE';
  if(g?.passed===true&&typeof g.evidence==='string'&&typeof g.reviewer==='string'&&g.reviewer.trim()&&typeof g.sha256==='string'){
   try{
    const file=fs.realpathSync(path.resolve(base,g.evidence)),relative=path.relative(base,file);
    if(relative.startsWith('..')||path.isAbsolute(relative))status='OUTSIDE_PACKAGE';
    else if(!fs.statSync(file).isFile())status='NOT_FILE';
    else if(crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==g.sha256)status='HASH_MISMATCH';
    else status='EVIDENCE_PRESENT';
   }catch{status='UNREADABLE_EVIDENCE';}
  }results.push({id,status});
 }
 // Presence/hash checks cannot establish that an engineering report is correct.
 return {release:'HOLD',automaticProductionRelease:false,reason:results.every(x=>x.status==='EVIDENCE_PRESENT')?'Human technical acceptance still required':'Missing or invalid release evidence',results};
}
module.exports={REQUIRED,evaluate};
