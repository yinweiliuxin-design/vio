"""Generate editable KiCad capture from the V23 logical circuit, without releasing it."""
import copy
import json
import math
import re
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'reference' / 'v25-circuits.json'
EDA = ROOT / 'eda'
PROJECT = 'SmartVio'
NS = uuid.UUID('c685bbf5-4501-4b05-863b-4d22a3de6523')
uid = lambda key: str(uuid.uuid5(NS, key))
q = lambda value: json.dumps(str(value), ensure_ascii=False)
fx = '(effects (font (size 1.0 1.0)))'
parts = json.loads(SOURCE.read_text(encoding='utf-8'))
mapping_path = ROOT / 'electrical' / 'footprint-map.json'
mapping = json.loads(mapping_path.read_text()) if mapping_path.exists() else {}


def role(c, p):
    if 'electricalType' in p:
        return p['electricalType']
    n = p['name'].upper()
    explicit = {'U501': {'11': 'passive'}, 'U1101': {'8': 'passive'},
                'U401': {'5': 'power_in'}, 'U1501': {'8': 'power_in'},
                'U701': {'1':'power_in','3':'power_in','10':'input','11':'input','16':'input'},
                'U601': {'25':'input','26':'input'},'U801': {'20':'power_in'},
                'U1801': {'1':'input','7': 'no_connect'}}
    if p['number'] in explicit.get(c['ref'], {}):
        return explicit[c['ref']][p['number']]
    if c['type'] not in ('IC', 'MODULE'):
        return 'passive'
    if n in ('NC', 'UNUSED'):
        return 'no_connect'
    if n in ('VOUT', 'OUT', '3V3_OUT', 'LDO', 'VREF', 'VAUX'):
        return 'power_out'
    if n.startswith(('VINL','VINR')):
        return 'input'
    if re.match(r'^(GND|AGND|DGND|PGND|SGND|VSS|VDD|VDDA|VSSA|AVDD|DVDD|IOVDD|VBAT|VIN$|V_PLUS|V_MINUS|V\+|V-|VPWR|VM$)', n) or n == '3V3' or n == 'PAD':
        return 'power_in'
    if n in ('BAT', 'IN', 'HPVDD', 'HPVSS'):
        return 'passive'
    if n in ('SDA', 'SCL', 'CC1', 'CC2') or n.startswith(('PA', 'PB', 'PC', 'PD', 'PE', 'IO')):
        return 'bidirectional'
    if n in ('PG', 'PGOOD', 'CHG', 'FLT', 'FLT_N', 'INT_N', 'ALERT', 'ALERT_RDY'):
        return 'open_collector'
    if n.startswith(('OUT', 'DOUT', 'TXD', 'MISO')):
        return 'output'
    if n.startswith(('IN+', 'IN-', 'IN_', 'INL', 'INR', 'AIN', 'VINL', 'VINR')):
        return 'input'
    if n in ('EN', 'EN_N', 'EN1', 'EN2', 'CE', 'SD_MODE', 'DIN', 'BCLK', 'LRCLK', 'SCKI', 'SCK', 'SCL', 'ADDR', 'ADD0', 'KILL', 'MODE', 'G0', 'G1', 'FB', 'FB2', 'PS_SYNC', 'VSEL', 'EN_UVLO', 'OVLO') or n.startswith('SEL'):
        return 'input'
    if n.startswith(('IN_A', 'IN_B', 'IN_C', 'IN_D')):
        return 'input'
    return 'bidirectional'


def geometry(c):
    n = len(c['pins'])
    simple = n == 2 and c['type'] in ('R', 'C', 'L')
    if simple:
        return 2.54, 7.62, [(c['pins'][0], -7.62, 0, 0), (c['pins'][1], 7.62, 0, 180)]
    left_n = math.ceil(n / 2)
    h = max(7.62, (left_n + 1) * 2.54)
    pp = []
    for i, p in enumerate(c['pins']):
        right = i >= left_n
        row = i - left_n if right else i
        y = (left_n - 1) * 1.27 - row * 2.54
        pp.append((p, 25.4 if right else -25.4, y, 180 if right else 0))
    return h, 25.4, pp


def library(c, embedded=True):
    name = c['ref']
    libname = 'SmartVio:' + name if embedded else name
    h, w, pp = geometry(c)
    bodyw = w - 5.08
    s = f'(symbol {q(libname)} (pin_names (offset 0.508)) (in_bom yes) (on_board yes)\n'
    s += f'(property "Reference" {q(re.sub(r"[^A-Z]", "", name))} (at 0 {-h/2-3.81} 0) {fx})\n'
    s += f'(property "Value" {q(c["value"])} (at 0 {-h/2-1.27} 0) {fx})\n'
    s += f'(symbol {q(name+"_0_1")} (rectangle (start {-bodyw} {h/2}) (end {bodyw} {-h/2}) (stroke (width 0.254) (type default)) (fill (type background))))\n'
    s += f'(symbol {q(name+"_1_1")}\n'
    for p, x, y, angle in pp:
        s += f'(pin {role(c,p)} line (at {x} {y} {angle}) (length 5.08) (name {q(p["name"])} {fx}) (number {q(p["number"])} {fx}))\n'
    return s + '))\n'


def text(value, x, y, size=1.27):
    return f'(text {q(value)} (at {x} {y} 0) (effects (font (size {size} {size})) (justify left)) (uuid {uid(value+str(x)+str(y))}))\n'


def capture(name, components, title, pageid, project=PROJECT, parent_uuid=None):
    root_uuid = uid(project)
    instance_path = '/' + root_uuid + ('/' + pageid if parent_uuid else '')
    sid = uid(name + project)
    s = f'(kicad_sch (version 20260101) (generator "smartvio_native_capture") (uuid {root_uuid if not parent_uuid else sid}) (paper "A2")\n'
    s += f'(title_block (title {q(title)}) (date "2026-10-08") (rev "V25 REVIEW") (company "SmartVio") (comment 1 "ENGINEERING CAPTURE - NOT RELEASED FOR MANUFACTURE"))\n'
    s += '(lib_symbols\n' + ''.join(library(c) for c in components) + ')\n'
    s += text(title, 15, 15, 2.0)
    s += text('Pin-level capture. Global net labels connect sheets. Review findings remain open.', 15, 21)
    heights = [32., 32., 32., 32.]
    for c in components:
        h, w, pp = geometry(c)
        col = min(range(4), key=lambda i: heights[i])
        x, y = 78 + col * 140, heights[col] + h / 2 + 10
        x, y = round(x/1.27)*1.27, round(y/1.27)*1.27
        heights[col] += h + 26
        if heights[col] > 365:
            raise ValueError('Page overflow ' + name)
        ref = c['ref']
        footprint = mapping.get(ref, {}).get('id') or ''
        on_board = 'no' if mapping.get(ref, {}).get('board', '').startswith('external-') else 'yes'
        s += f'(symbol (lib_id {q("SmartVio:"+ref)}) (at {x} {y} 0) (unit 1) (in_bom yes) (on_board {on_board}) (dnp no) (uuid {uid(project+ref)})\n'
        # Values are shortened only visually; the complete specification remains a field.
        val = c['mpn'] or c['value'].split('/')[0].split(';')[0]
        if len(val) > 45:
            val = val[:42] + '...'
        s += f'(property "Reference" {q(ref)} (at {x} {y-h/2-6} 0) {fx})\n'
        s += f'(property "Value" {q(val)} (at {x} {y-h/2-3} 0) {fx})\n'
        for key, value in [('Footprint',footprint),('Specification',c['value']),('MPN',c.get('mpn') or ''),('Release','HOLD - design review required')]:
            s += f'(property {q(key)} {q(value)} (at {x} {y} 0) (effects (font (size 1 1)) hide))\n'
        s += f'(instances (project {q(project)} (path {q(instance_path)} (reference {q(ref)}) (unit 1)))))\n'
        for p, px, py, angle in pp:
            ax, ay = x + px, y - py
            if p['net'] is None:
                s += f'(no_connect (at {ax} {ay}) (uuid {uid(project+ref+p["number"]+"nc")}))\n'
            else:
                bx = ax + (5.08 if px > 0 else -5.08)
                s += f'(wire (pts (xy {ax} {ay}) (xy {bx} {ay})) (stroke (width 0) (type default)) (uuid {uid(project+ref+p["number"]+"wire")}))\n'
                rot = 0 if px < 0 else 180
                s += f'(global_label {q(p["net"])} (shape passive) (at {bx} {ay} {rot}) (effects (font (size 0.85 0.85)) (justify {"left" if px<0 else "right"})) (uuid {uid(project+ref+p["number"]+"label")}))\n'
    if not parent_uuid:
        s += '(sheet_instances (path "/" (page "1")))\n'
    return s + ')\n'

