"""Get public manufacturer characteristic sheets, with explicit failed access records."""
import hashlib
import json
from pathlib import Path
import sys
import urllib.request
from pypdf import PdfReader
import pypdfium2 as pdfium

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "sources"
OUT.mkdir(exist_ok=True)
PARTS = ["C2012X7R1E105K085AB", "C2012X7R1E225K125AB",
         "C2012X7R1E475K125AB", "C3216X7R1E106K160AB", "C3216X5R1C226M160AB"]
URLS = {p: "https://product.tdk.cn/system/files/dam/doc/product/capacitor/ceramic/mlcc/charasheet/" + p.lower() + ".pdf" for p in PARTS}
for p in ["C0805C225K3RACTU", "C0805C105K3RACTU", "C0805C475K3RACTU",
          "C1206C106K3RACTU", "C1206C226M3RACTU"]:
    URLS[p] = "https://www.yageogroup.com/download/specsheet/" + p
URLS["TDK-spec-current"] = "https://product.tdk.cn/system/files/dam/doc/product/capacitor/ceramic/mlcc/specification/mlccspec_commercial_general_midvoltage_en.pdf"
manifest = []
for name, url in URLS.items():
    target = OUT / (name + ".pdf")
    row = {"id": name, "url": url, "file": str(target.relative_to(ROOT))}
    try:
        if not target.exists():
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=15) as response:
                data = response.read()
                row["final_url"] = response.url
            if not data.startswith(b"%PDF"):
                raise ValueError("Response is not PDF")
            target.write_bytes(data)
        data = target.read_bytes()
        reader = PdfReader(target)
        row.update(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data), pages=len(reader.pages), status="PDF_FETCHED")
        txt = "\n".join(f"PAGE {i+1}\n{p.extract_text()}" for i, p in enumerate(reader.pages))
        (OUT / (name + ".txt")).write_text(txt, encoding="utf-8")
        if name != "TDK-spec-current":
            doc = pdfium.PdfDocument(target)
            for i in range(len(doc)):
                doc[i].render(scale=1.5).to_pil().save(OUT / f"{name}-p{i+1}.png")
    except Exception as exc:
        row.update(status="ACCESS_FAILED_NOT_EVIDENCE", error=str(exc))
    manifest.append(row)
    print(name, row["status"], flush=True)
    (ROOT / "curve-source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
