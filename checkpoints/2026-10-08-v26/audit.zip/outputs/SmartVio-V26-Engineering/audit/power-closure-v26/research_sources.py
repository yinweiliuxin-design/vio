"""Fetch only primary component evidence; write only this audit directory."""
import hashlib
import json
from pathlib import Path
import sys
import urllib.request
from pypdf import PdfReader

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "sources"
OUT.mkdir(exist_ok=True)
PARTS = ["C2012X7R1E105K085AB", "C2012X7R1E225K125AB",
         "C2012X7R1E475K125AB", "C3216X7R1E106K160AB",
         "C3216X5R1C226M160AB"]
URLS = {p: "https://product.tdk.com/info/en/documents/chara_sheet/" + p + ".pdf" for p in PARTS}
URLS.update({
    "BQ24074": "https://www.ti.com/lit/ds/symlink/bq24074.pdf",
    "TDK-general-spec": "https://product.tdk.com/system/files/dam/doc/product/capacitor/ceramic/mlcc/specification/mlccspec_commercial_general_en.pdf",
    "STM32H743": "https://www.st.com/resource/en/datasheet/stm32h743vi.pdf",
    "PCM5102A": "https://www.ti.com/lit/ds/symlink/pcm5102a.pdf",
    "TPS63070": "https://www.ti.com/lit/ds/symlink/tps63070.pdf",
    "TPD2S703": "https://www.ti.com/lit/ds/symlink/tpd2s703-q1.pdf",
    "TPS3700": "https://www.ti.com/lit/ds/symlink/tps3700.pdf",
})
for p in ["RT0603BRD074K99L", "RT0603BRD071K24L", "RT0603BRD0768K1L",
          "RT0603BRD0720K5L", "RT0603BRD07316RL", "RT0603BRD071K50L"]:
    URLS[p] = "https://www.yageogroup.com/download/specsheet/" + p

manifest = []
for name, url in URLS.items():
    target = OUT / (name + ".pdf")
    row = {"id": name, "url": url, "file": str(target.relative_to(ROOT))}
    try:
        if not target.exists():
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=25) as response:
                data = response.read()
                row["final_url"] = response.url
            if not data.startswith(b"%PDF"):
                raise ValueError("Response is not PDF")
            target.write_bytes(data)
        data = target.read_bytes()
        row.update(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                   pages=len(PdfReader(target).pages), status="PDF_FETCHED")
        text = "\n".join(f"PAGE {i+1}\n{p.extract_text()}" for i, p in enumerate(PdfReader(target).pages))
        (OUT / (name + ".txt")).write_text(text, encoding="utf-8")
    except Exception as exc:
        row.update(status="ACCESS_FAILED_NOT_EVIDENCE", error=str(exc))
    manifest.append(row)
    print(name, row["status"], flush=True)
    (ROOT / "download-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
