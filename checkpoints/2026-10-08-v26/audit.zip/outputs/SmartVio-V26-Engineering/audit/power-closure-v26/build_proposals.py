"""Recompute bounded design proposals; never write source, PCB or firmware."""
import copy
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
EXPECTED = "0e910987449bffa901d04ab268c706915137b6e57687c6ca12c37101dc3c9430"
NATIVE = PROJECT / "electrical/native-components.json"
SOURCE_BYTES = NATIVE.read_bytes()
assert hashlib.sha256(SOURCE_BYTES).hexdigest() == EXPECTED, "Source changed: rebase required"
native = json.loads(SOURCE_BYTES)
byref = {c["ref"]: c for c in native}
index = {c["ref"]: i for i, c in enumerate(native)}
assert len(native) == len(byref)

def dump(name, obj):
    path = ROOT / name
    assert path.resolve().is_relative_to(ROOT.resolve())
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def guard(ref):
    c = copy.deepcopy(byref[ref])
    return {"ref": ref, "array_index": index[ref], "original_record": c,
            "original_record_canonical_sha256": hashlib.sha256(json.dumps(c, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "original_pin_net_guards": [{"number": p["number"], "name": p.get("name"), "net": p.get("net")} for p in c["pins"]]}

def envelope(value, fraction):
    return [value * (1-fraction), value * (1+fraction)]

RES_ENVELOPE = 0.005
MON_MIN = 9_700_000
MON_NOM = 10_000_000

def charge_choice(name, riset, rterm, rtmr, rilim, parts):
    ri = envelope(riset, RES_ENVELOPE)
    rt = envelope(rterm, RES_ENVELOPE)
    tm = envelope(rtmr, RES_ENVELOPE)
    rl = envelope(rilim, RES_ENVELOPE)
    ri_min_loaded = 1 / (1/ri[0] + 1/MON_MIN)
    ri_nom_loaded = 1 / (1/riset + 1/MON_NOM)
    cc = [797/ri[1]*1000, 890/ri_nom_loaded*1000, 975/ri_min_loaded*1000]
    # Extra parasitic current is a design allocation, not a measured circuit limit.
    cc_with_leak = [cc[0]-0.1, cc[1], cc[2]+0.1]
    term = [0.0225*rt[0]/ri[1]*1000, .030*rterm/ri_nom_loaded*1000,
            .0375*rt[1]/ri_min_loaded*1000]
    term_usb100 = [.008*rt[0]/ri[1]*1000, .010*rterm/ri_nom_loaded*1000,
                   .012*rt[1]/ri_min_loaded*1000]
    timer = [10*tm[0]/1000*36/3600, 10*rtmr/1000*48/3600, 10*tm[1]/1000*60/3600]
    klow, ktyp = (1500, 1610) if rilim < 3000 else (1330, 1525)
    ilim = [klow/rl[1]*1000, ktyp/rilim*1000, 1720/rl[0]*1000]
    cv_reserve = .45 if name == "B_FAST_1P5A_SOURCE" else 1.5
    sys_load = .06*3.45/(.7*4.1) + .005
    loss = (5.5-2.9)*cc_with_leak[2]/1000 + (5.5-4.1)*sys_load
    return {
        "id": name, "status": "GUARDED_DESIGN_PROPOSAL_NOT_APPLIED", "parts": parts,
        "resistor_envelope_fraction": RES_ENVELOPE,
        "resistor_envelope_basis": {"initial": .001, "TCR_25ppm_at_max_delta100C": .0025,
                                    "additional_drift_allocation_not_factory_guarantee": .0015,
                                    "required_resistor_body_C": [0,125]},
        "RISET_ohm": riset, "RITERM_ohm": rterm, "RTMR_ohm": rtmr, "RILIM_ohm": rilim,
        "charge_mA_min_nom_max_resistors_only": cc,
        "charge_mA_min_nom_max_with_0p25uA_monitor_parasitic_allocation": cc_with_leak,
        "monitor_allocation": "10M initial+tcr screen >=9.7Mohm; +/-0.25uA net ISET parasitic allocated as +/-0.1mA charge. This allocation must bound actual switch/OPA leakage; it is not calibration.",
        "precharge_mA_min_nom_max": [70/ri[1]*1000, 88/ri_nom_loaded*1000, 106/ri_min_loaded*1000],
        "termination_nonUSB100_mA_min_nom_max": term,
        "termination_USB100_mA_min_nom_max": term_usb100,
        "termination_max_margin_to_10mA": 10-term[2],
        "fast_timer_h_min_nom_max": timer,
        "precharge_timer_min_min_nom_max": [x*6 for x in timer],
        "timer_R_range_inside_18_72k": tm[0] > 18000 and tm[1] < 72000,
        "input_limit_mA_min_nom_max_ISET_mode": ilim,
        "ideal_1000mAh_CC_floor_h_min_nom_max_current": [1000/i for i in cc_with_leak],
        "minimum_fast_timer_minus_CC_floor_h": timer[0]-1000/cc_with_leak[0],
        "allocated_CV_time_h_not_pack_guarantee": cv_reserve,
        "replenishable_charge_mAh_with_that_CV_allocation": max(0,timer[0]-cv_reserve)*cc_with_leak[0],
        "fast_phase_time_condition": "Qreplenish/Iactual + tCV <= tFAST_min; precharge has its own separate timer. Dynamic slowdown prevents this from being a wall-clock bound.",
        "housekeeping_SYS_current_A_at4p1V_60mArail": sys_load,
        "housekeeping_input_current_headroom_mA": ilim[0]-cc_with_leak[2]-1000*sys_load,
        "worst_charge_only_linear_dissipation_allocated_W": loss,
        "thermal_design_target_Tj_C": 110,
        "required_effective_theta_to45C_ambient_C_per_W": (110-45)/loss,
        "thermal_basis": "Conservative 5.5V input/2.9V fast-transition corner and 4.1V SYS. 110C is design target, 45C is chosen ambient corner; effective theta and pack heating are not measured. TI current table conditions include VIN=5V, no thermal/DPPM reduction and no OUT load.",
        "normal_charging_authorized": False, "physical_tests": 0,
    }

choices = [
    charge_choice("A_LOW_CURRENT_CURRENT_TERMINATION", 4990,1240,68100,4420,
                  {"R501": "RT0603BRD074K99L", "R502": "retain RC0603FR-074K42L",
                   "R2351_ITERM_new": "RT0603BRD071K24L", "R2352_TMR_new": "RT0603BRD0768K1L"}),
    charge_choice("B_FAST_1P5A_SOURCE",1240,316,20500,1500,
                  {"R501": "RT0603BRD071K24L", "R502": "RT0603BRD071K5L",
                   "R2351_ITERM_new": "RT0603BRD07316RL", "R2352_TMR_new": "RT0603BRD0720K5L"})
]
# A retains RC R502; recompute its limits with the wider existing thick-film allocation.
choices[0]["input_limit_mA_min_nom_max_ISET_mode"] = [1330/(4420*1.025)*1000,1525/4420*1000,1720/(4420*.975)*1000]
choices[0]["R502_retained_envelope_fraction"] = .025
choices[0]["R502_retained_envelope_basis"] = "1% initial plus100ppm/C*100C plus0.5% drift allocation; input-current grant must exceed maximum"
choices[0]["housekeeping_input_current_headroom_mA"] = choices[0]["input_limit_mA_min_nom_max_ISET_mode"][0]-choices[0]["charge_mA_min_nom_max_with_0p25uA_monitor_parasitic_allocation"][2]-1000*choices[0]["housekeeping_SYS_current_A_at4p1V_60mArail"]
choices[0]["policy"] = "Select the pack's current-termination branch with conservative <=10mA threshold. Extended TMR is independent backup; it does not implement the alternative3.5h timer recommendation. A3.5h product session limit yields a partial charge at this current. Do not claim full capacity/time closure."
choices[1]["policy"] = "Require a real >=1.5A input grant, hardware EN1LOW/EN2HIGH and charge-only housekeeping budget for the fast-current calculation.20.5k gives <=3.434h counted fast-phase time; precharge and dynamic slowdown are separate. Add a future <=3.5h wall-clock session cap starting first CELOW, persistent across resets/CE/input cycles. This policy is a proposal; current firmware offers no charging authorization."

fit = json.loads((PROJECT / "audit/pin-closure-v26/bq24074-charge-fit.json").read_text())
baseline_cc = [797/(4990*1.01)*1000,
               890/(1/(1/4990+1/10000000))*1000,
               975/(1/(1/(4990*.99)+1/9900000))*1000]
baseline_term = [baseline_cc[0]*.09, baseline_cc[1]*.10, baseline_cc[2]*.11]
assert all(abs(a-b) < .001 for a,b in zip(
    baseline_cc, fit["current_budget"]["fastcharge_current_mA_min_nom_max"]))
assert all(abs(a-b) < .001 for a,b in zip(
    baseline_term, fit["default_termination"]["nonUSB100_mA_min_nom_max"]))
baseline = {"schema": "SmartVio.V26.charge-calculations.v2", "source_sha256": EXPECTED,
            "prior_report": "../pin-closure-v26/bq24074-charge-fit.json",
            "original_defaults": {"TMR_NC_fast_h": [4,5,6], "TMR_NC_pre_min": [24,30,36],
                                  "ITERM_NC_nonUSB100_mA": baseline_term,
                                  "RISET_mA_initial_only": baseline_cc,
                                  "recomputed_this_run_and_compared_to_prior_report": True},
            "voltage_static": {"BQ_V": [4.16,4.23], "pack_allowed_V": [4.15,4.25], "transient_proof": False},
            "choices": choices, "full_1000mAh_charge_completion_guaranteed": False,
            "normal_charging_authorized": False, "physical_tests": 0}
dump("charge-calculations.json", baseline)

power_rows = []
for label, v, eta, rload in [("same_corner3V70pct8ohm",3,.7,8),
                            ("same_corner3V70pct6p8ohm",3,.7,6.8),
                            ("same_corner2p5V70pct6p8ohm",2.5,.7,6.8),
                            ("same_corner3V85pct8ohm",3,.85,8)]:
    rail = .65*3.45/(v*eta)
    speaker = 1/(rload*v*eta)
    current = rail+speaker+.01
    power_rows.append({"case": label, "loaded_SYS_V": v, "both_efficiencies_assumed": eta,
                       "unchanged_rail_allocation_A": .65,"rail_voltage_upper_V":3.45,
                       "speaker_Vrms":1,"speaker_R_ohm":rload,"speaker_W":1/rload,
                       "rail_pack_A":rail,"speaker_pack_A_excluding_IQ":speaker,"IQ_aux_reserve_A":.01,
                       "total_A":current,"margin_to2A":2-current,
                       "JST_pair_40mohm_drop_V":current*.04,"JST_pair_loss_W":current*current*.04})
q = .65*3.45/.7 + 1/(6.8*.7)
iq=.01
path_models=[]
for resistance in [.04,.14,.25]:
    vpack=3
    disc=(vpack+resistance*iq)**2-4*resistance*(q+vpack*iq)
    current=((vpack+resistance*iq)-math.sqrt(disc))/(2*resistance)
    path_models.append({"pack_terminal_V":vpack,"path_R_model_ohm":resistance,"pack_A":current,
                        "loaded_SYS_V":vpack-resistance*current,"margin_to2A":2-current})
dump("same-corner-pack-budget.json", {"source_sha256":EXPECTED,
    "supersedes": "battery-revision/layout-fit-current.json power.scenarios only; old artifacts remain historical",
    "correction": "1.067857A baseline itself uses3.0V and70%; recalculate that rail term at every scenario, rather than retaining it at2.5V/85%.",
    "formula":"Ipack =0.65*3.45/(VSYS*etaRail) + 1Vrms^2/(Rload*VSYS*etaAmp) +0.010",
    "rows":power_rows,"constant_power_path_sensitivity":path_models,
    "path_model_note":"0.14ohm =JST pair0.04 +BQ0.10 inferred from specified100mV at1A; this linear extrapolation is NOT a resistance guarantee above1A or atVBAT=3.0V.0.25ohm is an explicit design sensitivity including wire/copper, not manufacturer guaranteed bound.",
    "nominal_capacity_runtime_is_not_proved":True,
    "pack_and_JST_continuous_A":2,"PCM_trip_A":[2,5.5],
    "limits_not_measurements":["efficiency floor70%, rail0.65A and10mA reserve are design allocations, not IC maxima",
       "2.5V SYS is a path/brownout sensitivity; retain3.0V pack normal-discharge cutoff",
       "speaker6.8ohm is DC resistance tolerance, not guaranteed minimum complex impedance",
       "ripple/inrush/simultaneity and switch/eFuse/thermal fault bounds remain separate"],
    "physical_tests":0})

def cap_model(mpn, nominal, tol, voltage, package, dims, dc, ac, age, temp=.85, freq=.98):
    factors={"initial":1-tol,"TCC_min":temp,"DC_bias_screen":dc,
             "small_signal_AC_screen":ac,"aging_screen":age,"frequency_screen":freq}
    low=nominal*math.prod(factors.values())
    high=nominal*(1+tol)*1.15*1.03
    return {"mpn":mpn,"nominal_uF":nominal,"tolerance_fraction":tol,"rated_V":voltage,
            "package":package,"max_body_LWH_mm":dims,"working_min_uF_screen":low,
            "working_max_uF_screen":high,"lower_factors":factors,
            "upper_factors":{"initial":1+tol,"TCC_max":1.15,"AC_frequency_reading_reserve":1.03},
            "guaranteed_working_ceff_min_uF":None,"guaranteed_switching_ESR_max_ohm":None,
            "evidence_class":"TYPICAL_MANUFACTURER_CURVE_PLUS_DESIGN_RESERVES_NOT_COMBINED_GUARANTEE"}

models={
 "TDK1":cap_model("C2012X7R1E105K085AB",1,.1,25,"0805",[2.2,1.45,1.0],.95,.90,.90),
 "TDK4p7":cap_model("C2012X7R1E475K125AB",4.7,.1,25,"0805",[2.2,1.45,1.45],.85,.90,.90),
 "TDK2p2":cap_model("C2012X7R1E225K125AB",2.2,.1,25,"0805",[2.2,1.45,1.45],.99,.90,.90),
 "KEM10":cap_model("C1206C106K3RACTU",10,.1,25,"1206",[3.4,1.8,1.8],.85,.85,.90),
 "TDK22":cap_model("C3216X5R1C226M160AB",22,.2,16,"1206",[3.4,1.8,1.8],.65,.90,.90),
}
models["KEM10"]["aging_basis"]="3%/decade hour relative48h:10years yields about9.78% loss;0.90 rounds down. Exact p1."
models["KEM10"]["dc_bias_max_V"] =4.5
models["KEM10"]["DC_curve_reading"]="p2:4.5V about-14%; lower retention0.85; p3:smallAC about-9%, reserve0.85. Curves are explicitly simulations, not specifications."
for key in ["TDK1","TDK4p7","TDK2p2","TDK22"]:
    models[key]["aging_and_AC_basis"]="10% aging and10% AC-amplitude loss are explicit design allocations; exact TDK chart does not guarantee them. Lifetime/time since deaging and actual AC sensitivity must be bounded separately; these are not manufacturer aging limits."
    models[key]["dc_bias_max_V"] =1.4 if key=="TDK2p2" else 3.45
    models[key]["curve_revision"]="Exact MPN characteristic sheet January3,2016; current official catalog corroborates MPN. Curves are typical reference data."
models["TDK2p2"]["DC_curve_reading"]="At1.4V curve is near0% with a small positive hump;0.99 lower screen. Use lower than curve to include reading reserve; no production guarantee inferred."
models["TDK1"]["DC_curve_reading"]="At3.45V curve about-1..-2%; lower screen0.95."
models["TDK4p7"]["DC_curve_reading"]="At3.45V curve about-9..-10%; lower screen0.85."
models["TDK22"]["DC_curve_reading"]="At3.45V curve about-29..-30%; lower screen0.65."

anchors=[("C303","TDK1",1,.47,None,"HP flying capacitor"),
         ("C304","TDK4p7",1,None,None,"HP negative storage; must exceed flying MAX"),
         ("C701","TDK4p7",1,2.2,None,"PCM5102A flying; increased nominal requires startup review"),
         ("C702","TDK4p7",1,2.2,None,"PCM5102A negative storage; manufacturer example2.2uF"),
         ("C807","TDK2p2",1,1.76,2.64,"separate VCAP1 core regulator"),
         ("C808","TDK2p2",1,1.76,2.64,"separate VCAP2 core regulator"),
         ("C1102","KEM10",1,4.7,None,"TPS63070 VIN ceramic bulk"),
         ("C1106","TDK22",3,22,None,"analog ferrite bulk;22uF effective design target"),
         ("C1502","TDK1",1,.3,3,"TPD2S703 VREF capacitor"),
         ("C1902","TDK4p7",1,1,None,"TPS3700 supply bypass")]
cap_rows=[]
for ref,key,count,minimum,maximum,role in anchors:
    model=copy.deepcopy(models[key])
    lo=model["working_min_uF_screen"]*count
    hi=model["working_max_uF_screen"]*count
    ok=(minimum is None or lo>=minimum) and (maximum is None or hi<=maximum)
    cap_rows.append({"ref":ref,"role":role,"candidate":model,"quantity_in_group":count,
                     "additional_refs": ["C2340","C2341"] if ref=="C1106" else [],
                     "net_pair_unchanged":[p.get("net") for p in byref[ref]["pins"]],
                     "group_working_screen_uF":[lo,hi],"required_or_design_target_uF":[minimum,maximum],
                     "screen_result":"WITHIN_ALLOCATED_MODEL_ONLY" if ok else "OUTSIDE_CONSERVATIVE_MODEL_HOLD",
                     "auto_apply":False,"current_source_ceff_proven":False,"physical_tests":0})
hp_fly=cap_rows[0]["group_working_screen_uF"][1]
hp_store=cap_rows[1]["group_working_screen_uF"][0]
cap_rows[1]["HP_storage_min_exceeds_flying_max_uF"]=hp_store-hp_fly
assert hp_store>hp_fly

vcap_narrow = 2.2*.9*.99*.97*.97*.95
vcap_note={"required_ceff_uF":[1.76,2.64],"required_ESR_ohm_less_than":.1,
    "ESR_curve_at100kHz_1MHz_ohm_approx":[.010,.0035],
    "ESR_working_design_screen_ohm":.05,
    "ESR_screen_basis":"5x the approximate0.010ohm highest reading in100kHz..1MHz; no statistical meaning or maximum guarantee. DF maximum at1kHz cannot be transferred to this band.",
    "restricted_model": {"cap_body_C":[0,60],"Vdc_max":1.4,"initial_min":.9,"bias_min":.99,
                         "T_factor_min":.97,"aging_allowance_min":.97,"AC_allowance_min":.95,
                         "result_min_uF":vcap_narrow,"margin_to1p76_uF":vcap_narrow-1.76},
    "decision":"MPN is a practical0805 prototype/design candidate, but even the explicitly narrower conservative model slightly misses1.76uF and the broad model also misses. No VCAP PASS. Require the operational1.76..2.64uF/ESR<0.1ohm acceptance contract; do not use a nominal2.2uF or ESR graph as closure.",
    "not_waiting_dependency":"This numeric gap is actionable now. Parent can retain a conditional candidate or reopen only the two VCAP positions for a tighter characterized2.2uF option; physical tests later validate, not create a fabricated guarantee."}
for r in cap_rows:
    if r["ref"] in ["C807","C808"]:
        r["VCAP_limits"]=copy.deepcopy(vcap_note)
    else:
        r["typical_ESR_band_ohm_approx"]= [0.002,0.030]
        r["working_ESR_design_screen_ohm"]=.05
        r["ESR_basis"]="Exact manufacturer ESR curves visually inspected;0.05ohm engineering allowance at100kHz..1MHz, not a guaranteed max. HP pump1.2..1.35MHz is within nearby flat curve region."

# Supporting capacitors complete the charger/regulator context but are not new critical anchors.
support=[]
for ref,vdc,dc,minimum in [("C501",5.5,.75,1),("C502",4.5,.85,4.7),("C503",4.25,.85,4.7)]:
    m=cap_model("C1206C106K3RACTU",10,.1,25,"1206",[3.4,1.8,1.8],dc,.85,.90)
    m["dc_bias_max_V"]=vdc
    support.append({"ref":ref,"candidate":m,"required_min_uF":minimum,
                    "net_pair_unchanged":[p.get("net") for p in byref[ref]["pins"]],
                    "auto_apply":False,"status":"WITHIN_ALLOCATED_MODEL_ONLY"})
output_cap=3*models["TDK22"]["working_min_uF_screen"]
output_max=3*models["TDK22"]["working_max_uF_screen"]
regulator={"C1104_C1105_replace_and_add_C2342": {"mpn":models["TDK22"]["mpn"],
    "refs":["C1104","C1105","C2342"],"quantity":3,"net_pair":["V3D","GND"],
    "working_total_screen_uF":[output_cap,output_max],"TI_recommended_effective_uF":[15,470],
    "L1101":"XGL4020-152MEC","nominal_L_uH":1.5,"L_upper_20pct_uH":1.8,
    "required_min_by10x_Leff_uF":18,"screen_margin_uF":output_cap-18,
    "remote_bypass_not_counted":"C1902/C1106 and all remote3V3 caps are excluded from local regulator minimum",
    "status":"WITHIN_ALLOCATED_MODEL_ONLY_NOT_LOOP_TRANSIENT_APPROVAL"}}
cap_report={"schema":"SmartVio.V26.compact-capacitor-proposals.v2","source_sha256":EXPECTED,
    "critical_anchor_count":10,"critical_physical_count":sum(r["quantity_in_group"] for r in cap_rows),
    "large_C0G_added":0,"all_candidates_exact_order_codes":True,"stock_quote_or_purchase_executed":False,
    "model_domain":{"cap_body_C":[-20,60],"DC_V":"per row; normal rail/pump voltages only",
                     "frequency_band_for_ESR_screen_Hz":[100000,1000000],
                     "default_age_and_AC_allocations_are_requirements_not_guarantees":True},
    "important_limits":["DCbias/ESR curves are typical; multiplied design screens are neither combined guaranteed minima nor a production yield model",
       "TDK AC/aging reserves need a defined lifetime/deaging/AC-level contract; no global lifecycle PASS",
       "VCAP nominal tolerance plusX7RfullT already permits2.2*.9*.85=1.683uF and2.2*1.1*1.15=2.783uF beforebias/aging; both exceedST's allowed variation",
       "Input hotplug, transient/overvoltage, ripple current, startup, ESR acrossloop band and placement remain application checks",
       "No capacitor proposal is silently applied; no data copied into current-source effectiveC"],
    "rows":cap_rows,"charger_support":support,"regulator_support":regulator,"physical_tests":0,
    "normal_charging_authorized":False}
dump("compact-ceff-proposals.json",cap_report)

primary=[]
for f in ["download-manifest.json","curve-source-manifest.json","final-part-manifest.json"]:
    for row in json.loads((ROOT/f).read_text()):
        if row.get("status")=="PDF_FETCHED":
            if not any(x["id"]==row["id"] for x in primary):
                row["manufacturer_author"]= "Texas Instruments" if row["id"] in ["BQ24074","PCM5102A","TPS63070","TPD2S703","TPS3700"] else "STMicroelectronics" if row["id"]=="STM32H743" else "TDK" if row["id"].startswith(("TDK","C2012","C3216")) else "YAGEO / KEMET"
                primary.append(row)
for name,path,url in [
    ("VARTA56457201020",PROJECT/"audit/selection/battery-revision/sources/VARTA56457201020-current.pdf","https://catalogue.texim-europe.com/getfile.ashx?id=143327"),
    ("JST-PH",PROJECT/"audit/selection/battery-revision/sources/JST-PH.pdf","https://www.jst-mfg.com/product/pdf/eng/ePH.pdf"),
    ("TPA6132A2",PROJECT/"audit/selection/battery-revision/sources/TI-TPA6132A2.pdf","https://www.ti.com/lit/ds/symlink/tpa6132a2.pdf")]:
    assert path.exists()
    primary.append({"id":name,"file":str(path.relative_to(PROJECT)),"path_base":"engineering-project",
                    "url":url,"sha256":sha(path),"status":"LOCAL_ORIGINAL_PRIMARY_REUSED",
                    "provenance":"Manufacturer authored; VARTA hosted by distributor, others official manufacturer host"})
used_ids={"BQ24074","STM32H743","PCM5102A","TPS63070","TPD2S703","TPS3700",
          "C2012X7R1E105K085AB","C2012X7R1E225K125AB","C2012X7R1E475K125AB",
          "C3216X5R1C226M160AB","C1206C106K3RACTU","TDK-spec-current",
          "RT0603BRD074K99L","RT0603BRD071K24L","RT0603BRD0768K1L",
          "RT0603BRD0720K5L","RT0603BRD07316RL","RT0603BRD071K5L",
          "VARTA56457201020","JST-PH","TPA6132A2"}
pages={"BQ24074":[8,10,12,13,25,26,27,28,34,35],"STM32H743":[106,211],
       "PCM5102A":[26],"TPS63070":[4,17,19],"TPD2S703":[7,8,20],
       "C1206C106K3RACTU":[1,2,3,4],"TPA6132A2":[15],"JST-PH":[1,2]}
for s in primary:
    s["used_for_decision"]=s["id"] in used_ids
    s["pdf_pages_used"]=pages.get(s["id"],[1]) if s["used_for_decision"] else []
dump("sources.json",{"date":"2026-10-08","primary_only":True,"sources":primary,
                     "failed_access_retained_in_separate_download_manifests":True})

all_existing=set(byref)
newrefs={"R2351","R2352","C2340","C2341","C2342"}
assert newrefs.isdisjoint(all_existing)
allnets={p.get("net") for c in native for p in c["pins"] if p.get("net")}
newnets={"CHG_ITERM_ECO","CHG_TMR_ECO"}
assert newnets.isdisjoint(allnets)
deps=set(r[0] for r in anchors)|{"U501","R501","R502","R1715","C501","C502","C503",
    "U1101","L1101","C1101","C1103","C1104","C1105","FB1101","U301","U701","U801",
    "R1504","J501","R590"}
deps|={r for r in byref if r.startswith(("U19","R19","RT19","C19","Q160","R160","U170","R171"))}
control_nets={"CHG_EN1","CHG_EN2","CHARGE_DISABLE","CHARGE_GATE","RISET","RILIM",
              "PACK_NTC","CELL_NTC_SENSE","MON_ICHG_BUF_IN"}
direct_control_refs={c["ref"] for c in native if any(p.get("net") in control_nets for p in c["pins"])}
deps|=direct_control_refs
deps={r for r in deps if r in byref}
dump("original-ref-net-guards.json",{"source_path":str(NATIVE),"source_sha256":EXPECTED,
    "source_component_count":len(native),"ref_count":len(deps),"records":[guard(r) for r in sorted(deps)],
    "new_refs_must_remain_absent":sorted(newrefs),"new_nets_must_remain_absent":sorted(newnets),
    "all_direct_control_net_neighbors_guarded":sorted(direct_control_refs),
    "source_rebase_required_after_parent_changes":True})

def resistor_new(ref,mpn,value,net):
    return {"ref":ref,"kind":"R","value":value,"mpn":mpn,"manufacturer":"YAGEO",
            "package":"0603/1608;0.1%;25ppm/C;0.1W;bodymax1.7x0.9x0.55mm",
            "pins":[{"number":"1","name":"1","net":net},{"number":"2","name":"2","net":"GND"}],
            "status":"PROPOSAL_ONLY_NOT_PLACED_OR_APPLIED","productionApproval":False}

charge_patches=[]
for choice in choices:
    ri_mpn=choice["parts"]["R501"]
    changes=[{"ref":"R501","before_guard_ref":"R501","set":{"mpn":ri_mpn,"manufacturer":"YAGEO",
               "value":f'{choice["RISET_ohm"]}ohm0.1%;25ppm/C; charge ECO {choice["id"]}'}}]
    if choice["id"].startswith("B"):
        changes.append({"ref":"R502","before_guard_ref":"R502","set":{"mpn":choice["parts"]["R502"],"value":"1.5kohm0.1%;25ppm/C; require>=1.5A sourcegrant"}})
    charge_patches.append({"choice":choice["id"],"mutually_exclusive_group":"CHARGE_ECO",
       "preconditions_file":"original-ref-net-guards.json","source_sha256_must_equal":EXPECTED,
       "replace_fields":changes,
       "pin_deltas":[{"ref":"U501","pin":"15","old_name":"ITERM","old_net":None,"new_net":"CHG_ITERM_ECO","remove":"noConnectReason"},
                     {"ref":"U501","pin":"14","old_name":"TMR","old_net":None,"new_net":"CHG_TMR_ECO","remove":"noConnectReason"}],
       "add_components":[resistor_new("R2351",choice["parts"]["R2351_ITERM_new"],f'{choice["RITERM_ohm"]}ohm',"CHG_ITERM_ECO"),
                         resistor_new("R2352",choice["parts"]["R2352_TMR_new"],f'{choice["RTMR_ohm"]}ohm',"CHG_TMR_ECO")],
       "retained_pin_guards":{"U501.1":"PACK_NTC","U501.2/3":"PACK_PLUS","U501.4":"CHARGE_DISABLE",
                             "U501.5":"CHG_EN2","U501.6":"CHG_EN1","U501.8/17":"GND","U501.10/11":"SYS",
                             "U501.12":"RILIM","U501.13":"USB_5V_SAFE","U501.16":"RISET"},
       "unchanged_safety_and_policy_refs": sorted(r for r in deps if r.startswith(("U19","R19","RT19","Q160","R160"))),
       "required_integration_preconditions":["Atomic with supporting C501/C502/C503 selection, sourcegrant, thermal/current budgets and native no-connect removal; neither resistor alone closes charge",
         "Keep independent103AT-2/TPS3700 externally biased interlock; pack10kB3380 is not that thermistor. No invented R/T/return guarantee",
         "Target PE14 remainsLOW/CEHIGH until independently reviewed authorization. No new firmware/source write follows from this file",
         "Monitor calibration uses actualRISET and loading; FAST requires changing the future4990ohm firmware calibration contract to1240ohm, not using existing diagnostic readings as true current",
         "Do not auto-clear CHGtimerfault by CEtoggling/USBsuspend/inputreset; first-session timer is never restarted for completion",
         "Normal pack discharge cutoff3V retained; PCM2.3V is emergency protection",
         "Resistor drift/temperature/monitor-parasitic allocations must be satisfied; no fabricated maximum-current guarantee outsideTIconditions"],
       "auto_apply":False,"normal_charging_authorized":False})

cap_patches=[]
reg_support_rows=[{"ref":ref,"candidate":copy.deepcopy(models["TDK22"]),
                   "net_pair_unchanged":[p.get("net") for p in byref[ref]["pins"]]}
                  for ref in ["C1104","C1105"]]
for row in cap_rows+support+reg_support_rows:
    ref=row["ref"]
    m=row["candidate"]
    cap_patches.append({"ref":ref,"original_guard_ref":ref,
       "replace_fields":{"mpn":m["mpn"],"manufacturer":"TDK" if m["mpn"].startswith("C2012") or m["mpn"].startswith("C3216") else "KEMET/YAGEO",
                         "value":f'{m["nominal_uF"]}uF/{m["rated_V"]}V; effective value remains conditional',
                         "package":f'{m["package"]}; exact maxbody {m["max_body_LWH_mm"]}mm; manufacturer land required'},
       "pin_nets_must_be_unchanged":row["net_pair_unchanged"],"proposed_group_quantity":row.get("quantity_in_group",1),
       "additional_refs":row.get("additional_refs",[]),"footprint_action":"New0805/1206 land and placement required where current0603/0805 differs; do not reuse old coordinate/land blindly",
       "numeric_report":"compact-ceff-proposals.json","auto_apply":False,
       "eligibility":"HOLD_VCAP_NOT_FOR_SOURCE_MERGE" if ref in ["C807","C808"] else "REVIEWABLE_CANDIDATE_ONLY_NOT_CEFF_RELEASE"})
dump("guarded-eco-proposals.json",{"schema":"SmartVio.V26.guarded-ECO.v2","proposal_only":True,
    "allowed_write_scope":str(ROOT),"source_sha256":EXPECTED,"global_source_written":False,
    "pcb_written":False,"firmware_written":False,"mainboard_layers_unchanged":4,
    "parent_board_status_user_reported_not_retested":{"errors":0,"warnings":4,"unconnected":215},
    "charge_choices":charge_patches,"capacitor_replacements":cap_patches,
    "additional_component_groups":[{"anchor":"C1106","new_refs":["C2340","C2341"],"mpn":models["TDK22"]["mpn"],"pins":{"1":"V3A","2":"GND"}},
       {"anchors":["C1104","C1105"],"new_ref":"C2342","mpn":models["TDK22"]["mpn"],"pins":{"1":"V3D","2":"GND"}}],
    "no_automatic_application_or_patch_executor_supplied":True})

integration={"source_sha256":EXPECTED,"normal_charging_authorized":False,
    "direct_merge_audit_only":[
        "Same-corner current budget corrections and numeric sensitivity limits",
        "BQ24074 floating TMR/ITERM default corrections, independently recomputed",
        "Primary evidence archive and exact-MPN ratings/dimensions",
        "Guarded proposal files and explicit Ceff/VCAP gaps; not source approval"],
    "unconditional_global_source_or_PCB_merges":[],
    "charging_ECO_choices":"Both proposal only; mutually exclusive; grants, independent temperature gate, calibrated current, timer/session policy and thermal design remain required",
    "compact_caps":"8 of 10 anchors are within allocated model only; footprint/placement/loop/startup conditions remain. Both VCAP positions HOLD",
    "no_stock_claim":"Exact manufacturer order codes exist with primary PDFs; stock, lead time and purchase were not checked or executed",
    "parent_firmware_result_user_reported_not_rerun":{
        "F01_F02_pass":True,"suites":9,"groups":103,"assertions":22541966,
        "does_not_authorize_normal_charge_or_hardware_Ceff":True},
    "parent_board_user_reported_not_rerun":{"errors":0,"warnings":4,"unconnected":215,"layers":4},
    "numeric_checks_now_vs_physical_tests_later":"Publish finite calculated limits now. Physical thermal/loadstep/CC-CV/ESR/temperature-lag verification is a separate future phase, not an indefinite prerequisite to this proposal handoff.",
    "writes":"Only audit/power-closure-v26; no source/PCB/firmware writes"}
dump("integration-disposition.json",integration)
handoff=["SmartVio V26 finite power handoff - 2026-10-08",
    "NORMAL CHARGING DISABLED. Proposal only. Source/PCB/firmware untouched;4 layers retained.",
    "Source: "+EXPECTED,"",
    "DIRECT MERGE: audit corrections (same-corner budget, TMR/ITERM NC defaults), primary evidence, guarded proposal documents.",
    "SOURCE/PCB DIRECT MERGE: NONE. Both charging choices and all cap changes require their stated conditions; VCAP specifically HOLD.",
    "NC defaults:4..6h fast timer,14.232..21.721mA termination at nominal178.446mA. No default10mA cutoff.",
    "Same-corner load:3V/70%/6.8ohm speaker=1.147885A;2.5V sensitivity=1.375462A. Allocations, not measured maxima.",
    "A: R501 RT0603BRD074K99L; retain R502 RC0603FR-074K42L; R2351 RT0603BRD071K24L; R2352 RT0603BRD0768K1L.",
    "A:158.825..196.573mA charge;5.536..9.417mA termination;6.776..11.407h counted fast timer. Not full1000mAh/3.5h closure.",
    "B: R501 RT0603BRD071K24L; R502 RT0603BRD071K5L; R2351 RT0603BRD07316RL; R2352 RT0603BRD0720K5L.",
    "B:639.444..790.442mA charge;5.677..9.654mA termination;2.040..3.434h counted fast timer.",
    "B:>=1.5A actual source grant; charge-only housekeeping; future<=3.5h persistent wallclock cap;2.163W/<=30.05C/W thermal screen. No actual full-charge/time/thermal proof.",
    "All new RT resistors0.1%,25ppm/C,0603; total0.5% envelope includes allocated drift, not guaranteed lifetime drift.","",
    "10 CRITICAL ANCHORS: exact manufacturer MPN | conservative working Ceff screen | disposition"]
for r in cap_rows:
    handoff.append(f'{r["ref"]}: {r["candidate"]["mpn"]}, {r["quantity_in_group"]}x{r["candidate"]["package"]}, {r["group_working_screen_uF"][0]:.4f}..{r["group_working_screen_uF"][1]:.4f}uF; '+("HOLD VCAP" if r["ref"] in ["C807","C808"] else "CONDITIONAL MODEL ONLY"))
handoff += ["Ten anchors use12 compact physical capacitors; no giant C0G bank. Full support actions for charger/regulator are also included.",
    "VCAP required1.76..2.64uF and ESR<0.1ohm; proposed0805 fails broad/narrow Ceff screens. No fabricated PASS.",
    "TDK curves are typical, AC/aging allocations are assumptions; KEMET has actual AC/DC/aging evidence. Combined Ceff/ESR guarantees remain null.",
    "Parent firmware F01/F02+9suites/103groups/22,541,966 assertions passed: user-reported, not rerun here, not hardware/charge authorization.",
    "REPORT.txt: full calculations. guarded-eco-proposals.json + original-ref-net-guards.json: original ref/net/value guards. sources.json: URLs/pages/SHA256.",
    "Abort/rebase on original source mismatch. No automatic application supplied. Physical tests later; no supplier/sample wait to deliver this bounded proposal."]
(ROOT/"HANDOFF.txt").write_text("\n".join(handoff)+"\n",encoding="utf-8")

lines=["SmartVio V26 bounded charging / compact Ceff remediation","2026-10-08. REVIEWABLE PROPOSALS ONLY. No globalsource/PCB/firmware writes.",
       "Source SHA256: "+EXPECTED,"Parent PCB:4layers;0errors/4warnings/215unconnected are user-reported and were not rerun here.","",
       "1. Corrected same-corner pack budget"]
for r in power_rows:
    lines.append(f'{r["case"]}: rail{r["rail_pack_A"]:.6f}A +speaker{r["speaker_pack_A_excluding_IQ"]:.6f}A +reserve0.010A ={r["total_A"]:.6f}A; margin{r["margin_to2A"]:.6f}A to2A.')
lines += ["The old1.067857A baseline may only be reused at3V/70%;2.5V or85% needs recalculation.",
          "JST+path constant-power sensitivity is separate;2.5V SYS is not permission to discharge the pack below3V.","",
          "2. Actual BQ default NC behavior", "TMR floating: precharge24/30/36min; fastcharge4/5/6h. Floating does not disable timers.",
          "ITERM floating: nonUSB10014.232/17.845/21.721mA with initial R501 tolerance/10Mmonitor screen.",
          "These defaults neither implement10mA cutoff nor prove1000mAh replenishment before timeout.","",
          "3. Two finite mutually exclusive charger ECO choices"]
for c in choices:
    lines += [c["id"],"Parts: "+json.dumps(c["parts"]),
        "All new RT parts:0.1%,25ppm/C,0603,0.1W; conservative total resistor envelope0.5% includes explicit drift allocation.",
        "ICHG mA(min/nom/max incl allocated parasitic): "+" / ".join(f"{x:.3f}" for x in c["charge_mA_min_nom_max_with_0p25uA_monitor_parasitic_allocation"]),
        "ITERM nonUSB100 mA: "+" / ".join(f"{x:.3f}" for x in c["termination_nonUSB100_mA_min_nom_max"]),
        "TFAST counted h: "+" / ".join(f"{x:.4f}" for x in c["fast_timer_h_min_nom_max"]),
        "TPRE counted min: "+" / ".join(f"{x:.3f}" for x in c["precharge_timer_min_min_nom_max"]),
        f'CC-only1000mAh worst floor{c["ideal_1000mAh_CC_floor_h_min_nom_max_current"][0]:.3f}h; minimum timer remaining{c["minimum_fast_timer_minus_CC_floor_h"]:.3f}h forCV.',
        f'With explicit CV allocation{c["allocated_CV_time_h_not_pack_guarantee"]}h, replenishment numeric budget{c["replenishable_charge_mAh_with_that_CV_allocation"]:.1f}mAh. Allocation is not a pack charge-time guarantee.',
        f'Input limit mA: '+" / ".join(f"{x:.2f}" for x in c["input_limit_mA_min_nom_max_ISET_mode"]),
        f'Charge-only linear loss screen{c["worst_charge_only_linear_dissipation_allocated_W"]:.3f}W; effective theta <= {c["required_effective_theta_to45C_ambient_C_per_W"]:.2f}C/W for45Cambient/110Cjunction target.',
        c["policy"],""]
lines += ["Preferred integration direction:B only when>=1.5A sourcegrant and its thermal/session conditions are implemented. A is a low-current alternative using the pack current-cutoff branch; it is not a3.5h full-charge solution.",
          "Do not enable either today. Preserve normal charging disabled and independent103AT-2 window.","",
          "4. Ten compact exact-MPN proposals (working screens, NOT combined guarantees)",
          "Ref | exactMPN | count/package | working Ceff screen uF | application disposition"]
for r in cap_rows:
    m=r["candidate"]
    lines.append(f'{r["ref"]} | {m["mpn"]} | {r["quantity_in_group"]}x{m["package"]} | {r["group_working_screen_uF"][0]:.4f}..{r["group_working_screen_uF"][1]:.4f} | {r["screen_result"]}')
lines += [f'HP storage lower{hp_store:.4f}uF > flying upper{hp_fly:.4f}uF under these allocated factors.',
          "C1106 uses3x1206 (C1106+C2340+C2341); total critical count12, no large C0G bank.",
          f'TPS63070 local output support:C1104+C1105+C2342,3x{models["TDK22"]["mpn"]}; lower{output_cap:.4f}uF >18uF forLeff<=1.8uH; upper{output_max:.4f}uF <470uF. Remote caps not counted.',
          "C501/C502/C503 supporting proposal:C1206C106K3RACTU,10uF25V1206 each; modeled lower values:"]
for r in support:
    lines.append(f'{r["ref"]}: {r["candidate"]["working_min_uF_screen"]:.4f}uF at{r["candidate"]["dc_bias_max_V"]}V, target >= {r["required_min_uF"]}uF.')
lines += ["VCAP: separate2.2uF +/-20% (1.76..2.64uF) andESR<100mohm perSTRev11 p106/p211.",
          f'Even restricted0..60C/1.4V/3%aging/5%AC-loss screen gives{vcap_narrow:.6f}uF minimum, below1.76uF. Broad model also misses; no VCAP PASS.',
          "TDK225 ESR curve~3.5..10mohm at100kHz..1MHz;50mohm engineering screen is below100mohm, but no published guaranteed ESR maximum. This is a concrete0805 candidate with explicit numeric qualification gap.",
          "TC/DCbias/AC/frequency/aging are separate factors. TDK AC/aging allowances are design assumptions; KEMET10uF includes actual AC, DC and3%/decade evidence. No screen is a manufacturer combined guarantee.",
          "PCM pump nominal4.7uF replaces2.2uF manufacturer example to budget>=2.2uF effective; increased startup/pump transient behavior remains a review condition, not an endorsed reference-design substitution.","",
          "5. Exact guard / integration handoff", "guarded-eco-proposals.json: mutually exclusive charging operations, per-ref capacitor replacements and new ref allocations; autoapply false.",
          "original-ref-net-guards.json: full original component records, array indexes, canonical hashes, every original pin/net, required absent refs/nets.",
          "Abort on source hash/ref/value/MPN/pin/net mismatch and rebase against parent's current source. Never integrate against old C0G bank assumptions.",
          "U501 pin15 NC ->CHG_ITERM_ECO->R2351->GND; pin14 NC ->CHG_TMR_ECO->R2352->GND. All otherU501pins guarded unchanged.",
          "J501/VARTA/JST atomic revision and independentRT1921 safety guard remain adopted; PACK_NTC10k+/-1%,B3380 lacks fullR/T/B-tolerance/return proof. No SEMITEC properties transferred.","",
          "6. Numeric design limits now / physical tests later", "NOW:<=1A charging,<=10mA termination screen, valid18..72kTMR, actual sourcegrant and currentheadroom, session/counted-timer distinction, localCeff/VCAP limits and maximum body dimensions are explicit.",
          "LATER:installedcelltemperature lag; realCC/CV/safety timer/wallclock/fault persistence; pack unplug/short/openNTC; regulator loadstep/hotplug/ripple/loop; VCAP bias/AC/aging/ESR; 3D land/height/routing and capacitor lot verification.",
          "No supplier/sample wait is required to circulate these proposals. No hardware/thermal/prototype/product PASS is asserted.","",
          "Sources: sources.json lists exact URLs/pages/SHA256; all technical evidence is manufacturer-authored. Failed fetches are retained as failures, never evidence."]
(ROOT/"REPORT.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

assert sha(NATIVE)==EXPECTED
checks={"source_unchanged":True,"critical_refs_exactly10":len(cap_rows)==10,
        "new_refs_absent_in_original":newrefs.isdisjoint(all_existing),
        "new_nets_absent_in_original":newnets.isdisjoint(allnets),
        "termination_both_upper_below10mA":all(c["termination_nonUSB100_mA_min_nom_max"][2]<10 for c in choices),
        "charge_both_upper_below1A":all(c["charge_mA_min_nom_max_with_0p25uA_monitor_parasitic_allocation"][2]<1000 for c in choices),
        "TMR_both_inside_range":all(c["timer_R_range_inside_18_72k"] for c in choices),
        "HP_storage_model_above_flying_max":hp_store>hp_fly,
        "regulator_output_model_above18uF":output_cap>=18,
        "VCAP_gaps_explicit":all(r["screen_result"]=="OUTSIDE_CONSERVATIVE_MODEL_HOLD" for r in cap_rows if r["ref"] in ["C807","C808"]),
        "guaranteed_ceff_not_fabricated":all(r["candidate"]["guaranteed_working_ceff_min_uF"] is None for r in cap_rows),
        "primary_exact_proposed_MPNs_archived":all(any(s["id"]==r["candidate"]["mpn"] and s["status"]=="PDF_FETCHED" for s in primary) for r in cap_rows)}
checks["regulator_existing_and_new_cap_actions_complete"] = {"C1104","C1105"}.issubset({p["ref"] for p in cap_patches})
checks["baseline_current_and_NC_termination_recomputed"] = True
checks["all_direct_charge_temperature_control_neighbors_guarded"] = direct_control_refs.issubset(deps)
assert all(checks.values()),checks
dump("verification.json",{"scope":"STRUCTURED_GUARDS_AND_ARITHMETIC_ONLY","checks":checks,
    "physical_tests":0,"thermal_tests":0,"board_DRC_rerun":False,"normal_charging_authorized":False,
    "product_or_capacitor_qualification_pass":False})
dump("artifact-hashes.json",{p.name:sha(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in [".json",".txt",".py"] and p.name!="artifact-hashes.json"})
print(json.dumps({"status":"REPORTS_GENERATED_NO_GLOBAL_WRITES","charge":choices,
                  "cap_rows":[{"ref":r["ref"],"Ceff":r["group_working_screen_uF"],"status":r["screen_result"]} for r in cap_rows],
                  "checks":checks},indent=2))
