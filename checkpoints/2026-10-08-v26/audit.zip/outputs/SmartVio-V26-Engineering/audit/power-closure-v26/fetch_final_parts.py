"""Bounded final exact resistor and tight-tolerance VCAP candidate lookup."""
import hashlib
import json
from pathlib import Path
import urllib.request
from pypdf import PdfReader
import pypdfium2 as pdfium
ROOT = Path(__file__).resolve().parent
rows = []
for name in ["RT0603BRD071K5L", "C0805C225J3RACTU"]:
    url = "https://www.yageogroup.com/download/specsheet/" + name
    row = {"id": name, "url": url}
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=20) as response:
            data = response.read()
        assert data.startswith(b"%PDF")
        path = ROOT / "sources" / (name + ".pdf")
        path.write_bytes(data)
        r = PdfReader(path)
        (path.with_suffix(".txt")).write_text("\n".join(f"PAGE {i+1}\n{p.extract_text()}" for i,p in enumerate(r.pages)), encoding="utf-8")
        doc = pdfium.PdfDocument(path)
        for i in range(len(doc)):
            doc[i].render(scale=1.5).to_pil().save(path.with_name(f"{name}-p{i+1}.png"))
        row.update(status="PDF_FETCHED", file=str(path.relative_to(ROOT)), sha256=hashlib.sha256(data).hexdigest(), pages=len(r.pages))
    except Exception as exc:
        row.update(status="ACCESS_FAILED_NOT_EVIDENCE", error=str(exc))
    rows.append(row)
    print(name, row["status"], flush=True)
    (ROOT / "final-part-manifest.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
