# V26 passive handoff

Current native:316 parts /1081 pins, SHA256 `587358f65402f79e200a5991e694b35c95370abecb3aabd0c1c0513aa372917f`.
Selection before:`9bd1cf536cdadedb0ce32d8e34c6477fd861b35ea2a09dff6479c50b2e4f0ba9` preserved in `selection-delivery-9bd1cf536cda/`.

100 capacitor selections and6 magnetic/clock selections are observed merged by parent.
10 remaining anchors +30 new capacitors are proposal only. Use `pending-eco-patch.json`
with `new-components.json` atomically; do not replay the historical100-field patch.
This worker did not write global native/PCB/firmware. All tests Phys0.

Scope116=110 C+3 L+1 FB+1 CMC+1 crystal, not all287 active selections.
Proposed C budgets36; proposed Ceff unknown74. Current standard-test budgets28,
current unknown82 because8 proposed banks are not installed. Full application0,
procurement0, arbitrary working-band Ceff proof0. No overall PASS.

`report.html` links all49 original PDFs through relative `source-evidence/` paths,
plus manufacturer URLs and SHA256. Copy this entire audit directory for portable links.
`Passive_V26_ManufacturerLand.pretty/` is an uninstalled design-stage footprint library.
Pads are manufacturer-derived; no global board fit/routing/assembly acceptance implied.
Polarized polymer replacements:pad1 anode=rail,pad2 cathode=GND. C0G banks retain
original anchor nets; each2220 body maximum6.1x5.4x1.85mm. Not drop-in0805 replacements.

See `remaining-holds.json`, every-ref `application-audit.json`, and `verification.json`.
