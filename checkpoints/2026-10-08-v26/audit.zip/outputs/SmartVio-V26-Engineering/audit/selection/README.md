# V26 Selection Merge Handoff

Core patch is ready for scoped engineering integration, not production release.
Do not replace the global native-component array or discard parent power changes.

## Files

- `corrected-components.json`: 17 owned replacements/addition, including four jacks, five buttons, three wheels, three cyan LEDs, speaker and proposed R826.
- `authorized-net-deltas.json`: atomic per-component before/after records and firmware dependencies.
- `SmartVio_V26_Selection.pretty`: five source-derived footprints plus one unmodified official KiCad Molex library footprint.
- `footprint-sources.json`, `source-manifest.json`: pad coordinates, drawing pages, source URLs and actual archived-byte SHA256 hashes.
- `verification.json`: six footprints parsed by KiCad 10.0.6; local pad/slot/cutout coordinates checked; no whole-board DRC or physical validation.
- `battery-interface-proposal.json`: separate J501 update, no audio patch dependency.
- `harness-bom.json`: real finished GlobTek pack and separate RT1921 SEMITEC 103AT-2; no invented finished-pack MPN or new external port.
- `battery-ntc-handoff.json`, `application-review.json`: independent sensor proof, application limits, explicit assumptions and remaining holds.
- `merge-status.json`: brief integration status and critical dependencies.

## Integration Gates

1. Replace jacks atomically. Kycon pins 1=sleeve, 2=ring2, 3=ring1, 4=tip. Ground pins 1/2 for the proposed TRS use. J301 5/6 detection is normally open: inserted LOW. Preserve other three unused detection pairs as real unconnected lands.
2. Carry jack and wheel Edge.Cuts into actual board fabrication. Kycon nominal land-edge clearance is 0.35 mm, so a default 0.5 mm rule is not compatible without an explicitly reviewed local fabrication rule. Wheel rectangular retention holes are not ordinary large-radius milled slots.
3. Buttons need all four terminals; LED manufacturer pin 1 is cathode, not the old generic anode. Do not flatten these into old generic footprints.
4. R826 is proposed 10k from always-present SYS to PWR_PB, not KEY_PWR or switched V3D. Check reference availability at merge; parent chooses final verified 0603 land.
5. Speaker is a spring-pressure assembly using a manufacturer reference contact pattern, not reflow solder terminals. Qualify the fixture and branch-specific filter/drive limit; do not ground either BTL output.
6. Parent PC13 AUDIO_BUS_EN and independent USB-fed sensor gate remain untouched. RT1921 is an insulated external cell-surface sensor. PACK_NTC is exclusively the BQ redundant channel. No shared TS-current-dependent gate is proposed.
7. GlobTek pack's actual internal NTC is 10k +/-5% with unspecified B/B tolerance. The independent SEMITEC sensor is 10k +/-1%, B25/85=3435 K +/-1%. Do not substitute the former as a tight-tolerance hardware-window sensor.

Physical samples and thermal measurements: **0**. No CAM, safety certification or production approval.
