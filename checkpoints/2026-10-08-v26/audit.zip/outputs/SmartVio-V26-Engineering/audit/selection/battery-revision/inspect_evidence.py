"""Copy existing primary PDFs into this review and print selected evidence."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
from pypdf import PdfReader

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
items = [
    ("audit/audio/sources/Panasonic_AQY221R2VY.pdf", "Panasonic-AQY221R.pdf"),
    ("audit/audio/sources/TPA6132A2.pdf", "TI-TPA6132A2.pdf"),
    ("audit/audio/sources/TLV9064.pdf", "TI-TLV9064.pdf"),
    ("audit/audio/sources/MAX98357A.pdf", "ADI-MAX98357A.pdf"),
    ("audit/controls-protection/source-evidence/tpd1e10b06.pdf", "TI-TPD1E10B06.pdf")
]
manifest = []
terms = ("absolute maximum", "current limit", "short-circuit", "short circuit", "6V", "recommended operating")
for relative, name in items:
    source = PROJECT / relative
    target = ROOT / "sources" / name
    shutil.copyfile(source, target)
    manifest.append({"file": "sources/" + name, "copied_from": str(source),
                     "sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
    reader = PdfReader(target)
    print(f"\nSOURCE {name}; PAGES {len(reader.pages)}")
    for n, p in enumerate(reader.pages, 1):
        txt = p.extract_text()
        if name.startswith("Panasonic") or any(t in txt.lower() for t in terms):
            print(f"PAGE {n}\n{txt}")
(ROOT / "reused-source-hashes.json").write_text(json.dumps(manifest, indent=2) + "\n")
