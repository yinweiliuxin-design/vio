"""Validate only review artifacts with KiCad; never modify global files."""
import hashlib
import json
from pathlib import Path
import pcbnew

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
parsed = []
for path in ROOT.glob("*.json"):
    read(path)
    parsed.append(path.name)
sources = read(ROOT / "source-manifest.json")["sources"]
for source in sources:
    assert sha(ROOT / source["file"]) == source["sha256"], source["id"]
base = read(ROOT / "baseline-owned-records.json")
byref = {c["ref"]:c for c in base["records"]}
records = read(ROOT / "corrected-components.proposal.json")
assert {r["ref"] for r in records} == {"J501","K1201","K1202"}
for c in records:
    assert {p["number"]:p.get("net") for p in c["pins"]} == {p["number"]:p.get("net") for p in byref[c["ref"]]["pins"]}
    assert c["release"] == "HOLD" and c["productionApproval"] is False
library = ROOT / "footprints/SmartVio_Battery_Revision.pretty"
fp = pcbnew.FootprintLoad(str(library), "JST_PH_S3B_PH_SM4_TB_OfficialLand_3P")
assert fp is not None
pads = []
for p in fp.Pads():
    pos, size = p.GetPosition(), p.GetSize()
    pads.append({"number":p.GetNumber(), "at_mm":[pcbnew.ToMM(pos.x),pcbnew.ToMM(pos.y)],
                 "size_mm":[pcbnew.ToMM(size.x),pcbnew.ToMM(size.y)]})
assert sorted(p["number"] for p in pads) == ["1","2","3","MP","MP"]
actual = {p["number"]:p for p in pads if p["number"] != "MP"}
for i in range(1,4):
    assert actual[str(i)]["at_mm"] == [(i-2)*2,-2.7]
    assert actual[str(i)]["size_mm"] == [1,3.8]
gap = 2.9 + 3.4/2 - (-2.7+3.8/2)
span = 2.9 + 3.4/2 - (-2.7-3.8/2)
assert gap <= 5.5 and span >= 9
fit = read(ROOT / "layout-fit-current.json")
assert abs(sum(fit["vertical_stack"]["allocation_mm"].values())-21.8) < 1e-9
for case in fit["power"]["scenarios"]:
    assert abs(case["combined_pack_a"]-(1.067857142857143+1/case["load_model_ohm"]/case["loaded_sys_v"]/case["efficiency_assumption"]+.01)) < 1e-9
    assert case["combined_pack_a"] < 2
report = {"status":"REVIEW_ARTIFACT_CHECKS_PASS_NOT_PRODUCT_PASS", "json_files_parsed": parsed,
          "primary_pdf_hashes_verified":len(sources), "component_records":3,
          "electrical_pin_net_deltas":0, "kicad_version":pcbnew.Version(),
          "proposed_jst_footprint_load":True, "pads":pads,
          "land_gap_mm":round(gap,6), "land_span_mm":round(span,6),
          "arithmetic_checks":True,
          "baseline_native_sha256":base["baseline"]["sha256"],
          "native_current_sha256":sha(PROJECT/"electrical/native-components.json"),
          "global_files_written_by_this_review":[],
          "full_board_drc_run":False,"physical_tests":0,"thermal_tests":0,"production_approval":False}
(ROOT / "verification.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
fp_report = read(ROOT / "footprint-verification.json")
fp_report.update({"status":"DRAWING_DIMENSIONS_AND_KICAD_PARSE_VERIFIED_PROPOSAL_ONLY",
                  "kicad_parse_verified":True,"kicad_version":pcbnew.Version()})
(ROOT / "footprint-verification.json").write_text(json.dumps(fp_report,indent=2)+"\n",encoding="utf-8")
manifest = [{"file":str(p.relative_to(ROOT)),"sha256":sha(p)} for p in sorted(ROOT.rglob("*"))
            if p.is_file() and p.name != "artifact-hashes.json"]
(ROOT/"artifact-hashes.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in report.items() if k not in ["pads","json_files_parsed"]}))
