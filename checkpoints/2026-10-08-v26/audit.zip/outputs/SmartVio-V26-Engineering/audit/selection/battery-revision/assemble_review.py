"""Generate scoped review artifacts from read-only project baselines."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, data):
    target = (ROOT / name).resolve()
    if not target.is_relative_to(ROOT):
        raise ValueError("outside review")
    target.write_text(json.dumps(data, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

source_specs = [
    ("varta-1000", "VARTA56457201020-current.pdf", "VARTA Storage GmbH", "Rev No.1-0626", [1], "https://catalogue.texim-europe.com/getfile.ashx?id=143327", "Manufacturer-authored PDF delivered by distributor; not manufacturer-hosted bytes"),
    ("varta-1400", "VARTA56427201022-current.pdf", "VARTA Storage GmbH", "Rev No.1-0426", [1], "https://catalogue.texim-europe.com/getfile.ashx?id=143314", "Manufacturer-authored PDF delivered by distributor; not manufacturer-hosted bytes"),
    ("jst", "JST-PH.pdf", "JST", "Undated ePH five-page catalog", [1,2,3,4], "https://www.jst-mfg.com/product/pdf/eng/ePH.pdf", "Official manufacturer host"),
    ("ssr", "Panasonic-AQY221R.pdf", "Panasonic Industry", "ASCTB471E202610", [2,4,5,8,11,12,14], "https://api.pim.na.industrial.panasonic.com/file_stream/main/fileversion/279337", "Official manufacturer PDF reused from earlier audit, hash verified"),
    ("tvs", "TI-TPD1E10B06.pdf", "Texas Instruments", "SLLSEB1G August2024", [3,4,5,6,9,11], "https://www.ti.com/lit/ds/symlink/tpd1e10b06.pdf", "Official manufacturer PDF reused from earlier audit, hash verified"),
    ("hp", "TI-TPA6132A2.pdf", "Texas Instruments", "SLOS597B July2017", [4,5,10], "https://www.ti.com/lit/ds/symlink/tpa6132a2.pdf", "Official manufacturer PDF reused from earlier audit, hash verified"),
    ("opamp", "TI-TLV9064.pdf", "Texas Instruments", "SBOS839N July2026", [10,14,26], "https://www.ti.com/lit/ds/symlink/tlv9064.pdf", "Official manufacturer PDF reused from earlier audit, hash verified"),
    ("speaker-amp", "ADI-MAX98357A.pdf", "Analog Devices", "Rev16 February2026", [4,5,28], "https://www.analog.com/media/en/technical-documentation/data-sheets/max98357a-max98357b.pdf", "Official manufacturer PDF reused from earlier audit, hash verified")
]
sources = []
for sid, name, author, revision, pages, url, provenance in source_specs:
    file = ROOT / "sources" / name
    sources.append({"id": sid, "file": "sources/" + name, "author": author,
                    "revision": revision, "pdf_pages": pages, "url": url,
                    "sha256": sha(file), "bytes": file.stat().st_size,
                    "provenance": provenance})
write("source-manifest.json", {"date": "2026-10-08", "sources": sources,
    "web_catalog_corroboration": [
        {"url": "https://www.varta-ag.com/en/industry/product-solutions/power-pack-solutions/cellpac-lite", "finding": "Manufacturer current table lists both56457201020 and56427201022 at2A; noNTC R/T guarantee inferred", "local_html_sha256": None},
        {"url": "https://industry.panasonic.com/global/en/products/control/relay/photomos/number/aqy221r6vy", "finding": "ExactAQY221R6VY,1A,0.35ohmmax,noovercurrentprotection", "local_html_sha256": None}],
    "failed_source_access": [{"source": "VARTA direct design-library ZIP", "result": "CAPTCHA/HTML instead ofZIP. Not treated as a downloaded primary-host file. Distributor-hosted original PDFs used and clearly identified."}]})

native_path = PROJECT / "electrical/native-components.json"
native = read(native_path)
by_ref = {c["ref"]: c for c in native}
refs = ["J501","U301","U101","U201","U501","U902","Q1201","C121","C211","C212","C221","C222","R121","R211","R212","R231","R232","R241","R242"]
refs += [f"{prefix}{1200+i}" for prefix in ["K","D","R"] for i in range(1,8)]
baseline = {"file": str(native_path), "sha256": sha(native_path), "components": len(native),
            "captured_at": datetime.now(timezone.utc).isoformat()}
write("baseline-owned-records.json", {"baseline": baseline, "records": [by_ref[r] for r in refs]})
evidence = {s["id"]: s for s in sources}

# Proposed records are independent of stale prior selection evidence.
j = deepcopy(by_ref["J501"])
for key in ["evidence", "footprintAudit", "selectionStatus", "verificationScope"]:
    j.pop(key, None)
j.update({"manufacturer": "JST", "mpn": "S3B-PH-SM4-TB(LF)(SN)",
          "value": "JST PH 3-way internal2A AWG24 pack header",
          "package": "2mm pitch horizontalSMT;3signals+2mechanicaltabs;height5.5mm nominal;width9.9mm nominal",
          "note": "System harness assignment1RED+,2BLACK-,3WHITE_NTC. ManufacturerVARTA bare-wire pack has no factory plug. JST tabs have no electrical pin number;MP is local only.",
          "footprint": "SmartVio_Battery_Revision:JST_PH_S3B_PH_SM4_TB_OfficialLand_3P",
          "evidence": evidence["jst"], "release": "HOLD", "selectionStatus": "PROPOSAL_NOT_AUTHORIZED_GLOBAL_CHANGE",
          "verificationScope": "Primary rating,crimp,pin1 and land reviewed;wireOD/assembly,current corners and complete fit not released",
          "productionApproval": False, "physicalSamplesTested": 0})
j["pins"] = [{"number": str(i), "name": name, "net": net, "footprintPad": str(i),
              "electricalType": "passive", "pinFunctionOrigin": "system-controlled harness assignment",
              "manufacturerContactNumberEvidence": evidence["jst"]}
             for i, name, net in [(1,"PACK+","PACK_PLUS"),(2,"PACK-","GND"),(3,"NTC","PACK_NTC")]]
j["pins"].append({"number": "MP", "name": "LOCAL_REINFORCEMENT_TABS", "net": None,
                  "footprintPad": "MP", "electricalType": "passive", "numberIsLocalMechanical": True,
                  "manufacturerPinNumber": None, "intentionalNoConnect": True,
                  "noConnectReason": "Two real,unnumbered JST mechanical tabs,not electrical contacts"})
fp_path = ROOT / "footprints/SmartVio_Battery_Revision.pretty/JST_PH_S3B_PH_SM4_TB_OfficialLand_3P.kicad_mod"
j["footprintAudit"] = {"file": str(fp_path.relative_to(ROOT)), "sha256": sha(fp_path),
                       "status": "OFFICIAL_DRAWING_DERIVED_PROPOSAL", "allowManufacturingExport": False}
proposed = [j]
for ref in ["K1201","K1202"]:
    c = deepcopy(by_ref[ref])
    c.update({"mpn": "AQY221R6VY", "value": "AQY221R6VY", "manufacturer": "Panasonic Industry",
              "release": "HOLD", "selectionStatus": "CONDITIONAL_MARGIN_PROPOSAL_NOT_FAULT_APPROVAL",
              "productionApproval": False, "evidence": evidence["ssr"],
              "note": "Same official SSOP4 pins/land.1A/0.35ohmmax at25C;no current protection;offvoltage40->30V. Seeprotection-coordination.json before merge."})
    for p in c["pins"]:
        p["evidence"] = evidence["ssr"]
    c["auditSnapshot"] = baseline
    c["exposedPadAudit"] = {"present": False, "extraNcPins": [], "evidence": evidence["ssr"]}
    c["footprintAudit"]["evidence"] = evidence["ssr"]
    proposed.append(c)
write("corrected-components.proposal.json", proposed)
write("native-authorized-net-deltas.proposal.json", {
    "status": "PROPOSED_ONLY_REQUIRES_PARENT_ACCEPTANCE", "baseline": baseline,
    "authorized_by_worker_to_apply_globally": False, "electrical_net_deltas": [],
    "record_replacements": [{"ref": c["ref"], "old_mpn": by_ref[c["ref"]]["mpn"], "proposed_mpn": c["mpn"],
                             "record_file": "corrected-components.proposal.json",
                             "atomic_group": "battery-header-harness" if c["ref"] == "J501" else "headphone-ssr-margin",
                             "pins_and_nets_unchanged": True} for c in proposed],
    "offboard_bom_changes": [{"old_mpn": "BL0750F5030481S1PCTC", "proposed_mpn": "56457201020", "qty": 1,
                               "atomic_group": "battery-header-harness", "record_file": "proposal.json"},
                              {"manufacturer": "JST", "mpn": "PHR-3", "qty": 1},
                              {"manufacturer": "JST", "mpn": "SPH-002T-P0.5S", "qty": 3}],
    "required_removal": "Remove incompatible oldMolex510210300/500798000 mating harness provision when battery group accepted; do not reuse1A PicoBlade",
    "passive_parameter_proposal": "C121/C211/C212/C221/C222 candidate>=25V with unchangedCeff; no exactMPN verified or automatic replacement",
    "global_files_written": []})

board = read(ROOT / "board-inspection.json")
power_path = PROJECT / "audit/system-v26/power-and-stack-budget.json"
contract = PROJECT / "firmware/contracts/power-audio.json"
speaker_code = PROJECT / "firmware/sv_speaker.c"
pre = 1.067857142857143
scenarios = []
for name, load, v, eta in [("Parent nominal1Vrms case",8,3,.85),
                           ("6.8ohm resistance sensitivity",6.8,3,.85),
                           ("Lower voltage and efficiency sensitivity",6.8,2.5,.70)]:
    output = 1 / load
    increment = output / (v * eta)
    scenarios.append({"name": name, "speaker_vrms": 1, "load_model_ohm": load,
                      "speaker_output_w": output, "loaded_sys_v": v, "efficiency_assumption": eta,
                      "additional_speaker_supply_a_excluding_iq": increment,
                      "extra_iq_and_aux_reservation_a": .01,
                      "combined_pack_a": pre + increment + .01,
                      "margin_to_2a_a": 2-pre-increment-.01,
                      "efficiency_and_10ma_reservation_guaranteed": False})
stack_alloc = {"cup_floor":1.0,"lower_insulation":.3,"pack_max":5.4,
               "provisional_swelling_allowance":1.0,"separate_ntc_plus_adhesive":2.6,
               "sensor_to_separator_gap":.5,"rigid_insulating_separator":1.0,
               "separator_to_back_components_gap":.5,"back_component_height_allocation":2.0,
               "main_pcb":1.0,"top_component_and_mating_height_allocation":5.5,"cover":1.0}
stack_total = sum(stack_alloc.values())
overlap = []
for fp in board["footprints"]:
    x,y,w,h = fp["bounds_mm"]
    if fp["side"] == "B" and x < 62 and x+w > 10 and y < 36.75 and y+h > 2.25:
        overlap.append(fp["ref"])
write("layout-fit-current.json", {
    "status": "UNDER_MAINBOARD_ENGINEERING_CANDIDATE_NOT_FULL_ASSEMBLY_RELEASE",
    "physical_measurements": 0, "thermal_measurements": 0, "production_approval": False,
    "constraints": {"existing_cavity_lwh_mm":[78,47,22],"cover_lw_mm":[148,49],
                    "cup_candidate_lwh_mm":[76,43,18],"main_board_lwh_mm":[72,39,1],
                    "total_thickness_max_mm":25,"outward_max_excluding_rollers_mm":5,
                    "extra_cavity":False,"old29_2_strip_is_hard_constraint":False},
    "pack": {"mpn":"56457201020","max_body_lwh_mm":[52,34.5,5.4],
             "source_id":"varta-1000","body_includes_pcm_and_label":True,
             "wire_free_length_mm":[45,55],"straight_body_plus_max_wire_mm":107,
             "full_harness_max_envelope_mm":None,
             "conclusion":"Fold/routethree leads into an internal end/side lane. Do not treat107mm collinear length as requiredcavity length or claim whole harness fits from body size alone."},
    "plan_projection": {"orientation":"52mm along72/76/78mm;34.5mm across39/43/47mm",
                        "main_total_clearance_lw_mm":[20,4.5],"cup_total_clearance_lw_mm":[24,8.5],
                        "cavity_total_clearance_lw_mm":[26,12.5],
                        "proposed_pack_bay_lw_mm":[54,36.5],"bay_allowance":"1mm per planar side; engineering allocation, not manufacturer swelling guarantee",
                        "illustrative_cup_inner_lw_mm_with1mm_walls":[74,41],
                        "remaining_after_bay_lw_mm":[20,4.5],
                        "old_strip_width_excess_mm":5.3,
                        "old_strip_disposition":"Relocate battery under main; no feature deletion or new cavity. Not a rejection criterion.",
                        "transverse_52mm_over49mm_cover_excess_mm":3,
                        "same_plane_speaker_frame_end_to_end_mm":70.15,
                        "same_plane_speaker_frame_side_by_side_width_mm":47.65,
                        "speaker_integration":"End-to-end52+18.15 fits raw76mm projection, but54mm bay+20.15mm framed speaker allowance=74.15mm, marginally exceeds74mm illustrative inner length. Place acoustic volume in a separately evaluated height/cover region or revise tray detailing; do not assume common battery void provides1cc sealed volume. Side-by-side fails43mmcup width.",
                        "fit_verified":False},
    "board_read_only_check": {k:v for k,v in board.items() if k != "footprints"},
    "centered_pack_shadow_on_board": {"bounds_xywh_mm":[10,2.25,52,34.5],
                                      "back_footprint_bbox_intersections":len(overlap),"refs":overlap,
                                      "interpretation":"Planar bounding-box intersections, not3D collisions. Proves underside is populated;packmustnotcontactcomponent/solder surfaces."},
    "vertical_stack": {"allocation_mm":stack_alloc,"total_allocated_mm":stack_total,
                       "margin_vs22mm_mm":22-stack_total,"margin_vs25mm_mm":25-stack_total,
                       "excess_over18mm_cup_depth_mm":stack_total-18,
                       "depth_interpretation":"21.8mm arithmetic candidate remains below22/25mm; with18mm cup,3.8mm must sit above its reference plane if that is the correct enclosure datum. This is below5mm only conditionally. Do not add22+5 and call27mm allowable.",
                       "not_guaranteed_dimensions":["cup/cover thickness and datum","1mmswelling reserve","all219back-device heights<=2mm","alltopfeaturesandmating<=5.5mm","sensor attachment gap","actualspeakerchamber/snaps/screws/interconnect crossings"],
                       "known_source_dimensions":"Pack5.4mmmax;mainPCB1mmcurrentfile;RT1921body2.4mmmaxperexistingselection,2.6mmincludesprovisional0.2bond;JST5.5mmnominalnotmaximum.",
                       "decision":"Credible under-board arrangement worth integration review, but0.2mm22mmheadroom cannot be called tolerance closure. Use full25mmlimit only after correctreference/coverplane validation; do notcompresspouch."},
    "power": {"pre_speaker_pack_requirement_a":pre,"budget_file":str(power_path),"budget_sha256":sha(power_path),
              "baseline_0_65a_rail_allocation_reduced":False,
              "reason_no_new_per_ic_budget":"Verified2Aprotectedcatalogpack found; retainparentconservativeallocationratherthanreplaceitwithunguaranteedtypicalICconsumption.",
              "speaker_contract_file":str(contract),"speaker_contract_sha256":sha(contract),
              "speaker_code_file":str(speaker_code),"speaker_code_sha256":sha(speaker_code),
              "speaker_actual_code":"sv_speaker_peak_cap clampsupper>=5500mV,computesint24cap1372681for0.9Vpeakmodel; sv_speaker_process applies850HzHPF andclampsbothsigns,RIGHTzero. Parent1Vrmsuppercontractusedwithoutreducingit.",
              "speaker_limit_physical_verification":False,"speaker_continuous_3w_or1w_assumed":False,
              "scenarios":scenarios,
              "load_caveat":"6.8ohm is minus15percent nominalresistance model,notguaranteedfrequencydependentminimumimpedance. Existingfilter/limitercontractmustnotbebypassedinanymode.",
              "amp_iq_evidence":"ADIp4:3.35mAmaxat5V25C;2.85mAmaxat3.7V25C. Noalltemperaturemaxprovidedhere;10mAisreviewreserveNOTmanufacturerbound. Efficiencyp5is92percenttypatdifferentconditions,not85percentguarantee.",
              "transients":"1Vrms6.8ohmsineIpeak=0.208Aloadcurrent,notpack-averagecurrentlimit. PWM,ripple,inrush,rail/RFsimultaneityandBQpathdropneedclosedanalysis. PCMtrip2..5.5A/8..16msisnotpermissiontoexceed2Arating.",
              "connector":{"continuous_rating_a":2,"condition":"AWG24withPHR-3/SPH-002T-P0.5S andqualifiedcrimp","pair_max_contact_resistance_after_test_ohm":.04,"at2a_pair_drop_v":.08,"at2a_pair_loss_w":.16,"boardtraceandwirelossincluded":False},
              "decision":"Approx1.127Aparentnominalincl10mAreserve;approx1.162Alowvoltage/efficiencysensitivity.2Apack/connectorgiveabout0.84Aanalyticalmarginwithoutfeaturederating. Notcompletefault/temperatureapproval."},
    "holds":["exactpackNTCBtolerance/RTandreturn","BQterminationand3Vdischargecutoffreview","complete3Dstack/tolerances/strainrelief","temperature/supplytransientcorners","audioTVS/SSRcoordination" ]})
write("footprint-verification.json", {
    "status":"PROPOSAL_GEOMETRY_REVIEWED_KICAD_PARSE_PENDING",
    "official_source":"JST-PH.pdf p2side-entrymountingsurfaceview,p4header",
    "provided_file":str(fp_path.relative_to(ROOT)),"sha256":sha(fp_path),
    "manufacturer_requirements_mm":{"signal_pitch":2,"signal_pitch_tolerance":.05,"signal_width_min":1,
                                    "overall_y_span_min":9,"retainer_lower_edge_to_signal_lower_edge_max":5.5,
                                    "retainer_size":[1.5,3.4],"outer_signal_center_to_retainer_inner_edge":1.6},
    "provided_values_mm":{"pitch":2,"signal_pad_size":[1,3.8],"overall_y_span":9.2,
                          "retainer_lower_edge_to_signal_lower_edge":5.4,
                          "signal_centers":[[-2,-2.7],[0,-2.7],[2,-2.7]],
                          "mp_centers":[[-4.35,2.9],[4.35,2.9]],"mp_size":[1.5,3.4]},
    "library_caveat":"ArchivedKiCadupstreamfootprintuses1x3.5mmsignals aty-2.85:edgegap5.7mm with9.2mmoverallspan. ThisreviewdoesNOTdeclarethosebytesmatchJST5.5max; providedlocalrectangular1x3.8mmproposalreducesgapto5.4. No3DmodelorfullboardDRCapprovalimplied.",
    "pin1":"leftmostsignal in drawing mounting-surfaceview;harnessmatingviewcanmirror:usemarkedcircuit1,notthecolororderinthephoto",
    "mp":"localidentifierforbothunnumberedmechanicaltabs,netsnull",
    "assembly_release":False})
write("status.json", {
    "status":"CHECKPOINT_READY_SPECIFIC2A_BATTERY_AND_CONNECTOR_PROPOSAL",
    "preferred_pack":"VARTA56457201020", "alternative_pack":"VARTA56427201022",
    "pack_continuous_a":2,"header_and_mate_continuous_a":2,"preferred_pack_max_lwh_mm":[52,34.5,5.4],
    "ntc":"10kOhm+/-1%,B3380K;Btolerance/RT/exactsensorMPN/returnunknown",
    "speaker":"Unchangedexisting1Vrmscontract,notassumed3W;seeactualfirmwarehashesandanalyticalscenarios",
    "merge_artifacts":["proposal.json","corrected-components.proposal.json","native-authorized-net-deltas.proposal.json","layout-fit-current.json","protection-coordination.json","source-manifest.json","footprint-verification.json"],
    "scope_owned":str(ROOT),"global_files_written":[],"parent_acceptance_required":True,
    "physical_tests":0,"thermal_tests":0,"production_approval":False,
    "not_all_pass":True})
print(json.dumps({"records_proposed":[c["ref"] for c in proposed],"stack_mm":stack_total,
                  "centered_shadow_back_footprints":len(overlap),"current_cases_a":[s["combined_pack_a"] for s in scenarios]}))
