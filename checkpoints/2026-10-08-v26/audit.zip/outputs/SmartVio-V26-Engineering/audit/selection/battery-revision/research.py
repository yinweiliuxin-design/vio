"""Archive primary evidence and inspect PDFs, confined to this review folder."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def within(relative):
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError("Path outside owned review folder")
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def fetch(url, relative):
    path = within(relative)
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=45) as response:
        data = response.read(64 * 1024 * 1024 + 1)
        if len(data) > 64 * 1024 * 1024:
            raise ValueError("Source exceeds64MiB")
        if path.suffix == ".pdf" and not data.startswith(b"%PDF"):
            raise ValueError("Response is not PDF")
        if path.suffix == ".zip" and not data.startswith(b"PK"):
            raise ValueError("Response is not ZIP")
        path.write_bytes(data)
        record = {"url": url, "final_url": response.url,
                  "file": str(path.relative_to(ROOT)), "bytes": len(data),
                  "sha256": hashlib.sha256(data).hexdigest()}
    manifest = within("source-downloads.json")
    records = json.loads(manifest.read_text()) if manifest.exists() else []
    records = [r for r in records if r["file"] != record["file"]] + [record]
    manifest.write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record))


def extract(relative):
    path = within(relative)
    destination = within("sources/" + path.stem + "/placeholder").parent
    with zipfile.ZipFile(path) as archive:
        for item in archive.infolist():
            target = (destination / item.filename).resolve()
            if not target.is_relative_to(destination):
                raise ValueError("Unsafe archive path")
        archive.extractall(destination)
        print("\n".join(archive.namelist()))


def pdf(relative, page):
    from pypdf import PdfReader
    path = within(relative)
    reader = PdfReader(path)
    if page is None:
        for i, p in enumerate(reader.pages, 1):
            print(f"\nPAGE {i}\n{p.extract_text()}")
        return
    sys.path.insert(0, str(ROOT.parents[4] / "work/v25/audio/pythonlibs"))
    import fitz
    doc = fitz.open(path)
    output = within(f"renders/{path.stem}-p{page}.png")
    doc[page - 1].get_pixmap(matrix=fitz.Matrix(2, 2)).save(output)
    print(str(output))


parser = argparse.ArgumentParser()
parser.add_argument("operation", choices=["fetch", "extract", "pdf"])
parser.add_argument("source")
parser.add_argument("target", nargs="?")
args = parser.parse_args()
if args.operation == "fetch":
    fetch(args.source, args.target)
elif args.operation == "extract":
    extract(args.source)
else:
    pdf(args.source, int(args.target) if args.target else None)
