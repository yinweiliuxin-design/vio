"""Read-only PCB geometry snapshot; never saves a board."""
import hashlib
import json
from pathlib import Path
import pcbnew

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
path = PROJECT / "pcb-work/SmartVio-main-v26-final.kicad_pcb"
board = pcbnew.LoadBoard(str(path))
def mm(value):
    return round(pcbnew.ToMM(value), 4)
box = board.GetBoardEdgesBoundingBox()
records = []
for fp in board.GetFootprints():
    pos = fp.GetPosition()
    bounds = fp.GetBoundingBox(False, False)
    records.append({"ref": fp.GetReference(), "value": fp.GetValue(),
                    "footprint": str(fp.GetFPID().GetLibItemName()),
                    "side": "B" if fp.IsFlipped() else "F",
                    "xy_mm": [mm(pos.x), mm(pos.y)],
                    "bounds_mm": [mm(bounds.GetX()), mm(bounds.GetY()),
                                  mm(bounds.GetWidth()), mm(bounds.GetHeight())]})
result = {"board": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
          "kicad_version": pcbnew.Version(), "read_only": True,
          "thickness_mm": mm(board.GetDesignSettings().GetBoardThickness()),
          "outline_bounding_box_mm": [mm(box.GetX()), mm(box.GetY()),
                                      mm(box.GetWidth()), mm(box.GetHeight())],
          "front_count": sum(r["side"] == "F" for r in records),
          "back_count": sum(r["side"] == "B" for r in records),
          "component_z_heights_verified": False, "footprints": records}
(ROOT / "board-inspection.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "footprints"}))
print(json.dumps([r for r in records if r["side"] == "B" or r["ref"] == "J501"]))
