import copy
import hashlib
import json
import runpy
import shutil
from collections import Counter
from pathlib import Path

OUT=Path(__file__).resolve().parent
ENGINE=OUT.parents[1]
EXPECTED='0e910987449bffa901d04ab268c706915137b6e57687c6ca12c37101dc3c9430'
OLD='587358f65402f79e200a5991e694b35c95370abecb3aabd0c1c0513aa372917f'


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,v): (OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


current_file=ENGINE/'electrical/native-components.json'
assert sha(current_file)==EXPECTED,'Unrecognized native change: do not silently rebase.'
before={c['ref']:c for c in read(OUT/'snapshots/native-587358f65402.json')}
current={c['ref']:c for c in read(current_file)}
changed=[r for r in before if before[r]!=current[r]]
assert set(changed)=={'J501','K1201','K1202','R403','R404','R601'}


def connections(c):
    return sorted((str(p['number']),p.get('net'),str(p.get('footprintPad',p['number']))) for p in c['pins'])


assert set(before)==set(current)
assert all(connections(before[r])==connections(current[r]) for r in before)
history=OUT/'snapshots/historical-report-587358f65402'
history.mkdir(exist_ok=True)
for name in ['status.json','pin-review.json','findings.json','verification.json','source-provenance.json',
             'correction-patch.json','bq24074-charge-fit.json','application-by-ref.json']:
    dest=history/name
    if not dest.exists() and (OUT/name).exists(): shutil.copyfile(OUT/name,dest)
merge_path=ENGINE/'audit/system-v26/battery-revision-merge.json'
merge=read(merge_path)
assert merge['sourceAfterSHA256']==EXPECTED and merge['normalChargeAuthorized'] is False and merge['physicalTests']==0
rebase={'old_sha256':OLD,'current_sha256':EXPECTED,'changed_refs':changed,
        'changed_fields':{r:[k for k in before[r].keys()|current[r].keys() if before[r].get(k)!=current[r].get(k)] for r in changed},
        'pin_net_pad_number_differences':[],'parts':len(current),'pins':sum(len(c['pins']) for c in current.values()),
        'nets':len({p['net'] for c in current.values() for p in c['pins'] if p.get('net')}),
        'J501_MP_function_name_change':{'before':before['J501']['pins'][-1]['name'],'after':current['J501']['pins'][-1]['name']},
        'merge_record':{'path':str(merge_path.relative_to(ENGINE)),'sha256':sha(merge_path)},
        'normal_charging_authorized':False,'physical_tests_executed':0,'parent_authorized_rebase':True}
assert (rebase['parts'],rebase['pins'],rebase['nets'])==(316,1081,220)
save('source-rebase.json',rebase)
runpy.run_path(str(OUT/'prepare.py'),run_name='__main__')
runpy.run_path(str(OUT/'finalize_review.py'),run_name='__main__')

status=read(OUT/'status.json')
review=read(OUT/'pin-review.json')
patch=read(OUT/'correction-patch.json')
byref=read(OUT/'application-by-ref.json')
provenance=read(OUT/'source-provenance.json')
verification=read(OUT/'verification.json')

applied=patch.pop('metadata_only_changes')
assert {x['ref'] for x in applied}=={'R403','R404','R601'}
assert all(all(current[x['ref']].get(k)==v for k,v in x['set_fields'].items()) for x in applied)
patch['metadata_only_changes']=[]
patch['parent_applied_metadata_changes']=[{'ref':x['ref'],'before_mpn':before[x['ref']].get('mpn'),
                                         'current_mpn':current[x['ref']]['mpn'],'mpn_package_integrated':True,
                                         'application_approved':False,'merge_source_sha256':EXPECTED} for x in applied]
patch['count_distinction']='CurrentblankC/RMPNs=9capacitors; R403/R404/R601 alreadyparentmerged. Historical10compoundcapacitoranchors remainunmerged, andincludealreadyexactC1902.'
assert len(patch['current_blank_C_R_MPNs'])==9
patch['source_rebase_reference']='source-rebase.json'
save('correction-patch.json',patch)
status['new_parent_atomic_candidate']['status']='PARENT_ATOMIC_ENGINEERING_MERGE_APPLIED'
status['new_parent_atomic_candidate']['instruction']='CurrentJ501isJSTandK1201/2areAQY221R6VY; oldMolex/relayrecordsremainhistoricalonly. Boardgeometry/exportstillrequiresparentparity.'
status['current_blank_C_R_MPN_count']=9
status['current_blank_C_MPN_refs']=[x['ref'] for x in patch['current_blank_C_R_MPNs']]
status['current_blank_R_MPN_refs']=[]
status['parent_applied_zero_ohm_MPN_changes']=3
status['source_net_count']=220
status['files']['source_rebase']='source-rebase.json'
status['files']['parity']='current-parity.json'
status['normal_charging_authorized']=False

for rows in [review['rows'],byref['rows']]:
    for r in rows:
        if r['ref'] in ['R403','R404']:
            r['pending_limits']=['0ohmexactMPNisnowparentmerged. USBend-to-endSI,ESDparasitics andcurrent/faultlimits remainunclosed.']
        if r['ref']=='R601':
            r['pending_limits']=['0ohmexactMPNisnowparentmerged. ADCXIground/SCKImode reviewed; completeclockstartup/sequence andjumperoperatinglimits notqualified.']
        if r['ref']=='J501':
            r['normal_operation']='CurrentJ501isJST S3B-PH-SM4-TB(LF)(SN),2mm pitch. Systemcontrolledharness1RED PACK_PLUS,2BLACK GND,3WHITE PACK_NTC; MPmechanicaltabsNC. NotafactoryVARTAplug.'
            r['pending_limits']=['Delegatedbattery/harnessowner: AWG24 crimp/insulationOD/polarity/current/stack/NTCreturn qualification. OldMolexlanddoesnotapply.']
        if r['ref'] in ['R403','R404','R601'] and 'terminal_map_review' in r:
            r['terminal_map_review']['status']='EVIDENCED_TERMINAL_ROLE_DESIGN_MAPPING'
            r['terminal_map_review']['scope']='Exactmanufacturerzeroohm two-terminaljumper established;1/2 areinterchangeableprojectpadnumbers, notboardgeometryapproval.'
            r['terminal_map_review']['evidence']=[{'source_id':'RC0603JR-070RL','pdf_pages':[1]}]
status['terminal_role_design_mapping_evidenced_baseline_pins']=sum(r['terminal_map_review']['status']=='EVIDENCED_TERMINAL_ROLE_DESIGN_MAPPING' for r in review['rows'])
status['terminal_role_mapping_remaining_baseline_pins']=287-status['terminal_role_design_mapping_evidenced_baseline_pins']
assert status['terminal_role_design_mapping_evidenced_baseline_pins']==232
review.update({k:v for k,v in status.items() if k!='rows'})
save('pin-review.json',review)
save('application-by-ref.json',byref)

charge=read(OUT/'bq24074-charge-fit.json')
charge['current_engineering_pack']=charge.pop('candidate_not_current')
charge['current_engineering_pack']['status']='ADOPTED_IN_PARENT_POWER_PACK_BOM_NOT_CHARGE_RELEASE'
bom_path=ENGINE/'manufacturing-v26/power-pack-BOM-V26.json'
assert bom_path.exists()
active_bom=read(bom_path)
assert '56457201020' in json.dumps(active_bom)
charge['active_pack_bom']={'path':str(bom_path.relative_to(ENGINE)), 'sha256':sha(bom_path)}
charge['normal_charging_authorized']=False
save('bq24074-charge-fit.json',charge)
anchors=read(OUT/'anchor-selection.json')
anchors['blank_C_R_count']=9
anchors['nominal_metadata_resistor_patch_count']=0
anchors['parent_applied_zero_ohm_changes']=3
save('anchor-selection.json',anchors)

# New target bytes are captured separately; historical finding references remain immutable.
fw_new_dir=OUT/'snapshots/current-firmware'
fw_new_dir.mkdir(exist_ok=True)
fw_current=[]
files=list((ENGINE/'firmware/stm32').glob('*.c'))+list((ENGINE/'firmware/stm32').glob('*.h'))
for p in files:
    digest=sha(p)
    target=fw_new_dir/(p.stem+'-'+digest[:12]+p.suffix)
    if not target.exists(): shutil.copyfile(p,target)
    fw_current.append({'path':str(p.relative_to(ENGINE)).replace('\\','/'),'sha256':digest,
                       'snapshot':str(target.relative_to(OUT)).replace('\\','/'),'snapshot_scope':'CURRENT_TARGET_SOURCE_CAPTURE_ONLY_NOT_TARGET_TEST_PASS'})
provenance['current_native_rebase']=rebase
provenance['active_pack_bom']=charge['active_pack_bom']
provenance['current_target_firmware_capture']=fw_current
for f in provenance['firmware_snapshots']:
    f['snapshot_is_current']=sha(ENGINE/f['path'])==f['sha256']
    f['classification']='CURRENT_UNCHANGED_FILE' if f['snapshot_is_current'] else 'HISTORICAL_FINDING_EVIDENCE_NOT_CURRENT_TARGET'
save('source-provenance.json',provenance)

ledger=read(ENGINE/'audit/system-v26/application-profiles.json')
def endpoint_set(data):
    return {(c['ref'],str(p['number']),p.get('net')) for c in data for p in c['pins']}
review_mapping_ok=all(all(any(str(p['number'])==str(cp['number']) and p.get('net')==cp.get('net')
                            for p in current[r['ref']]['pins']) for cp in r['current_pins']) for r in review['rows'])
parity={'source_sha256':EXPECTED,'source_rebase':'source-rebase.json','components':316,'pins':1081,'nets':220,
        'baseline_rows':len(review['rows']),'baseline_unique_keys':len({r['baseline_key'] for r in review['rows']}),
        'all_review_rows_bind_current_native_pins':review_mapping_ok,
        'all_current_scope_component_records_exactly_match':all(c==current[c['ref']] for c in read(OUT/'current-scope-components.json')),
        'net_connections_file_binds_current_source':all(
            any(str(p['number'])==str(ep['pin']) and p.get('net')==net for p in current[ep['ref']]['pins'])
            for net,eps in read(OUT/'current-net-connections.json').items() for ep in eps),
        'system_ledger_source_sha256':ledger.get('sourceSha256'),
        'system_ledger_same_source':ledger.get('sourceSha256')==EXPECTED,
        'parent_capture_map_board_sync':'Ownedbyparent; thisreviewdoesnotclaimrebuildingglobalcapture/map/PCB.',
        'parent_merge_record_hash':sha(merge_path),'normal_charging_authorized':False,'physical_tests_executed':0}
assert parity['all_review_rows_bind_current_native_pins'] and parity['all_current_scope_component_records_exactly_match'] and parity['net_connections_file_binds_current_source']
save('current-parity.json',parity)
verification['historical_firmware_drift_observations']=[c for c in verification['checks'] if c['check']=='Referenced firmware snapshots still current']
verification['checks']=[c for c in verification['checks'] if c['check']!='Referenced firmware snapshots still current']
verification['checks'].extend([
    {'check':'Parent6refatomicrebase exact','pass':True},
    {'check':'316parts1081pins220netscurrentparity','pass':True},
    {'check':'Everycurrentreviewpin bindsnewnative','pass':review_mapping_ok},
    {'check':'Currenttargetfirmwarecapturedseparatelyfromhistoricalfindings','pass':all(sha(ENGINE/x['path'])==x['sha256'] for x in fw_current)},
    {'check':'Finalnativehash0e910987stable','pass':sha(current_file)==EXPECTED},
])
verification['all_structure_checks_pass']=all(c['pass'] for c in verification['checks'])
verification['terminal_mapping_counts']={'evidenced_design':232,'pending_design':55,'actual_physical_verified':0}
verification['terminal_mapping_pending_baseline_keys']=[r['baseline_key'] for r in review['rows'] if r['terminal_map_review']['status']!='EVIDENCED_TERMINAL_ROLE_DESIGN_MAPPING']
verification['firmware_drift_requires_review']='HistoricaltargetdriftisexpectedafterF01/F02fix. Currentbytescaptured; newtargettests andownercompletionstillpending.'
verification['electrical_approval']=False
verification['normal_charging_authorized']=False
save('verification.json',verification)
status['current_data_parity_checks_pass']=verification['all_structure_checks_pass']
status['current_system_ledger_source_matches']=parity['system_ledger_same_source']
status['new_target_test_completion_received']=False
save('status.json',status)
followup=read(OUT/'parent-followup.json')
followup['parent_atomic_merge_integrated']=True
followup['native_hash']=EXPECTED
followup['source_rebase_reference']='source-rebase.json'
followup['historical_source_sha256']=OLD
save('parent-followup.json',followup)

report=OUT/'report.html'
content=report.read_text(encoding='utf-8')
content=content.replace('Current blank MPNs:9C+3R.','Current blank MPNs:9C;3zero-ohmMPNs alreadyparentmerged.')
content=content.replace('Current blank MPNs:9C+3R','Current blank MPNs:9C; R403/R404/R601alreadymerged')
content=content.replace('226/287 baseline pins','232/287 baseline pins').replace('61 still need','55 still need')
content=content.replace('226项端子角色','232项端子角色')
content=content.replace('Pendingparentatomiccandidate:','Appliedparentatomicengineeringselection:')
content=content.replace('No candidate is representedas currentnative.','J501/K1201/K1202 andzero-ohmMPNs nowmatchcurrentnative; nocharge/physicalrelease.')
content=content.replace('The previous74 is a candidate-selection layer count, not a current operating-Ceff approval count.','148baselinepins=74capacitorsstilllackeffectiveCproof; baselinebattery-delegatedpinsareseparatelycounted.')
content=content.replace('Exactzero-ohmMPN metadata candidate supplied, but notmerged here.','Exactzero-ohmMPN metadata parentmerged; applicationlimitsremain.')
notice='<h2>当前原子源绑定</h2><p>已绑定新SHA256 <code>'+EXPECTED+'</code>。316器件 /1081引脚 /220网络；仅J501/K1201/K1202/R403/R404/R601变更，电气网络及焊盘编号完全一致。R403/R404/R601已合并，不再重复作为待合并补丁。空白C/R料号现为9个电容。J501 MP仅功能说明改为加固焊脚。</p><p>端子角色有原厂依据232/287，待定义55；设计局部应用检查关闭28，仍待259，统计维度不可相加。新固件已独立捕获，但F01/F02继续等待新目标测试及负责人完成交接。</p><p><a href="source-rebase.json">原子差异记录</a> | <a href="current-parity.json">当前源一致性</a>。正常充电禁止，所有实物验证0；全局capture/map/主板同步由父端负责。</p>'
content=content.replace('<h2>最新父端跟进 / 当前交付口径</h2>',notice+'<h2>最新父端跟进 / 当前交付口径</h2>')
report.write_text(content,encoding='utf-8')
print(json.dumps({'rebound_source':EXPECTED,'application_counts':status['status_counts'],'terminal_mapping':[232,55],
                  'pending_metadata_patch':len(patch['metadata_only_changes']),'blank_C_R':len(patch['current_blank_C_R_MPNs']),
                  'parity_checks_pass':verification['all_structure_checks_pass'],'ledger_same_source':parity['system_ledger_same_source']},indent=2))
