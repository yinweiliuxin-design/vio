#ifndef SV_POT_ADC_H
#define SV_POT_ADC_H
#include "sv_ui.h"
bool sv_pot_adc_init(void);
void sv_pot_adc_stop(void);
sv_pot_bus sv_pot_adc_bus(void);
#endif
