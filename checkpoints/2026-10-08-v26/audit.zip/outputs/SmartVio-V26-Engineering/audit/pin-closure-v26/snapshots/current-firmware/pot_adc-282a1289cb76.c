#include "stm32h7xx_hal.h"
#include "pot_adc.h"
#include <string.h>
static ADC_HandleTypeDef adc;
static DMA_HandleTypeDef dma;
static uint32_t words[3] __attribute__((section(".dma"),aligned(32)));
static volatile uint32_t done,error;
volatile struct {uint32_t cfgr,cfgr2,ccr,sqr1,smpr1,smpr2,pcsel,clock_hz,generations,errors;} sv_pot_registers;
void sv_pot_adc_stop(void){
    HAL_NVIC_DisableIRQ(DMA2_Stream0_IRQn);HAL_NVIC_DisableIRQ(ADC_IRQn);
    if(adc.Instance){HAL_ADC_Stop_DMA(&adc);HAL_ADC_DeInit(&adc);}
    if(dma.Instance)HAL_DMA_DeInit(&dma);
    done=error=0;
}
bool sv_pot_adc_init(void){
    sv_pot_adc_stop();memset(&adc,0,sizeof(adc));memset(&dma,0,sizeof(dma));
    if(HAL_GetREVID()!=REV_ID_Y && HAL_GetREVID()!=REV_ID_V)return false;
    __HAL_RCC_ADC12_CLK_ENABLE();__HAL_RCC_DMA2_CLK_ENABLE();__HAL_RCC_D2SRAM1_CLK_ENABLE();
    GPIO_InitTypeDef g={0};g.Mode=GPIO_MODE_ANALOG;g.Pull=GPIO_NOPULL;
    g.Pin=GPIO_PIN_0|GPIO_PIN_1;HAL_GPIO_Init(GPIOB,&g);g.Pin=GPIO_PIN_1;HAL_GPIO_Init(GPIOC,&g);
    dma.Instance=DMA2_Stream0;dma.Init.Request=DMA_REQUEST_ADC1;dma.Init.Direction=DMA_PERIPH_TO_MEMORY;
    dma.Init.PeriphInc=DMA_PINC_DISABLE;dma.Init.MemInc=DMA_MINC_ENABLE;
    dma.Init.PeriphDataAlignment=DMA_PDATAALIGN_WORD;dma.Init.MemDataAlignment=DMA_MDATAALIGN_WORD;
    dma.Init.Mode=DMA_NORMAL;dma.Init.Priority=DMA_PRIORITY_LOW;dma.Init.FIFOMode=DMA_FIFOMODE_DISABLE;
    if(HAL_DMA_Init(&dma)!=HAL_OK)return false;
    adc.Instance=ADC1;adc.Init.ClockPrescaler=ADC_CLOCK_SYNC_PCLK_DIV4;
    adc.Init.Resolution=ADC_RESOLUTION_12B;adc.Init.ScanConvMode=ADC_SCAN_ENABLE;
    adc.Init.EOCSelection=ADC_EOC_SEQ_CONV;adc.Init.NbrOfConversion=3;
    adc.Init.ExternalTrigConv=ADC_SOFTWARE_START;adc.Init.ExternalTrigConvEdge=ADC_EXTERNALTRIGCONVEDGE_NONE;
    adc.Init.ConversionDataManagement=ADC_CONVERSIONDATA_DMA_ONESHOT;adc.Init.Overrun=ADC_OVR_DATA_PRESERVED;
    adc.Init.LeftBitShift=ADC_LEFTBITSHIFT_NONE;__HAL_LINKDMA(&adc,DMA_Handle,dma);
    if(HAL_ADC_Init(&adc)!=HAL_OK || HAL_ADCEx_Calibration_Start(&adc,ADC_CALIB_OFFSET_LINEARITY,ADC_SINGLE_ENDED)!=HAL_OK)return false;
    const uint32_t channels[3]={ADC_CHANNEL_9,ADC_CHANNEL_5,ADC_CHANNEL_11};
    const uint32_t ranks[3]={ADC_REGULAR_RANK_1,ADC_REGULAR_RANK_2,ADC_REGULAR_RANK_3};
    for(unsigned i=0;i<3;i++){
        ADC_ChannelConfTypeDef c={0};c.Channel=channels[i];c.Rank=ranks[i];
        c.SamplingTime=ADC_SAMPLETIME_387CYCLES_5;c.SingleDiff=ADC_SINGLE_ENDED;c.OffsetNumber=ADC_OFFSET_NONE;
        if(HAL_ADC_ConfigChannel(&adc,&c)!=HAL_OK)return false;
    }
    /* SQR1 channels9,5,11 in that order and length3. Read actual registers. */
    sv_pot_registers.cfgr=ADC1->CFGR;sv_pot_registers.cfgr2=ADC1->CFGR2;sv_pot_registers.ccr=ADC12_COMMON->CCR;
    sv_pot_registers.sqr1=ADC1->SQR1;sv_pot_registers.smpr1=ADC1->SMPR1;sv_pot_registers.smpr2=ADC1->SMPR2;sv_pot_registers.pcsel=ADC1->PCSEL;
    sv_pot_registers.clock_hz=HAL_RCC_GetHCLKFreq()/4/(HAL_GetREVID()==REV_ID_V?2:1);
    if((ADC1->SQR1&(ADC_SQR1_L|ADC_SQR1_SQ1|ADC_SQR1_SQ2|ADC_SQR1_SQ3))!=
       (2u|(9u<<ADC_SQR1_SQ1_Pos)|(5u<<ADC_SQR1_SQ2_Pos)|(11u<<ADC_SQR1_SQ3_Pos)))return false;
    if((ADC1->CFGR&ADC_CFGR_RES)!=ADC_RESOLUTION_12B ||
       (ADC12_COMMON->CCR&ADC_CCR_CKMODE)!=ADC_CLOCK_SYNC_PCLK_DIV4 ||
       ((ADC1->SMPR1&ADC_SMPR1_SMP9)>>ADC_SMPR1_SMP9_Pos)!=ADC_SAMPLETIME_387CYCLES_5 ||
       ((ADC1->SMPR1&ADC_SMPR1_SMP5)>>ADC_SMPR1_SMP5_Pos)!=ADC_SAMPLETIME_387CYCLES_5 ||
       ((ADC1->SMPR2&ADC_SMPR2_SMP11)>>ADC_SMPR2_SMP11_Pos)!=ADC_SAMPLETIME_387CYCLES_5 ||
       (ADC1->PCSEL&((1u<<9)|(1u<<5)|(1u<<11)))!=((1u<<9)|(1u<<5)|(1u<<11)))return false;
    HAL_NVIC_SetPriority(DMA2_Stream0_IRQn,4,0);HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
    HAL_NVIC_SetPriority(ADC_IRQn,4,0);HAL_NVIC_EnableIRQ(ADC_IRQn);
    return true;
}
static bool start(void *ctx){(void)ctx;if(error)return false;done=0;return HAL_ADC_Start_DMA(&adc,words,3)==HAL_OK;}
static int poll(void *ctx,uint32_t raw[3]){
    (void)ctx;if(error || (ADC1->ISR&ADC_ISR_OVR))return -1;
    if(!done)return 0;
    __DMB();if(__HAL_DMA_GET_COUNTER(&dma)!=0)return -1;
    memcpy(raw,words,sizeof(words));return 1;
}
static void stop(void *ctx){(void)ctx;if(HAL_ADC_Stop_DMA(&adc)!=HAL_OK)error=1;}
sv_pot_bus sv_pot_adc_bus(void){return (sv_pot_bus){start,poll,stop,NULL};}
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *h){if(h==&adc){__DMB();done=1;sv_pot_registers.generations++;}}
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *h){if(h==&adc){error=1;sv_pot_registers.errors++;}}
void DMA2_Stream0_IRQHandler(void){HAL_DMA_IRQHandler(&dma);}
void ADC_IRQHandler(void){HAL_ADC_IRQHandler(&adc);}
