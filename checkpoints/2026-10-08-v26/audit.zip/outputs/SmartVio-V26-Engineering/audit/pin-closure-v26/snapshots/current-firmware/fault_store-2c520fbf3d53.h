#ifndef SV_FAULT_STORE_H
#define SV_FAULT_STORE_H
#include <stdint.h>
uint32_t sv_fault_store_load(void);
int sv_fault_store_append(uint32_t faults);
#endif
