#ifndef SV_HAL_CONF_H
#define SV_HAL_CONF_H
#define HAL_MODULE_ENABLED
#define HAL_RCC_MODULE_ENABLED
#define HAL_GPIO_MODULE_ENABLED
#define HAL_DMA_MODULE_ENABLED
#define HAL_CORTEX_MODULE_ENABLED
#define HAL_SAI_MODULE_ENABLED
#define HAL_PWR_MODULE_ENABLED
#define HAL_FLASH_MODULE_ENABLED
#define HAL_IWDG_MODULE_ENABLED
#define HAL_ADC_MODULE_ENABLED
#define USE_HAL_ADC_REGISTER_CALLBACKS 0U
#define HSE_STARTUP_TIMEOUT 100U
#define HSI_VALUE 64000000UL
#define CSI_VALUE 4000000UL
#define LSI_VALUE 32000UL
#define LSE_VALUE 32768UL
#define LSE_STARTUP_TIMEOUT 5000U
#define EXTERNAL_CLOCK_VALUE 24576000UL
#define VDD_VALUE 3300UL
#define TICK_INT_PRIORITY 0U
#define USE_RTOS 0U
#define USE_HAL_SAI_REGISTER_CALLBACKS 0U
#define USE_FLASH_ECC 0U
#include "stm32h7xx_hal_rcc.h"
#include "stm32h7xx_hal_gpio.h"
#include "stm32h7xx_hal_dma.h"
#include "stm32h7xx_hal_cortex.h"
#include "stm32h7xx_hal_sai.h"
#include "stm32h7xx_hal_pwr.h"
#include "stm32h7xx_hal_flash.h"
#include "stm32h7xx_hal_iwdg.h"
#include "stm32h7xx_hal_adc.h"
#define assert_param(x) ((void)0U)
#endif
