#include "sv_speaker.h"
#include "dsp/filtering_functions.h"
#include <math.h>
/* Bilinear 850Hz/48kHz two-pole Butterworth HPF. CMSIS uses positive
 * feedback coefficients, opposite the denominator convention. */
static const float coeff[5]={0.924335148f,-1.848670296f,0.924335148f,1.842936908f,-0.854403684f};
void sv_speaker_reset(sv_speaker *s){
    arm_biquad_casd_df1_inst_f32 f;
    arm_biquad_cascade_df1_init_f32(&f,1,coeff,s->state);
}
int32_t sv_speaker_peak_cap(uint32_t upper){
    /* Until ADC/board transfer is qualified, never use a nominal3.3V model
     * or reduce the SYS upper bound below MAX98357's5.5V supply limit.
     * max(SYS,2.727V full-scale peak at gain3.6dB) gives a conservative
     * candidate audio transfer envelope; 0.9V peak leaves measurement margin.
     * This is not a guarantee for PWM, overshoot, acoustics or heating. */
    if(upper<5500)upper=5500;
    if(upper>6000)return 0;
    int32_t cap=(int32_t)((uint64_t)8388607u*900u/upper);
    return cap<3355392?cap:3355392;
}
bool sv_speaker_process(sv_speaker *s,float *mono,uint32_t *out,size_t frames,uint32_t upper){
    if(!s || !mono || !out || frames>128)return false;
    int32_t cap=sv_speaker_peak_cap(upper);
    arm_biquad_casd_df1_inst_f32 f={.numStages=1,.pState=s->state,.pCoeffs=coeff};
    arm_biquad_cascade_df1_f32(&f,mono,mono,(uint32_t)frames);
    bool ok=true;
    for(size_t n=0;n<frames;n++){
        float v=mono[n]*8388608.0f;
        if(!isfinite(v)){ok=false;v=0;}
        if(v>cap)v=(float)cap;
        if(v< -cap)v=(float)-cap;
        out[2*n]=(uint32_t)(int32_t)v*256u;out[2*n+1]=0;
    }
    if(!ok){sv_speaker_reset(s);for(size_t n=0;n<2*frames;n++)out[n]=0;}
    return ok;
}
