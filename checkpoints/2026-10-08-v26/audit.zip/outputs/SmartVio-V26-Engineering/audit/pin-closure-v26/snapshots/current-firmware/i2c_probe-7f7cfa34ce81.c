#ifdef SV_I2C_REGISTER_MODEL
#include "i2c-model-device.h"
#define SAMPLE_ISR() sv_i2c_model_status()
#else
#include "stm32h7xx.h"
#define SAMPLE_ISR() I2C1->ISR
#endif
#include "i2c_probe.h"

/* CMSIS device registers only. RM0433 I2C master transfer procedure: pointer
 * write without AUTOEND, TC, repeated START+read with AUTOEND, STOPF clear. */
typedef struct {uint32_t at,limit,spins;} deadline;
static bool expired(deadline *d){
    /* Iteration cap also bounds a broken/stopped SysTick. */
    return sv_target_millis()-d->at>=d->limit || ++d->spins>=200000u;
}
static bool wait_flag(uint32_t mask,deadline *d){
    for(;;){
        uint32_t s=SAMPLE_ISR();
        if(s&(I2C_ISR_NACKF|I2C_ISR_BERR|I2C_ISR_ARLO|I2C_ISR_OVR))return false;
        if(s&mask)return true;
        if(expired(d))return false;
    }
}
static bool abort_transfer(void){
    /* Monitor faults latch upstream. No automatic retry or bus clock-pulsing. */
    /* ARLO means another master owns the bus: never request its STOP. */
    uint32_t s=I2C1->ISR;
    if((s&I2C_ISR_BUSY) && !(s&I2C_ISR_ARLO))I2C1->CR2|=I2C_CR2_STOP;
    I2C1->CR1&=~I2C_CR1_PE;
    I2C1->ICR=I2C_ICR_NACKCF|I2C_ICR_BERRCF|I2C_ICR_ARLOCF|I2C_ICR_OVRCF|I2C_ICR_STOPCF;
    return false;
}
static bool begin(uint8_t address,uint32_t count,bool read,bool autoend,deadline *d){
    if(expired(d) || !(I2C1->CR1&I2C_CR1_PE))return false;
    I2C1->CR2=((uint32_t)address<<1)|(count<<I2C_CR2_NBYTES_Pos)|
              (read?I2C_CR2_RD_WRN:0)|(autoend?I2C_CR2_AUTOEND:0)|I2C_CR2_START;
    return true;
}
static bool idle(deadline *d){
    while(SAMPLE_ISR()&I2C_ISR_BUSY)if(expired(d))return false;
    I2C1->ICR=I2C_ICR_NACKCF|I2C_ICR_BERRCF|I2C_ICR_ARLOCF|I2C_ICR_OVRCF|I2C_ICR_STOPCF;
    return true;
}
static bool read_word(void *ctx,uint8_t addr,uint8_t reg,uint8_t *data,size_t n,uint32_t timeout){
    (void)ctx;
    if(!data || !timeout || timeout>2 || !((n==2 && (addr==0x48 || addr==0x49)) || (addr==0x4a && n>=1 && n<=3)))return false;
    deadline d={sv_target_millis(),timeout,0};
    if(!idle(&d)||!begin(addr,1,false,false,&d)||!wait_flag(I2C_ISR_TXIS,&d))return abort_transfer();
    I2C1->TXDR=reg;
    if(!wait_flag(I2C_ISR_TC,&d)||!begin(addr,(uint32_t)n,true,true,&d))return abort_transfer();
    for(unsigned j=0;j<n;j++){
        if(!wait_flag(I2C_ISR_RXNE,&d))return abort_transfer();
        data[j]=(uint8_t)I2C1->RXDR;
    }
    if(!wait_flag(I2C_ISR_STOPF,&d))return abort_transfer();
    I2C1->ICR=I2C_ICR_STOPCF;
    if(expired(&d))return abort_transfer();
    return true;
}
static bool write_word(void *ctx,uint8_t addr,uint8_t reg,const uint8_t *data,size_t n,uint32_t timeout){
    (void)ctx;
    if(!data || !timeout || timeout>2 || !((n==2 && (addr==0x48 || addr==0x49)) || (addr==0x4a && n>=1 && n<=3)))return false;
    deadline d={sv_target_millis(),timeout,0};
    if(!idle(&d)||!begin(addr,(uint32_t)n+1,false,true,&d)||!wait_flag(I2C_ISR_TXIS,&d))return abort_transfer();
    I2C1->TXDR=reg;
    for(unsigned j=0;j<n;j++){
        if(!wait_flag(I2C_ISR_TXIS,&d))return abort_transfer();
        I2C1->TXDR=data[j];
    }
    if(!wait_flag(I2C_ISR_STOPF,&d))return abort_transfer();
    I2C1->ICR=I2C_ICR_STOPCF;
    if(expired(&d))return abort_transfer();
    return true;
}
bool sv_stm32_i2c1_init(void){
    uint32_t div=RCC->CR&RCC_CR_HSIDIV;
    if(!(RCC->CR&RCC_CR_HSIRDY) || (div!=RCC_CR_HSIDIV_8 && div!=RCC_CR_HSIDIV_1))return false;
    /* Official HAL RCC_I2C123CLKSOURCE_HSI = I2C123SEL_1 (binary10). */
    RCC->D2CCIP2R=(RCC->D2CCIP2R&~RCC_D2CCIP2R_I2C123SEL)|RCC_D2CCIP2R_I2C123SEL_1;
    RCC->AHB4ENR|=RCC_AHB4ENR_GPIOBEN;(void)RCC->AHB4ENR;
    GPIOB->BSRR=(1u<<8)|(1u<<9);
    GPIOB->OTYPER|=(1u<<8)|(1u<<9);
    GPIOB->PUPDR&=~((3u<<16)|(3u<<18));
    GPIOB->OSPEEDR&=~((3u<<16)|(3u<<18));
    GPIOB->AFR[1]=(GPIOB->AFR[1]&~0xffu)|0x44u;
    GPIOB->MODER=(GPIOB->MODER&~((3u<<16)|(3u<<18)))|(2u<<16)|(2u<<18);
    RCC->APB1LENR|=RCC_APB1LENR_I2C1EN;(void)RCC->APB1LENR;
    RCC->APB1LRSTR|=RCC_APB1LRSTR_I2C1RST;RCC->APB1LRSTR&=~RCC_APB1LRSTR_I2C1RST;
    I2C1->CR1=0;
    /* HSI/8=8MHz; prescaler2 =>4MHz, unchanged5us high/low timing. */
    I2C1->TIMINGR=((div==RCC_CR_HSIDIV_8?1u:15u)<<I2C_TIMINGR_PRESC_Pos)|(7u<<I2C_TIMINGR_SCLDEL_Pos)|
                  (4u<<I2C_TIMINGR_SDADEL_Pos)|(19u<<I2C_TIMINGR_SCLH_Pos)|19u;
    I2C1->TIMEOUTR=0;I2C1->CR1=I2C_CR1_PE;
    return true;
}
sv_mon_bus sv_stm32_monitor_bus(void){sv_mon_bus bus={NULL,read_word,write_word};return bus;}
static bool codec_read(void *ctx,uint8_t reg,uint8_t *v){return read_word(ctx,0x4a,reg,v,1,2);}
static bool codec_write(void *ctx,uint8_t reg,uint8_t v){return write_word(ctx,0x4a,reg,&v,1,2);}
sv_codec_bus sv_stm32_codec_bus(void){sv_codec_bus bus={NULL,codec_read,codec_write};return bus;}
