#ifndef SV_AUDIO_HW_H
#define SV_AUDIO_HW_H
#include "sv_factory.h"
bool sv_audio_hw_start(void);
void sv_audio_hw_stop(void);
uint32_t sv_audio_hw_service(sv_factory *,uint32_t now);
uint32_t sv_audio_hw_pairs(void);
bool sv_audio_hw_ready(uint32_t now);
void sv_audio_hw_codec_ready(uint32_t now);
void sv_audio_emergency_mute(void);
#endif
