#ifndef SV_I2C_PROBE_H
#define SV_I2C_PROBE_H
#include "sv_telemetry.h"
#include "sv_pcm1864.h"
bool sv_stm32_i2c1_init(void);
sv_mon_bus sv_stm32_monitor_bus(void);
sv_codec_bus sv_stm32_codec_bus(void);
uint32_t sv_target_millis(void);
#endif
