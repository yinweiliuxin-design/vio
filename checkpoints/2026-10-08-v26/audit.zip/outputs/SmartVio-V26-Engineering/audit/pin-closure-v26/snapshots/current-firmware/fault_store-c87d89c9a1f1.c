#include "stm32h7xx_hal.h"
#include "fault_store.h"
#include "sv_factory.h"
#include <string.h>
/* Bank2 sector7 reserved by linker. No erase or automatic fault clearing. */
#define JOURNAL (FLASH_BANK2_BASE+7u*128u*1024u)
static uint32_t next;
static uint32_t crc(const uint32_t *p){uint32_t c=0xffffffffu;for(unsigned i=0;i<7;i++)for(unsigned b=0;b<32;b++){uint32_t bit=(p[i]>>b)&1;c=(c>>1)^((0u-((c^bit)&1))&0xedb88320u);}return ~c;}
uint32_t sv_fault_store_load(void){
    uint32_t faults=0;next=0;
    for(unsigned i=0;i<4096;i++){
        const uint32_t *r=(const uint32_t*)(JOURNAL+i*32u);bool blank=true;
        for(unsigned j=0;j<8;j++)if(r[j]!=0xffffffffu)blank=false;
        if(blank){next=i;return faults;}
        if(r[0]!=0x53564626 || r[1]!=i || r[3]!=~r[2] || r[7]!=crc(r))faults|=SV_D_FAULT_RESET;
        else faults|=r[2];
        next=i+1;
    }
    return faults|SV_D_FAULT_RESET;
}
int sv_fault_store_append(uint32_t faults){
    if(next>=4096)return 0;
    uint32_t r[8] __attribute__((aligned(32)))={0x53564626,next,faults,~faults,0,0,0,0};r[7]=crc(r);
    if(HAL_FLASH_Unlock()!=HAL_OK)return 0;
    HAL_StatusTypeDef result=HAL_FLASH_Program(FLASH_TYPEPROGRAM_FLASHWORD,JOURNAL+next*32u,(uint32_t)r);
    HAL_FLASH_Lock();__DSB();if(result!=HAL_OK)return 0;
    if(memcmp((const void*)(JOURNAL+next*32u),r,32))return 0;
    next++;return 1;
}
