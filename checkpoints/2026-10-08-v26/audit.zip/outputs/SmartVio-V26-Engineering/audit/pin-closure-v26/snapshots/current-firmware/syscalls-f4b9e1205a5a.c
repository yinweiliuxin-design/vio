#include <sys/stat.h>
#include <errno.h>
#include <stddef.h>
void _init(void){}
void _fini(void){}
/* No heap, filesystem or semihosting on this HOLD target. */
void *_sbrk(ptrdiff_t increment){(void)increment;errno=ENOMEM;return (void*)-1;}
int _write(int fd,const void *p,size_t n){(void)fd;(void)p;(void)n;errno=ENOSYS;return -1;}
int _read(int fd,void *p,size_t n){(void)fd;(void)p;(void)n;errno=ENOSYS;return -1;}
int _close(int fd){(void)fd;return -1;}
int _fstat(int fd,struct stat *s){(void)fd;s->st_mode=S_IFCHR;return 0;}
int _isatty(int fd){(void)fd;return 1;}
int _lseek(int fd,int offset,int whence){(void)fd;(void)offset;(void)whence;return 0;}
int _getpid(void){return 1;}
int _kill(int pid,int sig){(void)pid;(void)sig;errno=EINVAL;return -1;}
void _exit(int status){(void)status;for(;;){}}
