import hashlib
import html
import json
import runpy
from pathlib import Path

OUT = Path(__file__).resolve().parent
runpy.run_path(str(OUT / 'build_review.py'), run_name='__main__')
ENGINE = OUT.parents[1]


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(name, v):
    (OUT / name).write_text(json.dumps(v, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


review = read(OUT / 'pin-review.json')
status = read(OUT / 'status.json')
provenance = read(OUT / 'source-provenance.json')
verification = read(OUT / 'verification.json')
rows = review['rows']
mapping_count = 0
unknown_mapping = []
for r in rows:
    ref = r['ref']
    evidenced = ((ref.startswith('C') and bool(r['current_mpn'])) or
                 ref in ['L1101', 'L1501', 'L1502', 'FB1101', 'FL1501', 'Y801',
                         'SW810', 'SW811', 'SW812', 'SW813', 'SW814', 'D850', 'D851', 'D852',
                         'J102', 'J201', 'J202', 'J301'])
    r['terminal_map_review'] = {
        'status': 'EVIDENCED_TERMINAL_ROLE_DESIGN_MAPPING' if evidenced else 'PENDING_TERMINAL_OR_INTERFACE_DEFINITION',
        'actual_manufactured_physical_pin_verified': False,
        'current_routed_board_pad_geometry_verified_in_this_review': False,
        'scope': 'Manufacturer terminal role/polarity and native mapping only. Nonpolar two-terminal1/2 labels are project pad conventions, not polarized manufacturer pin identities.'
    }
    if evidenced:
        mapping_count += 1
    else:
        unknown_mapping.append(r['baseline_key'])
status['terminal_role_design_mapping_evidenced_baseline_pins'] = mapping_count
status['terminal_role_mapping_remaining_baseline_pins'] = len(unknown_mapping)
status['actual_physical_pin_or_hardware_verified'] = 0
status['terminal_mapping_is_not_application_approval'] = True
status['terminal_mapping_count_overlaps_application_counts'] = True
status['new_parent_atomic_candidate'] = {
    'VARTA': '56457201020', 'J501': 'S3B-PH-SM4-TB(LF)(SN)', 'K1201_K1202': 'AQY221R6VY',
    'status': 'PARENT_PROPOSAL_NOT_PRESENT_IN_AUDITED_NATIVE', 'pins_nets_intended_unchanged': True,
    'instruction': 'Do not label old J501/Molex mapping as proven for proposed JST. Recheck after atomic integration.'}
review.update({k:v for k,v in status.items() if k not in ['rows']})
save('pin-review.json', review)

# Capacity is the candidate's nominal discharge capacity, not a guaranteed upper charge requirement.
rmin, rmax = 4990*.99, 4990*1.01
parallel_min = 1/(1/rmin+1/(10e6*.99))
parallel_nom = 1/(1/4990+1/10e6)
imin, inom, imax = 797/rmax, 890/parallel_nom, 975/parallel_min
iterm_normal = [.09*imin, .10*inom, .11*imax]
iterm_usb100 = [.027*imin, .033*inom, .040*imax]
varta_dir = ENGINE / 'audit/selection/battery-revision'
varta_manifest = read(varta_dir / 'source-manifest.json')['sources']
varta = next(s for s in varta_manifest if s['id']=='varta-1000')
varta_file = varta_dir/varta['file']
assert sha(varta_file)==varta['sha256']
varta_evidence = {
    'id':'VARTA_56457201020_REV1_0626','manufacturer_author':'VARTA Storage GmbH',
    'host_provenance':'Manufacturer-authored original PDF hosted by distributor Texim, NOT manufacturer-hosted bytes',
    'manufacturer_url':varta['url'],'bundle_relative_path':'../selection/battery-revision/'+varta['file'],
    'sha256':varta['sha256'],'page_count':3,'pdf_pages':[1], 'reuse_not_redownload':True}
provenance['manufacturer_documents'].append(varta_evidence)

termination_options=[]
for ohms, purpose in [(1650,'Near10mA nominal; not a guaranteed<=10mA ceiling'),
                      (1300,'Conservative<=10mA upper screen in nonUSB100 modes under stated resistor assumptions; lower threshold extends CV')]:
    termination_options.append({
        'RITERM_ohm':ohms,'tolerance_percent_assumed':1,'purpose':purpose,
        'nonUSB100_current_mA_min_nom_max':[.0225*ohms*.99/rmax*1000,.03*ohms/parallel_nom*1000,.0375*ohms*1.01/parallel_min*1000],
        'USB100_current_mA_min_nom_max':[.008*ohms*.99/rmax*1000,.010*ohms/parallel_nom*1000,.012*ohms*1.01/parallel_min*1000],
        'formula':'ITERM=KITERM*RITERM/RISET_effective; KITERM .0225/.0300/.0375 nonUSB100, .008/.010/.012 USB100',
        'new_ref':None,'exact_mpn':None,'status':'RESISTANCE_OPTION_ONLY_NOT_A_MERGEABLE_NEW_PART',
        'blocked_by':['R tolerance/TCR/operating temperature and monitor leakage budget must be included.',
                      'VARTA10mA is a recommendation, not a published zero-tolerance hard threshold window.',
                      'No USB current authorization or charger enable follows from this option.']})
timer_options=[]
for ohms in [47500,68100,70600]:
    tmin,tnom,tmax=10*(ohms/1000)*.99*36/3600,10*(ohms/1000)*48/3600,10*(ohms/1000)*1.01*60/3600
    timer_options.append({'RTMR_ohm':ohms,'tolerance_percent_assumed':1,
                          'fastcharge_timer_hours_min_typ_max':[tmin,tnom,tmax],
                          'precharge_timer_minutes_min_typ_max':[tmin*6,tnom*6,tmax*6],
                          'resistor_range_inside_18_to_72kohm':18000<ohms*.99 and ohms*1.01<72000,
                          'ideal_CC_1Ah_worst_current_time_hours':1/imin,
                          'minimum_timer_minus_ideal_CC_floor_hours':tmin-1/imin,
                          'exact_mpn':None,'new_ref':None,
                          'status':'TIMING_WINDOW_OPTION_ONLY_NOT_FULL_CHARGE_PROOF',
                          'formula':'tFAST=10*RTMR(kohm)*KTMR(s/kohm), KTMR36/48/60; tPRE=tFAST/10'})

charge = {
    'schema':'smartvio-v26-bq24074-candidate-charge-fit/1.0', 'audited_native_sha256':status['source_sha256'],
    'scope':'User-requested charger interface calculation supplement. Pack selection, NTC and protection remain battery-owner decisions.',
    'candidate_not_current':{'mpn':'VARTA56457201020','nominal_mAh':1000,'minimum_rated_mAh':950,
                             'charge_method':'CC/CV','max_charge_current_mA':1000,'max_charge_voltage_V':[4.15,4.25],
                             'recommended_cutoff_mA':10,'alternative_recommended_timer_h':3.5,'charge_temperature_C':[0,45],
                             'capacity_is_guaranteed_upper_bound':False,'source':{'source_id':varta_evidence['id'],'pdf_pages':[1]}},
    'current_connections':{'R501':'4.99kohm1% RISET toGND', 'U501_16':'RISET',
                           'U501_14_TMR':{'net':None,'meaning':'NC selects internal default timer; not timer disabled'},
                           'U501_15_ITERM':{'net':None,'meaning':'NC selects internal termination; not no termination'},
                           'monitor_load':'R1715=10Mohm fromMON_ICHG_BUF_IN toGND through TMUX1511 when on',
                           'enable':'CE remains high/charging disabled by safety policy; no enable authorization generated'},
    'evidence':[{'source_id':'BQ24074','pdf_pages':[8,9,10,13,25,27,28]},
                {'source_id':varta_evidence['id'],'pdf_pages':[1]}],
    'current_budget':{
        'KISET_Aohm_min_typ_max':[797,890,975], 'RISET_initial_ohm_min_max':[rmin,rmax],
        'parallel_monitor_min_ohm':parallel_min,
        'fastcharge_current_mA_min_nom_max':[imin*1000,inom*1000,imax*1000],
        'precharge_current_mA_min_nom_max':[70/rmax*1000,88/parallel_nom*1000,106/parallel_min*1000],
        'formula':'ICHG=KISET/RISET; lower screen allows monitor disconnected, upper screen includes10M1% parallel load; no requiredCCcurrent assumed duringDPPM.',
        'basis_limits':['BQ electrical-current guarantees are over0..125C junction at stated test conditions, VIN5V, noDPPM/thermal reduction.',
                       'Resistor initial1% only. Extra temperature coefficient, analog-switch/OPA leakage and field drift excluded from these numerical screens.',
                       'Current delivery is less inUSB100, thermalregulation,DPPM,orinputDPM;178mA is not a minimum available charging current.',
                       'The10Mmonitor loading is modeled as a passive parallel path. Actual monitor transfer/current accuracy is not thereby calibrated.']},
    'default_termination':{
        'nonUSB100_mA_min_nom_max':[x*1000 for x in iterm_normal],
        'USB100_mA_min_nom_max':[x*1000 for x in iterm_usb100],
        'conclusion':'DefaultnonUSB100 termination is above recommended10mA and can terminate earlier; not equivalent to the battery recommendation. This is a matching/capacity issue, not proof of overcharge.',
        'termination_detection_disabled_during':['thermal regulation','DPPM','VIN-DPM'],
        'ITERM_pin_may_be_NC':True,
        'termination_and_pack_fit_closed':False},
    'default_timers':{
        'precharge_minutes_min_typ_max':[24,30,36], 'fastcharge_hours_min_typ_max':[4,5,6],
        'ideal_1Ah_CC_hours_at178mA':1/.178,
        'ideal_1Ah_CC_hours_at_programmed_min_nom_max':[1/imin,1/inom,1/imax],
        'ideal_charge_in_3h5_mAh_at_min_nom_max':[3.5*imin*1000,3.5*inom*1000,3.5*imax*1000],
        'conclusion':'A nominal1000mAh replenishment at178mA has an idealCC-only floor about5.62h; default4..6h safety timer does not prove completion beforetimeout. ActualSOC/precharge/CV/capacity/efficiency matter.',
        'VARTA_3h5_interpretation':'The one-page pack sheet gives10mA or3.5h but does not state the charging current/conditions for thattimer. At178mA,3.5h is a partial-charge time budget, not a1000mAh full-charge proof. Do not scale the recommendation silently.',
        'dynamic_timer':'Timer slows proportionately inDPPM/VIN-DPM/thermalregulation and suspends inthermalshutdown; it is not a fixedwallclock upperlimit.',
        'reset_events':['CEtoggle','USBsuspend enter/exit','inputpower cycle/OVP restart perdata sheet'],
        'fault_policy':'Do not cyclically clear timeout or resetCE to force completion. Preservefaultlatch/authorization policy.',
        'timer_fit_closed':False},
    'termination_resistor_options':termination_options,'timer_resistor_options':timer_options,
    'unapplied_circuit_delta_options':[
        {'pin':'U501.15','from_net':None,'proposed_net':'CHG_ITERM','new_component':'RITERM, no ref/MPN allocated','other_net':'GND','automatic_merge':False},
        {'pin':'U501.14','from_net':None,'proposed_net':'CHG_TMR','new_component':'RTMR, no ref/MPN allocated','other_net':'GND','automatic_merge':False}],
    'what_is_closed':[
        'BQ24074 pin14/15 NC meanings and publishedtimer/termination formulas have been checked.',
        'CurrentnonUSB100 default termination is not10mA within the stated initial-tolerance current budget.',
        'Defaulttimer doesnotguaranteefull1000mAh replenishment at178mA; typical5h is not a guaranteed6h.',
        'BQstatic4.16..4.23V fallsinsidecandidate4.20+/-0.05V voltageinterval; no transient/clamp guarantee follows.'],
    'remaining_no_release_conditions':[
        'No agreed battery-compatible termination window/charge-time policy atactuallowC-rate; externalR options are proposals only.',
        'CV/precharge worst-casetime, usableSOC range, actualcapacityupper andtemperature bounds absent.',
        'Inputcurrentgrant andSYSload/thermalbudget do not guarantee178mA delivered.',
        'PackNTCR/T tolerances, independenttemperatureinterlock attachment and0..45Cmatch stillownedbybatteryagent.',
        'C501/C502/C503 biasedcapacitance andpowerpathtransients unclosed.',
        'No changes toCHARGE_DISABLE, firmwarepermission ornormalchargingrelease.'],
    'normal_charging_authorized':False,'physical_tests_executed':0,'global_native_written':False}
save('bq24074-charge-fit.json',charge)

anchor_data=[]
oldrows={r['ref']:r for r in read(ENGINE/'audit/passive-closure/application-audit.json')['rows']}
patch=read(OUT/'correction-patch.json')
for change in patch['unmerged_compound_anchor_changes']:
    ref=change['ref']; old=oldrows[ref]
    anchor_data.append({'ref':ref,'current_mpn':old['current_mpn'],'current_value':old['current_value'],
                        'current_pins':old['current_pins'],'proposed_mpn':change['set_fields']['mpn'],
                        'proposed_value':change['set_fields']['value'],
                        'proposed_part':old.get('selected_part'), 'bank':old.get('bank'),
                        'current_standard_test_capacitance_bound_uF':old.get('current_standard_test_capacitance_bound_uF'),
                        'proposal_only':True,'application_approved':False,'physical_tests_executed':0,
                        'reason':'Parent did not merge this compoundcap/geometry ECO. Proposedbounds may not be copied into current effectiveC.'})
save('anchor-selection.json',{'source_sha256':status['source_sha256'],'anchors':anchor_data,
                             'anchor_count':len(anchor_data),'new_components_still_unmerged':30,
                             'blank_C_R_count':len(patch['current_blank_C_R_MPNs']), 'nominal_metadata_resistor_patch_count':3})
patch['charge_fit_reference']='bq24074-charge-fit.json'
patch['charge_new_net_deltas_authorized_or_applied']=False
save('correction-patch.json',patch)
status['files'].update({'charging':'bq24074-charge-fit.json','anchor_selection':'anchor-selection.json'})
status['charge_fit_normal_charging_authorized']=False
status['charge_fit_primary_conclusion']='ITERMdefaultnonUSB100 roughly14.23..21.72mA; TMRdefault4..6h cannotprove full1000mAh at178mA. Optionsnotapplied.'
save('status.json',status)
save('source-provenance.json',provenance)
verification['terminal_mapping_counts']={'evidenced_design':mapping_count,'pending_design':len(unknown_mapping),'actual_physical_verified':0}
verification['terminal_mapping_pending_baseline_keys']=unknown_mapping
verification['checks'].extend([
    {'check':'Terminal mapping categories total287','pass':mapping_count+len(unknown_mapping)==287},
    {'check':'VARTA candidate original PDF checksum matches source manifest','pass':sha(varta_file)==varta['sha256']},
    {'check':'No normal charging authorization introduced','pass':charge['normal_charging_authorized'] is False},
    {'check':'Defaultfastchargebudgetmax stillbelowcandidate1A under statedscreen','pass':imax<1.0},
    {'check':'Currentnative atfinalizationmatchesauditedinput','pass':sha(ENGINE/'electrical/native-components.json')==status['source_sha256']},
])
verification['all_structure_checks_pass']=all(c['pass'] for c in verification['checks'])
save('verification.json',verification)

addition='<h2>Terminal Mapping and Charge Interface Supplement</h2>'
addition+=f'<p>{mapping_count}/287 baseline pins have manufacturer-supported terminal-role/native mapping; {len(unknown_mapping)} still need exactinterface/terminaldefinition. Actualhardwarephysicalpinverified=0. These mappingcounts overlap, and must not be added to, applicationcounts.</p>'
addition+='<p>Pendingparentatomiccandidate: VARTA56457201020 + JST S3B-PH-SM4-TB(LF)(SN) + K1201/2 AQY221R6VY. No candidate is representedas currentnative.</p>'
addition+='<p><a href="bq24074-charge-fit.json">BQ24074 /1000mAh /178mA analysis</a> | <a href="anchor-selection.json">10 anchors with exact parts/land/evidence</a></p>'
addition+='<p>ITERM NC selects defaulttermination: nonUSB100 about14.23..21.72mA understatedinitialtolerancebudget, not10mA. TMR NC selects4..6hfastchargetimer and24..36minprecharge. Ideal1000/178=5.618h beforeCV. Defaulttimer andVARTA3.5h recommendation do notprove fullcharge atthiscurrent.</p>'
addition+='<p>1.65k ITERM is a nominal10mA option but notguaranteed10mAupper;1.30k givesabout5.75..9.97mA nonUSB100 understatedassumptions.70.6k TMR1% givesabout6.989..11.884h fasttimer;CV andpacktimepolicy stillunproved. Valuesonly,noallocatedref/exactMPN ornetchange. TimersslowunderDPPM/thermalinputlimits;never disable/periodicallyresettimer toclaimcompletion. Normalchargingremainsdisabled.</p>'
report=OUT/'report.html'
content=report.read_text(encoding='utf-8')
content=content.replace('<h2>Required Corrections / Limits</h2>', addition+'<h2>Required Corrections / Limits</h2>')
report.write_text(content,encoding='utf-8')
result={k:status[k] for k in ['closed_design_review_pins','not_closed_baseline_pins','status_counts',
                              'terminal_role_design_mapping_evidenced_baseline_pins','terminal_role_mapping_remaining_baseline_pins']}
result['BQ_current_mA']=[imin*1000,inom*1000,imax*1000]
result['BQ_default_termination_mA']=[x*1000 for x in iterm_normal]
result['verification_pass']=verification['all_structure_checks_pass']
print(json.dumps(result,ensure_ascii=False,indent=2))

# Parent disposition supersedes the old target snapshot, without erasing its evidence.
findings=read(OUT/'findings.json')
for f in findings:
    if f['id'] in ['F01','F02']:
        f['historical_snapshot_status']=f['status']
        f['historical_snapshot_statement']=f['statement']
        f['status']='AWAITING_NEW_FIRMWARE_INTEGRATION_AND_TARGET_TEST_VERIFICATION'
        f['parent_followup']='Parent dispatched firmware owner for immediate correction and target tests. Completion not yet received in this task.'
        f['statement']='Historical snapshot issue has been assigned for remediation; latest integrated target status remains unverified here. '+f['historical_snapshot_statement']
        f['closure_evidence_needed']=['Integrated firmware source hash','Target-path test showing corrected behavior','Owner/parent completion handoff; physical tests stay0 unless actually performed']
save('findings.json',findings)
patch['firmware_or_circuit_findings']=findings
patch['unmerged_compound_anchor_changes_disposition']='HISTORICAL_MATH_OPTION_NOT_RECOMMENDED_FOR_INTEGRATION'
for a in patch['unmerged_compound_anchor_changes']:
    a['status']='HISTORICAL_MATH_OPTION_NOT_RECOMMENDED_FOR_INTEGRATION'
    a['integration_candidate']=False
    a['parent_followup']='Do not place30-bank proposal merely to raise closure count; prioritize compact manufacturer-example MLCC design.'
save('correction-patch.json',patch)
strict=read(OUT/'critical-capacitor-options.json')
strict['integration_candidate']=False
strict['disposition']='ARCHIVED_MATHEMATICAL_COUNTEREXAMPLES_NOT_RECOMMENDED_IMPLEMENTATIONS'
for option in strict.get('options',[]):
    option['status']='NOT_RECOMMENDED_LARGE_C0G_BANK_NO_PLACEMENT_APPROVAL'
save('critical-capacitor-options.json',strict)
anchors=read(OUT/'anchor-selection.json')
anchors['disposition']='Historical10compoundanchors only; not preferrednewimplementation. Seecompact-mlcc-options.json.'
for a in anchors['anchors']:
    a['integration_candidate']=False
save('anchor-selection.json',anchors)

compact=[]
for refs,source_ref,reason in [
    (['C303','C1502'],'C301','1uF16V0805 preserves nominal capacitance; pump/VREFbias andESR still need application-specific evidence.'),
    (['C304','C701','C702','C807','C808','C1902'],'C305','2.2uF16V0805 preserves nominalcapacitance; smaller than2220bank, but2.2uF nominal is not proof ofVCAPwindow/pumpstorage/inputeffective1uF.')]:
    p=oldrows[source_ref]['selected_part']
    compact.append({'refs':refs,'candidate_mpn':p['mpn'],'manufacturer':'YAGEO','nominal_uF':p['nominal_uF'],
                    'rated_voltage_V':p['rated_voltage_V'],'tolerance_percent':p['tolerance_percent'],'dielectric':p['dielectric'],
                    'package':'0805/2012','body_lwh_max_mm':p['body_lwh_max_mm'],'land':p['land'],
                    'evidence':p['evidence'],'reason':reason,'ceff_min_uF':None,'dc_bias_retention_guaranteed':None,
                    'application_status':'NOMINAL_PACKAGE_CANDIDATE_ONLY_NOT_CEFF_APPROVED','eligible_automatic_merge':False})
for refs,mpn,cap,voltage,dielectric,temp,url in [
    (['C1102'],'GRM21BC71E106ME11L',10,25,'X7S',[-55,125],'https://www.murata.com/ja-jp/products/productdetail?partno=GRM21BC71E106ME11L'),
    (['C1104','C1105','C1106'],'GRM21BC81C226ME44L',22,16,'X6S',[-55,105],'https://www.murata.com/products/productdetail?partno=GRM21BC81C226ME44L')]:
    compact.append({'refs':refs,'candidate_mpn':mpn,'manufacturer':'Murata','nominal_uF':cap,'rated_voltage_V':voltage,
                    'tolerance_percent':20,'dielectric':dielectric,'temperature_range_C':temp,
                    'package':'0805/2012','body_lwh_max_mm':[2.2,1.45,1.45],
                    'body_dimensions_evidence_class':'Officialmanufacturerproductpage searchindex; directpage access403; notsavedasverifiedcurrentPDF',
                    'manufacturer_product_url':url,
                    'evidence':[{'source_id':'TPS63070','pdf_pages':[16,19],
                                 'claim':'Exact Murata BOM order code;0805size, ratedvoltage, nominalvalue. Table6 says2outputparts below/equal5V,3above5V.'}],
                    'manufacturer_land':None,'manufacturer_land_status':'ExactMuratarecommendedpad drawing notcaptured; do notoverwritecurrentpads bybodycodealone',
                    'ceff_min_uF':None,'application_status':'PREFERRED_COMPACT_POWER_DESIGN_EVALUATION_NOT_GUARANTEED_CEFF',
                    'eligible_automatic_merge':False})
compact_doc={
    'schema':'smartvio-v26-compact-mlcc-evaluation/1.0','source_sha256':status['source_sha256'],
    'direction':'Keep realistic0603/0805 decoupling andmanufacturerexample bulk. LargeC0Gbanks are mathematicalalternatives, not suggestedrouting.',
    'changes_applied':False,'candidates':compact,
    'manufacturer_curve_access':{
        'output_model_url':'https://ds.murata.com/simsurfing/mlcc.html?oripartnumbers=%5B%22GRM21BC81C226ME44L%22%5D&partnumbers=%5B%22GRM21BC81C226ME44%22%5D',
        'official_index_observed_update':'2026-09-02',
        'live_product_access':'403 forbothMurata productpages; noaccessrestrictionbypass attempted',
        'numerical_DC_curve_export_obtained':False,
        'claim_limit':'Officialpart/index andTIBOM establish a realcandidate, not an extractedbiascurve or guaranteedmin. No inventedbiaspoint.',
        'typical_curve_is_not_manufacturer_guaranteed_corner':True},
    'acceptance_thresholds_not_existing_proofs':{
        'C1104_C1105':{'VDC_design_screen_V':3.45,'required_min_uF':18,
                       'formula':'44uF*.8(initialtol)*.78(X6Sfulltemp)*D(bias)*A(aging)>=18uF',
                       'required_D_times_A_min':18/(44*.8*.78),
                       'assumptions':'Separablefactorsare anexplicitqualificationbudget, not a combinedmanufacturer guarantee. ACamplitude/frequency/mountingstillmatter.'},
        'C1102_single10uF':{'VDC_design_screen_V':4.5,'required_min_uF':4.7,
                            'formula':'10*.8*.78*D*A>=4.7','required_D_times_A_min':4.7/(10*.8*.78)},
        'C1102_optional_two10uF':{'new_ref_allocated':False,'required_D_times_A_min':4.7/(20*.8*.78),
                                'status':'ONE_EXTRA0805_OPTION_ONLY_IFCURVE_ANDTRANSIENTDATAREQUIREIT'},
        'C303_C304':{'formula':'2.2*.9*.85*Dstorage*Astorage >=1*1.1*1.15*Dflying_max*Aflying_max',
                     'required_storage_to_flying_combined_factor_ratio_min':1.265/1.683,
                     'voltage_condition':'UseactualCPP-CPN differential andHPVSS magnitude, not eachpin-to-groundalone; pumpingAC/ESR stillopen.'},
        'C807_C808':{'zero_bias_initial_plus_X7R_temperature_extremes_uF':[1.683,2.783],
                     'strict_interpreted_operating_window_uF':[1.76,2.64],
                     'result':'GenericX7R+/-15% and10% initialtol alreadycannotprovethewholewindow. Exactcharacteristic/qualificationoracceptedmanufacturerreferenceconditionsneeded;noautomaticVCAPapproval.'},
        'C1502':{'formula':'1*.9*.85*D*A>=.3','required_D_times_A_min':.3/.765,
                  'remaining':'Max3uF underactualbias/AC andregulatorloopESR also need evidence.'}},
    'remaining_nonclosable_from_current_evidence':[
        'Exactmanufacturerbias/AC/frequency/temperature/agingcombined lowerbounds are absent, evenwheretypicalcurves mayexist.',
        'ExactMurata manufacturerland andcurrentsupply/lifecycleconfirmation notarchived;TIdesignexampleis2019, notcurrentstockapproval.',
        'VCAP ESR<100mohm atregulatorconditions andpumpcapacitorripplecurrent/loopplacement notproved.',
        'Buckinputsourceimpedance andoutputloadstep/loopstability notestablishedbytwo22uFnames.',
        'The30newbankgeometry/inrush/QODtotal wouldneednewreview; notproposedforroutineintegration.'],
    'normal_charging_authorized':False,'procurement_approved':False,'physical_tests_executed':0}
save('compact-mlcc-options.json',compact_doc)
status['firmware_findings_disposition']='F01/F02assignedtofirmwareowner; awaitingnewintegratedsourceandtargettests, notallegationagainstunreadnewfirmware'
status['large_C0G_bank_disposition']='NOT_RECOMMENDED_FOR_INTEGRATION; no closurecredit'
status['files']['compact_mlcc']='compact-mlcc-options.json'
save('status.json',status)
for r in review['rows']:
    if r['ref']=='C824':
        r['pending_limits']=['F01 historicaltargetissueassignedtofirmwareowner. Awaitnewsourceintegrationandtargettests; no conclusionaboutunreadnewtarget.']
    if r['ref'] in ['J301','C320','J901','LS901']:
        r['firmware_followup']='F02 assigned tofirmwareowner; pendingnewintegratedtargetverification. Localpassiveconclusionsdonotcertifyroutingpolicy.'
review.update({k:v for k,v in status.items() if k!='rows'})
save('pin-review.json',review)
byref=read(OUT/'application-by-ref.json')
for r in byref['rows']:
    if r['ref']=='C824': r['pending_limits']=['F01 assigned tofirmwareowner; newintegratedsourceandtargettests pending.']
    if r['ref'] in ['J301','C320','J901','LS901']:
        r['firmware_followup']='F02assigned; newintegratedtargetverification pending.'
save('application-by-ref.json',byref)
parent_followup={'user_directive':'F01/F02awaitnewfirmwareverification; demotehugeC0Gbanks; preferrealMLCCexampleandexplicitbiaslimits',
                 'old_source_sha256_retained':status['source_sha256'],'old_firmware_snapshots_retained':True,
                 'current_native_sha256':sha(ENGINE/'electrical/native-components.json'),
                 'current_firmware_hashes':{f['path']:sha(ENGINE/f['path']) for f in provenance['firmware_snapshots']},
                 'new_firmware_completion_received':False,'global_edits_performed':False}
save('parent-followup.json',parent_followup)
content=report.read_text(encoding='utf-8')
heading='<h2>最新父端跟进 / 当前交付口径</h2><p>F01/F02已派给固件负责人整改，状态为待新固件集成及目标测试复核；下方旧快照证据保留，不是对尚未复核的新固件作出失败判定。原287脚：28项局部设计检查关闭、259项未闭合；226项端子角色/极性映射有原厂依据，不等于实际PCB或实物验证。</p>'
heading+='<p>30颗新增电容和大规模C0G方案不建议合并，不用于提高关闭率。优先评估已有0603/0805 MLCC及TI示范：输出2x GRM21BC81C226ME44L、输入GRM21BC71E106ME11L。现有证据没有获取到可保证的偏压/温度/老化组合下限；原厂曲线不能凭空补数。</p><p><a href="compact-mlcc-options.json">紧凑MLCC候选与定量验收门槛</a> | <a href="parent-followup.json">父端跟进记录</a></p>'
content=content.replace('<h2>Required Corrections / Limits</h2>',heading+'<h2>Historical Snapshot Findings / Awaiting Integration</h2>')
content=content.replace('10 anchors with exact parts/land/evidence','Historical10anchors: not preferredforintegration')
report.write_text(content,encoding='utf-8')
