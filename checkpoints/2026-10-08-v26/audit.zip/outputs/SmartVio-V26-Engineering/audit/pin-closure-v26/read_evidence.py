import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sid = sys.argv[1]
pages = json.loads((ROOT / 'text' / (sid + '.json')).read_text(encoding='utf-8'))
query = sys.argv[2]
if query.isdigit():
    for p in pages:
        if p['page'] in {int(x) for x in sys.argv[2:]}:
            print('PAGE', p['page'], p['text'])
else:
    for p in pages:
        lines = p['text'].splitlines()
        matches = [i for i, line in enumerate(lines) if query.lower() in line.lower()]
        for i in matches[:5]:
            print('PAGE', p['page'], '\n'.join(lines[max(0, i-3):i+8]))
