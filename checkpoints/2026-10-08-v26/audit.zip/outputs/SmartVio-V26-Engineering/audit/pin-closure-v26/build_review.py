import copy
import hashlib
import html
import itertools
import json
import math
import os
import shutil
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
ENGINE = OUT.parents[1]
ROOT = ENGINE.parents[1]
OLD = ENGINE / 'audit/passive-closure'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ev(sid, *pages):
    return {'source_id': sid, 'pdf_pages': list(pages)}


prov = read(OUT / 'input-provenance.json')
source_hash = prov['inputs']['native']['sha256']
native = read(OUT / 'snapshots' / ('native-' + source_hash[:12] + '.json'))
parts = {c['ref']: c for c in native}
baseline = read(OUT / 'baseline-287.json')
netmap = read(OUT / 'current-net-connections.json')
oldrows = {r['ref']: r for r in read(OLD / 'application-audit.json')['rows']}
scope = {p['ref'] for p in baseline}
caprefs = {r for r in scope if r.startswith('C')}
sources = read(OUT / 'reused-document-index.json')
urls = {s['id']: s['manufacturer_url'] for s in read(OLD / 'source-evidence.json')}
selection_sources = read(ROOT / 'work/v26/selection/sources.json')
hash_urls = {s['sha256']: s['url'] for s in selection_sources if s.get('sha256')}
ti_ids = ['TLV9064', 'ADS1115', 'OPA4330', 'TMUX1511', 'TMP117', 'TPS25947']
urls.update({s: 'https://www.ti.com/lit/ds/symlink/' + s.lower() + '.pdf' for s in ti_ids})
urls['ESP32_MINI'] = 'https://www.espressif.com/sites/default/files/documentation/esp32-mini-1_datasheet_en.pdf'
local_evidence = OUT / 'source-evidence'
local_evidence.mkdir(exist_ok=True)
for s in sources:
    original = Path(s['absolute_path'])
    assert sha(original) == s['sha256']
    s['manufacturer_url'] = urls.get(s['id'], hash_urls.get(s['sha256']))
    if not original.is_relative_to(ENGINE):
        target = local_evidence / (s['id'] + '.pdf')
        shutil.copyfile(original, target)
    else:
        target = original
    s['bundle_relative_path'] = os.path.relpath(target, OUT).replace('\\', '/')
    s['reuse_not_redownload'] = True
    s['document_role'] = 'Original manufacturer publication; only cited pages used for decisions'
zero = read(OUT / 'new-source-evidence.json')
if isinstance(zero, list):
    zero = zero[0]
zp = OUT / 'new-source-evidence/RC0603JR-070RL.pdf'
sources.append({'id': 'RC0603JR-070RL', 'manufacturer_url': 'https://www.yageogroup.com/component-documentation/download/specsheet/RC0603JR-070RL',
                'sha256': sha(zp), 'page_count': 4, 'bundle_relative_path': 'new-source-evidence/RC0603JR-070RL.pdf', 'reuse_not_redownload': False})
pothtml = ROOT / 'work/v26/selection/sources/RK10J11R0A0L.html'
shutil.copyfile(pothtml, local_evidence / pothtml.name)
sources.append({'id': 'RK10J_EXACT_HTML', 'manufacturer_url': hash_urls[sha(pothtml)], 'sha256': sha(pothtml),
                'bundle_relative_path': 'source-evidence/' + pothtml.name, 'page_count': None,
                'text_lines': [732, 735, 1101, 1102], 'reuse_not_redownload': True})

# Snapshot actual implementation separately: the firmware is another owner's mutable scope.
fwfiles = ['sv_ui.c', 'sv_speaker.c', 'sv_telemetry.c', 'sv_pcm1864.c', 'sv_control.c',
           'stm32/main.c', 'stm32/pot_adc.c', 'stm32/board_pins.h', 'stm32/i2c_probe.c', 'contracts/power-audio.json']
fwdir = OUT / 'snapshots/firmware'
fwdir.mkdir(exist_ok=True)
fw_evidence = []
for f in fwfiles:
    p = ENGINE / 'firmware' / f
    target = fwdir / f.replace('/', '__')
    if not target.exists():
        shutil.copyfile(p, target)
    fw_evidence.append({'id': 'FW_' + f.replace('/', '_'), 'path': str(p.relative_to(ENGINE)).replace('\\', '/'),
                        'snapshot': str(target.relative_to(OUT)).replace('\\', '/'), 'sha256': sha(target),
                        'current_hash_at_review': sha(p), 'physical_execution_proven': False})


def fwref(file, start, end):
    return {'source_id': 'FW_' + file.replace('/', '_'), 'lines': [start, end]}


def bound(ref):
    r = oldrows[ref]
    if r['current_mpn'] != parts[ref].get('mpn'):
        raise AssertionError(('MPN drift in reused bound', ref))
    return r.get('current_standard_test_capacitance_bound_uF')


low, high = 0.95 * 0.997 * 0.997, 1.05 * 1.003 * 1.003
calc = {}


def calculation(cid, refs, formula, result, evidence, limits):
    calc[cid] = dict(id=cid, refs=refs.split(), formula=formula, result=result, evidence=evidence, limitations=limits)


calculation('C0G_BOUND', 'C320 C704 C705 C811 C820 C821 C822 C823 C824 C825 C1001 C1302 C1303 C1701 C1702 C1703 C1704 C1705 C1706 C1707 C1708 C830 C831 C832',
            'Cmin=Cnom*0.95*0.997*(1-max(.003,.25pF/Cnom)); Cmax uses + terms. DC factor=1 within rated voltage; aging=0.',
            {'factor_min_for_C_above_83pF': low, 'factor_max': high, 'temperature_C': [-55, 125],
             '10nF_min_max_nF': [10*low, 10*high], '100nF_min_max_nF': [100*low, 100*high]},
            [ev('KEM_C0G_SMD', 1, 2, 4, 14)],
            ['Manufacturer LCR test frequency, not arbitrary-frequency impedance.', 'One specified environmental-test allowance, not unlimited lifetime/combined damage.',
             'No switch-current, ESL, assembled geometry or high-frequency ESR approval.'])
calculation('KEY_RC', 'SW810 SW811 SW812 SW814 C821 C822 C823 C825',
            'Iclosed in [Vmin/Rmax,Vmax/Rmin]; Vopen_min=3.1-10.1k*250nA; tau=Rmax*Cmax; t70=-ln(.3)*tau; E=.5*Cmax*Vmax^2.',
            {'rail_assumption_V': [3.1, 3.45], 'closed_current_mA': [3.1/10100*1000, 3.45/9900*1000],
             'open_input_min_V': 3.1-10100*250e-9, 'CMOS_VIH_at_3V1': .7*3.1, 'low_contact_initial_max_V': 3.45/9900*.1,
             'tau_max_us_R_and_C_only': 10100*.01*high, 't70_max_us_R_and_C_only': -math.log(.3)*10100*.01*high,
             'stored_energy_max_uJ': .5*.01*high*3.45**2, 'switch_minimum_load': '10uA at1VDC', 'switch_maximum_load': '50mA at12VDC'},
            [ev('SKQG', 1), ev('STM32H743', 136, 137, 241, 242), ev('C0603C103J3GACTU', 1),
             fwref('sv_ui.c', 17, 39), fwref('stm32/main.c', 58, 64)],
            ['Pull-up does not limit the initial discharge of the capacitor directly across the switch.',
             'Contact pulse current and wear have no guaranteed bound here; switch pins remain pending.',
             'RC formula excludes unbounded board/input parasitic C. Manufacturer 5pF MCU input capacitance is typical, not a maximum.',
             '30ms firmware debounce exists for all four UI buttons; no measured bounce claim.'])
calculation('HP_DETECT_RC', 'J301 C320',
            'Open high=V3D-(R321+R322)*Ilkg; closed low<=Icontact*Rcontact+Ilkg*R322. tau_open=(101k+1.01k)*Cmax; tau_closed~1.01k*Cmax.',
            {'high_min_V_at_V3D3V1_pad250nA': 3.1-102010*250e-9,
             'input_low_screen_V': 3.45/99000*.1+1010*250e-9,
             'tau_open_max_ms_R_C_only': 102010*.01*high/1000,
             'tau_closed_max_ms_R_C_only': 1010*.01*high/1000,
             'inserted': 'NO contacts5/6 close: LOW', 'unplugged': 'open contact: HIGH',
             'firmware_debounce_ms': 30},
            [ev('KYCON_JACK', 1), ev('STM32H743', 136, 137, 241, 242), fwref('stm32/main.c', 224, 237)],
            ['Pad leakage limit used as published; do not invent per-pin10uA from the total-product leakage formula.',
             'This closes contact sensing electrical polarity/default/RC, not speaker routing policy.',
             'Sense open wire is indistinguishable from unplugged. Sense short is interpreted as inserted.'])
rpmin = 1/(1/9900 + 1/30000)
rpmax = 1/(1/10100 + 1/50000)
calculation('NRST_RC', 'C811 J801', 'R=R802 parallel internal30..50k; tau=R*C; fixture sink >=Vmax*(1/R802min+1/RPUmin).',
            {'parallel_R_ohm_min_max': [rpmin, rpmax], 'tau_ms_min_max': [rpmin*.1*low/1000, rpmax*.1*high/1000],
             'static_fixture_sink_mA_at_3V45': 3.45*(1/9900+1/30000)*1000,
             'manufacturer_recommended_cap_uF': .1},
            [ev('STM32H743', 144, 248), ev('C1206C104J3GACTU', 1)],
            ['Not a guaranteed boot deadline. Fixture must hold a valid low pulse and not drive an unpowered rail.', 'J801 fixture design is still pending.'])
calculation('LTC_INT', 'C824', 'VOLmax=.4V at3mA; pullup current<=3.45/9.9k; high=3.1-(1uA+.25uA)*10.1k. Pulse guarantee26ms vs software30ms.',
            {'pullup_max_mA': 3.45/9900*1000, 'high_min_V': 3.1-1.25e-6*10100,
             'low_max_V': .4, 'CMOS_VIL_at_3V1': .93, 'INT_min_pulse_ms': 26, 'software_contiguous_low_ms': 30,
             'minimum_pulse_margin_ms_before_polling_RC': -4},
            [ev('LTC2954', 3, 6), ev('STM32H743', 136, 137), fwref('stm32/main.c', 170, 175)],
            ['Electrical high/low levels pass; firmware can miss a shortest valid interrupt. Do not close the application.',
             '26ms specified minimum takes precedence over32ms nominal prose.'])
calculation('PWR_BUTTON_DC', 'SW813', 'R826 pulls PWR_PB to SYS, not V3D. Contact current <=4.5/9.9k+15uA; high>=2.9-1uA*10.1k.',
            {'SYS_assumed_V': [2.9, 4.5], 'closed_current_max_mA': (4.5/9900+15e-6)*1000,
             'closed_current_min_mA_from_external_pullup_only': 2.9/10100*1000,
             'contact_low_initial_max_V': (4.5/9900+15e-6)*.1, 'open_high_min_V': 2.9-.0101,
             'PB_threshold_min_max_V': [.6, 1.0], 'PB_external_allowed_max_V': 26.4},
            [ev('LTC2954', 3, 6, 12), ev('SKQG', 1)],
            ['No intentional shunt capacitor across this switch; unknown harness parasitics/ESD remain physical verification.',
             'Does not close downstream ONT/PDT timer tolerances or system brownout sequence.'])
calculation('POT_ADC', 'RV810 RV811 RV812 C830 C831 C832',
            'Rpot=10k+/-30%; Rth_max=13k/4+1.01k; Pmax=3.45^2/7k; tau=Rth*Cmax; t1percent=ln(100)*tau.',
            {'Rth_max_ohm': 4260, 'total_track_power_max_mW': 3.45**2/7000*1000, 'rated_power_mW_at_rated_ambient': 30,
             'manufacturer_temperature_C': [-10, 60], 'tau_max_ms_R_C_only': 4260*.1*high/1000,
             'passive_1percent_settle_ms': math.log(100)*4260*.1*high/1000,
             'actual_ADC_sample_cycles': 387.5, 'actual_firmware_scan_gap_ms': 20},
            [ev('RK10J', 1, 3), {'source_id': 'RK10J_EXACT_HTML', 'lines': [732, 747]},
             ev('STM32H743', 146, 249), fwref('stm32/pot_adc.c', 15, 45), fwref('sv_ui.c', 9, 15), fwref('sv_ui.c', 61, 80)],
            ['Actual ADC configuration exists; do not claim it is missing.', 'No guaranteed ADC charge-sharing/injection/acquisition error budget for the routed board yet.',
             'Open wiper can retain an in-range value; DMA freshness/range checks do not detect this fault.',
             'Board rated temperature must accommodate -10..60C potentiometer, including derating above50C.'])
calculation('DAC_FILTER', 'C704 C705', 'fc=1/(2*pi*R*C); use R701/R702470ohm1%, C2.2nF C0G bound.',
            {'fc_Hz_min_max_unloaded_model': [1/(2*math.pi*474.7*2.2e-9*high),1/(2*math.pi*465.3*2.2e-9*low)],
             'manufacturer_filter': '470ohm +2.2nF, characterized with10kohm load',
             'current_parallel_paths': ['R301/30222k plus headphone attenuator/input', 'C201/202 plus R290/29115k line path']},
            [ev('PCM5102A', 8, 26), ev('TPA6132A2', 5), ev('C0603C222J5GACTU', 1)],
            ['Closes local capacitor value/voltage/filter topology only, not composite loading, end-to-end THD or actual stopband response.',
             'TPA input impedance entries are typical; do not turn26.4k into a guaranteed load minimum.'])
calculation('DVDT', 'C1001', 'CdVdt_max=4.7nF*1.05630945 <10nF. Required rating>=VIN+5V; 50V>=23V+5V. Typical SR=2000/CpF.',
            {'cap_min_max_nF': [4.7*low,4.7*high], 'rating_V': 50, 'required_rating_at_operating_VINmax_V': 28,
             'typical_nominal_output_ramp_V_per_ms': 2000/4700, 'charging_I_test_uA_min_max': [.81,3.82],
             'DVDT_pin_I_over_C_test_screen_V_per_ms': [.81/(4.7*high),3.82/(4.7*low)]},
            [ev('TPS25947', 8, 11, 29, 30), ev('C0603C472J5GACTU', 1)],
            ['I/C screen is for stated current-test conditions, not a guaranteed system output ramp at5V.',
             'Actual COUT/inrush/current-limit/thermal transient still unknown. Open capacitor gives fastest ramp; short DVDT changes/prevents normal ramp.',
             '23V is recommended operating ceiling, not permission for30V steady operation.'])
ratio_corners = []
for top,bottom,pd,ron in itertools.product([15000*.999*.9975,15000*1.001*1.0025],
                                          [10000*.999*.9975,10000*1.001*1.0025],
                                          [100000*.999*.9975,100000*1.001*1.0025],[0,4.5]):
    vs = bottom/(top+bottom)
    rth = top*bottom/(top+bottom)
    ratio_corners.append(vs*pd/(rth+ron+pd))
calculation('MONITOR_RC', 'C1701 C1702 C1705 C1706',
            'S-divider15k/10k loaded by100k through RON: ratio=(Rb/(Rt+Rb))*Rpd/(Rt||Rb+RON+Rpd). Tolerance0.1%,TCR25ppm*100C independently worst-case.',
            {'nominal_ratio': 1/2.65, 'gain_corners': [min(ratio_corners),max(ratio_corners)],
             'USB5V889_max_divided_V_resistor_only': 5.889*max(ratio_corners),
             'SYS4V5_max_divided_V_resistor_only': 4.5*max(ratio_corners),
             'input_cap_tau_nominal_us': (1/(1/100000+1/6000))*.01,
             'output_cap_tau_max_us_R_C_only': 101*.01*high,
             'ADC_selected_FSR_V': 4.096, 'ADC_min_wait_ms': 10,
             'C0G_min_max_nF': [10*low,10*high], 'firmware_initial_monitor_wait_ms': 20},
            [ev('TMUX1511', 6, 7), ev('OPA4330', 9), ev('ADS1115', 5, 6),
             fwref('sv_telemetry.c', 57, 78), fwref('stm32/main.c', 161, 164)],
            ['Only passive input RC and healthy powered-rail range close for C1701/C1705.',
             'OPA turn-on100us, GBW and capacitive-drive graphs are typical, not worst-case settling/phase margin.',
             'Output filters C1702/C1706 remain pending amplifier stability and sample-charge interaction.',
             'TMUX powered-off leakage2uA at specified VD=0 cannot prove every off-state voltage by blindly multiplying100k.',
             'Bottom-divider open can overrange the following path; range rejection is not pin protection.',
             '5.889V USB and4.5V SYS are declared static design budgets, not proven transients.'])
calculation('VBUS_SENSE', 'C820',
            'R816=R817=100k1%; Vhigh_min=4.35*.495-350nA*50.5k; actual guaranteed-design VIH=.47*VDD+.25 (not only .7VDD CMOS envelope).',
            {'assumed_USB_valid_min_V': 4.35, 'Vhigh_min_V': 4.35*.495-350e-9*50500,
             'VIH_guaranteed_design_at_3V45_V': .47*3.45+.25,
             'high_margin_V': 4.35*.495-350e-9*50500-(.47*3.45+.25),
             'cap_nominal_nF': 1, 'divider_tau_max_us_R_C_only': 50500*.001*high,
             'off_supply_sense_max_at_USB5V889_V_resistor_only': 5.889*.505},
            [ev('STM32H743', 136, 137, 241, 242), ev('C0603C102J5GACTU', 1)],
            ['No false VIH-failure claim: manufacturer guaranteed-design threshold gives positive powered-state margin.',
             'PA9 mode and powered-off injection/pull configuration remain unqualified.',
             'USB_5V_SAFE low when eFuse/disable blocks it does not prove physical unplug. Firmware physical_usb_valid is not established by this divider.'])
calculation('LED_DC', 'D850 D851 D852', 'With VF>=0, Imax<=3.45/990; Pdiode_max<=3.45^2/(4*990); resistorPmax<=3.45^2/990.',
            {'current_max_mA':3.45/990*1000,'diode_power_screen_mW':3.45**2/(4*990)*1000,
             'resistor_power_screen_mW':3.45**2/990*1000, 'datasheet_IF_25C_mA':30,
             'physical_pad_map':'1=K/GND,2=A/resistor', 'VF_at5mA_max_V':3.2},
            [ev('CYAN_LED', 1, 2, 3)],
            ['No guaranteed brightness at this much lower current; optical acceptance limit is unspecified.',
             'Published730C/W thermal metric requires16mm2 per pad; do not apply to present tiny land.', 'Temperature/assembly and active firmware indication remain pending.'])
calculation('SPEAKER', 'J901 LS901', 'Ideal resistive sine screen P=Vsys^2/(2*6.8); actual firmware candidate Vpeak<=.9V gives P<=.9^2/6.8 for an arbitrary bounded audio waveform.',
            {'rating_W':1,'max_input_W':1.2,'nominal_impedance_ohm':8,'specified_impedance_tolerance_percent':15,
             'unrestricted_sine_screen_W_SYS4V5':4.5**2/(2*6.8),'firmware_candidate_peak_V':.9,
             'candidate_audio_power_screen_W':.9**2/6.8, 'firmware_hpf_Hz':850},
            [ev('SPEAKER', 1, 3),ev('MAX98357A', 1),fwref('sv_speaker.c', 4, 42), fwref('stm32/main.c', 224, 237)],
            ['8ohm+/-15% is not a guaranteed broadband/DC minimum load impedance. This is a screen, not power/thermal proof.',
             'Actual firmware includes850Hz HPF and peak cap; do not report a missing limiter.', 'PWM, gain transfer, ringing, spring-contact/1cc enclosure and excursion not qualified.',
             'Both speaker terminals are driven BTL; neither may be grounded by a scope/harness.',
             'Snapshot factory speaker route branch does not test hp_inserted; control-library HP interlock does not prove this target branch.'])
calculation('NO_CONNECT', 'J102 J201 J202', 'Manufacturer switch pair5/6 is separate; both have net=null in current native.',
            {'pad_pair':[5,6], 'external_bias_present':False,'current_design_status':'INTENTIONAL_UNUSED_DETECT_PAIR'},
            [ev('KYCON_JACK',1)], ['Baseline DA was an abstract contact and must map to both current physical pins; no extra baseline closure count.'])
calculation('CURRENT_CEFF_UNKNOWN', ' '.join(sorted(caprefs)),
            'A voltage rating or Cnom*(1-tolerance)*(1-temperature) is not a DC-biased class-II minimum. No primary worst-case bias/aging envelope => null.',
            {'guaranteed_operating_min_uF_when_unknown':None, 'nominal_mpn_selection_is_capacitance_proof':False},
            [ev('YAGEO_X7R',1),ev('YAGEO_X5R',1)],
            ['No fabricated percentage derating, no use of typical curve as guaranteed lower bound.', 'Current bound is never populated from an unmerged proposed bank.'])
calculation('CRITICAL_BANKS', 'C303 C304 C701 C702 C807 C808 C1102 C1104 C1105 C1106 C1501 C1502 C1902',
            'Recomputed standard-test C0G bank bounds; charge-pump storage min >= flying max; VCAP window1.76..2.64uF, separate ESR<.1ohm.',
            {'flying_1V04_min_max_uF':[1.04*low,1.04*high], 'storage_2V35_min_max_uF':[2.35*low,2.35*high],
             'storage_min_minus_flying_max_uF':2.35*low-1.04*high,
             'VCAP_cap_window_pass_for_proposal':1.76<=2.35*low and 2.35*high<=2.64,
             'VCAP_post_qualification_ESR_allowance_ohm_at1kHz':.005/(2*math.pi*1000*2.35*low*1e-6),
             'buck_required_Cout_uF_for_Lmax1V8uH':18, 'current_C1104_C1105_nominal_total_uF':44,
             'current_C1104_C1105_guaranteed_bias_min_uF':None},
            [ev('TPA6132A2',15,17),ev('STM32H743',106,211),ev('TPS63070',4,16,17,19),ev('KEM_C0G_SMD',4,14)],
            ['10 anchors +30 new components remain unmerged proposals.', 'VCAP allowed post-environment DF does not establish ESR<.1ohm; no measured ESR failure alleged.',
             'Polymer qualification/tolerance stack is not an operating-frequency guarantee.', 'Global V3LOAD upper-C/QOD sum remains conditional; no200uF guarantee.'])

decisions = {}


def assign(refs, status, role, evidence, calcs, normal, default, fault, pending, closure_scope=None):
    for ref in refs.split():
        assert ref in scope and ref not in decisions, ('bad/duplicate ref',ref)
        decisions[ref] = dict(status=status, application_role=role, evidence=evidence,
                              calculation_references=calcs, normal_operation=normal, default_or_power_off=default,
                              open_short_fault_review=fault, pending_limits=pending,
                              closed_scope=closure_scope if status=='CLOSED_DESIGN_REVIEW' else None)


CLOSED = 'CLOSED_DESIGN_REVIEW'
PENDING = 'PENDING_APPLICATION_LIMITS'
CEFF = 'PENDING_EFFECTIVE_CAPACITANCE'
DEFER = 'DEFERRED_BATTERY_OWNER'

assign('C320', CLOSED,'Headphone insertion RC at PA4', [ev('KYCON_JACK',1),ev('STM32H743',136,137)],['C0G_BOUND','HP_DETECT_RC'],
       'J3015/6 closes to GND when inserted; R321100k supplies pull-up, R3221k limits capacitor contact discharge. DC levels and C0G RC budget checked.',
       'Open/unplugged HIGH; capacitor initially discharged can look inserted until settling. Target waits30ms stable.',
       'Open C loses RC; short C holds inserted. Open detector looks unplugged; short detector looks inserted. Neither adds an external voltage source.',
       [],'Local passive sensing circuit, not complete speaker/privacy interlock; separate finding F02 remains open.')
assign('C821 C822 C823 C825', CLOSED,'UI button shunt C0G filters', [ev('STM32H743',136,137),ev('SKQG',1)],['C0G_BOUND','KEY_RC'],
       'Actual10k rail pull-up and10nF C0G establish input levels and low-frequency RC budget; firmware uses30ms stable samples.',
       'Unpressed HIGH, pressed LOW. MCU input initialization checked in target main.c.',
       'C open removes filtering; C short appears continuously pressed. Firmware requires release before click/long action; UI authorization still gates actions.',
       [],'Capacitor voltage/value/default/RC review only; the switch contact pulse-rating requirement is explicitly pending on SW810/811/812/814.')
assign('C811', CLOSED,'NRST local bypass', [ev('STM32H743',144,248)],['C0G_BOUND','NRST_RC'],
       '0.1uF C0G toGND matches manufacturer reset recommendation with10k external and30..50k internal pull-up.',
       'Cap initially low; releases through parallel pull-ups. No precise power-on-reset duration claimed.',
       'Short holds reset and prevents operation; open loses noise filter. SWD fixture still must obey sink/voltage conditions.',
       [],'Local NRST passive network, excluding fixture qualification.')
assign('C704 C705', CLOSED,'DAC output shunt low-pass capacitors', [ev('PCM5102A',8,26)],['C0G_BOUND','DAC_FILTER'],
       'Each2.2nF C0G follows a470ohm resistor from OUTL/OUTR and returns toGND.50V rating covers declared normal internal audio swing.',
       'No external source connected directly; downstream ports pass switches/coupling. DAC mute sequence is not inferred from capacitor.',
       'Short grounds filtered output through470ohm; open removes local HF attenuation. External port fault coverage belongs to the complete audio path.',
       [],'Local nominal/filter/voltage design; no complete DAC load, THD or output-port approval.')
assign('C1001', CLOSED,'eFuse DVDT capacitor selection', [ev('TPS25947',8,11,29,30)],['C0G_BOUND','DVDT'],
       '4.7nF C0G50V satisfies VIN+5V rating at recommended VIN<=23V and stays below10nF series-resistor recommendation threshold.',
       'Charging capacitor slows startup; exact output ramp is not guaranteed by the typical equation.',
       'Open yields fastest ramp; short DVDT prevents/changes intended ramp. Current limit and thermal protection remain independent required protections.',
       [],'Capacitor selection/pin-voltage and connection only; system inrush/thermal remains pending in critical-cap audit.')
assign('C1701 C1705', CLOSED,'USB/SYS monitor input shunt RC', [ev('TMUX1511',6),ev('OPA4330',9),ev('ADS1115',5,6)],['C0G_BOUND','MONITOR_RC'],
       'After15k/10k divider and analog switch,100k pulldown sets actual2.65 nominal scaling.10nF C0G25V has a published bound; calculated healthy powered inputs lie below3.1V.',
       '100k drains node after switch disable. No full powered-off injection guarantee inferred from a single leakage test point.',
       'Short C gives low channel; open C removes filtering. Divider faults can overrange; ADC range checks are not physical protection.',
       [],'Healthy powered-state passive RC and voltage budget only; off-state/fault protection and total measurement error remain system-level pending requirements.')
assign('J102 J201 J202', CLOSED,'Unused jack insertion-detect contacts', [ev('KYCON_JACK',1)],['NO_CONNECT'],
       'Current physical pads5 and6 both intentionally unconnected; independent of audio tip/ring/sleeve contacts.',
       'No pull-up, no rail, no MCU input left floating by these unused contact pads.',
       'Contact open or5-to6 closed produces no electrical action; arbitrary bridging to an audio pad is assembly failure, not intended topology.',
       [],'Unused detector pair only; audio contact paths were not counted closed by this legacy DA entry.')
assign('J301', CLOSED,'Used jack insertion-detect contact pair', [ev('KYCON_JACK',1)],['HP_DETECT_RC'],
       '5=HP_DETECT_RAW,6=GND. Detection is NO pair, not the old abstract DA ground terminal.',
       'Unplugged open/HIGH and inserted closed/LOW are consistent with current target read.',
       'Short senses inserted; open wire senses unplugged. Local sensing current is limited by100k and capacitor discharge by1k.',
       [],'Detection contact electrical mapping/default only; F02 speaker interlock is not closed.')
assign('SW813', CLOSED,'LTC2954 physical power button', [ev('SKQG',1),ev('LTC2954',3,6,12)],['PWR_BUTTON_DC'],
       'Pads1/2=PWR_PB and3/4=GND. R82610k toSYS provides a valid minimum switch wetting load and PB high level.',
       'Open high; pressed low crosses PB threshold. It is not on V3D and not directly connected to KEY_PWR.',
       'Open switch means no manual request; stuck-low invokes hardware long-press sequence. Exact system timing remains with C1302/1303.',
       [],'Button DC load, threshold, default and four-pad connectivity; does not approve full power sequence.')
assign('SW810 SW811 SW812 SW814', PENDING,'UI tactile switch contact load', [ev('SKQG',1),ev('STM32H743',136,137)],['KEY_RC'],
       'DC load meets10uA/1V minimum and50mA/12V maximum; four-pad ties checked against present native.',
       'Open high/closed low; firmware30ms debounce and release-before-action exist.',
       '10nF is directly across contact, so pull-up current is not a pulse-current upper bound. Stuck contact does not prove a released button.',
       ['Contact pulse current/wear limit for direct capacitor discharge has no guaranteed evidence; no blanket switch approval.'])
assign('C824', PENDING,'LTC INT_N interrupt shunt capacitor', [ev('LTC2954',3,6),ev('STM32H743',136,137),fwref('stm32/main.c',170,175)],['C0G_BOUND','LTC_INT'],
       '10k pull-up and10nF C0G give valid low/high electrical margins.',
       'Open-drain INT releases HIGH; this signal is not raw PWR_PB.',
       'Cap short appears asserted; open removes filtering. A26ms valid interrupt can be rejected by30ms contiguous-low target filter.',
       ['F01: event capture/debounce requirement must accept26ms guaranteed minimum minus RC/polling margin.'])
assign('C820', PENDING,'Protected USB voltage sense divider filter', [ev('STM32H743',136,137,241,242)],['C0G_BOUND','VBUS_SENSE'],
       '100k/100k divider into PA9 and1nF C0G; guaranteed-design powered GPIO threshold margin positive under declared rails.',
       'eFuse-blocked USB_5V_SAFE=0 is not equivalent to unplugged USB; PA9 power-off configuration not qualified.',
       'Bottom resistor open can expose PA9 to the protected rail; capacitor short asserts absent. Do not automatically unlock charger from absent.',
       ['PA9 actual mode/off-state injection and independent physical detach source required; voltage divider alone cannot supply the authorization contract.'])
assign('RV810 RV811 RV812 C830 C831 C832', PENDING,'Volume/tone/FX ADC potentiometer paths', [ev('RK10J',1,3),ev('STM32H743',146,249)],['C0G_BOUND','POT_ADC'],
       'Track endpoints=V3D/GND; wiper through1k into100nF C0G. Actual ADC12bit387.5cycle scanning20ms is implemented, not a stub.',
       'ADC initialized analog/no-pull; firmware requires a fresh volume-low pickup before audible UI control.',
       'Open wiper can leave a plausible in-range capacitor voltage, not detected by range or freshness alone; short wiper tohigh can look fullscale.',
       ['Open-wiper policy/detection not closed.', 'Actual acquisition/charge-sharing and transfer-error bound not demonstrated.',
        'Operating range limited by pot -10..60C; board temperature envelope/derating not approved.'])
assign('C1302 C1303', PENDING,'LTC2954 ONT/PDT timing capacitors', [ev('LTC2954',3,6,11)],['C0G_BOUND'],
       'ONT100nF25V and PDT470nF50V are C0G;6.4s/uF gives nominal additional0.64s and3.008s.',
       'Open pin defaults to32ms ON /64ms power-down nominal; healthy capacitance adds hold time.',
       'Open timer shortens intended delay. Short timer does not preserve intended delay; no fail-safe timing guarantee assumed.',
       ['Only1500pF timing min/max is guaranteed in the cited table. Scaling to100/470nF is not a manufacturer worst-case bound.',
        'System acceptable turn-on/forced-off timing interval and boot handshake budget remain unclosed.'])
assign('C1702 C1706', PENDING,'OPA4330 toADS1115 output isolation RC', [ev('OPA4330',9),ev('ADS1115',5,6)],['C0G_BOUND','MONITOR_RC'],
       '100ohm resistor isolates unity follower from10nF C0G at AIN0/AIN2; one-pole RC calculated.',
       '20ms initial monitor wait and10ms conversion wait are implemented; op-amp turn-on specification is typical only.',
       'Cap short loads buffer through100ohm; cap open removes charge reservoir/noise filter. Typical5mA short-circuit current not a guarantee.',
       ['Guaranteed/validated stability, output settling and switched-cap ADC interaction at this load are absent; total error is not justRC.'])
assign('D850 D851 D852', PENDING,'Cyan status LED current and polarity', [ev('CYAN_LED',1,2,3)],['LED_DC'],
       'Physical1=K/GND,2=A via1k, correcting old symbolic numbering. Absolute supply/resistor current bound calculated independent of typicalVF.',
       'No LED illumination assumed during reset or unless GPIO is actually driven; current target indication policy not qualified.',
       'Short LED draws bounded resistor current; open LED gives no indication. Reverse/assembly mismatch still needs actual board inspection.',
       ['Brightness requirement and operating-temperature/copper thermal validity are not closed; cannot infer5mA-bin brightness atactual lower current.'])
assign('J901 LS901', PENDING,'BTL speaker and harness', [ev('SPEAKER',1,3),ev('MAX98357A',1)],['SPEAKER'],
       'SPK_P=MAX OUTP andSPK_N=OUTN; neither pin is ground. Exact1W/8ohm speaker and current limiter/HPF reviewed.',
       'Target holds output muted until factory authorization; physical speaker_calibrated remains false/unverified.',
       'Any harness-toGND short is an output fault. Open speaker defeats acoustics; short terminal pair causes amplifier protection/thermal stress, not guaranteed continued operation.',
       ['Actual BTL PWM/gain/thermal/excursion/1cc cavity and spring interface limits not closed.', 'F02: factory speaker route HP interlock requires correction or explicit approved policy.'])
assign('J801', PENDING,'SWD service test pads', [ev('STM32H743',136,137,144)],['NRST_RC'],
       'VTREF=V3D,SWDIO=PA13,SWCLK=PA14,NRST shared with10k/0.1uF,ground present.',
       'Fixture must sense VTREF, not source it; attached debugger while V3D=0 requires no backdrive.',
       'Wrong-polarity/probe supply or NRST push-pull can inject rails. Existing pads alone do not define a safe fixture.',
       ['Probe levels, power sequencing, source current, reset sink and fixture keyed contact layout are unspecified.'])
assign('J902', PENDING,'RF factory programming interface', [ev('ESP32_MINI',8,9)],['CURRENT_CEFF_UNKNOWN'],
       'Power is currentV3LOAD, not oldV3D. RX/TX connect UART0,BOOT=IO0 pull-up,EN shared with10k pulldown/470ohm drive/1uF.',
       'Load switch off leaves RF domain unpowered; external programmer must not driveBOOT/EN/RX then. Program-mode firmware does not define fixture electrical limits.',
       'An externally driven high can backpower an off module. EN cap Ceff and actualRC delay are still unbounded.',
       ['V3LOAD-aware tri-state fixture and off-domain injection limits, EN timing and programmed reset sequence unqualified.'])
assign('J1801 J1802', PENDING,'Internal TMP117 sensor harness endpoints', [ev('TMP117',4,7,33,36)],['CURRENT_CEFF_UNKNOWN'],
       'Both headers carry sameV3D/GND/TEMP_SCL/TEMP_SDA;33ohm series components link bus toTMP117. ADD0 high yields address0x49 used by firmware.',
       'No second external supply assumed; unplug leaves sensor/bus transaction unavailable. Firmware ID/timeouts reject missing sensor.',
       'Short bus may disable other slaves; wrong harness polarity or hot plug can inject supplies. Header pin count alone does not prove hot-plug safety.',
       ['Connector exactMPN/polarization/wire rating, totalI2Ccap/rise time and thermal mounting not closed.', '0.1uF bypass C1801Ceff remains unknown.'])
assign('J101 C101', PENDING,'External piezo coupling and high impedance input', [ev('TLV9064',5,6)],['C0G_BOUND'],
       'PZ_RAW passes10k R101 toPZ_LIMIT then100nF C0G intoPU_BIAS/TLV9064.4.7M returns toVMID; no clamp found onPZ_LIMIT.',
       'Open input returns to bias through4.7M onamplifier side; external piezo charge source is not equivalent to a low-voltage internal rail.',
       'Piezo transient/polarity amplitude unknown; series10k alone does not prove25V cap or amplifier clamp-injection limits. Cap short removes DC isolation.',
       ['Piezo normal/fault voltage and source impedance limits, low-frequency input response and clamp-current protection unbounded.'])
assign('J501 C501 C502 C503 C1703 C1704 C1707 C1708', DEFER,'Battery/charger/current-monitor boundary', [ev('BQ24074',5,26,27),ev('TMUX1511',6)],['CURRENT_CEFF_UNKNOWN','MONITOR_RC'],
       'Current actualnet connections retained; no battery discharge/charge current orNTC conclusion is made here.',
       'Shared rail/load-switch changes not undone. Battery absence/power-off proof belongs to battery owner.',
       'Charger/BAT/ISET faults require pack/charger/NTC limits, not simple capacitor name review.',
       ['Delegated to battery owner; capacitorCeff may also be unknown. These17 baseline pins remain in the denominator and are not closed by delegation.'])
assign('L1101', PENDING,'TPS63070 buck-boost energy-transfer inductor', [ev('XGL4020',1,2),ev('TPS63070',4,17,18)],['CRITICAL_BANKS'],
       '1.5uH20% XGL4020-152MEC betweenL1/L2, max4.3x4.3x2.1.5.3A20%-drop and7.5A30%-drop figures are25C reference, not5A hot guarantee.',
       'Converter disabled state is not current-free under all port/battery faults.',
       'Open stops energy transfer; short/large saturation exposes switches to abnormalcurrent. Needhotinductance/ripple/peakcurrent/lossbudget.',
       ['Hot saturation definition, current limit tolerance, operatingripple/thermal/copper and mechanicalfit remain pending; envelope not4x4exact.'])
assign('FB1101', PENDING,'V3LOAD toV3A ferrite supply filter', [ev('WE_742792625',1,2)],['CURRENT_CEFF_UNKNOWN'],
       '742792625:120ohm+/-25%@100MHz zero-bias;0.05ohm maxDCR. Current path usesV3LOAD, not oldV3D.',
       'V3A follows switched loadrail; localcaps and driven audio signals can retain/backfeed charge.',
       'Open drops analograil; short removes isolation. DC-ratedcurrent is not guaranteed high-frequency impedance underload.',
       ['Biased impedance, actual analog loadpeak, ferrite/cap resonance and transient droop not closed.'])
assign('FL1501 L1501 L1502 R403 R404', PENDING,'USB differential protection/filter chain', [ev('ACM2012H_ZH',1,2),ev('0603HP',1,2),ev('TPD2S703_Q1',7,8),ev('RC0603JR-070RL',1)],['CURRENT_CEFF_UNKNOWN'],
       'CurrentCMC1-4 isDP and2-3 isDM; each then10nH2% intoVD+/VD-. USBsystem side uses0ohm toMCU. PairworstL difference0.4nH, notperfectmatching.',
       'USBoff/OVP routing and3.3V-free protection behavior cannot be inferred from filter names.',
       'Lineopen disconnects; short/swappedpair orleakage harms protocol/protection. CMC90ohm istypical65min, not USBeye guarantee.',
       ['SI/ESD/filter parasitics and exactend-toend differential routing/clockedge validation remain pending.',
        'R403/R404 exact0ohm candidate in separate guardpatch; noSI approval fromresistor identity.'])
assign('Y801 C812 C813', PENDING,'24.576MHz HSE oscillator loop', [ev('ABM8_current',1,2),ev('STM32H743',126,230)],['C0G_BOUND'],
       'ABM8-24.576MHZ-B2-T CL18pF;30pF each makes15pF plusunknownstray. Groundcasepads2/4; signalpads1/3 matchcurrentnative.',
       'Passivecrystal requires MCUoscillatorstartup; reset state is not proof ofsteadyclock.',
       'Open/short loadcap orwrongload canstop/shiftclock; MCUfirmwareclockchecks cannot guarantee analogstartupmargin.',
       ['No gm/startup/drive-power/maxstray bound orroutedparasitics; -20..70C exactsuffix notwide-temp.',
        '30pF budgetuses0.25pF post-environment allowance, not merely0.3%.'])
assign('R601', PENDING,'Unused ADC XI input tie', [ev('PCM1864',11,36,37,73),ev('RC0603JR-070RL',1),fwref('sv_pcm1864.c',5,10)],['CURRENT_CEFF_UNKNOWN'],
       'ADC_XI at1.8V-domain input is tiedtoGND; actual3.3Vexternalclock usesSCKI, softwareclockregister0x20maskedvalue0x41.',
       'XI is aninput, not oscillatoroutputXO; groundingXI mustnotshortanactivelydrivenXO.',
       'Open0ohm leavesunusedXI floating; SCKIselection shouldstillbe enforced; wrongassembly toXO wouldshortoutput.',
       ['Exactzero-ohmMPN metadata candidate supplied, but notmerged here. MCU/ADC clockstart/sequence remains pending.'])

# Every class-II/blank capacitor is assigned by its actual circuit function, not a universal PASS.
capgroups = [
 ('C102','VMID divider reservoir','TLV9064',[5,6], 'Across R103/R104 divider midpoint intoU101buffer;10uFnominal sets bias startup andnoise.','Open increasesbiasnoise; short collapsesVMID andbiases audio incorrectly.','Biassettling andnormal/faultcommon-mode budget unproved.'),
 ('C103 C104 C240 C241','TLV9064 analog supply bypass','TLV9064',[5,6], 'V3A rail toGND atpickup/linequadopamps;switchedanalograil requireslocaldecoupling.','Open reducesdecoupling; short loadsV3A/FB1101/V3LOAD.','DCbiasmin, supplytransient andplacement/currentloop unproved.'),
 ('C111 C231 C232','PCM1864 AC input coupling','PCM1864',[11,72,77], 'Betweenbufferoutput andADCsingle-endedinput;opampbias andADCcommon-mode differ.','Open loseschannel; short defeatsDCisolation andcanoverrangeADC.','Biasedcapacitance, requiredlowfrequencycorner andsource/loadvoltage differences unbounded.'),
 ('C121 C211 C212','Audio send/line output AC coupling','TLV9064',[5,6], 'Bufferoutput through10uF to220ohm andportswitch;required effective>=4.7uF remainsunproved.','Open losesoutput; short transfersDCbias toexternalport/protection.','Externaljackload/fault andeffective4.7uF minimum notproved.'),
 ('C201 C202','DAC tolinebuffer AC coupling','PCM5102A',[8,26], 'DACnode through1uF to15klineinputattenuation/bias network.','Open removeslinefeed; short changesDCcommon-mode.','Biasdependentcornerfrequency andopampinputheadroom unproved.'),
 ('C221 C222','Return-port AC coupling','TLV9064',[5,6], 'Externalreturnthroughportswitch and4.7uF to22k attenuation/bias network.','Open losesreturn; short defeatsDCblocking fromexternalport.','Externalaudio/faultenvelope andbiasedminimum notknown.'),
 ('C301 C302','TPA6132A2 AC input coupling','TPA6132A2',[5,15], '1uF from22k/10kattenuator intoheadphoneinput;inputimpedance dependson gain.','Open loseschannel; short bypassesDCblocking/popmitigation.','Ceffandlowfrequencyresponse unknown;typicalinputimpedance notaguaranteedlowerbound.'),
 ('C303 C304','Headphone flying/storage capacitors','TPA6132A2',[15,17], 'CPP-CPN1uF flying andHPVSS-GND2.2uFstorage;storageeffectiveMIN must>=flyingMAX.','Open/short pumpcapdisablesnegativegeneration orcreatesabnormalpumpcurrent.','CurrentMPNsblank;proposedC0Gmathbanksnotmerged;ESR/ripple/loopgeometry unproved.'),
 ('C305 C306 C307','TPA6132A2 positive/analog supply bypass','TPA6132A2',[15,17], 'HPVDDlocal2.2uF andV3A2.2uF/100nF;notnegativepumpstorage.','Open increasesdroop/noise; short loadspositiveanalograil.','MinCeff,chargepumpcurrentstep andplacement unproved.'),
 ('C401 C1002','Raw USB eFuse input bypass','TPS25947',[7,8,42], '100nF50V eachacrossVBUS_RAW toGND beforeeFuse;50Vratingisnotclampvoltage.','Open worsenshotplugringing; short directlyloadsUSBconnector;fuseupstreamoftheseisabsent.','Hotplugsourceimpedance/TVSfaults andcapCeffatvoltage unproved.'),
 ('C403 C1003','Protected USB rail/protection bypass','TPS25947',[8,29,30], 'USB_5V_SAFE bypassfeedsdownstreamprotection;1uF+100nF nominalcannotboundinrush.','Open losesdecoupling; short causesprotectedrailfault.','ActualoutputCeff,loadstep/eFuseinrush bound absent.'),
 ('C601','ADC reference bypass','PCM1864',[11,77], '1uF atVREFtoground;referencepinnotexternal3.3Vinput.','Open permitsreferencenoise; short disablesreference.','Manufacturer1uFselection andvalidCeff/ESRplacement notfullyproved.'),
 ('C602 C603','ADC internal LDO output bypass','PCM1864',[11,77], '100nF+10uF atADC_1V8/LDO11;notV3LOAD3.3Vcapacitors.','Open reducesLDOloadcap; short loadsinternalregulator.','Internal1.8VbiasCeff andstability/ESR needbound.'),
 ('C604 C605 C606 C607 C608','ADC analog/digital/I/O rail bypass','PCM1864',[11,77], 'C604/605=V3A;C606/607/608=V3LOADfollowingloadswitch.','Open reduceslocaldecoupling; short loadsrail;offdomainclockinjection remainspossible.','BiasedCeff/placement andpower-offbus isolation/current unknown.'),
 ('C701 C702','DAC flying/negative storage capacitors','PCM5102A',[26], '2.2uF CAPP-CAPM andVNEG-GND;currentMPNsblank.','Pumpcapopen/short preventsnormalnegativegeneration orcausesabnormalcurrent.','Proposed5x470nFC0Geachnotmerged;ESR/pumpcurrent/layout unclosed.'),
 ('C703','DAC internal 1.8V regulator bypass','PCM5102A',[5,26], '100nF atLDOO18 toGND;localDACinternalregulator.','Open increasesnoise/stabilityrisk; short disablesinternalrail.','Currentbiasedminimum/placement notproved.'),
 ('C710 C711 C712 C713 C714 C715','DAC analog/pump/digital supply bypass','PCM5102A',[26], 'V3A suppliesanalog/pumpbypass;V3LOADsuppliesdigital100nF+10uF.','Open increasesripple/pops; shortloadsrail.','Ceff/ESR/placement/power-sequenceandmute unproved.'),
 ('C801 C802 C803 C804 C805 C806','MCU digital supply bypass','STM32H743',[106,211], 'V3D100nF distributeddecouplersand4.7uFbulk;eachlocalpinloopmatters.','OpenlocalcapweakensHFdecoupling; shortcausesV3Dfault.','Rail3.45Visdesignassumption;biasedCeffandinstalledlocalplacement unproved.'),
 ('C807 C808','MCU VCAP internal core regulator','STM32H743',[106,211], 'SeparateVCAP1/2eachrequires2.2uF+/-20%,ESR<100mohm;donotjoincoreoutputs.','Open/shortcapcanpreventstartuporunstabilizeregulator.','UnmergedC0GbankwindowpassesatLCRtest;worstESRdoesnotclose. CurrentMPNsblank.'),
 ('C809 C810','MCU VDDA/VREF bypass','STM32H743',[106,211], '100nF+1uF behindR80110ohm toVDDA/VREF+;bothpinsactuallyshareMCU_VDDA.','OpenincreasesADCnoise; shortloadsV3Dthrough10ohm;Rpowermustbecheckedinfault.','Biasedmin/bulkresponse and10ohmdrop/ADCerror budget unclosed.'),
 ('C901','ESP32 EN timing capacitor','ESP32_MINI',[8,9], '1uFENtoGND with10kpulldownand470ohmMCUdrive;notstandard10kpullupRC.','Unpowered/MCUlowdefaultkeepsENlow;programfixturemusttakeoverwithoutconflict.','BiasedCeffandactualENresetpulse,GPIOdriveandfixturepower-offlimits unclosed.'),
 ('C902 C903','ESP32 switched rail bypass','ESP32_MINI',[8,9], 'V3LOAD100nF+22uF;RFtransmitstepsaffectswitchedrail.','OpenreducesRFrailreservoir; shortloadsTPS22918path.','BurstloadCeff/ESR,thermalandQODtotalmax unknown.'),
 ('C904 C905','MAX98357A SYS bypass','MAX98357A',[1,30], '100nF+10uF atSYS-fedBTLamplifier;notV3LOAD.','OpenincreasesPWMrailripple; shortloadsSYS;amplifiercanremainpoweredwhileaudiooff.','Biasedmin,PVDDswitchcurrent/placementandloopinductance unknown.'),
 ('C1101','TPS63070 VAUX bypass','TPS63070',[3,4,17], '100nF atVAUXpin3,notmainV3Doutputbulk.','Openincreasessupplynoise; shortloadsinternalailiarysource.','BiasminandVAUXlocalplacement unproved.'),
 ('C1102 C1103','TPS63070 SYS input bypass','TPS63070',[4,16,19], '10uFblankMPN+100nF atSYS;inputdemandchangeswithbuck/boostmode.','Openraisesinputripple; shortloadsSYS/sourceprotection.','Inputmin4.7uFproofandhotplug/coppercurrent missing;polymerproposalnotguaranteedoperatingCeff.'),
 ('C1104 C1105','TPS63070 main output bulk','TPS63070',[4,16,17,19], '2x22uFX5Rnominal atV3D;L1.5uH20%=>Lmax1.8uH and18uFdesignminimumscreen.','Openhalvesnominalbulk; shortfaultsV3D;neithersituationguaranteesloopstability.','44uFnominal isnot>=18uFbiasedminimumproof;loadtransient/ESR/stability alsoopen.'),
 ('C1106 C1107','Analog ferrite output bypass','WE_742792625',[1,2], '22uFblankMPN+100nF atV3AafterFB1101;negative/otherpumpcapsaredistinct.','Openincreasesrailnoise/resonance; shortloadsferrite/loadswitch.','ActualCeff/ferriteimpedanceanddamping unproved;polymerECOunmerged.'),
 ('C1301','LTC2954 SYS bypass','LTC2954',[6,12], '100nF acrossVIN1/GND4;alwayshousekeepingSYSdomain.','Openreduceslocaldecoupling; shortloadsSYS.','BiasedCeff/placementandrampbrownbound unclosed.'),
 ('C1401','USB CC protector VBIAS bypass','TPD2S300',[7,8], '100nF50V fromVBIAS toGND;notordinary3.3Vbypass.','OpenchangesCCprotectionbiasresponse; shortbiasfault.','VBIASfaultenvelope/Ceff andprotectioncoordination unclosed.'),
 ('C1402','USB CC protection 3.3V supply bypass','TPD2S300',[7,8], '1uF atV3D suppliesCCprotector;3.45Vstaticbudgetonly.','Openreducesdecoupling; shortloadsV3D;offrailCCexposure stillmustbeguarded.','Ceff/offstatefaultandplacement unclosed.'),
 ('C1501','TPD2S703 VPWR bypass','TPD2S703_Q1',[7,8,20], '2.2uF16V atUSB_5V_SAFE feedsVPWR;effectivewindow1..10uF required.','OpenreducesOVPtransientdecoupling; shortloadsprotectedUSB.','NoCeffwindowproof;2.2uFnominaldoesnotmatch10uFtypicalrecommendation;not automaticallyafailure.'),
 ('C1502','TPD2S703 VREF bypass','TPD2S703_Q1',[7,8,20], '1uFblankMPN onUSB_VREF/GND withR1504;nativecurrentnets used,notoldMODE1board.','Open/shortreferencecanbreakOVPoperation.','Effective0.3..3uF notproved incurrentnative;3x470nFbankproposalnotmerged.'),
 ('C1709 C1710 C1711','ADC/mux/opamp monitor supplies','ADS1115',[5,6], 'V3Dlocal100nFbypass forADS1115/TMUX1511/OPA4330.','Openreduceslocalbypass; shortloadsV3Dmonitorrail.','Actualbiasmin,localplacement/supplynoiseandmeasurementchainvalidity unclosed.'),
 ('C1801','TMP117 local supply bypass','TMP117',[33,36], '0.1uFnearTMP117V+/GND atsensor/harnessdomain;ADD0high.','Openaffectsnoise/accuracy; shortloadsV3D/harness.','Ceffandactualthermalsensorplacement/mounting unknown.'),
]
for refs,role,sid,pages,normal,fault,pending in capgroups:
    assign(refs,CEFF,role,[ev(sid,*pages)],['CURRENT_CEFF_UNKNOWN','CRITICAL_BANKS'] if any(r in refs.split() for r in ['C303','C807','C1102','C1104','C1502']) else ['CURRENT_CEFF_UNKNOWN'],
           normal,'Rails may be off or ramping; nominal capacitance/voltage do not guarantee startup or discharge timing.',fault,[pending])

assert set(decisions)==scope, {'missing':sorted(scope-set(decisions)), 'extra':sorted(set(decisions)-scope)}

rows=[]
for b in baseline:
    ref,pin=b['ref'],str(b['pin'])
    c=parts[ref]
    mapping='UNCHANGED_PHYSICAL_PIN'
    numbers=[pin]
    if ref in ('J102','J201','J202','J301') and pin=='DA':
        numbers=['5','6']; mapping='OLD_ABSTRACT_DETECT_CONTACT_TO_CURRENT_PAIR'
    elif ref.startswith('SW'):
        numbers=['1','2'] if pin=='1' else ['3','4']; mapping='OLD_TWO_TERMINAL_SWITCH_TO_CURRENT_FOUR_PADS'
    elif ref in ('D850','D851','D852'):
        numbers=['2'] if b['name']=='A' else ['1']; mapping='OLD_LOGICAL_A_K_TO_MANUFACTURER_PHYSICAL_K1_A2'
    elif ref=='FL1501':
        numbers=[{'1':'1','2':'4','3':'2','4':'3'}[pin]]; mapping='CMC_PAIR_MANUFACTURER_1_4_DP_2_3_DM'
    current=[p for p in c['pins'] if str(p['number']) in numbers]
    assert len(current)==len(numbers),(ref,pin,numbers,current)
    d=copy.deepcopy(decisions[ref])
    r=dict(baseline_key=ref+'.'+pin,baseline=copy.deepcopy(b),ref=ref,current_mpn=c.get('mpn'),current_value=c['value'],
           current_package=c.get('package'),current_pins=current,pin_mapping=mapping,current_source_sha256=source_hash,**d)
    r['current_net_connections']=[{'pin':p['number'],'net':p.get('net'),
                                  'endpoints':netmap.get(p.get('net'),[]),
                                  'connection_reference':'current-net-connections.json#'+str(p.get('net'))} for p in current]
    if ref in oldrows:
        old=oldrows[ref]
        for evidence in (old.get('selected_part') or {}).get('evidence',[]):
            sid=evidence.get('source_id', evidence.get('id'))
            if not any(x['source_id']==sid for x in r['evidence']):
                r['evidence'].append(ev(sid,*evidence.get('pdf_pages',[1])))
        cb=bound(ref) if ref.startswith('C') else None
        r['current_standard_test_capacitance_bound_uF']=cb
        r['current_working_band_ceff_min_uF']=None
        r['current_ceff_unknown']=ref.startswith('C') and cb is None
        r['nominal_selection_only']=ref.startswith('C') and cb is None
    else:
        r['current_ceff_unknown']=False
    r['design_review_closed']=r['status']==CLOSED
    r['application_fully_closed']=False
    r['procurement_approved']=False
    r['physical_tests_executed']=0
    rows.append(r)

findings=[
    {'id':'F01','priority':'HIGH','refs':['C824','U1301','U801'],'status':'PENDING_CORRECTION',
     'statement':'LTC2954 guarantees INT pulse as short as26ms; target main.c requires30ms consecutive low. A shortest valid shutdown interrupt can be missed.',
     'evidence':[ev('LTC2954',3),fwref('stm32/main.c',170,175)],'calculation':'LTC_INT',
     'proposal':'Latch the qualified interrupt edge or define a filter/poll bound strictly below26ms minus analog/polling margin. Preserve startup rejection and actual power-off policy. Firmware owner only.'},
    {'id':'F02','priority':'HIGH','refs':['J301','C320','J901','LS901'],'status':'PENDING_FIRMWARE_OWNER_REVIEW',
     'statement':'Snapshot target main.c computes inserted/hp_inserted but the SV_SPK desired-output branch does not test either. The separate sv_control library does gate speaker on headphone state; that does not establish target routing interlock.',
     'evidence':[fwref('stm32/main.c',224,237),fwref('sv_control.c',55,63)],
     'proposal':'Firmware owner to confirm policy and gate speaker off immediately on raw insertion, then apply release/debounce routing policy. No firmware edited.'},
    {'id':'F03','priority':'MEDIUM','refs':['RV810','RV811','RV812','C830','C831','C832'],'status':'PENDING_DESIGN_LIMIT',
     'statement':'RK10J operating range is-10..60C. Open wiper can produce an apparently valid ADC reading even with fresh DMA/range checks.',
     'evidence':[ev('RK10J',1),fwref('sv_ui.c',9,15)],'calculation':'POT_ADC',
     'proposal':'Declare temperature envelope and validate acquisition/open-wiper safety. A deliberate weak bias/test topology is a new circuit ECO, not an automatic resistor substitution.'},
    {'id':'F04','priority':'HIGH','refs':['C807','C808','C303','C304','C1102','C1104','C1105'],'status':'PENDING_UNMERGED_ECO_AND_OPERATING_BOUND',
     'statement':'Current nominal choices do not establish required biased C/ESR. Large C0G bank arithmetic is not proof of installed capacity or regulator-band behavior.',
     'evidence':[ev('STM32H743',106,211),ev('KEM_C0G_SMD',4,14),ev('TPS63070',4,17,19)],'calculation':'CRITICAL_BANKS'},
    {'id':'F05','priority':'HIGH','refs':['C820'],'status':'PENDING_SYSTEM_INTERFACE',
     'statement':'Powered-state GPIO threshold screen passes when using ST guaranteed-design threshold. It must not be reported as a VIH failure. Protected rail absence still cannot prove physical USB detach.',
     'evidence':[ev('STM32H743',136,137),fwref('sv_telemetry.c',148,180)],'calculation':'VBUS_SENSE'}]

# Field-only resistor proposal; no nominal, pin, net or global source writes.
zerochanges=[]
for ref in ['R403','R404','R601']:
    c=parts[ref]
    zerochanges.append({'ref':ref,'guard':{'mpn':c.get('mpn'),'value':c['value'],'pins':c['pins']},
                        'set_fields':{'mpn':'RC0603JR-070RL','manufacturer':'YAGEO',
                                      'package':'0603/1608; max1.7x0.9x0.55mm; nominal0ohm jumper; current/SI application HOLD'},
                        'nominal_value_unchanged':True,'pins_nets_not_replaced':True,'application_approved':False,
                        'evidence':[ev('RC0603JR-070RL',1)],
                        'unclosed':['Exact specsheet identifies jumper but does not establish jumper maximum resistance/current or manufacturer land.',
                                    'Retain existing0603 geometry for independent PCB check; not an approved manufacturer-pad change.']})
old_eco=read(OLD/'pending-eco-patch.json')
anchors=[]
for change in old_eco['changes']:
    ref=change['ref']; c=parts[ref]
    item=copy.deepcopy(change)
    item['guard']={k:c.get(k) for k in item['guard']}
    item['source_pins_guard']=c['pins']
    item['set_fields'].pop('passiveAudit',None)
    item['applied']=False
    item['status']='PROPOSAL_ONLY_PARENT_DID_NOT_MERGE_GEOMETRY_OR_CURRENT_BUDGET'
    item['source_reference']='../passive-closure/pending-eco-patch.json'
    anchors.append(item)
current_empty=[{'ref':r,'current_value':c['value'],'pins':c['pins']} for r,c in parts.items()
               if c['type'] in ('C','R') and not c.get('mpn')]
if not current_empty:
    current_empty=[{'ref':r,'current_value':c['value'],'pins':c['pins']} for r,c in parts.items()
                   if r.startswith(('C','R')) and not r.startswith('RV') and not c.get('mpn')]
correction={'schema':'smartvio-v26-passive-guarded-proposals/1.0','source_sha256':source_hash,'applied':False,
            'global_native_written':False,'metadata_only_changes':zerochanges,'unmerged_compound_anchor_changes':anchors,
            'unmerged_new_components_reference':'../passive-closure/new-components.json','unmerged_new_component_count':30,
            'current_blank_C_R_MPNs':current_empty,
            'count_distinction':'10 previous capacitor anchors are not10 blank C/R refs; current blank refs are9C+3R. C1902 is an anchor but already has an exact nominal MPN.',
            'firmware_or_circuit_findings':findings,'automatic_application_approval':False,'physical_tests_executed':0,
            'authorized_net_deltas':[], 'new_net_deltas_applied':[],
            'merge_instruction':'Use field guards. Do not replace complete native objects or their current V3LOAD nets. Compound bank anchors may not be merged without every companion and geometry approval.'}
save('correction-patch.json',correction)
strict=copy.deepcopy(read(OLD/'strict-ceff-options.json'))
strict['current_source_sha256']=source_hash
strict['historical_source_preserved']=True
strict['integrated_into_current_native']=False
strict['note']='Math alternatives only, not new installed components. Do not select a very large C0G bank solely because its standard-test Cmin passes.'
save('critical-capacitor-options.json',strict)

counts=dict(Counter(r['status'] for r in rows))
summary={'schema':'smartvio-v26-baseline-pin-application-review/1.0','generated_utc':datetime.now(timezone.utc).isoformat(),
         'source_sha256':source_hash,'source_part_count':316,'source_pin_count':1081,
         'baseline_count':287,'baseline_distinct_refs':len(scope),'reviewed_baseline_pins':len(rows),
         'status_counts':counts,'closed_design_review_pins':counts.get(CLOSED,0),
         'not_closed_baseline_pins':287-counts.get(CLOSED,0),'physical_tests_executed':0,'procurement_approved':False,
         'application_fully_closed_count':0,
         'scope_definition':'CLOSED_DESIGN_REVIEW closes only the named local pin/application checks under declared healthy rail assumptions. It is not complete system/assembly/fault qualification. Explicit missing physical/application limits stay pending. No family/name-based closure.',
         'global_assumptions':{'powered_V3D_V':[3.1,3.45],'SYS_normal_screen_V':[2.9,4.5],
                               'USB_safe_static_screen_max_V':5.889,'status':'DESIGN_BUDGETS_NOT_MEASURED_OR_MANUFACTURER_SYSTEM_TRANSIENT_GUARANTEES'},
         'baseline_to_current_mapping':'Old logical DA/switch/LED/CMC numbers are explicitly mapped; one old baseline pin counts once even if it maps to two current pads.',
         'parent_integration_preserved':{'nominal_preserving_changes_already_merged':100,'compound_anchors_unmerged':10,
                                        'new_capacitors_unmerged':30,'battery_owner_not_overridden':True},
         'files':{'pin_review':'pin-review.json','ref_review':'application-by-ref.json','calculations':'calculations.json',
                  'corrections':'correction-patch.json','findings':'findings.json','provenance':'source-provenance.json','verification':'verification.json'}}
save('pin-review.json',dict(summary,rows=rows))
save('application-by-ref.json',{'source_sha256':source_hash,'rows':[dict(ref=r,current_pins=parts[r]['pins'],**d) for r,d in decisions.items()]})
save('calculations.json',calc)
save('findings.json',findings)
save('status.json',summary)

used=set()
for r in rows:
    used.update(e['source_id'] for e in r['evidence'])
for c in calc.values():
    used.update(e['source_id'] for e in c['evidence'])
used.update(['RC0603JR-070RL','RK10J_EXACT_HTML'])
source_map={s['id']:s for s in sources}
fw_map={s['id']:s for s in fw_evidence}
assert not used-set(source_map)-set(fw_map), used-set(source_map)-set(fw_map)
save('source-provenance.json',{'inputs':prov,'manufacturer_documents':[source_map[s] for s in sorted(used) if s in source_map],
                               'firmware_snapshots':fw_evidence,'page_number_convention':'1-based PDF page, not guessed distributor page',
                               'new_download_count':1,'previous_100_source_redownload_count':0,
                               'reused_full_document_index':'reused-document-index.json'})

checks=[]


def check(name,result,detail=None):
    checks.append({'check':name,'pass':bool(result),'detail':detail})


check('287 unique baseline pin rows',len(rows)==287 and len({r['baseline_key'] for r in rows})==287)
check('136 refs explicitly assigned without fallback PASS',set(decisions)==scope)
check('Status counts total287',sum(counts.values())==287)
check('Every row has actual pins, evidence, calculation, default and fault analysis',all(r['current_pins'] and r['evidence'] and r['calculation_references'] and r['default_or_power_off'] and r['open_short_fault_review'] for r in rows))
check('No current-unknown Ceff capacitor counted closed',not any(r['design_review_closed'] and r['current_ceff_unknown'] for r in rows))
check('Closed rows have explicit scope and no local pending requirement',all(r['closed_scope'] and not r['pending_limits'] for r in rows if r['design_review_closed']))
check('All remaining rows name pending limit',all(r['pending_limits'] for r in rows if not r['design_review_closed']))
check('All calculation references resolve',all(x in calc for r in rows for x in r['calculation_references']))
page_errors=[]
for obj in rows+list(calc.values())+findings:
    for e in obj.get('evidence',[]):
        if 'pdf_pages' in e:
            s=source_map[e['source_id']]
            if not all(1<=p<=s['page_count'] for p in e['pdf_pages']):
                page_errors.append(e)
check('Cited PDF pages in range',not page_errors,page_errors)
check('All source PDFs have existing path and verified checksum',all(sha(OUT/s['bundle_relative_path'])==s['sha256'] for s in sources))
check('Resistor patch nominal and networks unchanged',all('value' not in x['set_fields'] and 'pins' not in x['set_fields'] for x in zerochanges))
check('Historical bank proposals not silently integrated',all(not x['applied'] for x in anchors) and all('C23' not in c['ref'] or c['ref'] in ('C231','C232') for c in native))
end_hash=sha(ENGINE/'electrical/native-components.json')
check('Current native still matches audited snapshot',end_hash==source_hash,{'before_sha256':source_hash,'after_sha256':end_hash})
fwdrift=[x for x in fw_evidence if sha(ENGINE/x['path'])!=x['sha256']]
check('Referenced firmware snapshots still current',not fwdrift,[x['path'] for x in fwdrift])
save('verification.json',{'schema':'smartvio-v26-pin-review-verification/1.0','checks':checks,'all_structure_checks_pass':all(c['pass'] for c in checks),
                          'electrical_approval':False,'physical_tests_executed':0,'global_native_pcb_firmware_written':False,
                          'source_end_sha256':end_hash,'counts':counts,'firmware_drift_requires_review':fwdrift,
                          'verification_meaning':'File/data coverage/provenance verification, not a blanket electrical PASS.'})

def h(x):
    return html.escape(str(x))


body=['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>V26 Pin Application Review</title>',
      '<style>body{font:15px system-ui;margin:32px;max-width:1550px;color:#20252a}table{border-collapse:collapse;width:100%}td,th{border:1px solid #bbb;padding:7px;vertical-align:top}th{background:#eee;text-align:left}code{word-break:break-all}details{margin:12px 0}a{color:#0658ac}.hold{color:#993800}.ok{color:#006743}</style>',
      '<h1>V26 / 287 Baseline Pin Application Review</h1>',
      '<p><b>Design review only. phys0. Procurement false. No global native/PCB/firmware edits.</b></p>',
      '<p>Current native: <code>'+source_hash+'</code>;316 parts /1081 pins. Baseline287 pins /136 refs, not287 fully approved parts.</p>',
      '<p>'+h(summary['scope_definition'])+'</p>',
      '<p>'+h(counts)+'</p>',
      '<p>100 nominal-preserving changes already parent-merged;10 compound anchors+30 new capacitors remain proposals. Current blank MPNs:9C+3R. The previous74 is a candidate-selection layer count, not a current operating-Ceff approval count.</p>',
      '<p><a href="pin-review.json">287-pin JSON</a> | <a href="application-by-ref.json">136-ref application JSON</a> | <a href="calculations.json">Calculations</a> | <a href="correction-patch.json">Guarded proposals</a> | <a href="critical-capacitor-options.json">Ceff alternatives</a> | <a href="verification.json">Verification</a> | <a href="source-provenance.json">Provenance</a></p>',
      '<h2>Required Corrections / Limits</h2>']
for f in findings:
    body.append('<p><b>'+h(f['id']+' '+f['priority'])+'</b> '+h(f['statement'])+' '+h(f.get('proposal',''))+'</p>')
body.append('<h2>Per-Pin Review</h2><table><tr><th>Baseline / Current</th><th>Status / Role</th><th>Normal / Default / Fault</th><th>Limits / Evidence</th></tr>')
for r in rows:
    links=[]
    for e in r['evidence']:
        if e['source_id'] in source_map:
            s=source_map[e['source_id']]
            path=s['bundle_relative_path']
            if e.get('pdf_pages'): path+='#page='+str(e['pdf_pages'][0])
            links.append('<a href="'+h(path)+'">'+h(e['source_id']+' pp'+str(e.get('pdf_pages',[])))+'</a>')
        else:
            s=fw_map[e['source_id']]
            links.append('<a href="'+h(s['snapshot'])+'">'+h(e['source_id']+' lines'+str(e.get('lines',[])))+'</a>')
    pins=', '.join(str(p['number'])+':'+str(p.get('net')) for p in r['current_pins'])
    body.append('<tr><td>'+h(r['baseline_key'])+'<br>'+h(pins)+'<br>'+h(r['current_mpn'])+'</td><td class="'+('ok' if r['design_review_closed'] else 'hold')+'">'+h(r['status'])+'<br>'+h(r['application_role'])+'</td><td>'+h(r['normal_operation'])+'<br><br>'+h(r['default_or_power_off'])+'<br><br>'+h(r['open_short_fault_review'])+'</td><td>'+h(r['pending_limits'] or r['closed_scope'])+'<br>'+h(r['calculation_references'])+'<br>'+'<br>'.join(links)+'</td></tr>')
body.append('</table><h2>Source Documents</h2>')
for sid in sorted(used):
    if sid not in source_map: continue
    s=source_map[sid]
    body.append('<p>'+h(sid)+' <a href="'+h(s['bundle_relative_path'])+'">local evidence</a> '+('<a href="'+h(s['manufacturer_url'])+'">manufacturer</a>' if s.get('manufacturer_url') else 'original URL not resolved; local hashed evidence provided')+' <code>'+h(s['sha256'])+'</code></p>')
body.append('</html>')
(OUT/'report.html').write_text('\n'.join(body),encoding='utf-8')
print(json.dumps({'status_counts':counts,'closed':counts.get(CLOSED,0),'blank_C_R':[x['ref'] for x in current_empty],
                  'verification_pass':all(c['pass'] for c in checks),'failed_checks':[x for x in checks if not x['pass']]},ensure_ascii=False,indent=2))
