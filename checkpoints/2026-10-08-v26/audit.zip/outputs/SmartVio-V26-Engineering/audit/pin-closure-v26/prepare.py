import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from pypdf import PdfReader

OUT = Path(__file__).resolve().parent
ENGINE = OUT.parents[1]
ROOT = ENGINE.parents[1]


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


inputs = {'native': ENGINE / 'electrical/native-components.json',
          'baseline': ENGINE / 'audit/all-pins.json',
          'system': ENGINE / 'audit/system-v26/application-profiles.json'}
data = {k: read(p) for k, p in inputs.items()}
provenance = {k: {'path': str(p.relative_to(ENGINE)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for k, p in inputs.items()}
snap = OUT / 'snapshots'
snap.mkdir(exist_ok=True)
for k, p in inputs.items():
    target = snap / (k + '-' + provenance[k]['sha256'][:12] + '.json')
    if not target.exists():
        target.write_bytes(p.read_bytes())
statuses = {'PASSIVE_APPLICATION_AND_MPN_REVIEW_PENDING', 'REQUIRES_REVIEW', 'HOLD_PHYSICAL_PAD_OR_FUNCTION'}
baseline = [p for p in data['baseline'] if p['reviewStatus'] in statuses]
assert len(baseline) == 287
native = {c['ref']: c for c in data['native']}
netmap = defaultdict(list)
for c in data['native']:
    for p in c['pins']:
        if p.get('net'):
            netmap[p['net']].append({'ref': c['ref'], 'pin': p['number'], 'name': p.get('name'), 'type': c['type'], 'value': c['value'], 'mpn': c.get('mpn')})
save('input-provenance.json', dict(inputs=provenance, part_count=len(native), pin_count=sum(len(c['pins']) for c in data['native']), baseline_pending=287,
                                   baseline_status_counts=dict(Counter(p['reviewStatus'] for p in baseline))))
save('baseline-287.json', baseline)
save('current-net-connections.json', dict(netmap))
scope_refs = {p['ref'] for p in baseline}
save('current-scope-components.json', [c for c in data['native'] if c['ref'] in scope_refs])
lines = []
for c in data['native']:
    if c['ref'] not in scope_refs:
        continue
    lines.append(f"{c['ref']} | {c['value']} | {c.get('mpn')}")
    for p in c['pins']:
        n = p.get('net')
        lines.append(f"  {p['number']} {p.get('name')}: {n}")
        if n and n != 'GND' and n not in ('V3D', 'V3A', 'V3LOAD', 'SYS', 'PACK_PLUS', 'USB_5V_SAFE'):
            lines.append('    ' + ' ; '.join(f"{e['ref']}.{e['pin']}({e['name']},{e['value']})" for e in netmap[n] if e['ref'] != c['ref']))
(OUT / 'circuit-inventory.txt').write_text('\n'.join(lines), encoding='utf-8')

files = {
    'STM32H743': ENGINE / 'audit/audio/sources/STM32H743.pdf',
    'TLV9064': ENGINE / 'audit/audio/sources/TLV9064.pdf',
    'PCM1864': ENGINE / 'audit/audio/sources/PCM1864.pdf',
    'PCM5102A': ENGINE / 'audit/audio/sources/PCM5102A.pdf',
    'TPA6132A2': ENGINE / 'audit/audio/sources/TPA6132A2.pdf',
    'MAX98357A': ENGINE / 'audit/audio/sources/MAX98357A.pdf',
    'ADS1115': ENGINE / 'audit/power/source-evidence/ads1115.pdf',
    'OPA4330': ENGINE / 'audit/power/source-evidence/opa4330.pdf',
    'TMUX1511': ENGINE / 'audit/power/source-evidence/tmux1511.pdf',
    'TMP117': ENGINE / 'audit/power/source-evidence/tmp117.pdf',
    'TPS25947': ENGINE / 'audit/power/source-evidence/tps25947.pdf',
    'LTC2954': ROOT / 'work/v26/selection/sources/2954fb.pdf',
    'ESP32_MINI': ROOT / 'work/v25/pcb/sources/esp32-mini-1.pdf',
    'SKQG': ROOT / 'work/v26/selection/sources/SKQG.pdf',
    'RK10J': ROOT / 'work/v26/selection/sources/RK10J.pdf',
    'KYCON_JACK': ROOT / 'work/v26/selection/sources/STX-353K7A-6N-KTTR.pdf',
    'CYAN_LED': ROOT / 'work/v26/selection/sources/APT1608VRCXF-A-5MAV.pdf',
    'SPEAKER': ROOT / 'work/v26/selection/sources/AS01808AO-SC18-WP-R.pdf',
}
for s in read(ENGINE / 'audit/passive-closure/source-evidence.json'):
    files.setdefault(s['id'], ENGINE / 'audit/passive-closure' / s['path'])
textdir = OUT / 'text'
textdir.mkdir(exist_ok=True)
manifest = []
for sid, p in files.items():
    assert p.exists(), p
    checksum = hashlib.sha256(p.read_bytes()).hexdigest()
    target = textdir / (sid + '.json')
    if not target.exists():
        doc = PdfReader(p)
        pages = [{'page': i+1, 'text': page.extract_text()} for i, page in enumerate(doc.pages)]
        target.write_text(json.dumps(pages, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    manifest.append({'id': sid, 'absolute_path': str(p), 'engine_relative_path': str(p.relative_to(ENGINE)) if p.is_relative_to(ENGINE) else None,
                     'sha256': checksum, 'page_count': len(read(target)), 'downloaded_again': False})
save('reused-document-index.json', manifest)
print('PREPARED', provenance['native']['sha256'], 'BASELINE', len(baseline), 'REFS', len(scope_refs), 'DOCS', len(manifest))
