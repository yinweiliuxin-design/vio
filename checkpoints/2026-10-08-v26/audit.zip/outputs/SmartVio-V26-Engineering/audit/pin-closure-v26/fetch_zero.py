import hashlib
import json
import urllib.request
from pathlib import Path
from pypdf import PdfReader

OUT = Path(__file__).resolve().parent
url = 'https://www.yageogroup.com/component-documentation/download/specsheet/RC0603JR-070RL'
folder = OUT / 'new-source-evidence'
folder.mkdir(exist_ok=True)
path = folder / 'RC0603JR-070RL.pdf'
if not path.exists():
    data = urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=35).read()
    assert data.startswith(b'%PDF')
    path.write_bytes(data)
doc = PdfReader(path)
pages = [{'page': i+1, 'text': p.extract_text()} for i, p in enumerate(doc.pages)]
(OUT / 'text/RC0603JR-070RL.json').write_text(json.dumps(pages, ensure_ascii=False, indent=2), encoding='utf-8')
(OUT / 'new-source-evidence.json').write_text(json.dumps([{'id': 'RC0603JR-070RL', 'manufacturer_url': url,
    'absolute_path': str(path), 'relative_path': str(path.relative_to(OUT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'pdf_pages': [1], 'download_scope': 'One missing zero-ohm exact-MPN source; no redownload of prior100 selected parts'}], indent=2), encoding='utf-8')
print(pages[0]['text'])
