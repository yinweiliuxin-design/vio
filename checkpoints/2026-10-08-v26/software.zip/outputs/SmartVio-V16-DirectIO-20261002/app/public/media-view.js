'use strict';
function mediaHTML(post){return (post.mediaFiles||post.media?.map(id=>({id,type:'image/png'}))||[]).map(m=>m.type.startsWith('video/')?`<video class="post-video" controls playsinline preload="none" src="/api/media/${E(m.id)}" aria-label="${E(t('video'))}"></video>`:`<img class="post-image" src="/api/media/${E(m.id)}" alt="${E(t('attachment'))}" loading="lazy">`).join('');}
