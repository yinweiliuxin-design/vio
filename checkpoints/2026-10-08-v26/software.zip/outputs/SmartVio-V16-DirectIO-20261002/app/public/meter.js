'use strict';
(function(root){
 function info(song={}){
  const meter=song.meter??[4,4];
  if(!Array.isArray(meter)||meter.length!==2||!Number.isInteger(meter[0])||meter[0]<1||meter[0]>12||![2,4,8,16].includes(meter[1]))throw Error('Unsupported time signature');
  const [n,d]=meter,unit=4/d,bar=n*unit,compound=d===8&&n>3&&n%3===0;
  return {n,d,unit,bar,compound,label:n+'/'+d};
 }
 function bars(song){return Math.max(1,Math.ceil(song.events.reduce((sum,e)=>sum+e.beats,0)/info(song).bar-1e-9));}
 function accent(beat,m){const tick=Math.round(beat/m.unit),pos=((tick%m.n)+m.n)%m.n;return pos===0?1320:m.compound&&pos%3===0?1100:880;}
 function fragments(song){const m=info(song),result=[];let used=0;for(const [index,e] of song.events.entries()){
  if(!Number.isFinite(e.beats)||e.beats<=0||e.beats>256)throw Error('Invalid note duration');
  let left=e.beats;while(left>1e-9){const beats=Math.min(m.bar-used,left);left-=beats;used+=beats;const barEnd=used>=m.bar-1e-9;result.push({index,beats,tied:left>1e-9&&e.midi!==null,barEnd});if(barEnd)used=0;}
 }return result;}
 const api={info,bars,accent,fragments};if(typeof module==='object'&&module.exports)module.exports=api;else root.Meter=api;
})(typeof globalThis==='object'?globalThis:this);
