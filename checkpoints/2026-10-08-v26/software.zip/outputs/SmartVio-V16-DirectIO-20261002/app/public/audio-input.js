'use strict';
const audioCopy={
 'zh-CN':['音频输入','系统默认','刷新设备','评分校准链路','有线 / 本机','USB 音频','外置无线系统','蓝牙音频','未校准','已填写校准偏移'],
 'en-GB':['Audio input','System default','Refresh devices','Scoring calibration route','Wired / local','USB audio','External wireless system','Bluetooth audio','Uncalibrated','Calibration offset entered'],
 'de-DE':['Audioeingang','Systemstandard','Geräte aktualisieren','Kalibrierungsweg','Kabel / lokal','USB-Audio','Externes Funksystem','Bluetooth-Audio','Nicht kalibriert','Kalibrierungswert eingetragen'],
 'ja-JP':['音声入力','システム既定','機器を更新','採点の補正経路','有線 / 本体','USBオーディオ','外部ワイヤレス','Bluetooth音声','未調整','補正値入力済み'],
 'fr-FR':['Entrée audio','Choix du système','Actualiser les appareils','Chemin de calibration','Filaire / local','Audio USB','Système sans fil externe','Audio Bluetooth','Non calibré','Décalage saisi']
};
let audioInputs=[];
const originalPracticeHeader=practiceHeader;
practiceHeader=()=>originalPracticeHeader()+audioInputControls();
const ac=()=>audioCopy[locale]||audioCopy['en-GB'];
function audioInputControls(){const c=ac();return `<div class="field-grid"><label>${E(c[0])}<select id="audio-input"><option value="">${E(c[1])}</option>${audioInputs.map((d,i)=>`<option value="${E(d.deviceId)}" ${engine.options.inputDeviceId===d.deviceId?'selected':''}>${E(d.label||'Input '+(i+1))}</option>`).join('')}</select></label><div>${button('audio-refresh',c[2],'refresh-cw')}</div><label>${E(c[3])}<select id="monitor-route">${['wired','usb','wireless','bluetooth'].map((r,i)=>`<option value="${r}" ${(engine.options.monitorRoute||'wired')===r?'selected':''}>${E(c[4+i])}</option>`).join('')}</select></label><output id="calibration-state">${E(engine.options.routeCalibrated?c[9]:c[8])}</output></div>`;}
async function refreshAudioInputs(){audioInputs=(await navigator.mediaDevices.enumerateDevices()).filter(d=>d.kind==='audioinput'&&d.deviceId);const el=document.getElementById('audio-input');if(el){const selectedId=engine.options.inputDeviceId||'';el.innerHTML=`<option value="">${E(ac()[1])}</option>`+audioInputs.map((d,i)=>`<option value="${E(d.deviceId)}">${E(d.label||'Input '+(i+1))}</option>`).join('');el.value=selectedId;if(el.value!==selectedId){engine.stopMicrophone();engine.configure({inputDeviceId:'',calibrationMs:0,routeCalibrated:false});saveMusic();}}}
function resetRouteCalibration(){engine.pause();engine.configure({calibrationMs:0,routeCalibrated:false});const input=document.getElementById('calibrationMs');if(input)input.value=0;const stateEl=document.getElementById('calibration-state');if(stateEl)stateEl.textContent=ac()[8];saveMusic();}
document.addEventListener('click',event=>{if(event.target.closest('[data-action="audio-refresh"]'))refreshAudioInputs().catch(catchError);});
document.addEventListener('change',event=>{const x=event.target;if(x.id==='audio-input'){engine.stopMicrophone();engine.configure({inputDeviceId:x.value});resetRouteCalibration();}if(x.id==='monitor-route'){engine.configure({monitorRoute:x.value});resetRouteCalibration();}if(x.id==='calibrationMs'){engine.options.routeCalibrated=true;saveMusic();const output=document.getElementById('calibration-state');if(output)output.textContent=ac()[9];}});
