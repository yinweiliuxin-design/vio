'use strict';
const $=s=>document.querySelector(s),E=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon=n=>`<i data-lucide="${n}"></i>`,icons=()=>window.lucide?.createIcons();
let state=null,locale=localStorage.getItem('sv13-locale')||'zh-CN',csrf='',noticeTimer;
const t=k=>I18N[locale]?.[k]??I18N['en-GB'][k]??k;
function notify(m){$('#notice').textContent=m;$('#notice').style.display='block';clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$('#notice').style.display='none',5000);}
function modal(content){$('#modal-body').innerHTML=content;if(!$('#modal').open)$('#modal').showModal();icons();}
function download(name,value,type='application/json'){const blob=value instanceof Blob?value:new Blob([typeof value==='string'?value:JSON.stringify(value,null,2)],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function request(url,payload){const r=await fetch(url+(url.includes('?')?'&':'?')+'locale='+encodeURIComponent(locale),payload===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(payload)});const result=await r.json();if(!r.ok)throw Error(result.error||r.statusText);if(result.csrf)csrf=result.csrf;return result;}
async function refresh(){state=await request('/api/state');$('#connection').textContent='Local API · '+state.revision;return state;}
async function act(a){state=await request('/api/action',a);return state.result;}
function button(a,label,i,extra=''){return `<button data-action="${a}" ${extra}>${i?icon(i):''}${E(label)}</button>`;}
function table(headers,rows){return `<div class="table-wrap"><table><thead><tr>${headers.map(x=>`<th>${E(x)}</th>`).join('')}</tr></thead><tbody>${rows.join('')||`<tr><td colspan="${headers.length}" class="empty">${E(t('empty'))}</td></tr>`}</tbody></table></div>`;}
function price(n,currency=state.profile.currency){return new Intl.NumberFormat(locale,{style:'currency',currency}).format(n/(currency==='JPY'?1:100));}
function requireUser(){if(state.user)return true;showAccount();return false;}
function catchError(e){notify(e.message||String(e));}
