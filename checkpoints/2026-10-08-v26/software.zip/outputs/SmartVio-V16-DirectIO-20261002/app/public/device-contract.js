'use strict';
(function(root){
 const routes=['speaker','phones','line','wireless','bluetooth'];
 function evaluate(s){
  const errors=[],warnings=[];
  if(!routes.includes(s.route))errors.push('ROUTE_UNKNOWN');
  if(!['aux','return','off'].includes(s.input))errors.push('INPUT_UNKNOWN');
  if(s.btReceive&&s.route==='bluetooth')errors.push('SINGLE_RADIO_TX_RX_UNVERIFIED');
  if(s.route==='wireless'&&!s.transmitterQualified)errors.push('TX_LEVEL_AND_DC_UNVERIFIED');
  if(s.route==='phones'&&!s.headphonesInserted)errors.push('HEADPHONES_NOT_CONNECTED');
  if(['line','wireless'].includes(s.route)&&!s.lineConnected)errors.push('LINE_NOT_CONNECTED');
  if(s.input!=='off'&&!s.inputConnected)errors.push('INPUT_NOT_CONNECTED');
  if(s.input==='return'&&!s.fxSendConnected)errors.push('RETURN_REQUIRES_SEND');
  if(s.input==='return'&&s.sendIncludesReturn)errors.push('FX_FEEDBACK_LOOP');
  if(s.thermalFault||s.batteryFault)errors.push('POWER_FAULT');
  if(s.route==='bluetooth')warnings.push('NOT_VALIDATED_FOR_LIVE_MONITORING');
  if(['wireless','bluetooth'].includes(s.route)&&!s.latencyCalibrated)warnings.push('CALIBRATION_REQUIRED');
  return {schemaVersion:2,simulation:true,physicalPorts:'integrated-direct',allowed:errors.length===0,errors,warnings,speakerEnabled:errors.length===0&&s.route==='speaker'&&!s.headphonesInserted,outputMuted:errors.length>0};
 }
 const api={evaluate,routes};if(typeof module==='object'&&module.exports)module.exports=api;else root.DeviceContract=api;
})(typeof globalThis==='object'?globalThis:this);
