$ErrorActionPreference = 'Stop'
$bundled = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
$node = if (Test-Path -LiteralPath $bundled) { $bundled } else { (Get-Command node -ErrorAction Stop).Source }
Write-Host 'V16 local sandbox. No real payments. Keep this window open while using the demo.'
Write-Host 'The server prints the actual client and merchant URLs. Ctrl+C stops it.'
& $node (Join-Path $PSScriptRoot 'server.cjs')
