'use strict';
const fs = require('node:fs');
const MAX_VIDEO = 30 * 1024 * 1024;
function inspect(buffer, declared) {
  const type = String(declared || '').split(';')[0].trim().toLowerCase();
  if (type === 'image/png' && buffer.length >= 33 && buffer.length <= 2 * 1024 * 1024 &&
      buffer.subarray(0, 8).toString('hex') === '89504e470d0a1a0a' && buffer.toString('ascii', 12, 16) === 'IHDR' &&
      buffer.readUInt32BE(16) > 0 && buffer.readUInt32BE(16) <= 2048 && buffer.readUInt32BE(20) > 0 && buffer.readUInt32BE(20) <= 2048) return {type, ext: 'png'};
  if (buffer.length > MAX_VIDEO || buffer.length < 32) throw Error('Invalid media size');
  // Container signatures are a sandbox admission check, not a malware scan or full decoder.
  if (type === 'video/webm' && buffer.subarray(0, 4).toString('hex') === '1a45dfa3' && buffer.subarray(0, 1024).includes(Buffer.from('webm'))) return {type, ext: 'webm'};
  if (type === 'video/mp4' && buffer.toString('ascii', 4, 8) === 'ftyp' && buffer.readUInt32BE(0) >= 16 && buffer.readUInt32BE(0) <= buffer.length) return {type, ext: 'mp4'};
  throw Error('Supported media: PNG / MP4 / WebM. Invalid container signature.');
}
function rangeFor(header, size) {
  if (!header) return null;
  const m = /^bytes=(\d*)-(\d*)$/.exec(header);
  if (!m || (!m[1] && !m[2])) return false;
  const start = m[1] ? Number(m[1]) : Math.max(0, size - Number(m[2]));
  const end = m[1] && m[2] ? Math.min(size - 1, Number(m[2])) : size - 1;
  return Number.isSafeInteger(start) && Number.isSafeInteger(end) && start >= 0 && start <= end && start < size ? {start, end} : false;
}
function serve(req, res, file, type) {
  const size = fs.statSync(file).size, range = rangeFor(req.headers.range, size);
  const headers = {'Content-Type': type, 'Content-Disposition': 'inline', 'Cache-Control': 'no-store', 'Accept-Ranges': 'bytes'};
  if (range === false) { res.writeHead(416, {...headers, 'Content-Range': `bytes */${size}`}); res.end(); return; }
  const start = range?.start ?? 0, end = range?.end ?? size - 1;
  res.writeHead(range ? 206 : 200, {...headers, 'Content-Length': end - start + 1, ...(range ? {'Content-Range': `bytes ${start}-${end}/${size}`} : {})});
  fs.createReadStream(file, {start, end}).on('error', () => res.destroy()).pipe(res);
}
module.exports = {inspect, rangeFor, serve, MAX_VIDEO};
