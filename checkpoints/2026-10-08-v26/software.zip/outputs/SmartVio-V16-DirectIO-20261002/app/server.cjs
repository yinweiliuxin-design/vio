'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {promisify}=require('node:util');
const mediaIO=require('./media.cjs');
const scrypt=promisify(crypto.scrypt),root=path.join(__dirname,'public');
const stateFile=process.env.SV_STATE_FILE||path.join(__dirname,'.state/state.json');
const seed=JSON.parse(fs.readFileSync(path.join(__dirname,'seed.json'),'utf8'));
let state=fs.existsSync(stateFile)?JSON.parse(fs.readFileSync(stateFile,'utf8')):structuredClone(seed);
if(state.schema!==13)throw Error('V13 schema required; never overwrite older data');
state.tickets ||= [];
const sessions=new Map(),attempts=new Map();let queue=Promise.resolve();let port=Number(process.env.PORT||8894);
const profiles={ 'en-GB':{market:'GB',brand:'VELLEN',currency:'GBP'},'de-DE':{market:'DE',brand:'VELLEN',currency:'EUR'},'en-US':{market:'US',brand:'silvio',currency:'USD'},'ja-JP':{market:'JP',brand:'silvio',currency:'JPY'},'zh-CN':{market:'GB',brand:'VELLEN',currency:'GBP',review:true},'fr-FR':{market:null,brand:'Violin Studio',currency:'EUR',review:true}};
const adminActions=new Set(['cms','moderate','resolve-report','rights','publish-song','ota','generate-code','revoke-code','merchant-ship','merchant-refund','product-stock','reply-ticket']);
const now=()=>Date.now(),id=()=>crypto.randomUUID();
function fail(message,status=400){const e=Error(message);e.status=status;throw e;}
function text(v,max=500,min=0){if(typeof v!=='string'||v.length>max||v.trim().length<min)fail('Invalid text');return v.trim();}
function integer(v,min,max){if(!Number.isInteger(v)||v<min||v>max)fail('Invalid integer');return v;}
function member(v,allowed){if(!allowed.includes(v))fail('Invalid option');return v;}
function safeEqual(a,b){const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&crypto.timingSafeEqual(x,y);}
async function hashPassword(p,salt=crypto.randomBytes(16).toString('hex')){text(p,128,12);return {salt,hash:(await scrypt(p,salt,64)).toString('hex')};}
async function verifyPassword(p,record){if(typeof p!=='string'||p.length>128||!record)return false;return safeEqual((await scrypt(p,record.salt,64)).toString('hex'),record.hash);}
function save(){fs.mkdirSync(path.dirname(stateFile),{recursive:true});fs.writeFileSync(stateFile+'.tmp',JSON.stringify(state,null,2));fs.renameSync(stateFile+'.tmp',stateFile);}
function user(session){const u=state.users.find(u=>u.id===session.userId);if(!u)fail('Sign in required',401);return u;}
function admin(session){if(!session.admin)fail('Merchant access required',403);}
function profile(locale){return profiles[locale]||profiles['en-GB'];}
function visible(p,u){if(p.status==='deleted')return false;if(p.userId===u?.id)return true;const author=state.users.find(x=>x.id===p.userId);if(!author||u?.blocks.includes(author.id)||author.blocks.includes(u?.id))return false;return p.status==='published'&&(p.visibility==='public'||(p.visibility==='followers'&&u?.following.includes(author.id)));}
function publicPost(p,u){return {...p,mediaFiles:(p.media||[]).map(id=>{const m=state.media.find(m=>m.id===id);return {id,type:m?.type||'image/png'};}),author:state.users.find(x=>x.id===p.userId)?.nickname||'Deleted user',likes:p.likes.length,liked:p.likes.includes(u?.id),saved:u?.bookmarks.includes(p.id)||false,comments:p.comments.filter(c=>c.status==='published'||c.userId===u?.id).map(c=>({...c,author:state.users.find(x=>x.id===c.userId)?.nickname||'Deleted user'})),repost:p.repostId?state.posts.find(x=>x.id===p.repostId&&visible(x,u))?.text||'[Unavailable]':null};}
function safeUser(u){if(!u)return null;const {credentials,...other}=u;return other;}
function customerState(session,locale){const u=state.users.find(x=>x.id===session.userId);return {schema:13,revision:state.revision,profile:profile(locale),profiles,csrf:session.csrf,user:safeUser(u),ownedMedia:state.media.filter(m=>m.userId===u?.id),tickets:state.tickets.filter(t=>t.userId===u?.id),cms:state.cms,songs:state.songs,features:state.features,products:state.products,posts:state.posts.filter(p=>visible(p,u)).map(p=>publicPost(p,u)),people:state.users.filter(x=>x.id!==u?.id&&!x.child&&x.privacy.profilePublic&&!x.blocks.includes(u?.id)&&!u?.blocks.includes(x.id)).map(x=>({id:x.id,nickname:x.nickname,bio:x.bio})),messages:state.messages.filter(m=>u&&(m.from===u.id||m.to===u.id)),sessions:state.practice.filter(x=>x.userId===u?.id),orders:state.orders.filter(x=>x.userId===u?.id),notifications:state.notifications.filter(x=>x.userId===u?.id),device:u?.device||null,ota:state.ota,payment:{provider:'local-sandbox',live:false},adminSetupNeeded:!state.adminCredentials,admin:session.admin};}
function merchantState(session){admin(session);return {revision:state.revision,tickets:state.tickets,orders:state.orders,products:state.products,posts:state.posts.filter(p=>p.visibility!=='private').map(p=>({...publicPost(p,null),comments:p.comments})),reports:state.reports,songs:state.songs,cms:state.cms,codes:state.codes,ota:state.ota,audit:state.audit,deletions:state.deletions,users:state.users.map(u=>({id:u.id,nickname:u.nickname,child:u.child})),payment:{provider:'local-sandbox',live:false}};}
function notify(uid,message){state.notifications.unshift({id:id(),userId:uid,message,read:false,at:new Date().toISOString()});state.notifications=state.notifications.slice(0,1000);}
function expireOrders(){let changed=false;for(const o of state.orders){if(o.status==='awaiting_payment'&&o.expiresAt<now()){o.status='expired';releaseStock(o);changed=true;}}if(changed){audit('expire-orders');save();}}
function purgeOrphanMedia(){const folder=path.join(path.dirname(stateFile),'media');if(!fs.existsSync(folder))return;for(const file of fs.readdirSync(folder)){if(/^[a-f0-9-]{36}\.(png|webm|mp4)$/.test(file)&&!state.media.some(m=>m.id+'.'+(m.ext||'png')===file))fs.unlinkSync(path.join(folder,file));}}
function releaseStock(o){if(o.reserved){for(const line of o.lines){const p=state.products.find(p=>p.id===line.productId);if(p)p.stock+=line.quantity;}o.reserved=false;}}
function orderOwned(orderId,u){const o=state.orders.find(o=>o.id===orderId&&o.userId===u.id);if(!o)fail('Order not found',404);return o;}
function applyPayment(event){
 if(state.paymentEvents.includes(event.id))return;
 const o=state.orders.find(o=>o.id===event.orderId);if(!o)fail('Unknown order');
 if(o.total!==event.amount||o.currency!==event.currency)fail('Payment amount/currency mismatch');
 if(o.status==='paid'||o.status==='shipped'||o.status==='refunded'){state.paymentEvents.push(event.id);return;}
 if(o.status!=='awaiting_payment')fail('Order is not payable');
 if(event.outcome==='success'){o.status='paid';o.reserved=false;o.paidAt=new Date().toISOString();o.paymentId=event.id;notify(o.userId,'Sandbox payment confirmed: '+o.number);}else{o.status=member(event.outcome,['failed','cancelled']);releaseStock(o);}
 state.paymentEvents.push(event.id);o.updatedAt=new Date().toISOString();
}
async function mutate(a,session){
 if(!a||typeof a!=='object'||Array.isArray(a))fail('Invalid action');
 if(adminActions.has(a.type))admin(session);
 const u=adminActions.has(a.type)?null:user(session);
 switch(a.type){
 case 'support-ticket':{if(state.tickets.filter(t=>t.userId===u.id).length>=50)fail('Ticket limit');state.tickets.unshift({id:id(),userId:u.id,category:member(a.category,['product','order','privacy','appeal']),message:text(a.message,2000,1),status:'open',reply:'',at:new Date().toISOString()});break;}
 case 'reply-ticket':{const t=state.tickets.find(t=>t.id===a.id);if(!t)fail('Ticket not found');t.reply=text(a.reply,2000,1);t.status='answered';notify(t.userId,'Service request answered');break;}
 case 'privacy':{const next={};for(const k of ['profilePublic','allowFollowers','analytics','cloudPractice','allowMessages'])next[k]=a[k]===true;if(u.child){next.profilePublic=false;next.allowMessages=false;next.allowFollowers=false;}u.privacy=next;u.consentVersion='2026-10-01-v13';u.consentAt=new Date().toISOString();break;}
 case 'profile':u.nickname=text(a.nickname,40,1);u.bio=text(a.bio,200);break;
 case 'favorite':{const song=state.songs.find(s=>s.id===a.id);if(!song)fail('Song not found');toggle(u.favorites,a.id);break;}
 case 'follow':{const target=state.users.find(x=>x.id===a.id&&x.id!==u.id);if(!target||u.child||target.child||!target.privacy.allowFollowers||target.blocks.includes(u.id)||u.blocks.includes(target.id))fail('Follow not available');toggle(u.following,a.id);break;}
 case 'block':{const target=state.users.find(x=>x.id===a.id&&x.id!==u.id);if(!target)fail('User not found');toggle(u.blocks,a.id);u.following=u.following.filter(x=>x!==a.id);break;}
 case 'post':{if(state.posts.filter(p=>p.userId===u.id&&p.status!=='deleted').length>=100)fail('Post limit reached');const visibility=u.child?'private':member(a.visibility,['private','followers','public']);const media=Array.isArray(a.media)?a.media.slice(0,3):[];if(media.some(x=>!state.media.some(m=>m.id===x&&m.userId===u.id)))fail('Invalid attachment');if(media.some(x=>state.media.find(m=>m.id===x)?.type.startsWith('video/'))&&a.mediaConsent!==true)fail('Explicit video upload consent required');const p={mediaConsentAt:a.mediaConsent===true?new Date().toISOString():null,id:id(),userId:u.id,text:text(a.text,2000,1),tags:Array.isArray(a.tags)?a.tags.slice(0,5).map(t=>text(t,25,1)):[],media,visibility,status:visibility==='private'?'private':'pending',likes:[],comments:[],createdAt:new Date().toISOString(),repostId:null};if(a.repostId){const target=state.posts.find(x=>x.id===a.repostId&&visible(x,u)&&x.visibility==='public'&&x.status==='published');if(!target)fail('Repost not allowed');p.repostId=target.id;}state.posts.unshift(p);break;}
 case 'delete-media':{const m=state.media.find(m=>m.id===a.id&&m.userId===u.id);if(!m)fail('Media not found',404);if(state.posts.some(p=>p.media?.includes(m.id)))fail('Delete the attached posts first');state.media=state.media.filter(x=>x.id!==m.id);break;}
 case 'edit-post':{const p=state.posts.find(p=>p.id===a.id&&p.userId===u.id&&p.status!=='deleted');if(!p)fail('Post not found',404);p.text=text(a.text,2000,1);p.status=p.visibility==='private'?'private':'pending';p.updatedAt=new Date().toISOString();break;}
 case 'delete-post':{const p=state.posts.find(p=>p.id===a.id&&p.userId===u.id);if(!p)fail('Post not found',404);state.posts=state.posts.filter(x=>x.id!==p.id);state.media=state.media.filter(m=>!p.media?.includes(m.id)||state.posts.some(x=>x.media?.includes(m.id)));for(const x of state.users)x.bookmarks=x.bookmarks.filter(x=>x!==p.id);break;}
 case 'like':case 'bookmark':{const p=state.posts.find(p=>p.id===a.id&&visible(p,u)&&p.status==='published');if(!p)fail('Post not found',404);toggle(a.type==='like'?p.likes:u.bookmarks,a.type==='like'?u.id:p.id);break;}
 case 'comment':{const p=state.posts.find(p=>p.id===a.id&&visible(p,u)&&p.status==='published');if(!p||u.child)fail('Comment not available');if(p.comments.length>=200)fail('Comment limit');p.comments.push({id:id(),userId:u.id,text:text(a.text,500,1),status:'pending',at:new Date().toISOString()});break;}
 case 'report':{const p=state.posts.find(p=>p.id===a.id&&visible(p,u));if(!p)fail('Post not found',404);state.reports.push({id:id(),userId:u.id,postId:p.id,reason:text(a.reason,300,1),status:'open'});break;}
 case 'notifications-read':state.notifications.filter(n=>n.userId===u.id).forEach(n=>n.read=true);break;
 case 'message':{const target=state.users.find(x=>x.id===a.to&&x.id!==u.id);if(!target||u.child||target.child||!u.privacy.allowMessages||!target.privacy.allowMessages||u.blocks.includes(target.id)||target.blocks.includes(u.id))fail('Messages not permitted');if(state.messages.filter(m=>m.from===u.id).length>=500)fail('Message limit');state.messages.push({id:id(),from:u.id,to:target.id,text:text(a.text,1000,1),at:new Date().toISOString()});notify(target.id,'New private message');break;}
 case 'practice':{if(!u.privacy.cloudPractice)fail('Practice sync is disabled');const song=state.songs.find(s=>s.id===a.songId);if(!song)fail('Song not found');const duration=Number(a.duration);if(!Number.isFinite(duration)||duration<0||duration>7200)fail('Invalid duration');let stats=null;if(a.stats){stats={validFrames:integer(a.stats.validFrames,0,1000000),totalFrames:integer(a.stats.totalFrames,0,1000000),meanAbsCents:Number(a.stats.meanAbsCents)};if(stats.validFrames>stats.totalFrames||!Number.isFinite(stats.meanAbsCents)||stats.meanAbsCents<0||stats.meanAbsCents>2400)fail('Invalid measurement');}state.practice.unshift({id:id(),userId:u.id,songId:song.id,title:song.title,duration,kind:stats?'browser-microphone-unvalidated':'playback-only',stats,at:new Date().toISOString()});break;}
 case 'cart':{const p=state.products.find(p=>p.id===a.id&&p.enabled);if(!p)fail('Product unavailable');const q=integer(a.quantity,0,10);u.cart=u.cart.filter(l=>l.productId!==p.id);if(q)u.cart.push({productId:p.id,quantity:q});break;}
 case 'checkout':{const k=text(a.idempotencyKey,100,8);const prior=state.orders.find(o=>o.userId===u.id&&o.idempotencyKey===k);if(prior)return {orderId:prior.id};if(u.child)fail('Guardian purchase required');if(!u.cart.length)fail('Cart is empty');const pr=profile(a.locale);if(!pr.market)fail('Market not configured');if(a.country!==pr.market)fail('Shipping country must match the selected market');if(a.accept!==true)fail('Sandbox terms required');const lines=u.cart.map(l=>{const p=state.products.find(p=>p.id===l.productId&&p.enabled);if(!p||p.stock<l.quantity)fail('Insufficient stock');if(p.type==='digital'&&!p.rightsCleared)fail('Digital rights not cleared');return {productId:p.id,title:p.title,quantity:l.quantity,unitAmount:p.prices[pr.currency]};});const subtotal=lines.reduce((t,l)=>t+l.unitAmount*l.quantity,0);if(!Number.isSafeInteger(subtotal)||subtotal<=0)fail('Invalid total');const shipping=0,tax=0;const o={id:id(),number:'TEST-'+String(state.orders.length+1).padStart(6,'0'),userId:u.id,idempotencyKey:k,brand:pr.brand,market:pr.market,currency:pr.currency,lines,subtotal,shipping,tax,total:subtotal+shipping+tax,taxMode:'SANDBOX_ONLY_NOT_TAX_ADVICE',address:{name:text(a.name,80,1),line:text(a.address,200,1),postal:text(a.postal,20,1),country:pr.market},status:'awaiting_payment',provider:'local-sandbox',live:false,reserved:true,expiresAt:now()+15*60*1000,createdAt:new Date().toISOString()};for(const l of lines)state.products.find(p=>p.id===l.productId).stock-=l.quantity;state.orders.unshift(o);u.cart=[];return {orderId:o.id};}
 case 'sandbox-pay':{const o=orderOwned(a.orderId,u);const outcome=member(a.outcome,['success','failed','cancelled']);applyPayment({id:'sandbox-'+o.id+'-'+outcome,orderId:o.id,amount:o.total,currency:o.currency,outcome});break;}
 case 'cancel-order':{const o=orderOwned(a.orderId,u);if(o.status!=='awaiting_payment')fail('Cannot cancel this state');o.status='cancelled';releaseStock(o);break;}
 case 'request-refund':{const o=orderOwned(a.orderId,u);if(!['paid','shipped'].includes(o.status))fail('Refund unavailable');o.refundRequest={reason:text(a.reason,300,1),at:new Date().toISOString(),status:'requested'};break;}
 case 'merchant-ship':{const o=state.orders.find(o=>o.id===a.id);if(!o||o.status!=='paid'||o.refundRequest?.status==='requested')fail('Order not shippable');o.status='shipped';o.tracking={carrier:text(a.carrier,40,1),number:text(a.tracking,80,1),kind:'sandbox'};notify(o.userId,'Sandbox shipment updated: '+o.number);break;}
 case 'merchant-refund':{const o=state.orders.find(o=>o.id===a.id);if(!o)fail('Order not found');if(o.status==='refunded')break;if(!['paid','shipped'].includes(o.status))fail('Order not refundable');if(o.status==='paid')for(const l of o.lines)state.products.find(p=>p.id===l.productId).stock+=l.quantity;o.status='refunded';o.refund={id:id(),amount:o.total,at:new Date().toISOString(),provider:'local-sandbox',live:false};if(o.refundRequest)o.refundRequest.status='approved';notify(o.userId,'Sandbox refund confirmed: '+o.number);break;}
 case 'product-stock':{const p=state.products.find(p=>p.id===a.id);if(!p)fail('Product not found');p.stock=integer(a.stock,0,100000);break;}
 case 'device':u.device={status:member(a.status,['connected','disconnected','error']),source:'simulation',latencyMs:null};break;
 case 'bind':{const c=state.codes.find(c=>c.code===a.code&&c.status==='active');if(!c||u.binding)fail('Binding not available');c.status='used';c.userId=u.id;u.binding={device:'DEMO-SV210',code:c.code};break;}
 case 'unbind':u.binding=null;break;
 case 'generate-code':state.codes.unshift({code:'DEMO-'+crypto.randomBytes(6).toString('hex').toUpperCase(),status:'active'});break;
 case 'revoke-code':{const c=state.codes.find(c=>c.code===a.code);if(!c)fail('Code not found');c.status='revoked';break;}
 case 'cms':state.cms[member(a.locale,Object.keys(profiles))]=text(a.text,200);break;
 case 'moderate':{const p=state.posts.find(p=>p.id===a.id);if(!p)fail('Post not found');const status=member(a.status,['published','rejected']);if(a.commentId){const c=p.comments.find(c=>c.id===a.commentId);if(!c)fail('Comment not found');c.status=status;notify(c.userId,'Comment review: '+status);}else{if(p.visibility==='private')fail('Private posts cannot be published by moderator');p.status=status;notify(p.userId,'Post review: '+status);}break;}
 case 'resolve-report':{const r=state.reports.find(r=>r.id===a.id);if(!r)fail('Report not found');r.status='resolved';r.resolution=text(a.resolution,300,1);notify(r.userId,'Your report has been reviewed.');break;}
 case 'rights':{const s=state.songs.find(s=>s.id===a.id);if(!s)fail('Song not found');const status=member(a.status,['pending','reviewed']);const territories=Array.isArray(a.territories)?a.territories.filter(x=>['GB','DE','US','JP'].includes(x)):[];const evidence=text(a.evidence,1000);if(status==='reviewed'&&(!evidence||!territories.length))fail('Evidence and territory required');s.rights={status,evidence,territories};if(status==='pending')s.published=false;break;}
 case 'publish-song':{const s=state.songs.find(s=>s.id===a.id);if(!s||s.rights.status!=='reviewed')fail('Rights not cleared');s.published=!s.published;break;}
 case 'ota':{if(!/^\d+\.\d+\.\d+$/.test(a.version))fail('Invalid firmware version');state.ota={version:a.version,stage:member(a.stage,['draft','5%','25%','100%','rollback']),simulated:true,deviceWritten:false};break;}
 case 'delete-account':{if(!await verifyPassword(a.password,u.credentials))fail('Password confirmation required',403);const active=state.orders.filter(o=>o.userId===u.id&&['awaiting_payment','paid','shipped'].includes(o.status));if(active.length)fail('Resolve open orders before deletion; contact merchant for refund');state.deletions.unshift({id:id(),requestedAt:new Date().toISOString(),status:'local-complete',scope:'Local account and content erased; test orders pseudonymized',backupStatus:'No automatic backups in this local demo'});for(const o of state.orders.filter(o=>o.userId===u.id)){o.userId=null;o.address={country:o.market};}state.posts=state.posts.filter(p=>p.userId!==u.id);for(const p of state.posts){p.likes=p.likes.filter(x=>x!==u.id);p.comments=p.comments.filter(c=>c.userId!==u.id);}state.tickets=state.tickets.filter(x=>x.userId!==u.id);state.practice=state.practice.filter(x=>x.userId!==u.id);state.reports=state.reports.filter(x=>x.userId!==u.id);state.notifications=state.notifications.filter(x=>x.userId!==u.id);for(const x of state.users){x.following=x.following.filter(x=>x!==u.id);x.blocks=x.blocks.filter(x=>x!==u.id);}state.codes.filter(c=>c.userId===u.id).forEach(c=>{c.status='revoked';delete c.userId;});state.users=state.users.filter(x=>x.id!==u.id);for(const s of sessions.values())if(s.userId===u.id)s.userId=null;break;}
 default:fail('Unknown action');
 }
 return {};
}
function toggle(a,v){const n=a.indexOf(v);if(n<0)a.push(v);else a.splice(n,1);}
function audit(action){state.revision++;state.audit.unshift({id:id(),action,at:new Date().toISOString(),mode:'local-sandbox'});state.audit=state.audit.slice(0,1000);}
function send(res,status,body){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(body));}
function getSession(req,res){const match=String(req.headers.cookie||'').match(/(?:^|;\s*)sv13=([a-f0-9]{64})(?:;|$)/);let s=match?sessions.get(match[1]):null;if(s&&s.expiresAt<now()){sessions.delete(match[1]);s=null;}if(!s){const sid=crypto.randomBytes(32).toString('hex');s={id:sid,csrf:crypto.randomBytes(32).toString('hex'),userId:null,admin:false,expiresAt:now()+8*3600000};sessions.set(sid,s);res.setHeader('Set-Cookie',`sv13=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);}return s;}
function rotateSession(s,res){sessions.delete(s.id);s.id=crypto.randomBytes(32).toString('hex');s.csrf=crypto.randomBytes(32).toString('hex');s.expiresAt=now()+8*3600000;sessions.set(s.id,s);res.setHeader('Set-Cookie',`sv13=${s.id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800`);}
function rateLimit(req,key){const k=(req.socket.remoteAddress||'local')+':'+key;let a=attempts.get(k);if(!a||a.until<now()){a={n:0,until:now()+60000};attempts.set(k,a);}if(++a.n>30)fail('Too many requests, retry later',429);}
async function body(req,max=65536){let size=0,chunks=[];for await(const c of req){size+=c.length;if(size>max)fail('Body too large',413);chunks.push(c);}return Buffer.concat(chunks);}
async function handleApi(req,res,url){const session=getSession(req,res),locale=url.searchParams.get('locale')||'en-GB';
 if(req.method==='GET'){
  if(url.pathname.startsWith('/api/media/')){const m=state.media.find(m=>m.id===url.pathname.split('/').pop()),u=state.users.find(u=>u.id===session.userId);if(!m)fail('Not found',404);const allowed=m.userId===u?.id||state.posts.some(p=>p.media?.includes(m.id)&&(visible(p,u)||(session.admin&&p.visibility!=='private')));const file=path.join(path.dirname(stateFile),'media',m.id+'.'+(m.ext||'png'));if(!allowed||!fs.existsSync(file))fail('Not found',404);mediaIO.serve(req,res,file,m.type);return;}
  if(url.pathname==='/api/state'){send(res,200,customerState(session,locale));return;}
  if(url.pathname==='/api/admin/state'){send(res,200,merchantState(session));return;}
  if(url.pathname==='/api/export'){const u=user(session);send(res,200,{user:safeUser(u),tickets:state.tickets.filter(t=>t.userId===u.id),posts:state.posts.filter(p=>p.userId===u.id),practice:state.practice.filter(p=>p.userId===u.id),orders:state.orders.filter(p=>p.userId===u.id),reports:state.reports.filter(p=>p.userId===u.id),messages:state.messages.filter(m=>m.from===u.id||m.to===u.id),media:state.media.filter(m=>m.userId===u.id)});return;}
  fail('Not found',404);
 }
 if(req.method!=='POST')fail('Method not allowed',405);
 if(url.pathname==='/api/media'){
  const u=user(session);if(!safeEqual(session.csrf,String(req.headers['x-csrf-token']||'')))fail('CSRF rejected',403);if(req.headers.origin&&![`http://127.0.0.1:${port}`,`http://localhost:${port}`].includes(req.headers.origin))fail('Origin rejected',403);
  if(state.media.filter(m=>m.userId===u.id).length>=30)fail('Media limit: 30 files');
  req.setTimeout(30000,()=>req.destroy());
  const b=await body(req,mediaIO.MAX_VIDEO),meta=mediaIO.inspect(b,req.headers['content-type']);
  if(state.media.filter(m=>m.userId===u.id).reduce((n,m)=>n+m.bytes,0)+b.length>120*1024*1024||state.media.reduce((n,m)=>n+m.bytes,0)+b.length>500*1024*1024)fail('Local media storage quota exceeded',413);
  const m={id:id(),userId:u.id,...meta,bytes:b.length,createdAt:new Date().toISOString()},folder=path.join(path.dirname(stateFile),'media');
  fs.mkdirSync(folder,{recursive:true});const file=path.join(folder,m.id+'.'+m.ext);
  try{fs.writeFileSync(file,b,{flag:'wx'});state.media.push(m);audit('media-upload');save();}catch(e){if(fs.existsSync(file))fs.unlinkSync(file);throw e;}
  send(res,200,m);return;
 }
 const raw=await body(req);
 if(url.pathname==='/api/webhooks/sandbox'){
  if(!process.env.SV_WEBHOOK_SECRET)fail('External sandbox webhook disabled',503);
  const time=req.headers['x-event-time'],signature=req.headers['x-event-signature'];if(!/^\d+$/.test(String(time))||Math.abs(now()/1000-Number(time))>300)fail('Stale signature',403);
  const expected=crypto.createHmac('sha256',process.env.SV_WEBHOOK_SECRET).update(time+'.').update(raw).digest('hex');if(!safeEqual(expected,String(signature||'')))fail('Bad signature',403);
  const e=JSON.parse(raw);text(e.id,100,1);member(e.outcome,['success','failed','cancelled']);applyPayment(e);audit('sandbox-webhook');save();send(res,200,{received:true});return;
 }
 if(req.headers.origin&&![`http://127.0.0.1:${port}`,`http://localhost:${port}`].includes(req.headers.origin))fail('Origin rejected',403);
 if(!safeEqual(session.csrf,String(req.headers['x-csrf-token']||'')))fail('CSRF rejected',403);
 if(!String(req.headers['content-type']).startsWith('application/json'))fail('JSON required',415);
 const a=JSON.parse(raw);
 if(['/api/register','/api/login','/api/admin/setup','/api/admin/login'].includes(url.pathname))rateLimit(req,'auth');
 if(url.pathname==='/api/register'){
  const nickname=text(a.nickname,40,1),handle=text(a.handle,40,3).toLowerCase();if(!/^[a-z0-9_-]+$/.test(handle)||state.users.some(u=>u.handle===handle))fail('Handle unavailable');
  if(a.agree!==true)fail('Privacy terms required');const credentials=await hashPassword(a.password);const u={id:id(),handle,nickname,bio:'',credentials,child:a.child===true,privacy:{profilePublic:false,allowFollowers:false,allowMessages:false,analytics:false,cloudPractice:false},consentVersion:'2026-10-01-v13',consentAt:new Date().toISOString(),favorites:[],following:[],blocks:[],bookmarks:[],cart:[],binding:null};state.users.push(u);session.userId=u.id;rotateSession(session,res);audit('register');save();send(res,200,customerState(session,locale));return;
 }
 if(url.pathname==='/api/login'){const u=state.users.find(u=>u.handle===String(a.handle).toLowerCase());if(!await verifyPassword(a.password,u?.credentials))fail('Invalid credentials',401);session.userId=u.id;rotateSession(session,res);send(res,200,customerState(session,locale));return;}
 if(url.pathname==='/api/logout'){session.userId=null;session.admin=false;rotateSession(session,res);send(res,200,customerState(session,locale));return;}
 if(url.pathname==='/api/admin/setup'){if(state.adminCredentials)fail('Already configured',409);state.adminCredentials=await hashPassword(a.password);session.admin=true;rotateSession(session,res);audit('admin-setup');save();send(res,200,customerState(session,locale));return;}
 if(url.pathname==='/api/admin/login'){if(!await verifyPassword(a.password,state.adminCredentials))fail('Invalid credentials',401);session.admin=true;rotateSession(session,res);send(res,200,customerState(session,locale));return;}
 if(url.pathname==='/api/action'){const deletedUser=a.type==='delete-account'?session.userId:null;const extra=await mutate(a,session);if(deletedUser){state.messages=state.messages.filter(m=>m.from!==deletedUser&&m.to!==deletedUser);state.media=state.media.filter(m=>m.userId!==deletedUser);}audit(a.type);save();purgeOrphanMedia();send(res,200,{...customerState(session,locale),result:extra});return;}
 fail('Not found',404);
}
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8','.pdf':'application/pdf'};
const server=http.createServer((req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Permissions-Policy','camera=(self), microphone=(self), geolocation=()');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
 if(![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host)){send(res,403,{error:'Host rejected'});return;}
 let url;try{url=new URL(req.url,`http://127.0.0.1:${port}`);}catch{send(res,400,{error:'Invalid URL'});return;}
 if(url.pathname.startsWith('/api/')){queue=queue.then(async()=>{try{expireOrders();}catch{send(res,500,{error:'State persistence unavailable'});return;}const before=structuredClone(state),sessionBefore=structuredClone(sessions);try{await handleApi(req,res,url);}catch(e){state=before;sessions.clear();for(const [k,v] of sessionBefore)sessions.set(k,v);if(!res.headersSent)send(res,e.status||400,{error:e.message});else res.end();}});return;}
 if(req.method!=='GET'){send(res,405,{error:'Method not allowed'});return;}
 try{const f=path.resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/client.html':url.pathname));if(!f.startsWith(root+path.sep)||!types[path.extname(f)]||!fs.existsSync(f)||!fs.statSync(f).isFile())fail('Not found',404);res.writeHead(200,{'Content-Type':types[path.extname(f)]});fs.createReadStream(f).pipe(res);}catch(e){send(res,e.status||400,{error:e.message});}
});
server.on('error',e=>{if(e.code==='EADDRINUSE'&&port<8910){port++;server.listen(port,'127.0.0.1');}else{console.error(e);process.exit(1);}});
server.listen(port,'127.0.0.1',()=>{port=server.address().port;const info={url:`http://127.0.0.1:${port}/client.html`,admin:`http://127.0.0.1:${port}/admin.html`,pid:process.pid};console.log(JSON.stringify(info));if(process.env.SV_READY_FILE)fs.writeFileSync(process.env.SV_READY_FILE,JSON.stringify(info));});
