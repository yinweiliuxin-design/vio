V16 local sandbox (storage schema remains 13)

Start: PowerShell ./start-demo.ps1
Alternative: Node.js 22 or newer, `node server.cjs`
Default: http://127.0.0.1:8894/client.html and /admin.html
If occupied the server selects the next port, up to 8910. Read the printed URL.
No npm install is needed to RUN this package. Browser libraries are vendored.
Create a customer account. The merchant page asks you to set a password on first use.
Use test identities and addresses only. All prices and payments are test fixtures.
Only binds to 127.0.0.1. This is NOT an internet deployment.
Do not expose the service with a proxy or tunnel.

Persistence: app/.state/state.json and app/.state/media/
Sessions are in memory and require login after restart.
Original seeds contain no user accounts, passwords or merchant secrets.
Do not distribute .state or .env files. The delivery ZIP excludes them.
To reset a demo, stop its process and move its .state directory to your own backup
location. Do not perform this on a live user service. Backups can contain personal data.

Tests: `node tests/api.cjs` (Node built-ins only, uses a fresh temporary directory).
Browser evidence and the original test source are under ../verification/.
The browser harness there records this host's runtime path; it is evidence, not a
portable install script. The API smoke test here is portable.
For rebuilding vendored libraries: pnpm install --ignore-scripts --frozen-lockfile.
Pin versions in package.json / pnpm-lock.yaml. No cloud SDK or payment SDK is active.

Optional signed sandbox webhook:
Set SV_WEBHOOK_SECRET only in the environment. Never put a real production key here.
Read ../docs/payment-contract.json for the canonical payload and signature.
Without the environment variable, external sandbox callbacks return 503.
No payment-provider account is configured. sandbox-pay is intentionally a simulation.

Production blockers: database transactions, identity and MFA, HTTPS, secure cookies,
password recovery, abuse prevention, file safety, deletion/retention jobs, chosen
payment provider, taxes/shipping, legal entities, mobile builds and device integration.
Do not bypass those blockers by renaming this directory to production.
