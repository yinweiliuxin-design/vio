"""Verify the integrity of this engineering handoff, not hardware approval."""
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _validate(root):
    manifest = json.loads((root / 'HANDOFF-MANIFEST.json').read_text(encoding='utf-8'))
    errors = []
    for entry in manifest['files']:
        path = (root / entry['path']).resolve()
        if not path.is_relative_to(root.resolve()):
            errors.append('PATH_ESCAPE:' + entry['path'])
        elif not path.is_file():
            errors.append('MISSING:' + entry['path'])
        elif sha(path) != entry['sha256']:
            errors.append('HASH_MISMATCH:' + entry['path'])
    source = root / 'electrical/native-components.json'
    if sha(source) != manifest['sourceSha256']:
        errors.append('SOURCE_MISMATCH')
    parts = json.loads(source.read_text(encoding='utf-8'))
    refs = [c['ref'] for c in parts]
    if len(set(refs)) != len(refs):
        errors.append('DUPLICATE_REFERENCE')
    for c in parts:
        numbers = [str(p['number']) for p in c['pins']]
        if len(set(numbers)) != len(numbers):
            errors.append('DUPLICATE_PIN:' + c['ref'])
    summary = json.loads((root / 'verification/release-summary-v26.json').read_text(encoding='utf-8'))
    if summary.get('sourceSha256') != manifest['sourceSha256']:
        errors.append('SUMMARY_SOURCE_MISMATCH')
    for name in ['electrical-check-v26.json', 'capture-summary.json', 'legacy-287-tracking.json']:
        evidence = json.loads((root / 'verification' / name).read_text(encoding='utf-8'))
        if evidence.get('sourceSha256') != manifest['sourceSha256']:
            errors.append('EVIDENCE_SOURCE_MISMATCH:' + name)
    board_summary = json.loads((root / 'verification/pcb-final-v26/summary.json').read_text(encoding='utf-8'))
    for board in board_summary['boards']:
        board_path = root / board['boardPath']
        if sha(board_path) != board['boardSha256']:
            errors.append('BOARD_EVIDENCE_MISMATCH:' + board['board'])
        report = json.loads((root / board['drcPath']).read_text(encoding='utf-8'))
        if report['source'] != board_path.name:
            errors.append('DRC_SOURCE_MISMATCH:' + board['board'])
        counts = [sum(v['severity'] == severity for v in report['violations']) for severity in ['error', 'warning']]
        if counts != [board['errors'], board['warnings']] or len(report['unconnected_items']) != board['unconnected']:
            errors.append('DRC_COUNTS_MISMATCH:' + board['board'])
    for path in (root / 'pcb-work/cam-review-v26-current').glob('*/CAM-manifest.json'):
        cam = json.loads(path.read_text(encoding='utf-8'))
        if cam['sourceSHA256'] != manifest['sourceSha256']:
            errors.append('CAM_SOURCE_MISMATCH:' + cam['kind'])
        if sha(root / cam['boardRelativePackPath']) != cam['boardSHA256']:
            errors.append('CAM_BOARD_MISMATCH:' + cam['kind'])
        if sha(root / 'pcb-work/verification/current-native-parity.json') != cam['paritySHA256']:
            errors.append('CAM_PARITY_MISMATCH:' + cam['kind'])
        for item in cam['CAM']:
            if sha(root / item['relativePackPath']) != item['sha256']:
                errors.append('CAM_FILE_MISMATCH:' + item['relativePackPath'])
    current = set(e['path'] for e in manifest['files'])
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()
              and p.name != 'HANDOFF-MANIFEST.json'}
    errors.extend('UNMANIFESTED:' + x for x in sorted(actual - current))
    blockers = content_bindings(root, manifest, parts, summary, errors)
    return {'integrity': 'PASS' if not errors else 'FAIL', 'errors': errors,
            'sourceSha256': manifest['sourceSha256'], 'filesChecked': len(manifest['files']),
            'components': len(parts), 'pins': sum(len(c['pins']) for c in parts),
            'manufactureRelease': not errors and not blockers,
            'declaredManufactureRelease': summary.get('manufactureRelease') is True,
            'productionBlockers': blockers,
            'physicalTests': summary.get('physicalTests', 0),
            'scope': 'Hash and revision integrity only; neither ERC nor hash validation approves production.'}


KINDS = {'main', 'usb', 'audio', 'cover', 'sensor'}
PARITY_FIELDS = ('pinNetDifferences', 'candidateHarnessDifferences', 'valueDifferences',
                 'mpnDifferences', 'pinFunctionDifferences', 'padSetDifferences', 'footprintIdDifferences')


def sexpr(text):
    # Parse KiCad atoms/strings without requiring a copied SDK or parser package.
    stack, root = [], []
    for token in re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+', text):
        if token == '(':
            node = []
            (stack[-1] if stack else root).append(node)
            stack.append(node)
        elif token == ')':
            if not stack:
                raise ValueError('Unbalanced KiCad expression')
            stack.pop()
        else:
            if not stack:
                raise ValueError('Atom outside KiCad expression')
            stack[-1].append(json.loads(token) if token.startswith('"') else token)
    if stack or len(root) != 1:
        raise ValueError('Unbalanced KiCad expression')
    return root[0]


def children(node, key):
    return [x for x in node if isinstance(x, list) and x and x[0] == key]


def content_bindings(root, manifest, parts, summary, errors):
    root = root.resolve()
    blockers = []

    def require(condition, code):
        if not condition:
            errors.append(code)

    def path(value, metadata=False):
        value = str(value).replace('\\', '/')
        marker = '/outputs/SmartVio-V26-Engineering/'
        if metadata and marker in value:
            value = value.split(marker, 1)[1]
        p = (root / value).resolve()
        if re.match(r'^[A-Za-z]:', value) or not p.is_relative_to(root):
            raise ValueError('PATH_ESCAPE:' + value)
        return p

    def read(value):
        return json.loads(path(value).read_text(encoding='utf-8-sig'))

    def bind(value, digest, code, metadata=False):
        p = path(value, metadata)
        require(p.is_file() and isinstance(digest, str) and sha(p) == digest.lower(), code)
        return p.relative_to(root).as_posix()

    def records(rows, code):
        require(isinstance(rows, list) and bool(rows), code + ':EMPTY')
        result = {}
        for row in rows:
            value = row.get('relativePackPath', row.get('path', row.get('Path')))
            key = bind(value, row.get('sha256', row.get('Hash')), code + ':' + str(value), True)
            require(key not in result, code + ':DUPLICATE:' + key)
            result[key] = str(row.get('sha256', row.get('Hash'))).lower()
        return result

    source_hash = sha(path('electrical/native-components.json'))
    electrical = read('verification/electrical-check-v26.json')
    mapping = read('electrical/footprint-map.json')
    sync = read('verification/capture-map-sync-v26.json')
    require(sync['sourceSha256'].lower() == source_hash, 'FOOTPRINT_EVIDENCE_SOURCE_MISMATCH')
    bind('electrical/footprint-map.json', sync['mapSha256'], 'FOOTPRINT_MAP_HASH_MISMATCH')
    require(sync['sourceComponentCount'] == len(parts), 'FOOTPRINT_SOURCE_COUNT_MISMATCH')
    files = [e['path'] for e in manifest['files']]
    for part in parts:
        require(part['ref'] in mapping, 'FOOTPRINT_REFERENCE_MISSING:' + part['ref'])
        for e in mapping.get(part['ref'], {}).get('source', []):
            if not isinstance(e, dict) or 'sha256' not in e or 'path' not in e:
                continue
            suffix = e['path'].replace('\\', '/')
            candidates = [p for p in files if p == suffix or p.endswith('/' + suffix)]
            require(bool(candidates), 'FOOTPRINT_SOURCE_MISSING:' + suffix)
            for p in candidates:
                bind(p, e['sha256'], 'FOOTPRINT_SOURCE_HASH_MISMATCH:' + p)
    netlist = ET.parse(path('verification/native-netlist.xml'))
    exported = {x.get('ref'): x for x in netlist.findall('./components/comp')}
    require(set(exported) == {p['ref'] for p in parts}, 'NETLIST_REFERENCE_MISMATCH')
    expected = {}
    for part in parts:
        for pin in part['pins']:
            if pin.get('net'):
                expected.setdefault(pin['net'], set()).add((part['ref'], str(pin['number'])))
        x = exported.get(part['ref'])
        if x is not None:
            require(x.findtext('footprint', '') == (mapping.get(part['ref'], {}).get('id') or ''),
                    'NETLIST_FOOTPRINT_MISMATCH:' + part['ref'])
            require(x.findtext('value', '') == part['value'], 'NETLIST_VALUE_MISMATCH:' + part['ref'])
    nets = {}
    for n in netlist.findall('./nets/net'):
        if not n.get('name', '').startswith('unconnected-'):
            nodes = {(v.get('ref'), v.get('pin')) for v in n.findall('node') if not v.get('ref', '').startswith('#')}
            if nodes:
                nets[n.get('name')] = nodes
    require(nets == expected, 'NETLIST_PIN_NET_MISMATCH')
    eda_refs = {}
    for p in sorted(path('eda').glob('*.kicad_sch')):
        tree = sexpr(p.read_text(encoding='utf-8-sig'))
        for symbol in children(tree, 'symbol'):
            props = {x[1]: x[2] for x in children(symbol, 'property')}
            ref = props.get('Reference', '')
            if ref.startswith('#'):
                continue
            require(ref not in eda_refs, 'EDA_DUPLICATE_REFERENCE:' + ref)
            eda_refs[ref] = props
    require(set(eda_refs) == {p['ref'] for p in parts}, 'EDA_REFERENCE_MISMATCH')
    for part in parts:
        props = eda_refs.get(part['ref'], {})
        require(props.get('Value') == part['value'], 'EDA_VALUE_MISMATCH:' + part['ref'])
        require(props.get('Footprint', '') == (mapping.get(part['ref'], {}).get('id') or ''),
                'EDA_FOOTPRINT_MISMATCH:' + part['ref'])
    erc = read('verification/erc.json')
    require(erc['source'] == 'SmartVio.kicad_sch', 'ERC_SOURCE_MISMATCH')
    count = sum(len(s['violations']) for s in erc['sheets'])
    require(count == electrical['ercViolations'], 'ERC_COUNTS_MISMATCH')
    require(electrical['components'] == len(parts) and electrical['pins'] == sum(len(p['pins']) for p in parts)
            and electrical['footprintFieldsChecked'] == len(parts), 'ELECTRICAL_COUNTS_MISMATCH')
    if count or electrical.get('pass') is not True:
        blockers.append('ERC_OR_LOGICAL_REVIEW_OPEN')

    snapshot = read('verification/pcb-final-v26/summary.json')
    current = read('pcb-work/v26-final-summary.json')
    parity = read('pcb-work/verification/current-native-parity.json')
    for name, e, key in (('SNAPSHOT', snapshot, 'sourceSha256'), ('CURRENT', current, 'sourceSHA256'),
                         ('PARITY', parity, 'sourceSHA256')):
        require(e[key].lower() == source_hash, name + '_SOURCE_MISMATCH')
    bind('pcb-work/footprint-map.json', current['footprintMapSHA256'], 'CURRENT_MAP_HASH_MISMATCH')
    require(read('pcb-work/footprint-map.json') == mapping, 'PCB_CAPTURE_MAP_MISMATCH')
    bind('pcb-work/verification/current-native-parity.json', current['currentNativeParitySHA256'], 'CURRENT_PARITY_HASH_MISMATCH')
    bind('verification/native-netlist.xml', parity['currentNativeExportSHA256'], 'PARITY_EXPORT_HASH_MISMATCH')
    require(not parity['sourceExportPinNetDifferences'] and not parity['sourceExportReferenceDifferences'], 'PARITY_SOURCE_DIFFERENCES')
    boards = {b['board']: b for b in snapshot['boards']}
    cb = {b['kind']: b for b in current['boards']}
    pb = {b['kind']: b for b in parity['boards']}
    for label, rows, index in (('SNAPSHOT', snapshot['boards'], boards), ('CURRENT', current['boards'], cb), ('PARITY', parity['boards'], pb)):
        require(set(index) == KINDS and len(rows) == 5, label + '_BOARD_SET_MISMATCH')
    counts_by_kind = {}
    for kind, b in boards.items():
        board_path = path(b['boardPath'])
        require(b['sourceSha256'].lower() == source_hash, 'BOARD_SOURCE_MISMATCH:' + kind)
        require(cb[kind]['boardSHA256'].lower() == pb[kind]['boardSHA256'].lower() == sha(board_path), 'BOARD_PARITY_HASH_MISMATCH:' + kind)
        require(path(cb[kind].get('relativePackPath', cb[kind]['boardPath']), True) == board_path and
                path(pb[kind]['boardPath'], True) == board_path, 'BOARD_PATH_MISMATCH:' + kind)
        require(cb[kind]['parity'] == pb[kind], 'CURRENT_BOARD_PARITY_MISMATCH:' + kind)
        for field in PARITY_FIELDS:
            require(not pb[kind][field], 'BOARD_PARITY_DIFFERENCES:' + kind + ':' + field)
        require(pb[kind]['footprintFilesResolvable'] is True, 'BOARD_FOOTPRINT_UNRESOLVED:' + kind)
        records(cb[kind]['nativeFiles'], 'NATIVE_FILE_HASH_MISMATCH:' + kind)
        dc = cb[kind]['drc']
        require(path(dc['relativePackPath']) == path(b['drcPath']), 'DRC_PATH_MISMATCH:' + kind)
        bind(b['drcPath'], dc['reportSHA256'], 'DRC_HASH_MISMATCH:' + kind)
        report = read(b['drcPath'])
        counts = [sum(v['severity'] == s for v in report['violations']) for s in ('error', 'warning')]
        counts.append(len(report['unconnected_items']))
        require(counts == [dc['errors'], dc['warnings'], dc.get('unconnected', dc.get('unconnectedErrors'))], 'CURRENT_DRC_COUNTS_MISMATCH:' + kind)
        counts_by_kind[kind] = counts
        if any(counts):
            blockers.append('DRC_NOT_CLOSED:' + kind)
        if report.get('ignored_checks') or b.get('projectIgnoredCategories') or b.get('projectExclusionCount'):
            blockers.append('DRC_RULES_EXCLUDED:' + kind)
    cams = sorted(path('pcb-work/cam-review-v26-current').glob('*/CAM-manifest.json'))
    require({p.parent.name for p in cams} == KINDS - {'main'} and len(cams) == 4, 'CAM_BOARD_SET_MISMATCH')
    for p in cams:
        cam = read(p.relative_to(root))
        kind = cam['kind']
        require(kind == p.parent.name and kind != 'main', 'CAM_KIND_MISMATCH:' + kind)
        b = boards[kind]
        require(not any(counts_by_kind[kind]) and not read(b['drcPath'])['violations'], 'CAM_DRC_NOT_ZERO:' + kind)
        require(path(cam['boardRelativePackPath']) == path(b['boardPath']), 'CAM_BOARD_PATH_MISMATCH:' + kind)
        bind(b['drcPath'], cam['nativeDRCSHA256'], 'CAM_DRC_HASH_MISMATCH:' + kind)
        drc_value = cam.get('nativeDRCRelativePackPath') or cam['nativeDRCPath']
        require(path(drc_value, True) == path(b['drcPath']), 'CAM_DRC_PATH_MISMATCH:' + kind)

    build = read('firmware/verification/build-status.json')
    completion = read('firmware/verification/f01-f02-completion.json')
    parent = read('verification/parent-host-rerun-v26.json')
    for name, e, key in (('BUILD', build, 'nativeSourceSha256'), ('SAFETY', completion, 'nativeSourceSha256'), ('PARENT', parent, 'sourceSha256')):
        require(e[key].lower() == source_hash, name + '_SOURCE_MISMATCH')
    delivered = records(build['deliveredArtifacts'], 'TARGET_ARTIFACT_HASH_MISMATCH')
    safety_artifacts = records(completion['artifacts'], 'SAFETY_ARTIFACT_HASH_MISMATCH')
    safety_inputs = records(completion['inputSafetySourceHashes'], 'SAFETY_INPUT_HASH_MISMATCH')
    rerun = records(parent['artifactChecks'], 'PARENT_ACTUALHASH_MISMATCH')
    required = {'firmware/build/smartvio-h743-DIAG.' + ext for ext in ('bin', 'elf', 'hex', 'map')}
    required |= {'firmware/build/esp32/' + p for p in ('smartvio_rf_diag.elf', 'smartvio_rf_diag.bin', 'smartvio_rf_diag.map',
                 'bootloader/bootloader.bin', 'partition_table/partition-table.bin', 'flash_args', 'flasher_args.json')}
    require(required <= delivered.keys(), 'TARGET_ARTIFACT_SET_INCOMPLETE')
    require(delivered == safety_artifacts, 'SAFETY_TARGET_ARTIFACT_SET_MISMATCH')
    require(all(rerun.get(p) == h for p, h in {**delivered, **safety_inputs}.items()), 'PARENT_TARGET_SAFETY_BINDING_MISMATCH')
    bind('firmware/stm32/main.c', completion['mainSourceSha256'], 'SAFETY_MAIN_HASH_MISMATCH')
    require('firmware/stm32/main.c' in safety_inputs, 'SAFETY_MAIN_RECORD_MISSING')
    for name, key in (('build-inputs.json', 'armBuildInputsSha256'), ('esp-native-build.json', 'espBuildInputsSha256')):
        bind('firmware/verification/' + name, build[key], 'BUILD_INPUT_MANIFEST_HASH_MISMATCH:' + name)
        evidence = read('firmware/verification/' + name)
        # Check current delivered inputs; external SDK provenance is not a package payload.
        local = [r for r in evidence['inputs'] if '/outputs/SmartVio-V26-Engineering/' in str(r['Path']).replace('\\', '/')
                 or str(r['Path']).replace('\\', '/').startswith('firmware/')]
        records(local, 'BUILD_SOURCE_HASH_MISMATCH:' + name)
    results = parent['results']
    require(parent['suiteCount'] == len(results) == 9 and len({r['program'] for r in results}) == 9 and
            all(r['exitCode'] == 0 and r['result'].get('failed', 0) == 0 for r in results) and
            parent['allNineHostProgramsPass'] is True and parent['currentTargetAndSafetyInputHashesPass'] is True, 'PARENT_RERUN_NOT_PASS')
    for r in results:
        bind('firmware/build/' + r['program'], r['sha256'], 'PARENT_PROGRAM_HASH_MISMATCH:' + r['program'])
    findings = read('audit/pin-closure-v26/findings.json')
    selected = [f for f in findings if f['id'] in ('F01', 'F02')]
    require({f['id'] for f in selected} == {'F01', 'F02'} and len(selected) == 2, 'SAFETY_FINDINGS_INCOMPLETE')
    for f in selected:
        require(f['current_source_sha256'].lower() == source_hash and f['current_firmware_main_sha256'].lower() ==
                completion['mainSourceSha256'].lower() and f['statement'] == completion[f['id']], 'SAFETY_FINDING_BINDING_MISMATCH:' + f['id'])
        for key, expected_path in (('completion_evidence', 'firmware/verification/f01-f02-completion.json'),
                                   ('independent_parent_rerun', 'verification/parent-host-rerun-v26.json')):
            e = f[key]
            require(e['relativePath'] == expected_path, 'SAFETY_FINDING_PATH_MISMATCH:' + f['id'])
            bind(e['relativePath'], e['sha256'], 'SAFETY_FINDING_HASH_MISMATCH:' + f['id'])
    status = read('audit/pin-closure-v26/status.json')
    require(status['source_sha256'].lower() == source_hash, 'APPLICATION_SOURCE_MISMATCH')
    if status.get('not_closed_baseline_pins', 1) or status.get('normal_charging_authorized') is not True:
        blockers.append('APPLICATION_OR_CHARGE_REVIEW_OPEN')
    if build.get('normalCharging') != 'ENABLED_QUALIFIED' or completion.get('normalCharging') != 'ENABLED_QUALIFIED':
        blockers.append('NORMAL_CHARGING_DISABLED_OR_UNQUALIFIED')
    if build.get('remainingBlockers') or build.get('productionFreezePermitted') is not True:
        blockers.append('FIRMWARE_PRODUCTION_FREEZE_BLOCKED')
    if summary.get('issues') or not read('verification/legacy-287-tracking.json').get('all287FullyClosed'):
        blockers.append('SYSTEM_APPLICATION_REVIEW_OPEN')
    if not summary.get('physicalTests'):
        blockers.append('PHYSICAL_QUALIFICATION_NOT_EVIDENCED')
    if manifest.get('manufactureRelease') is not True or summary.get('manufactureRelease') is not True:
        blockers.append('PRODUCTION_RELEASE_NOT_DECLARED')
    return blockers


def validate(root):
    try:
        return _validate(Path(root))
    except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError, ET.ParseError) as exc:
        return {'integrity': 'FAIL', 'errors': ['INVALID_OR_MISSING_EVIDENCE:' + str(exc)],
                'manufactureRelease': False, 'productionBlockers': ['EVIDENCE_INVALID'],
                'scope': 'Content integrity only; no production or hardware approval.'}


def exit_code(result, require_production=False):
    return 1 if result['integrity'] != 'PASS' else 2 if require_production and not result['manufactureRelease'] else 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--require-production-release', action='store_true')
    args = parser.parse_args()
    result = validate(args.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(exit_code(result, args.require_production_release))
