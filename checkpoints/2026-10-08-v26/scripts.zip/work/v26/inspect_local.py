import json
from pathlib import Path
import pcbnew as p

ROOT = Path(__file__).resolve().parents[2] / 'outputs/SmartVio-V26-Engineering/pcb-work'
rows = {}
for name in ['usb', 'audio']:
    b = p.LoadBoard(str(ROOT / f'SmartVio-{name}-v26-final.kicad_pcb'))
    tracks = []
    for t in b.GetTracks():
        if name == 'usb' and t.GetNetname() != 'VBUS_RAW':
            continue
        if name == 'audio' and t.GetNetname() != 'GND':
            continue
        tracks.append({'uuid': t.m_Uuid.AsString(), 'net': t.GetNetname(), 'layer': b.GetLayerName(t.GetLayer()),
                       'start': [p.ToMM(t.GetStart().x), p.ToMM(t.GetStart().y)],
                       'end': [p.ToMM(t.GetEnd().x), p.ToMM(t.GetEnd().y)],
                       'width': p.ToMM(t.GetWidth(t.GetLayer())) if isinstance(t, p.PCB_VIA) else p.ToMM(t.GetWidth()),
                       'via': isinstance(t, p.PCB_VIA)})
    pads = [{'ref': f.GetReference(), 'pin': pad.GetNumber(), 'net': pad.GetNetname(),
             'xy': [p.ToMM(pad.GetPosition().x), p.ToMM(pad.GetPosition().y)],
             'size': [p.ToMM(pad.GetSize().x), p.ToMM(pad.GetSize().y)]}
            for f in b.GetFootprints() for pad in f.Pads() if pad.GetNetname() in (['VBUS_RAW'] if name == 'usb' else ['GND'])]
    zones = []
    for z in b.Zones():
        if z.GetIsRuleArea():
            continue
        layer = z.GetLayer()
        polys = z.GetFilledPolysList(layer)
        outlines = []
        for i in range(polys.OutlineCount()):
            line = polys.Outline(i)
            pts = [[p.ToMM(line.CPoint(j).x), p.ToMM(line.CPoint(j).y)] for j in range(line.PointCount())]
            outlines.append({'points': pts, 'area': line.Area() / 1e12})
        zones.append({'uuid': z.m_Uuid.AsString(), 'layer': b.GetLayerName(layer), 'net': z.GetNetname(),
                      'islandMode': int(z.GetIslandRemovalMode()), 'outlines': outlines})
    rows[name] = {'tracks': tracks, 'pads': pads, 'zones': zones}
path = ROOT / 'verification/parent-local-geometry-before.json'
path.write_text(json.dumps(rows, indent=2), encoding='utf-8')
print(json.dumps({name: {'tracks': rows[name]['tracks'], 'pads': rows[name]['pads'],
                        'zoneSizes': [{'layer': z['layer'], 'areas': [o['area'] for o in z['outlines']]} for z in rows[name]['zones']]}
                  for name in rows}, indent=2))
