"""Inspect actual critical-pad placement and rail copper without inferring hardware approval."""
import argparse
import hashlib
import html
import json
import math
import os
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
WORK = BASE / 'work/v26/pcb'
for name, folder in [('KICAD_CONFIG_HOME','config'), ('KICAD_DOCUMENTS_HOME','documents'), ('DOCUMENTS_HOME','documents')]:
    os.environ[name] = str(WORK / folder)
import pcbnew as p

ap = argparse.ArgumentParser()
ap.add_argument('--board', type=Path, default=ROOT / 'pcb-work/SmartVio-main-v26-final.kicad_pcb')
a = ap.parse_args()
assert a.board.resolve().is_relative_to((ROOT / 'pcb-work').resolve())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
xy = lambda v: [round(p.ToMM(v.x),6), round(p.ToMM(v.y),6)]
b = p.LoadBoard(str(a.board.resolve()))
fps = {f.GetReference():f for f in b.GetFootprints()}
checks = [
    ('U501','13','C501','1','charger input','https://www.ti.com/lit/ds/symlink/bq24074.pdf','12.1'),
    ('U501','10','C502','1','charger output','https://www.ti.com/lit/ds/symlink/bq24074.pdf','12.1'),
    ('U501','2','C503','1','battery bypass','https://www.ti.com/lit/ds/symlink/bq24074.pdf','12.1'),
    ('U1101','12','C1102','1','buck-boost input bulk','https://www.ti.com/lit/ds/symlink/tps63070.pdf','11.1'),
    ('U1101','12','C1103','1','buck-boost input HF','https://www.ti.com/lit/ds/symlink/tps63070.pdf','11.1'),
    ('U1101','7','C1104','1','buck-boost output bulk','https://www.ti.com/lit/ds/symlink/tps63070.pdf','11.1'),
    ('U1101','8','C1105','1','buck-boost output bulk2','https://www.ti.com/lit/ds/symlink/tps63070.pdf','11.1'),
    ('U1101','3','C1101','1','VAUX bypass','https://www.ti.com/lit/ds/symlink/tps63070.pdf','11.1'),
    ('U1101','11','L1101','1','L1 switching path','https://www.ti.com/lit/ds/symlink/tps63070.pdf','11.1'),
    ('U1101','9','L1101','2','L2 switching path','https://www.ti.com/lit/ds/symlink/tps63070.pdf','11.1'),
    ('U601','6','C601','1','ADC VREF','https://www.ti.com/lit/ds/symlink/pcm1864.pdf','12.1'),
    ('U601','11','C602','1','ADC internal LDO HF','https://www.ti.com/lit/ds/symlink/pcm1864.pdf','12.1'),
    ('U601','11','C603','1','ADC internal LDO bulk','https://www.ti.com/lit/ds/symlink/pcm1864.pdf','12.1'),
    ('U601','8','C604','1','ADC analog supply HF','https://www.ti.com/lit/ds/symlink/pcm1864.pdf','12.1'),
]
entries = []
for r1,n1,r2,n2,role,url,section in checks:
    d1 = [d for d in fps[r1].Pads() if d.GetNumber()==n1]
    d2 = [d for d in fps[r2].Pads() if d.GetNumber()==n2]
    first, second = min(((u,v) for u in d1 for v in d2), key=lambda q:math.dist(xy(q[0].GetPosition()),xy(q[1].GetPosition())))
    assert first.GetNetname() == second.GetNetname(), (r1,n1,r2,n2)
    distance = math.dist(xy(first.GetPosition()),xy(second.GetPosition()))
    same = fps[r1].IsFlipped()==fps[r2].IsFlipped()
    flags = []
    if not same:
        flags.append('OPPOSITE_SURFACE_LOCAL_DECOUPLING_REVIEW_REQUIRED')
    if distance > 3:
        flags.append('LONGER_THAN_INTERNAL_3MM_SCREENING_TRIGGER_NOT_MANUFACTURER_NUMERIC_LIMIT')
    entries.append({'role':role,'fromRef':r1,'fromPin':n1,'toRef':r2,'toPin':n2,
                    'fromXYMm':xy(first.GetPosition()),'toXYMm':xy(second.GetPosition()),
                    'net':first.GetNetname(),'padCenterDistanceMm':round(distance,6),
                    'sameComponentSurface':same,'findings':flags,'source':url,'section':section,
                    'distanceIsNotActualTraceLength':True,'applicationApproved':False})

segments = [t for t in b.GetTracks() if not isinstance(t,p.PCB_VIA)]
# Screening allocations are not measured maxima or a substitute for IPC-2152/thermal qualification.
budgets = {'PACK_PLUS':1.137381,'SYS':1.137381,'V3D':.65,'V3LOAD':.45,'V3A':.08,'USB_5V_SAFE':.393}
rail = []
for net,current in budgets.items():
    ts = [t for t in segments if t.GetNetname()==net]
    details = []
    for t in ts:
        width = p.ToMM(t.GetWidth());length = t.GetLength()/1e6
        internal = t.GetLayer() not in [p.F_Cu,p.B_Cu]
        area_mil2 = width/.0254 * .035/.0254
        temp = (current / ((.024 if internal else .048) * area_mil2**.725))**(1/.44)
        resistance = 1.724e-8 * (1+.00393*(85-20)) * (length/1000) / ((width/1000)*.000035)
        details.append({'uuid':str(t.m_Uuid.AsString()),'layer':p.LayerName(t.GetLayer()),
                        'widthMm':round(width,6),'lengthMm':round(length,6),
                        'screenedSingleSegmentDeltaTC':round(temp,4),
                        'resistanceAt85Cohm':round(resistance,6),'dropAtAllocationV':round(current*resistance,6)})
    rail.append({'net':net,'screeningAllocationA':current,'copperThicknessAssumedUm':35,
                 'traceWidthsMm':sorted({q['widthMm'] for q in details}),
                 'segmentsExceeding10CScreening':sum(q['screenedSingleSegmentDeltaTC']>10 for q in details),
                 'segments':details,'powerPathApproved':False,
                 'scope':'IPC-2221 legacy isolated-segment screening only, not validated temperature; no summation over branched rails.'})
report = {'sourceSHA256':sha(ROOT/'electrical/native-components.json'),'boardSHA256':sha(a.board),
          'boardRelativePath':a.board.resolve().relative_to(ROOT).as_posix(),'criticalConnections':entries,
          'oppositeSurfaceCount':sum(not r['sameComponentSurface'] for r in entries),
          'padDistanceScreeningCount':sum(r['padCenterDistanceMm']>3 for r in entries),
          'rails':rail,'threeMmIsProjectScreeningNotManufacturerLimit':True,
          'requiredReview':['Direct short same-surface power/ground loops, not only airwire distance.',
                            'Wide power trunks and brief reviewed pin necks; vias and temperature must be sized separately.',
                            'Quiet analog return, clock/USB/RF reference continuity and actual copper crossings.',
                            'Manufacturer effective capacitance, ESR, ripple, stability and real component placement.'],
          'physicalTests':0,'productionApproved':False}
out = ROOT/'audit/system-v26'
(out/'critical-layout-review.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
rows = ''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in
                [r['role'],r['fromRef']+'.'+r['fromPin'],r['toRef']+'.'+r['toPin'],r['net'],r['padCenterDistanceMm'],r['sameComponentSurface']])+'</tr>' for r in entries)
(out/'critical-layout-review.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Actual critical PCB layout review</title><style>body{font:14px Arial;margin:24px;max-width:1100px;color:#222}table{border-collapse:collapse}td,th{padding:8px;border:1px solid #bbb}.scroll{overflow:auto}p{overflow-wrap:anywhere}</style><h1>Actual critical PCB layout review</h1><p>Engineering review only. Distances are native pad centers, not trace lengths. 3 mm is an internal screening trigger, not a TI numeric limit. No hardware test or thermal approval.</p><p>'+html.escape(report['boardRelativePath'])+'<br>'+report['boardSHA256']+'</p><div class="scroll"><table><tr><th>Role<th>From<th>To<th>Net<th>Distance mm<th>Same surface</tr>'+rows+'</table></div><p><a href="critical-layout-review.json">Full rail screening and trace UUIDs</a></p></html>',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['boardSHA256','oppositeSurfaceCount','padDistanceScreeningCount','physicalTests','productionApproved']}))
