"""Current-revision engineering portal with explicit provenance and release gates."""
import hashlib
import html
import json
from pathlib import Path
from urllib.parse import quote

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
escape = html.escape


def read(path, default=None):
    file = ROOT / path
    return json.loads(file.read_text(encoding='utf-8-sig')) if file.exists() else default


def table(headers, rows):
    return '<div class="scroll"><table><thead><tr>' + ''.join('<th>'+escape(str(x))+'</th>' for x in headers) + '</tr></thead><tbody>' + ''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows) + '</tbody></table></div>'


def link(path, label):
    if not (ROOT / path).exists():
        return '<span>'+escape(label)+'：尚无本版文件</span>'
    return '<a href="'+quote(path.replace('\\','/'), safe='/')+'">'+escape(label)+'</a>'


electrical = read('verification/electrical-check-v26.json', {})
passive = read('audit/passive-closure/verification.json', {})
budget = read('audit/system-v26/power-and-stack-budget.json', {})
firmware = read('firmware/verification/v26-implementation-status.json', {})
build = read('firmware/verification/build-status.json', {})
esp = read('firmware/verification/esp-native-build.json', {})
board = read('pcb-work/v26-final-summary.json', read('pcb-work/board-progress.json', {}))
pcb_independent = read('verification/pcb-final-v26/summary.json', {})
pin_review = read('audit/pin-closure-v26/status.json', {})
pack_revision = read('audit/system-v26/battery-revision-merge.json', {})
pack_proposal = read('audit/selection/battery-revision/proposal.json', {})
host = read('verification/parent-host-rerun-v26.json', {})
safety = read('firmware/verification/f01-f02-completion.json', {})
source_hash = hashlib.sha256((ROOT / 'electrical/native-components.json').read_bytes()).hexdigest()
parts = read('electrical/native-components.json', [])
links = [
    ('eda/SmartVio.kicad_pro','原生 KiCad 工程'), ('eda/SmartVio.kicad_sch','原生原理图'),
    ('drawings/SmartVio-V26-Schematic-REVIEW.pdf','24页原理图审阅PDF（非工厂放行）'),
    ('verification/electrical-check-v26.json','本版ERC、网表及错误注入'),
    ('verification/mcu-physical-package-check.json','STM32全部100个物理脚号独立核对'),
    ('verification/legacy-287-tracking.json','原287待核对项逐项追踪'),
    ('audit/pin-closure-v26/report.html','原阶段287脚应用复核；F01/F02更新见本轮软件修复记录'),
    ('audit/pin-closure-v26/findings.json','逐脚审核发现与修复追踪'),
    ('audit/system-v26/application-profiles.json','1081脚供电、信号、默认与故障台账'),
    ('audit/system-v26/power-and-stack-budget.json','供电、电流、NTC与堆叠预算'),
    ('audit/system-v26/critical-layout-review.html','实际电源/音频关键回路距离、层面及铜宽审阅'),
    ('audit/power-closure-v26/HANDOFF.txt','充电与紧凑电容整改提案，尚未纳入主板'),
    ('audit/power-closure-v26/guarded-eco-proposals.json','两套充电ECO：准确料号、引脚变更及合并守卫'),
    ('audit/power-closure-v26/compact-ceff-proposals.json','10个关键位置紧凑电容比较，VCAP保持HOLD'),
    ('audit/power-closure-v26/same-corner-pack-budget.json','同工况电流角点与电源路径敏感性计算'),
    ('audit/system-v26/parent-power-review.json','独立复算与67组件守卫核验'),
    ('audit/system-v26/ntc-independent-calculations.json','独立温区保护容差角点计算'),
    ('audit/selection/application-review.json','插座、控件、LED、喇叭、电池选型审核'),
    ('audit/selection/battery-revision/proposal.json','2A成品电池与配套内部连接器选型'),
    ('audit/system-v26/battery-revision-merge.json','电池、内部连接器、耳机隔离器件合并记录'),
    ('audit/selection/battery-revision/protection-coordination.json','七路音频保护配合及未闭合限值'),
    ('audit/passive-closure/report.html','116个无源器件准确型号、有效容量与限制'),
    ('audit/passive-closure/pending-eco-patch.json','历史大型电容阵列提案，仅留存追溯，不推荐直接合并'),
    ('pcb-work/v26-final-summary.json','本版PCB最终快照'),
    ('verification/pcb-final-v26/summary.json','独立复跑五板严格DRC与源文件哈希'),
    ('manufacturing-v26/BOM-V26-ENGINEERING-NOT-RELEASED.csv','本版工程BOM，不能直接用于采购放行'),
    ('manufacturing-v26/power-pack-BOM-V26.json','当前电池包、内部接插件及端子BOM'),
    ('manufacturing-v26/FACTORY-PROCEDURE-DRAFT.txt','工厂11步流程草案'),
    ('manufacturing-v26/harness-process-DRAFT.json','线束切长、剥线、触点与焊接草案'),
    ('manufacturing-v26/interboard-wire-by-wire.html','37条板间连线：逐线、逐脚、两端坐标'),
    ('pcb-work/verification/CAM-index-v26-current.json','子板制造审阅输出索引'),
    ('firmware/verification/build-status.json','STM32目标构建状态'),
    ('firmware/verification/esp-native-build.json','ESP真实交叉编译证据'),
    ('firmware/verification/v26-implementation-status.json','固件已实现功能与限制'),
    ('firmware/contracts/driver-status.json','已实现驱动与未完成功能逐项表'),
    ('verification/parent-host-rerun-v26.json','独立复跑九套主机程序测试'),
    ('firmware/verification/f01-f02-completion.json','关机脉冲锁存、耳机原始信号静音修复及目标重编译'),
    ('audit/pin-closure-v26/firmware-safety-closure.json','F01/F02本轮软件整改证据，实板时序待测'),
    ('firmware/build/smartvio-h743-DIAG.elf','STM32音频诊断ELF'),
    ('firmware/build/esp32/smartvio_rf_diag.bin','ESP蓝牙诊断BIN'),
    ('firmware/build/esp32/flasher_args.json','ESP分区与烧录地址'),
    ('firmware/READ-ME.txt','烧录与诊断说明'),
    ('firmware/BUILD-PORTABLE.txt','可移交构建环境、版本与依赖'),
    ('firmware/verification/vendor-handoff.json','交付包内最小依赖库与许可证校验'),
]
pack_detail = ('已在本工程源中合并2A VARTA 56457201020及2A JST内部连接器；原0.7A选型退出当前BOM。' if pack_revision.get('applied') else
    '2A VARTA 56457201020及2A JST内部连接器已有具体提案；在源/板未同步前不能当作已替换。')
pack_detail += '完整温区、受限启动、电源角点、电池托架及连接器高度仍须以本版分析为准。'
issues = [
    ('P0','原287项',f"已审查{pin_review.get('reviewed_baseline_pins',0)}项；局部设计审核关闭{pin_review.get('closed_design_review_pins',0)}项，仍未关闭{pin_review.get('not_closed_baseline_pins',287)}项。供电条件、有效容量及故障限值不能用名称一致替代。"),
    ('P0','电池与满载预算',pack_detail),
    ('P0','有效容量及电源瞬态','100项电容准确料号已合并，74项仍无保证的工作偏压Ceff下界。新版10关键位置比较共12只紧凑电容，未合并；C807/C808 VCAP不满足保守模型，保持HOLD。历史大型阵列不推荐直接采用。'),
    ('P0','PCB/制造输出','必须以本版原生DRC、全部真实焊盘和源/板一致性为准。未连接主板不得输出成完整整机投板包；HDI USB工艺不能冒充普通通孔。'),
    ('P0','保护配合','耳机放大器内置保护尚无数值上界证明外部SSR短路电流合格；USB瞬态钳位与3.3V PHY限值仍需闭环。'),
    ('P0','充电功能','默认TMR/ITERM并非10mA与3.5小时方案。两套准确料号ECO已复算但未合并，快充方案仍需真实电源授权、热预算和持久会话上限；正常自动充电保持禁用。电池NTC完整容差与回路仍未闭合。'),
    ('P1','结构与装配','完整堆叠、卡扣、喇叭弹片压缩/声腔与返修可达性未完成批准。6mm是螺丝长度上限，当前没有经验证的工厂扭矩值。'),
    ('P1','实物联调','目标编译不是上板。实际时钟、ADC/DAC、端口/插拔、无线断重连、低电量、充电全过程及温升测试均为0。'),
]
summary = {'revision': 'V26', 'sourceSha256': source_hash, 'components': len(parts), 'pins': sum(len(c['pins']) for c in parts),
    'nativeERC': electrical, 'passiveClosure': passive.get('closure_counts', {}), 'stmBuild': build, 'espBuild': esp,
    'pcbSnapshot': board, 'independentPCB': pcb_independent, 'pinApplicationReview':pin_review,
    'batteryRevision':pack_revision,
    'hostIndependentRerun':host, 'firmwareSafetyCompletion':safety,
    'issues': [{'priority': a, 'item': b, 'detail': c} for a,b,c in issues],
    'excludedWaitingDependencies': ['Violin factory geometry/thickness measurement','Supplier samples before current remediation'],
    'sampleBuildReady': False, 'manufactureRelease': False, 'physicalTests': 0,
    'gateDistinction': 'First EVT prototype need not have prior physical results; it does require complete safe design, valid lands/routing/manufacturing data and scoped factory acceptance. Physical qualification comes after first build. Current main routing/power/BOM/protection issues already prevent complete first-sample release.',
    'inheritedV25Files': 'Historical material only. Current portal links are explicit; a copied legacy PASS is not V26 evidence.'}
(ROOT / 'verification/release-summary-v26.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
css = '''*{box-sizing:border-box}body{margin:0;font:14px/1.65 "Microsoft YaHei",Arial,sans-serif;color:#25352f;background:#fff;letter-spacing:0}header{padding:18px 24px;border-bottom:1px solid #ccd6d1;background:#f4f7f5}h1{margin:0;font-size:23px}h2{font-size:18px;margin:26px 0 12px}main{max-width:1220px;margin:auto;padding:20px 24px}nav{display:flex;flex-wrap:wrap;gap:18px;margin-top:12px}a{color:#086f83;overflow-wrap:anywhere}p{margin:10px 0}.status{border-left:4px solid #b23b40;background:#fff0f0;padding:12px 16px}.facts{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0;border-block:1px solid #ccd6d1;margin:20px 0}.facts>div{padding:12px;border-right:1px solid #ccd6d1}.facts b{display:block;font-size:20px;color:#16744d}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;vertical-align:top;padding:10px;border:1px solid #ccd6d1;overflow-wrap:anywhere}th{background:#edf4f0}.links{columns:2;column-gap:32px}.links p{break-inside:avoid}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.6 Consolas,monospace;background:#f4f7f5;padding:14px}.small{font-size:12px;color:#52645a}input{border:1px solid #a9beb2;padding:9px;max-width:100%;width:300px;font:inherit}figure{margin:14px 0;border-block:1px solid #ccd6d1;padding:12px 0}figure img{max-width:100%;height:auto;display:block}.list{margin:8px 0;padding-left:22px}@media(max-width:700px){main{padding:16px}header{padding:16px}.facts{grid-template-columns:repeat(2,minmax(0,1fr))}.links{columns:1}th,td{min-width:130px}h1{font-size:21px}}'''
css += 'body{overflow-wrap:anywhere}.scroll{max-width:100%}.facts>div{min-width:0}'
body = '<header><h1>SmartVio V26 工程整改审阅</h1><nav><a href="#results">本轮结果</a><a href="#issues">未闭合项</a><a href="#files">文件索引</a><a href="#pins">逐脚检索</a><a href="#process">工厂步骤</a></nav></header><main>'
body += '<p class="status">当前交付：工程审核与诊断文件，不是完整一体机样机生产放行包。琴厂测量、供应商样品不作为本轮等待条件；但不把未验证项目改写为已通过。</p>'
body += '<div class="facts"><div><b>'+str(len(parts))+' / '+str(sum(len(c['pins']) for c in parts))+'</b>器件 / 电气引脚</div><div><b>'+str(electrical.get('ercViolations','待核'))+'</b>本版ERC违规</div><div><b>'+str(len(electrical.get('netlistDifferences',[])))+'</b>网表节点差异</div><div><b>0</b>实物测试</div></div>'
body += '<p class="small">当前源 SHA256：'+source_hash+'</p><section id="results"><h2>本轮实际修改</h2>'
body += table(['领域','已落到文件的内容','证据边界'],[
    ('脚号与接口','PC13 pin7修正；共模1-4/2-3绕组修正；Kycon替换6/8冲突插座；LED1K2A；按钮4脚真实触点','需PCB/程序同步，实物未测'),
    ('电源与保护','USB独立唤醒；性能电源门控；I2C隔离；独立偏置103AT-2温区保护；实际电流预算','角点计算不是热测试或保护认证'),
    ('器件与电容','6项磁件/晶振、100项电容准确MPN合并；按键/调节轮/青色LED/薄喇叭/成品pack有原厂资料','完整应用及采购批准未完成'),
    ('EDA核对',str(len(electrical.get('logicalTopologyChecks',{})))+'项拓扑检查、'+str(len(electrical.get('negativeControls',[])))+'项故障注入检查；24页原生工程','仅捕获/拓扑/规则验证'),
    ('固件','关机脉冲EXTI锁存；耳机原始信号与GPIO提交二次互锁；ARM与ESP重编译；九套主机测试通过','主机103组、22,541,966次断言，不是硬件测试或充电授权'),
])+'</section>'
body += '<section id="issues"><h2>设计整改与验证未完成项</h2><p>首支EVT样机不要求先有实物测试结果；但需完整安全电路、可制造焊盘、连通布线及同版制造文件。本版主板、电池预算和保护配合未闭合，尚不能作为完整一体机样机投板包。实物音频、蓝牙与温升是在样机制作后的资格验证。</p>'+table(['等级','项目','本轮结论'],issues)+'</section>'
if pcb_independent:
    body += '<section><h2>原生PCB严格复验</h2>'+table(['板','错误','警告','未连接','忽略类别','生产批准'],
        [[x['board'],x['errors'],x['warnings'],x['unconnected'],len(x['projectIgnoredCategories']), '否'] for x in pcb_independent['boards']])
    body += '<p>DRC在内存中重新铺铜后执行，原始板文件哈希未改变；规则检查不是回流、阻抗、射频或实物测试。</p>'
    for name,label in [('main','主板'),('usb','USB板'),('audio','音频接口板'),('cover','控制板'),('sensor','温度传感板')]:
        path = 'drawings/pcb-native-v26/'+name+'-front.svg'
        if (ROOT/path).exists():
            body += '<figure><figcaption>'+label+'：当前原生铜层与丝印审阅图，未获整机投板批准</figcaption><img src="'+path+'" alt="'+label+'真实PCB铜层与丝印"></figure>'
    body += '</section>'
body += '<section id="files"><h2>当前文件索引</h2><div class="links">'+''.join('<p>'+link(path,label)+'</p>' for path,label in links)+'</div></section>'
body += '<section id="pins"><h2>逐脚检索</h2><input id="search" aria-label="查找器件、引脚或网络" placeholder="器件 / 引脚 / 网络 / 型号">'
body += '<div id="rows">'+table(['位号','脚号','功能','网络','型号'], [[c['ref'],p['number'],p.get('nativeName',p['name']),p['net'] or 'NC',c.get('mpn') or '铜端点或待定'] for c in parts for p in c['pins']])+'</div></section>'
body += '<section id="process"><h2>工厂步骤草案</h2>'+table(['步骤','工作','处理'],[[s['id'],s['name'],s['instruction']] for s in read('manufacturing-v26/factory-sequence-DRAFT.json',{'steps':[]})['steps']])+'</section>'
body += '<h2>审核快照</h2><p>PCB快照含源版本：旧版复制的结果不等于本版通过。所有例外必须逐项确认，并由授权工程师/电子厂签署。</p><details><summary>查看原生PCB详细快照</summary><pre>'+escape(json.dumps(board,ensure_ascii=False,indent=2))+'</pre></details>'
body += '<p>原厂依据：<a href="https://www.ti.com/lit/ds/symlink/bq24074.pdf">TI BQ24074</a>；<a href="https://docs.kicad.org/10.0/en/pcbnew/pcbnew.html#generating-outputs">KiCad制造输出</a>。其他49份原厂PDF及页码/哈希见无源器件与选型资料。</p>'
body += '<script>document.getElementById("search").addEventListener("input",e=>{const q=e.target.value.toLowerCase();document.querySelectorAll("#rows tbody tr").forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(q))})</script></main>'
(ROOT / 'index.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SmartVio V26 工程整改审阅</title><style>'+css+'</style></head><body>'+body+'</body></html>',encoding='utf-8')
print(json.dumps({'portal': str(ROOT/'index.html'), 'sourceSha256': source_hash, 'productionRelease':False},ensure_ascii=False))
