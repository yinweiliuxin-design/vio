"""Create a curated V26 handoff; never package inherited release claims."""
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
DEST = BASE / 'outputs/SmartVio-V26-Engineering-Handoff'
ZIP = DEST.with_suffix('.zip')
if DEST.exists():
    raise SystemExit('A curated handoff already exists. Choose a new destination; do not overwrite evidence.')
DEST.mkdir()


def copy(path):
    source = ROOT / path
    if not source.exists():
        raise FileNotFoundError(str(source))
    target = DEST / path
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(source, target, ignore=shutil.ignore_patterns(
            '__pycache__', '*.pyc', '*.kicad_prl', '*.lck', '*.bak', '*-backups',
            'sdkconfig.old', 'smartvio-h743-HOLD.*', 'smartvio-h743-HOLD-*'))
    else:
        shutil.copy2(source, target)


for path in ['index.html', 'revision-state.json', 'eda', 'manufacturing-v26',
             'firmware', 'audit/selection', 'audit/passive-closure', 'audit/system-v26', 'audit/pin-closure-v26',
             'audit/power-closure-v26',
             'electrical/native-components.json', 'electrical/footprint-map.json',
             'drawings/SmartVio-V26-Schematic-REVIEW.pdf',
             'reference/v26-circuits.json', 'reference/v25-circuits.json',
             'reproduce/capture-template.py', 'reproduce/capture_library.py',
             'verification/electrical-check-v26.json', 'verification/capture-summary.json',
             'verification/mcu-physical-package-check.json',
             'verification/export-log-v26.json', 'verification/native-netlist.xml',
             'verification/legacy-287-tracking.json', 'verification/release-summary-v26.json',
             'verification/parent-host-rerun-v26.json',
             'verification/pdf-render-check-v26.json', 'verification/schematic-montage-v26.png',
             'verification/pcb-final-v26', 'drawings/pcb-native-v26',
             'verification/portal-qa.json', 'verification/portal-1280.png', 'verification/portal-390.png']:
    copy(path)

for path in (ROOT / 'drawings').glob('*.svg'):
    copy(path.relative_to(ROOT).as_posix())
for path in ['audit/passives/sources', 'audit/power/source-evidence',
             'audit/audio/sources', 'audit/controls-protection/source-evidence']:
    if (ROOT / path).exists():
        copy(path)

board_summary = ROOT / 'pcb-work/v26-final-summary.json'
if not board_summary.exists():
    raise SystemExit('PCB final engineering snapshot missing. Do not curate an ambiguous board version.')
copy('pcb-work/v26-final-summary.json')
for name in ['main', 'usb', 'audio', 'cover', 'sensor']:
    stem = f'pcb-work/SmartVio-{name}-v26-final'
    copy(stem + '.kicad_pcb')
    copy(stem + '.kicad_pro')
    if (ROOT / (stem + '.kicad_dru')).exists():
        copy(stem + '.kicad_dru')
for folder in ['pcb-work/SmartVioV25.pretty', 'pcb-work/SmartVioV26.pretty',
               'pcb-work/verification', 'pcb-work/cam-review-v26-current']:
    if (ROOT / folder).exists():
        copy(folder)
for name in ['fp-lib-table', 'footprint-map.json', 'README.txt']:
    if (ROOT / 'pcb-work' / name).exists():
        copy('pcb-work/' + name)

# Datasheet indexes retain original URLs; source PDFs are evidence, not instructions.
sources = BASE / 'work/v26/selection/sources'
if sources.exists():
    shutil.copytree(sources, DEST / 'audit/selection/source-evidence')
reproduce = DEST / 'reproduce'
shutil.copy2(BASE / 'work/v26/validate_handoff.py', reproduce / 'validate_handoff.py')
(DEST / 'READ-FIRST.txt').write_text(
    'SmartVio V26 工程整改交付，不是完整一体机样机生产放行包。\n'
    '先打开 index.html，再读 verification/release-summary-v26.json 和逐板严格DRC。\n'
    '琴厂尺寸、供应商寄样不列为本轮外部等待条件；不能据此批准尚未完成的电气、堆叠或实物测试。\n'
    '当前 source SHA256 见 HANDOFF-MANIFEST.json。旧版V25生产包与HOLD镜像不是本包放行依据。\n'
    '电池满载电流、有效电容量、主板连通/布局、保护配合、充电和实物联调仍有明确阻断项。\n'
    '任何CAM审阅文件均不得当作完整装配制造文件；电子厂DFM签署为空，不能替厂签署。\n'
    '首支EVT不必预先有实物测试结果；投板前必须先完成安全电路与可制造数据。本版主板、电源和保护设计未闭合。\n'
    '文件完整性验证：python reproduce/validate_handoff.py\n'
    '生产门禁验证：python reproduce/validate_handoff.py --require-production-release\n'
    '本版预期完整性退出0；生产门禁退出2，表示不允许完整生产放行。\n'
    '目标编译成功不代表实物音频、蓝牙、充电、温升通过。\n', encoding='utf-8-sig')
files = []
for path in sorted(DEST.rglob('*')):
    if path.is_file():
        files.append({'path': path.relative_to(DEST).as_posix(), 'bytes': path.stat().st_size,
                      'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
manifest = {'revision': 'V26', 'createdUTC': datetime.now(timezone.utc).isoformat(),
            'sourceSha256': hashlib.sha256((DEST / 'electrical/native-components.json').read_bytes()).hexdigest(),
            'scope': 'Curated engineering handoff / NOT RELEASED', 'manufactureRelease': False,
            'files': files}
(DEST / 'HANDOFF-MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
check = subprocess.run([sys.executable, str(reproduce / 'validate_handoff.py')],
                       capture_output=True, text=True, encoding='utf-8')
if check.returncode:
    raise RuntimeError(check.stdout + check.stderr)
gate = subprocess.run([sys.executable, str(reproduce / 'validate_handoff.py'), '--require-production-release'],
                      capture_output=True, text=True, encoding='utf-8')
if gate.returncode != 2:
    raise RuntimeError('Production gate did not fail closed: ' + gate.stdout + gate.stderr)
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(DEST.rglob('*')):
        if path.is_file():
            z.write(path, DEST.name + '/' + path.relative_to(DEST).as_posix())
with zipfile.ZipFile(ZIP) as z:
    bad = z.testzip()
    names = z.namelist()
    if bad or len(names) != len(set(names)):
        raise RuntimeError('ZIP CRC/duplicate failure: ' + str(bad))
result = {'directory': str(DEST), 'zip': str(ZIP), 'files': len(files) + 1,
          'zipBytes': ZIP.stat().st_size, 'zipSHA256': hashlib.sha256(ZIP.read_bytes()).hexdigest(),
          'zipCRC': 'PASS', 'integrityExitCode': check.returncode,
          'productionGateExitCodeExpected2': gate.returncode, 'manufactureRelease': False}
(ROOT / 'verification/handoff-package-check.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
