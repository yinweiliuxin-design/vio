"""Use the refreshed physical inventory as the schematic Footprint source."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
source = ROOT / 'electrical/native-components.json'
parts = json.loads(source.read_text(encoding='utf-8'))
mapping_file = ROOT / 'pcb-work/footprint-map.json'
mapping = json.loads(mapping_file.read_text(encoding='utf-8-sig'))
source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
for c in parts:
    assert c['ref'] in mapping, c['ref']
    entry = mapping[c['ref']]
    assert entry['sourceSHA256'].lower() == source_hash, c['ref']
    if entry.get('board', '').startswith('external-'):
        assert c['ref'] == 'RT1921' and entry['id'] is None
    else:
        assert entry['padSetMatches'] is True, (c['ref'], entry['missingPads'], entry['extraPads'])
        assert entry['captureFieldResolution'] == 'LIBRARY_FILE_EXISTS_AND_NATIVE_BOARD_PARSE_VALID'
(ROOT / 'electrical/footprint-map.json').write_text(json.dumps(mapping, ensure_ascii=False, indent=2), encoding='utf-8')
(ROOT / 'verification/capture-map-sync-v26.json').write_text(json.dumps({
    'sourceSha256': source_hash, 'mapSha256': hashlib.sha256(mapping_file.read_bytes()).hexdigest(),
    'sourceComponentCount': len(parts), 'physicalInventoryEntries': len(mapping),
    'externalNonPCBRefs': ['RT1921'], 'status': 'SOURCE_MAP_PADSETS_VERIFIED_NO_PRODUCTION_APPROVAL'}, indent=2), encoding='utf-8')
print(json.dumps({'sourceSha256': source_hash, 'parts': len(parts), 'mapEntries': len(mapping)}))
