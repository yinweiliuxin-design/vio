"""Bind selected native boards, fresh DRC and CAM to their real content hashes."""
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE / 'work/v26/parser-tools'))
import sexpdata as sx

ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
PCB = ROOT / 'pcb-work'
VERIFY = PCB / 'verification'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
write = lambda p, v: p.write_text(json.dumps(v, ensure_ascii=False, indent=2), encoding='utf-8')
rel = lambda p: p.relative_to(ROOT).as_posix()
source = ROOT / 'electrical/native-components.json'
source_hash = sha(source)
snapshot = read(ROOT / 'verification/pcb-final-v26/summary.json')
parity_path = VERIFY / 'current-native-parity.json'
parity = read(parity_path)
mapping = read(PCB / 'footprint-map.json')
capture = read(ROOT / 'verification/electrical-check-v26.json')
assert capture['pass'] and not capture['footprintFieldDifferences']
assert snapshot['sourceSha256'] == parity['sourceSHA256'] == capture['sourceSha256'] == source_hash
assert not parity['sourceExportPinNetDifferences'] and not parity['sourceExportReferenceDifferences']
assert snapshot['allNativeRulesEnabled']
boards, cams = [], []
for state in snapshot['boards']:
    kind = state['board']
    board = ROOT / state['boardPath']
    assert sha(board) == state['boardSha256']
    inventory = read(VERIFY / f'final-inventory-{kind}.json')
    assert inventory['boardSHA256'] == sha(board)
    p = next(p for p in parity['boards'] if p['kind'] == kind)
    assert p['boardSHA256'] == sha(board)
    assert all(not p[k] for k in ['pinNetDifferences', 'candidateHarnessDifferences', 'valueDifferences', 'mpnDifferences', 'padSetDifferences', 'pinFunctionDifferences'])
    drc_path = ROOT / state['drcPath']
    drc = read(drc_path)
    assert drc['source'] == board.name
    clean = not drc['violations'] and not drc['unconnected_items']
    manifest = PCB / 'cam-review-v26-current' / kind / 'CAM-manifest.json'
    if manifest.exists():
        assert clean, f'Non-clean board has current selected CAM: {kind}'
        cam = read(manifest)
        assert cam['boardSHA256'] == sha(board) and cam['nativeDRCSHA256'] == sha(drc_path)
        assert cam['sourceSHA256'] == source_hash and cam['paritySHA256'] == sha(parity_path)
        for f in cam['CAM']:
            assert sha(ROOT / f['relativePackPath']) == f['sha256']
        cam['nativeDRCRelativePackPath'] = rel(drc_path)
        write(manifest, cam)
        cams.append({'kind': kind, 'boardSHA256': sha(board), 'manifestRelativePackPath': rel(manifest),
                     'manifestSHA256': sha(manifest), 'directoryRelativePackPath': rel(manifest.parent),
                     'files': cam['CAM'], 'productionApproved': False})
    native = [{'relativePackPath': rel(board.with_suffix(ext)), 'sha256': sha(board.with_suffix(ext))}
              for ext in ['.kicad_pcb', '.kicad_pro', '.kicad_dru'] if board.with_suffix(ext).exists()]
    boards.append({**state, 'kind': kind, 'boardSHA256': sha(board), 'nativeFiles': native,
                   'footprints': inventory['footprintCount'], 'tracks': inventory['trackCount'],
                   'vias': inventory['viaCount'], 'layers': inventory['copperLayers'],
                   'thicknessMm': inventory['thicknessMm'], 'parity': p,
                   'drc': {'errors': state['errors'], 'warnings': state['warnings'], 'unconnected': state['unconnected'],
                           'relativePackPath': rel(drc_path), 'reportSHA256': sha(drc_path),
                           'violationsByType': {t: sum(v['type'] == t for v in drc['violations']) for t in sorted({v['type'] for v in drc['violations']})}},
                   'status': 'LOCAL_NATIVE_DRC_CLOSED_NOT_SYSTEM_RELEASE' if clean else 'NATIVE_DRC_NOT_CLOSED_NO_FABRICATION',
                   'CAMDirectoryRelativePackPath': rel(manifest.parent) if manifest.exists() else None,
                   'productionApproved': False})

def child(node, key):
    return next((e for e in node if isinstance(e, list) and str(e[0]) == key), None)

usb = ROOT / next(b['boardPath'] for b in boards if b['kind'] == 'usb')
tree = sx.loads(usb.read_text(encoding='utf-8'))
micro = [e for e in tree if isinstance(e, list) and str(e[0]) == 'via' and sx.Symbol('micro') in e]
assert len(micro) == 1
ball = next(p for p in mapping['U1401']['physicalPads'] if p['number'] == 'B2')
assert child(micro[0], 'at')[1:] == ball['xyMm'] and ball['net'] == 'GND'
assert child(micro[0], 'layers')[1:] == ['F.Cu', 'In1.Cu']
assert child(micro[0], 'filling')[1] == child(micro[0], 'capping')[1] == sx.Symbol('yes')
write(VERIFY / 'usb-final-b2-microvia-evidence.json', {
    'sourceSHA256': source_hash, 'boardSHA256': sha(usb), 'boardRelativePackPath': rel(usb),
    'actualB2Pad': ball, 'actualMicroviaNativeSExpression': sx.dumps(micro[0]),
    'nativeStackup': sx.dumps(child(child(tree, 'setup'), 'stackup')),
    'microviaDiameterMm': child(micro[0], 'size')[1], 'microviaDrillMm': child(micro[0], 'drill')[1],
    'strictWholeUsbUnconnected': next(b['unconnected'] for b in boards if b['kind'] == 'usb'),
    'process': 'F-to-In1 filled/capped laser microvia; HDI fabrication DFM required',
    'scope': 'Actual geometry and native rule check; no impedance, assembly or hardware approval', 'productionApproved': False})

main = next(b for b in boards if b['kind'] == 'main')
issues = read(ROOT / main['drcPath'])['violations']
collisions = [v for v in issues if v['type'] == 'courtyards_overlap']
write(VERIFY / 'main-placement-technical-blocks.json', {
    'sourceSHA256': source_hash, 'boardSHA256': main['boardSHA256'],
    'currentCourtyardOverlapCount': len(collisions), 'collisions': collisions,
    'currentV26': {k: main[k] for k in ['errors', 'warnings', 'unconnected']},
    'placementEntries': [{k: e.get(k) for k in ['id', 'mpn', 'xyMm', 'side', 'courtyardBBoxMm', 'physicalPads']} | {'ref': ref}
                         for ref, e in mapping.items() if e.get('board') == 'main'],
    'scope': 'Current actual geometry, not proof that all alternate arrangements are impossible',
    'productionApproved': False})
tvs = []
for i in range(1, 8):
    ref = f'D120{i}'
    pads = mapping[ref]['physicalPads']
    checks = {'twoPads': len(pads) == 2, 'numbers': {p['number'] for p in pads} == {'1', '2'},
              'sizeMm': all(p['sizeMm'] == [.3, .5] for p in pads),
              'centersMm': sorted(p['relativeXYMm'] for p in pads) == [[-.35, 0.0], [.35, 0.0]],
              'maskMarginMm': all(p['maskMarginMm'] == .07 for p in pads),
              'cornersMm': all(p['cornerRadiusMm'] == .05 for p in pads)}
    tvs.append({'ref': ref, 'pads': pads, 'tests': checks, 'numericLandPass': all(checks.values())})
assert all(t['numericLandPass'] for t in tvs)
write(VERIFY / 'tvs-final-numeric-landcheck.json', {'sourceSHA256': source_hash, 'boardSHA256': main['boardSHA256'],
    'entries': tvs, 'allSevenNumericLandPass': True, 'scope': 'TI DPY0002A actual numeric land; protection coordination and routing are separate',
    'productionApproved': False})
cam_index = {'sourceSHA256': source_hash, 'status': 'CURRENT_ENGINEERING_REVIEW_CAM_ONLY', 'boards': cams,
             'excludedHistoricalDirectories': ['engineering-export', 'old power prototype', 'V25 CAM copies'],
             'productionApproved': False}
write(VERIFY / 'CAM-index-v26-current.json', cam_index)
summary = {'generatedUTC': datetime.now(timezone.utc).isoformat(), 'sourceSHA256': source_hash,
           'sourceComponents': capture['components'], 'sourcePins': capture['pins'], 'sourceNets': capture['nets'],
           'status': 'ENGINEERING_REVIEW_NOT_COMPLETE_PRODUCT_RELEASE', 'boards': boards,
           'captureFootprintSyncPending': False, 'captureFootprintFieldsChecked': capture['footprintFieldsChecked'],
           'footprintMapSHA256': sha(PCB / 'footprint-map.json'), 'currentNativeParitySHA256': sha(parity_path),
           'selectedCAMBoardKinds': [c['kind'] for c in cams], 'allSelectedIgnoredChecks': [],
           'CAMIndexRelativePackPath': rel(VERIFY / 'CAM-index-v26-current.json'),
           'physicalTests': 0, 'productionApproved': False,
           'limitations': ['Main-board routing and application review must be closed before complete EVT build.',
                           'Electrical protection, battery budget, effective capacitance and full stack are not approved by DRC.',
                           'PCB sources include valid parts and actual copper; manufacturing approval is not delegated to this script.']}
for p in [VERIFY / 'final-summary.json', PCB / 'final-summary.json', PCB / 'v26-final-summary.json']:
    write(p, summary)
write(PCB / 'board-progress.json', summary)
(PCB / 'README.txt').write_text('SmartVio V26 当前PCB工程审核文件，整机未放行。\n'
    '以 v26-final-summary.json 和 verification/pcb-final-v26 的实际检查为准。\n'
    'Gerber/钻孔/焊膏/坐标仅在 cam-review-v26-current；主板未闭合时禁止作为完整一体机投板。\n'
    '各板原生文件均为 SmartVio-板名-v26-final；final仅表示本次选定版本，不代表工厂生产批准。\n'
    'USB中心地焊球使用填孔盖铜激光微孔，不是普通通孔。\n', encoding='utf-8-sig')
print(json.dumps({'boards': [{k: b[k] for k in ['kind', 'errors', 'warnings', 'unconnected']} for b in boards],
                  'CAM': [c['kind'] for c in cams], 'productionApproved': False}))
