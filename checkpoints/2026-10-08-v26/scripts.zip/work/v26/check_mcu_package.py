"""Check every STM32H743VIT6 LQFP100 pin against the package, not net labels."""
import hashlib
import json
import re
from pathlib import Path

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V26-Engineering'
source=ROOT/'electrical/native-components.json'
parts=json.loads(source.read_text(encoding='utf-8'))
stm=next(c for c in parts if c['ref']=='U801')
identity=('PE2 PE3 PE4 PE5 PE6 VBAT PC13 PC14 PC15 VSS VDD PH0 PH1 NRST PC0 PC1 PC2_C PC3_C VSSA VREF+ VDDA PA0 PA1 PA2 PA3 '
          'VSS VDD PA4 PA5 PA6 PA7 PC4 PC5 PB0 PB1 PB2 PE7 PE8 PE9 PE10 PE11 PE12 PE13 PE14 PE15 PB10 PB11 VCAP VSS VDD '
          'PB12 PB13 PB14 PB15 PD8 PD9 PD10 PD11 PD12 PD13 PD14 PD15 PC6 PC7 PC8 PC9 PA8 PA9 PA10 PA11 PA12 PA13 VCAP VSS VDD '
          'PA14 PA15 PC10 PC11 PC12 PD0 PD1 PD2 PD3 PD4 PD5 PD6 PD7 PB3 PB4 PB5 PB6 PB7 BOOT0 PB8 PB9 PE0 PE1 VSS VDD').split()
assert len(identity)==100
proof={'url':'https://www.st.com/resource/en/datasheet/stm32h743vi.pdf',
       'section':'DS12110 Rev11 Figure5 LQFP100 physical pin numbering; not BGA/144/176-pin column'}
rows=[]
for p in stm['pins']:
    actual=identity[int(p['number'])-1]
    named=p['name']
    used=p['net'] is not None
    matched=(named.startswith(actual) or (actual=='VREF+' and named=='VREF+') or
             (actual=='VCAP' and named.startswith('VCAP')))
    if not used:
        p['name']=actual+'_UNUSED'
        p['nativeName']=actual
        p['evidence']=proof
        p['pinAuditStatus']='VERIFIED_OFFICIAL'
        p['electricalType']='no_connect'
        matched=True
    rows.append({'pin':p['number'],'physicalIdentity':actual,'capturedName':p['name'],'net':p['net'],
                 'identityMatches':matched,'used':used,
                 'unusedTreatment':None if used else 'Physical pad no net; firmware analog/no-pull unless dedicated special pin; no LSE enabled',
                 'evidence':proof})
assert all(r['identityMatches'] for r in rows),[r for r in rows if not r['identityMatches']]
source.write_text(json.dumps(parts,ensure_ascii=False,indent=2),encoding='utf-8')
test=[dict(r) for r in rows]
test[6]['capturedName']='PE8_AUDIO_BUS_EN'
negativeDetected=not test[6]['capturedName'].startswith(test[6]['physicalIdentity'])
assert negativeDetected
out=ROOT/'verification/mcu-physical-package-check.json'
out.write_text(json.dumps({'pins':100,'identityMismatchCount':0,'rows':rows,
                          'negativeControlPin7PE8Detected':negativeDetected,
                          'scope':'Package identity only; alternate functions, firmware initialization and physical continuity are separate.'},indent=2),encoding='utf-8')
(ROOT/'audit/system-v26/native-revision.json').write_text(json.dumps({'parts':len(parts),
   'pins':sum(len(c['pins']) for c in parts),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print(json.dumps({'physicalIdentitiesChecked':100,'mismatches':0,'wrongPE8pin7Detected':negativeDetected}))
