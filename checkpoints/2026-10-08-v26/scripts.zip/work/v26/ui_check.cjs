const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = path.resolve(__dirname, '../../outputs/SmartVio-V26-Engineering');
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
  const results = [];
  for (const [width, height] of [[1280, 900], [390, 844]]) {
    const page = await browser.newPage({ viewport: { width, height } });
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(pathToFileURL(path.join(root, 'index.html')).href);
    const status = await page.evaluate(() => ({ title: document.title, rows: document.querySelectorAll('#rows tbody tr').length,
      pageOverflow: document.documentElement.scrollWidth > window.innerWidth,
      badInternalLinks: Array.from(document.querySelectorAll('a[href]')).filter(a => !a.getAttribute('href').startsWith('http') && !a.getAttribute('href').startsWith('#')).map(a => a.getAttribute('href')) }));
    const missing = status.badInternalLinks.filter(h => !fs.existsSync(path.join(root, decodeURIComponent(h))));
    await page.screenshot({ path: path.join(root, `verification/portal-${width}.png`) });
    await page.locator('#search').fill('CELL_NTC_SENSE');
    const filtered = await page.locator('#rows tbody tr:visible').count();
    results.push({ width, height, title: status.title, rows: status.rows, pageOverflow: status.pageOverflow,
      missingFiles: missing, pageErrors: errors, filteredRows: filtered,
      pass: !status.pageOverflow && !missing.length && !errors.length && status.rows === 1081 && filtered > 0 && filtered < 30 });
    await page.close();
  }
  await browser.close();
  fs.writeFileSync(path.join(root, 'verification/portal-qa.json'), JSON.stringify(results, null, 2));
  console.log(JSON.stringify(results, null, 2));
  if (results.some(r => !r.pass)) process.exitCode = 1;
})().catch(e => { console.error(e); process.exitCode = 1; });
