import hashlib
import json
import shutil
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/audit/passive-closure'
ENGINE = OUT.parents[1]
OLD = ENGINE / 'audit/critical-passives'
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'source-evidence').mkdir(exist_ok=True)
(WORK / 'text').mkdir(exist_ok=True)


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


native = ENGINE / 'electrical/native-components.json'
snapshot = WORK / 'native-input-snapshot.json'
if not snapshot.exists():
    shutil.copy2(native, snapshot)
    dump(WORK / 'input-baseline.json', {
        'utc': datetime.now(timezone.utc).isoformat(), 'path': str(native.relative_to(ROOT)),
        'sha256': digest(native), 'snapshot_sha256': digest(snapshot),
        'parent_eco': 'U1901 TPS22918; U1902 TMUX1511; V3LOAD already present; preserve baseline pins',
    })

manifest_path = OUT / 'source-evidence.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else []
ids = {s['id'] for s in manifest}


def record(source_id, url, data_path, origin):
    reader = PdfReader(data_path)
    text = [{'page': i + 1, 'text': p.extract_text() or ''} for i, p in enumerate(reader.pages)]
    dump(WORK / 'text' / (source_id + '.json'), text)
    manifest.append({'id': source_id, 'manufacturer_url': url,
                     'path': str(data_path.relative_to(OUT)), 'sha256': digest(data_path),
                     'pages': len(text), 'bytes': data_path.stat().st_size,
                     'origin': origin, 'retrieved_utc': datetime.now(timezone.utc).isoformat()})
    ids.add(source_id)
    dump(manifest_path, manifest)


for item in json.loads((OLD / 'source-manifest.json').read_text(encoding='utf-8'))['files']:
    source_id = item['source_id']
    if source_id in ids:
        continue
    src = OLD / item['package_relative_path']
    assert digest(src) == item['sha256'], source_id
    dst = OUT / 'source-evidence' / (source_id + '.pdf')
    shutil.copy2(src, dst)
    record(source_id, item['manufacturer_url'], dst, str(src.relative_to(ROOT)))

downloads = {
    'KEM_C0G_SMD': 'https://content.kemet.com/datasheets/KEM_C1003_C0G_SMD.pdf',
    'KEM_POLYMER': 'https://content.kemet.com/datasheets/KEM_T2076_T52X-530.pdf',
    'TPS22918': 'https://www.ti.com/lit/ds/symlink/tps22918.pdf',
    'ACM2012H': 'https://product.tdk.com/system/files/dam/doc/product/emc/emc/cmf_cmc/catalog/cmf_automotive_signal_acm2012h-t06_en.pdf',
    'C2220C474J5GACAUTO': 'https://www.yageogroup.com/download/specsheet/C2220C474J5GACAUTO',
    'CC0603JRNPO9BN103': 'https://www.yageogroup.com/download/specsheet/CC0603JRNPO9BN103',
    'CC0603JRNPO9BN222': 'https://www.yageogroup.com/download/specsheet/CC0603JRNPO9BN222',
    'CC0603JRNPO9BN102': 'https://www.yageogroup.com/download/specsheet/CC0603JRNPO9BN102',
    'CC0603KRX7R7BB225': 'https://www.yageogroup.com/download/specsheet/CC0603KRX7R7BB225',
    'CC0603KRX7R7BB104': 'https://www.yageogroup.com/download/specsheet/CC0603KRX7R7BB104',
    'YAGEO_NP0': 'https://yageogroup.com/content/datasheet/asset/file/UPY-GP_NP0_16V-to-250V',
    'YAGEO_X7R': 'https://www.yageogroup.com/content/datasheet/asset/file/UPY-GPHC_X7R_6_3V-TO-250V',
    'YAGEO_X5R': 'https://www.yageogroup.com/content/datasheet/asset/file/UPY-GPHC_X5R_4V-TO-50V',
    'ACM2012H_ZH': 'https://product.tdk.cn/system/files/dam/doc/product/emc/emc/cmf_cmc/catalog/cmf_automotive_signal_acm2012h-t06_zh.pdf',
    'ACM2012H_JA': 'https://product.tdk.com/system/files/dam/doc/product/emc/emc/cmf_cmc/catalog/cmf_automotive_signal_acm2012h-t06_ja.pdf',
    'WE_744232090': 'https://www.we-online.com/components/products/datasheet/744232090.pdf',
    'C2220C474J5GACTU': 'https://www.yageogroup.com/download/specsheet/C2220C474J5GACTU',
    'C1206C104J5GACTU': 'https://www.yageogroup.com/download/specsheet/C1206C104J5GACTU',
    'C0603C103J5GACTU': 'https://www.yageogroup.com/download/specsheet/C0603C103J5GACTU',
    'C0603C222J5GACTU': 'https://www.yageogroup.com/download/specsheet/C0603C222J5GACTU',
    'C0603C102J5GACTU': 'https://www.yageogroup.com/download/specsheet/C0603C102J5GACTU',
    'C0603C300J5GACTU': 'https://www.yageogroup.com/download/specsheet/C0603C300J5GACTU',
    'C0603C472J5GACTU': 'https://www.yageogroup.com/download/specsheet/C0603C472J5GACTU',
    'T520A226M010ATE070': 'https://www.yageogroup.com/download/specsheet/T520A226M010ATE070',
    'T520U476M010ATE055': 'https://www.yageogroup.com/download/specsheet/T520U476M010ATE055',
    'C1206C104J3GACTU': 'https://www.yageogroup.com/download/specsheet/C1206C104J3GACTU',
    'C0603C103J3GACTU': 'https://www.yageogroup.com/download/specsheet/C0603C103J3GACTU',
    'YAGEO_MLCC_LAND': 'https://www.yageogroup.com/content/datasheet/asset/file/UPY-AC_HICAP_X7RX7S',
    'T520A226M010ATE080': 'https://www.yageogroup.com/download/specsheet/T520A226M010ATE080',
}
for source_id, filename in {'PCM1864': 'PCM1864.pdf', 'PCM5102A': 'PCM5102A.pdf'}.items():
    if source_id not in ids:
        src = ENGINE / 'audit/audio/sources' / filename
        dst = OUT / 'source-evidence' / filename
        shutil.copy2(src, dst)
        record(source_id, 'https://www.ti.com/lit/ds/symlink/' + source_id.lower() + '.pdf', dst,
               str(src.relative_to(ROOT)))
attempts_path = WORK / 'download-attempts.json'
attempts = json.loads(attempts_path.read_text(encoding='utf-8')) if attempts_path.exists() else []
for source_id, url in downloads.items():
    if source_id in ids:
        continue
    if any(a['id'] == source_id for a in attempts):
        continue
    try:
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=35) as response:
            data = response.read()
        if not data.startswith(b'%PDF'):
            raise ValueError('Response is not an original PDF')
        dst = OUT / 'source-evidence' / (source_id + '.pdf')
        dst.write_bytes(data)
        record(source_id, url, dst, 'manufacturer-download')
        print(source_id, 'OK', len(data), flush=True)
    except Exception as exc:
        attempts.append({'id': source_id, 'url': url, 'error': str(exc),
                         'utc': datetime.now(timezone.utc).isoformat()})
        dump(attempts_path, attempts)
        print(source_id, 'FAILED', str(exc), flush=True)

print('PDF_COUNT', len(manifest), 'INPUT_SHA', digest(snapshot), flush=True)
