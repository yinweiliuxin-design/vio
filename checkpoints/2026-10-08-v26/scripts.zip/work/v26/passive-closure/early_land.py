import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/audit/passive-closure'
old = json.loads((OUT.parent / 'critical-passives/proposal.json').read_text(encoding='utf-8'))
native = {c['ref']: c for c in json.loads((Path(__file__).parent / 'native-input-snapshot.json').read_text(encoding='utf-8'))}
evidence = {s['id']: s for s in json.loads((OUT / 'source-evidence.json').read_text(encoding='utf-8'))}
lands = []

for row in old['components'][:6]:
    ref = row['ref']
    part = copy.deepcopy(row['candidate'])
    if ref == 'L1101':
        pads = [('1', [-1.675, 0], [0.98, 3.4]), ('2', [1.675, 0], [0.98, 3.4])]
        maxima = [4.3, 4.3, 2.1]
        delta = 'Relax former target <=4x4x2mm to maximum 4.3x4.3x2.1mm; not a 4.0mm maximum part.'
    elif ref == 'FB1101':
        pads = [('1', [-0.95, 0], [0.7, 0.7]), ('2', [0.95, 0], [0.7, 0.7])]
        maxima = [1.8, 1.0, 1.0]
        delta = 'Use manufacturer high-current land; preserve updated V3LOAD to V3A, not old V3D.'
    elif ref in ('L1501', 'L1502'):
        pads = [('1', [-0.7, 0], [0.69, 1.02]), ('2', [0.7, 0], [0.69, 1.02])]
        maxima = [1.75, 1.09, 1.092]
        delta = 'Body H<=0.94mm before optional solder, optional solder adds <=0.152mm; reserve 1.10mm component envelope. Pair not factory matched: worst |L1-L2|<=0.4nH at specified test conditions.'
    elif ref == 'FL1501':
        pads = [('1', [-0.925, -0.4], [0.75, 0.4]), ('2', [-0.925, 0.4], [0.75, 0.4]),
                ('3', [0.925, 0.4], [0.75, 0.4]), ('4', [0.925, -0.4], [0.75, 0.4])]
        maxima = [2.2, 1.4, 1.3]
        part['evidence'] = [{'source_id': 'ACM2012H_ZH', 'pdf_pages': [1, 3],
                             'section': 'Exact row, numbered body/land and 1-4 / 2-3 schematic; visually reviewed'}]
        delta = 'Actual 2012 maximum body 2.2x1.4x1.3mm. Manufacturer pad assignment:1=DP_CONN,4=DP_CMC,2=DM_CONN,3=DM_CMC; old placeholder pins must be remapped.'
    else:
        pads = [('1', [-1.15, 0.875], [1.3, 1.05]), ('2', [1.15, 0.875], [1.3, 1.05]),
                ('3', [1.15, -0.875], [1.3, 1.05]), ('4', [-1.15, -0.875], [1.3, 1.05])]
        maxima = [3.4, 2.7, 0.8]
        delta = 'Use official land, default CL18pF. B2 temperature range -20..70C; oscillator margin and actual stray loading remain design checks.'
    sources = []
    for e in part['evidence']:
        s = evidence.get(e.get('source_id'))
        if s:
            sources.append(dict(s, pdf_pages=e['pdf_pages']))
    pin_nets = {p['number']: p.get('net') for p in native[ref]['pins']}
    if ref == 'FL1501':
        pin_nets = {'1': 'USB_DP_CONN', '2': 'USB_DM_CONN', '3': 'USB_DM_CMC', '4': 'USB_DP_CMC'}
    lands.append({'ref': ref, 'selected_mpn': part['mpn'], 'manufacturer': part['manufacturer'],
                  'body_lwh_max_mm': maxima, 'pads': [{'number': n, 'center_xy_mm': xy,
                      'size_xy_mm': sz, 'net': pin_nets[n]} for n, xy, sz in pads],
                  'mechanical_delta': delta, 'evidence': sources,
                  'design_land_selected': True, 'applied_to_global_pcb': False,
                  'procurement_approved': False, 'physical_tests_executed': 0})

doc = {'schema': 'smartvio-v26-early-manufacturer-land/1.0',
       'units': 'mm', 'coordinates': 'top view; x right, y down; origin at body center; pads are rectangles',
       'scope': 'Design-stage handoff, NOT current PCB DRC/assembly certification', 'entries': lands,
       'cap_banks_warning': 'C0G proof-bank plan is in progress; do not freeze C303/C304, C807/C808 or C1902 space on old land.'}
(OUT / 'land-handoff.json').write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('LAND_READY', [e['ref'] for e in lands])
