import copy
import hashlib
import html
import json
import math
import re
import shutil
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/audit/passive-closure'
NATIVE = OUT.parents[1] / 'electrical/native-components.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def dump(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


proposal = read(OUT / 'proposal.json')
old_sha = proposal.get('selection_source_sha256', proposal['source_sha256'])
archive = OUT / ('selection-delivery-' + old_sha[:12])
archive.mkdir(exist_ok=True)
for name in ('proposal.json', 'verification.json', 'application-audit.json', 'correction-patch.json',
             'mpn-package-patch.json', 'new-components.json', 'calculations.json', 'source-followup.json',
             'land-handoff.json', 'report.html'):
    target = archive / name
    if not target.exists():
        shutil.copyfile(OUT / name, target)

native_bytes = NATIVE.read_bytes()
latest_sha = hashlib.sha256(native_bytes).hexdigest()
native = json.loads(native_bytes)
live = {c['ref']: c for c in native}
assert len(live) == len(native)
snapshot = WORK / ('native-' + latest_sha[:16] + '.json')
if not snapshot.exists():
    snapshot.write_bytes(native_bytes)
scope = {r for r, c in live.items() if c.get('type') in ('C', 'L', 'FB', 'CMC', 'XTAL')}
rows = proposal['per_ref']
assert {r['ref'] for r in rows} == scope
assert len(rows) == len(scope)
catalog = {p['mpn']: p for p in proposal['part_catalog']}
quick_patch = read(archive / 'mpn-package-patch.json')
full_patch = read(archive / 'correction-patch.json')
new = read(OUT / 'new-components.json')
initial_selection = read(WORK / ('native-' + old_sha[:16] + '.json'))
initial_map = {c['ref']: c for c in initial_selection}
selection_rows = {r['ref']: r for r in read(archive / 'proposal.json')['per_ref']}
old_mag_candidates = {c['ref']: c['candidate'] for c in read(OUT.parent / 'critical-passives/proposal.json')['components'] if c.get('candidate') and c['ref'] in {x['ref'] for x in read(OUT / 'magnetics-clock-patch.json')['changes']}}

merged = []
unmerged = []
for change in quick_patch['changes']:
    c = live[change['ref']]
    equal = all(c.get(k) == v for k, v in change['set_fields'].items())
    assert c['pins'] == change['source_pins_guard'], change['ref']
    (merged if equal else unmerged).append(change['ref'])
assert len(merged) == 100 and not unmerged, (len(merged), unmerged)
magnetic = read(OUT / 'magnetics-clock-patch.json')
for change in magnetic['changes']:
    assert all(live[change['ref']].get(k) == v for k, v in change['set_fields'].items()), change['ref']

pending = [copy.deepcopy(c) for c in full_patch['changes'] if c['ref'] not in merged]
assert len(pending) == 10
for change in pending:
    c = live[change['ref']]
    assert c['pins'] == change['source_pins_guard'], change['ref']
    assert c['value'] == initial_map[c['ref']]['value'], c['ref']
    change['guard'] = {k: copy.deepcopy(c.get(k)) for k in change['set_fields']}

new_refs = [c['ref'] for c in new['components']]
assert len(new_refs) == len(set(new_refs)) == 30
assert not (set(new_refs) & set(live))
for c in new['components']:
    if c.get('bank_anchor'):
        assert c['pins'] == live[c['bank_anchor']]['pins']
    assert c['application_approved'] is False and c['procurement_approved'] is False

# Dry-run the remaining compound ECO only in memory, preserving all parent-owned fields.
dry = copy.deepcopy(live)
for c in pending:
    assert all(dry[c['ref']].get(k) == v for k, v in c['guard'].items())
    dry[c['ref']].update(copy.deepcopy(c['set_fields']))
for c in new['components']:
    dry[c['ref']] = copy.deepcopy(c)
assert all(dry[r]['pins'] == live[r]['pins'] for r in live)
assert all(dry[r] == live[r] for r in live if r not in {c['ref'] for c in pending})
for ref, bank in proposal['selected_parallel_banks'].items():
    assert all(r in dry for r in bank['refs'])
    assert all(dry[r]['pins'] == live[ref]['pins'] for r in bank['refs'])

standard_current = []
for row in rows:
    c = live[row['ref']]
    row['selection_snapshot_before'] = {k: selection_rows[row['ref']].get('current_' + k) for k in ('mpn', 'value', 'package', 'pins')}
    row.update(current_mpn=c.get('mpn'), current_value=c['value'], current_package=c.get('package'),
               current_pins=copy.deepcopy(c['pins']), current_source_sha256=latest_sha)
    row['parent_native_integration'] = ('MPN_PACKAGE_MERGED_BY_PARENT' if c['ref'] in merged else
                                        'MAGNETICS_CLOCK_MERGED_BY_PARENT' if c['type'] != 'C' else
                                        'ANCHOR_SUBSTITUTION_NOT_MERGED_PROPOSAL_ONLY')
    row['current_ceff_min_uF'] = None
    if c['type'] == 'C':
        part = catalog[row['selected_mpn']]
        bound = part.get('cap_bound') if c.get('mpn') == row['selected_mpn'] and not row.get('bank') else None
        row['current_standard_test_capacitance_bound_uF'] = copy.deepcopy(bound)
        row['current_operating_frequency_ceff_min_uF'] = None
        row['current_ceff_basis'] = ('Manufacturer-specification C0G budget at declared LCR conditions available; no full working-frequency/ESR/transient or assembly approval'
                                   if bound else 'No current exact-MPN combined biased/temperature/aging lower bound; unmerged banks cannot be credited')
        if bound:
            standard_current.append(row['ref'])
    else:
        part = copy.deepcopy(old_mag_candidates[row['ref']])
        part['evidence'] = copy.deepcopy(row['manufacturer_land']['evidence'])
        part['package']['body_lwh_max_mm'] = row['manufacturer_land']['body_lwh_max_mm']
        part['package']['manufacturer_numbered_pads'] = row['manufacturer_land']['pads']
        if c['ref'] == 'FL1501':
            part['identity_status'] = 'EXACT_MPN_AND_NUMBERED_LAND_VERIFIED_FROM_OFFICIAL_CHINESE_CATALOG'
            part['package']['numbered_pad_topology_status'] = 'DRAWING_VERIFIED_1_TO_4_AND_2_TO_3'
        elif c['ref'] == 'Y801':
            part['identity_status'] = 'MANUFACTURER_ORDERING_TABLE_CONFIGURATION_SELECTED_DESIGN_STAGE'
            part['purchasing']['exact_order_code_documented'] = 'MANUFACTURER_ORDERING_CONFIGURATION'
            part['purchasing']['stock_verified'] = False
            part['purchasing']['factory_confirmation_is_design_closure_blocker'] = False
        row['selected_part'] = part
    assert row['application_approved'] is False and row['procurement_approved'] is False

counts = Counter(r['selection_status'] for r in rows)
closure = copy.deepcopy(proposal['closure_counts'])
closure.update(parent_merged_nominal_preserving_capacitor_changes=len(merged),
               remaining_anchor_substitutions_proposal_only=len(pending),
               remaining_new_capacitors_proposal_only=len(new_refs),
               current_standard_test_capacitance_budget_count=len(standard_current),
               current_capacitors_without_standard_test_bias_temperature_lower_budget=110-len(standard_current),
               current_arbitrary_operating_frequency_ceff_min_proven=0,
               all_project_287_closure_claim=False)
assert len(standard_current) == 28
assert counts['HOLD_NO_GUARANTEED_OPERATING_CEFF_MIN'] == 74
assert proposal['charge_pump']['ratio_check']
assert proposal['vcap']['capacitance_window_pass']
assert proposal['selected_parallel_banks']['C1902']['bound']['cap_min_uF'] >= 1

sources = read(OUT / 'source-evidence.json')
assert len({s['id'] for s in sources}) == len(sources)
evidence_checks = []
for s in sources:
    p = OUT / s['path']
    assert p.is_file() and p.read_bytes().startswith(b'%PDF')
    assert sha(p) == s['sha256'], s['id']
    assert s['manufacturer_url'].startswith('https://')
    evidence_checks.append({'id': s['id'], 'path': s['path'], 'sha256_matches': True})

for p in catalog.values():
    assert p['mpn'] in {s['id'] for s in sources}
    assert all(v > 0 for v in p['body_lwh_max_mm'])
    assert p['land']['pads'][0]['number'] == '1'
    if p['dielectric'] != 'C0G':
        assert p.get('cap_bound') is None
        assert p['standard_test_specification_ceff_min_uF'] is None

common = {k: proposal[k] for k in ('source_path', 'scope_count', 'scope_refs', 'physical_tests_executed',
                                  'global_native_pcb_firmware_written', 'procurement_approved')}
common.update(generated_utc=datetime.now(timezone.utc).isoformat(), source_sha256=latest_sha,
              selection_source_sha256=old_sha, source_part_count=len(native),
              source_pin_count=sum(len(c['pins']) for c in native))
parent = dict(common, schema='smartvio-v26-passive-parent-integration-followup/1.0',
              immutable_selection_delivery=archive.name, parent_merged_100_refs=merged,
              parent_merged_magnetics_clock_refs=[c['ref'] for c in magnetic['changes']],
              proposal_only_anchor_refs=[c['ref'] for c in pending], proposal_only_new_refs=new_refs,
              closure_counts=closure, current_standard_test_budget_refs=standard_current,
              before_after=[{'ref': r, 'before': initial_map[r], 'after': live[r]} for r in merged],
              claims={'all_287_closed': False, 'overall_pass': False, 'manufacturing_release': False,
                      'bank_installed': False, 'physical_tests_executed': 0},
              active_287_count='Parent/global active-selection count outside this 116-ref audit; not independently closed here')
dump('parent-integration-followup.json', parent)
proposal.update(common)
proposal.update(parent_integration_followup='parent-integration-followup.json', closure_counts=closure,
                immutable_before_after_archive=archive.name, pending_eco_patch='pending-eco-patch.json')
dump('proposal.json', proposal)
app = read(OUT / 'application-audit.json')
app.update(common)
app.update(rows=rows, closure_counts=closure, parent_integration_followup='parent-integration-followup.json',
           current_guaranteed_ceff_min_count=0,
           current_standard_test_capacitance_budget_count=28,
           warning='Current standard-test C0G budgets28 differ from actual full operating-frequency Ceff proofs0. Proposed minimum unknown74;8 bank replacements remain unmerged, so current standard-test unknown82. No 287-wide approval.')
dump('application-audit.json', app)
dump('pending-eco-patch.json', dict(common, schema='smartvio-v26-passive-pending-compound-eco/1.0',
                                  applied=False, changes=pending, requires_parent_explicit_design_acceptance=True,
                                  required_new_components_file='new-components.json',
                                  new_component_count=30, application_approved=False,
                                  instructions='Ten anchors + thirty additions proposal only. Do not apply banks piecemeal. Polarized C1102/C1106 require anode1 rail/cathode2 GND. No existing capacitor pin/net changes. Full circuit, geometry and current acceptance outstanding.'))
quick_live = read(OUT / 'mpn-package-patch.json')
quick_live.update(applied_by_parent_observed=True, parent_merge_observation_sha256=latest_sha,
                  parent_merged_change_count=100, do_not_replay=True,
                  original_guard_source_sha256=old_sha)
dump('mpn-package-patch.json', quick_live)
full_live = read(OUT / 'correction-patch.json')
full_live.update(parent_merged_refs=merged, unapplied_remaining_refs=[c['ref'] for c in pending],
                 remaining_patch='pending-eco-patch.json', original_guard_source_sha256=old_sha,
                 instructions='Historical full proposal:100 changes merged by parent;10 remaining anchors+30new unmerged. Use pending-eco-patch.json for outstanding ECO. Preserve original guards/before snapshot. No complete patch replay.')
dump('correction-patch.json', full_live)
new.update(current_parent_source_sha256=latest_sha, parent_merge_observed=False,
           integration_patch='pending-eco-patch.json')
dump('new-components.json', new)
follow = read(OUT / 'source-followup.json')
follow.update(post_capacitor_parent_merge_source_sha256=latest_sha,
              post_capacitor_parent_merge_part_count=len(native),
              post_capacitor_parent_merge_pin_count=common['source_pin_count'],
              parent_capacitor_merge_record='parent-integration-followup.json',
              parent_R826_and_latest_NTC_preserved=True)
dump('source-followup.json', follow)

calc = read(OUT / 'calculations.json')
calc.update(parent_merge_observation_sha256=latest_sha,
            selected_capacitor_banks_applied=False)
vcap = calc['vcap']
vcap['post_environment_DF_25C_1kHz_limit_percent'] = .5
vcap['post_environment_ESR_25C_1kHz_allowance_ohm_not_failure_measurement'] = .005 / (2 * math.pi * 1000 * vcap['bound_each']['cap_min_uF'] * 1e-6)
vcap['post_environment_note'] = 'The datasheet permits DF up to0.5% after the stated environmental tests. Thus initial0.1% DF alone cannot establish VCAP ESR<0.1ohm over qualification and working band. No actual failing ESR has been measured.'
dump('calculations.json', calc)
proposal['vcap'] = vcap
dump('proposal.json', proposal)
dump('magnetics-ratings.json', dict(common, rows=[r for r in rows if r['kind'] != 'C'],
                                   basis='Original manufacturer PDF ratings; package/numbered-land update from V26 original sources. No current or signal-integrity approval.'))

verification = read(OUT / 'verification.json')
verification.update(common)
verification.update(closure_counts=closure, no_overall_pass=True,
                    current_native_unchanged_during_build='See immutable selection-delivery snapshot for original build; parent100 authorized merge recorded separately',
                    current_native_unchanged_during_finalization=NATIVE.read_bytes() == native_bytes,
                    original_manufacturer_pdf_count=len(sources),
                    source_evidence_hash_checks=evidence_checks,
                    guarded_pending_eco_dry_run={'performed': True, 'global_written': False,
                        'resulting_parts_if_parent_accepts_all': len(dry),
                        'resulting_pins_if_parent_accepts_all': sum(len(c['pins']) for c in dry.values()),
                        'existing_capacitor_pins_unchanged': True,
                        'all_unrelated_components_unchanged': True,
                        'bank_atomic_members_present': True},
                    current_standard_test_capacitance_budget_count=28,
                    current_capacitors_without_standard_test_lower_budget_count=82,
                    parent_integration_followup='parent-integration-followup.json',
                    pending_patch='pending-eco-patch.json',
                    whole_project_287_application_approved=False,
                    source_snapshot_preserved=str(snapshot.relative_to(ROOT)))
dump('verification.json', verification)

unclosed = [
    '74 selected existing capacitor rows have no quantitative combined DC-bias/temperature/aging Ceff lower limit. This includes polymer converter parts; qualification numbers are not converter-frequency guarantees.',
    '8 bank anchors are not replaced and30 added capacitors do not exist in current native. Proposed36 C budgets consist of28 now-selected single C0G parts and8 unmerged banks. Current standard-test lower-budget unknown82, not merely74.',
    'VCAP proposed2.35uF window2.219125..2.482327uF meets1.76..2.64uF. Working-band ESR and post-environment DF limits do not prove<100mohm; bank placement not accepted.',
    'C303/C304 proposed1.04/2.35uF ratio closes declared-test capacity relation only. Flying-loop inductance, ESR/ripple and maximum differential voltage are not guaranteed. A bulky2220 bank is not a drop-in0805.',
    'C1102 proposed10->22uF polarized polymer andC1106 polarized substitution are not merged. C1104/C1105 current44uF nominal does not prove >=18uF effective output; C2351 47uF addition remains conditional/unmerged.',
    'C1902 current2.2uF X7R16V has no proved>=1uF floor at assumed3.45V. Its proposed2.35uF C0G bank has a declared-test floor2.219125uF but is not installed. Input droop/CIN-CL ratio remains open.',
    'QOD196.184543uF is a conditional estimate including10uF ASSUMED module allowance, not guaranteed CLmax<200uF. TI200uF condition is internal QOD only; parent1k resistor does not establish module capacitance or pulse-energy acceptance.',
    'C1501 retains2.2uF nominal; manufacturer recommends10uF VPWR. Minimum-only1.41uF C0G option does not close that recommendation. C1502 latest USB_VREF untouched; historical USB tentative board is not a current-routed defect claim.',
    'C501/C502/C503 and audio couplingC121/C211/C212 remain biased-capacity HOLD. Very large strict C0G replacement banks are mathematical options only, not board-fit or transient approval.',
    'L1101 max4.3x4.3x2.1 exceeds former4x4x2 target.5.3A is20% inductance-drop Isat at25C, not a guaranteed5A hot inductance/current floor. L1501/2 each2% tolerance imply worst difference0.4nH, not factory-matched.',
    'FB1101 zero-bias120ohm and CMC90ohm typical/min65ohm do not guarantee loaded filtering or USB eye. CMC manufacturer series paths1-4,2-3 already merged; full path signal integrity remains open.',
    'Y801 B2 limits temperature to-20..70C. CL18pF requires unknown actual stray capacitance; oscillator startup and drive margin are not established by ordering code alone.',
    'All new and changed lands require PCB assembly clearance/process acceptance. YAGEO CC lands use explicitly labelled same-body-size cross-grade manufacturer adaptation, not exact CC-series land endorsement.',
    'This worker audited116 C/L/FB/CMC/XTAL refs, not all287 active selections or all316 native parts. Resistor/IC/system approval is outside this scope. Phys0, procurement0, full_application0.',
]
dump('remaining-holds.json', dict(common, closure_counts=closure, remaining=unclosed,
                                 no_supplier_or_sample_wait_started=True,
                                 status='BOUNDED_DESIGN_AUDIT_HANDOFF_NOT_MANUFACTURING_RELEASE'))

links = ['proposal.json', 'verification.json', 'application-audit.json', 'parent-integration-followup.json',
         'mpn-package-patch.json', 'pending-eco-patch.json', 'correction-patch.json', 'new-components.json',
         'land-handoff.json', 'footprint-index.json', 'calculations.json', 'strict-ceff-options.json',
         'remaining-holds.json', 'source-evidence.json', 'source-followup.json', 'magnetics-ratings.json']
report = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>SmartVio V26 Passive Final Handoff</title><style>body{font:14px system-ui;margin:24px;color:#202020}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:7px;text-align:left;vertical-align:top}th{background:#eee}a{color:#005a92}li,code{overflow-wrap:anywhere}</style><h1>SmartVio V26 Passive Final Handoff</h1>'
report += f'<p>Current source: {len(native)} parts / {common["source_pin_count"]} pins, SHA256 <code>{latest_sha}</code>. Original selection source <code>{old_sha}</code> retained in {archive.name}.</p>'
report += '<p><b>100 nominal-preserving capacitor selections merged by parent;6 magnetics/clock selections already merged.10 anchor substitutions and30 new capacitors remain PROPOSAL ONLY. No overall PASS; no all287 closure; procurement0 / full application0 / Phys0.</b></p>'
report += '<p>116 existing refs:110 capacitors+6 magnetics/clock.36 proposed declared-test C bounds:28 selected individual C0G parts now in native+8 unmerged banks.74 selected rows still lack a guaranteed biased lower Ceff. Therefore current standard-test C budget known28 / unknown82; full working-band Ceff proof0. Nominal is not retained Ceff.</p>'
report += '<p>' + ' / '.join(f'<a href="{f}">{f}</a>' for f in links) + '</p><h2>Remaining Holds</h2><ol>'
report += ''.join('<li>' + html.escape(x) + '</li>' for x in unclosed) + '</ol>'
report += '<h2>Per-Ref Application Audit</h2><table><tr><th>Ref</th><th>Current MPN</th><th>Selected MPN</th><th>Native Integration</th><th>Current standard-test min uF</th><th>Proposed standard-test min uF</th><th>Open Checks</th></tr>'
for row in rows:
    current = row.get('current_standard_test_capacitance_bound_uF')
    app = row.get('application_audit', {})
    proposed = app.get('proposed_ceff_min_uF_at_declared_test_conditions')
    values = [row['ref'], row.get('current_mpn') or '-', row['selected_mpn'], row['parent_native_integration'],
              f'{current["cap_min_uF"]:.9g}' if current else 'UNKNOWN',
              f'{proposed:.9g}' if proposed is not None else 'HOLD',
              '; '.join(app.get('open_application_checks', row.get('remaining_checks', [])))]
    report += '<tr>' + ''.join('<td>' + html.escape(str(v)) + '</td>' for v in values) + '</tr>'
report += '</table><h2>Packaged Original Manufacturer PDFs</h2><ul>'
for s in sources:
    path = s['path'].replace('\\', '/')
    report += '<li>' + html.escape(s['id']) + ': <a href="' + html.escape(path) + '">original PDF</a> / <a href="' + html.escape(s['manufacturer_url']) + '">manufacturer</a> / SHA256 ' + s['sha256'] + '</li>'
report += '</ul></html>'
(OUT / 'report.html').write_text(report, encoding='utf-8')
for href in re.findall(r'href="([^"]+)"', report):
    if not href.startswith('https://'):
        assert (OUT / html.unescape(href)).exists(), href

readme = f'''# V26 passive handoff

Current native:316 parts /1081 pins, SHA256 `{latest_sha}`.
Selection before:`{old_sha}` preserved in `{archive.name}/`.

100 capacitor selections and6 magnetic/clock selections are observed merged by parent.
10 remaining anchors +30 new capacitors are proposal only. Use `pending-eco-patch.json`
with `new-components.json` atomically; do not replay the historical100-field patch.
This worker did not write global native/PCB/firmware. All tests Phys0.

Scope116=110 C+3 L+1 FB+1 CMC+1 crystal, not all287 active selections.
Proposed C budgets36; proposed Ceff unknown74. Current standard-test budgets28,
current unknown82 because8 proposed banks are not installed. Full application0,
procurement0, arbitrary working-band Ceff proof0. No overall PASS.

`report.html` links all49 original PDFs through relative `source-evidence/` paths,
plus manufacturer URLs and SHA256. Copy this entire audit directory for portable links.
`Passive_V26_ManufacturerLand.pretty/` is an uninstalled design-stage footprint library.
Pads are manufacturer-derived; no global board fit/routing/assembly acceptance implied.
Polarized polymer replacements:pad1 anode=rail,pad2 cathode=GND. C0G banks retain
original anchor nets; each2220 body maximum6.1x5.4x1.85mm. Not drop-in0805 replacements.

See `remaining-holds.json`, every-ref `application-audit.json`, and `verification.json`.
''' 
(OUT / 'README.md').write_text(readme, encoding='utf-8')
print('FINALIZED', latest_sha, 'merged', len(merged), 'pending', len(pending), 'new', len(new_refs), 'current_std_C', len(standard_current), 'unknown', 110-len(standard_current), 'sources', len(sources))
