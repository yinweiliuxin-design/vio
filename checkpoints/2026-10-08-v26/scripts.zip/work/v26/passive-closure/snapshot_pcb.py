import hashlib
import json
import math
import os
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
ENGINE = ROOT / 'outputs/SmartVio-V26-Engineering'
OUT = ENGINE / 'audit/passive-closure'
os.environ['KICAD_CONFIG_HOME'] = str(WORK / 'kicad-config')
os.environ['KICAD_DOCUMENTS_HOME'] = str(WORK / 'documents')
import pcbnew as pcb

native = json.loads((ENGINE / 'electrical/native-components.json').read_text(encoding='utf-8'))
refs = {c['ref'] for c in native if c.get('type') in ('C', 'L', 'FB', 'CMC', 'XTAL')}
result = {'scope': 'Read-only named board snapshots, not final routed V26 verification', 'boards': []}
for name, kind in [('SmartVio-main-v26-ground-seeded', 'V26_WORK_IN_PROGRESS_NAMED_SNAPSHOT'),
                   ('SmartVio-audio-tentative', 'INHERITED_HISTORICAL_BOARD'),
                   ('SmartVio-usb-tentative', 'INHERITED_HISTORICAL_BOARD')]:
    path = ENGINE / 'pcb-work' / (name + '.kicad_pcb')
    if not path.exists():
        continue
    data = path.read_bytes()
    board = pcb.LoadBoard(str(path))
    record = {'path': str(path.relative_to(ROOT)), 'classification': kind,
              'sha256_before': hashlib.sha256(data).hexdigest(), 'components': {}}
    for f in board.GetFootprints():
        if f.GetReference() not in refs:
            continue
        angle = math.radians(f.GetOrientationDegrees())
        origin = f.GetPosition()
        pads = []
        for p in f.Pads():
            x = pcb.ToMM(p.GetPosition().x - origin.x)
            y = pcb.ToMM(p.GetPosition().y - origin.y)
            pads.append({'number': p.GetNumber(), 'net': p.GetNetname(),
                         'local_xy_mm': [round(x * math.cos(angle) - y * math.sin(angle), 6),
                                         round(x * math.sin(angle) + y * math.cos(angle), 6)],
                         'size_xy_mm': [pcb.ToMM(p.GetSize().x), pcb.ToMM(p.GetSize().y)]})
        record['components'][f.GetReference()] = {'footprint_id': str(f.GetFPID()), 'pads': pads,
                                                 'angle_deg': f.GetOrientationDegrees(),
                                                 'side': 'B' if f.IsFlipped() else 'F'}
    record['sha256_after'] = hashlib.sha256(path.read_bytes()).hexdigest()
    record['unchanged_during_read'] = record['sha256_before'] == record['sha256_after']
    result['boards'].append(record)
(OUT / 'pcb-readonly-snapshot.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('BOARD_SNAPSHOT', [(b['classification'], len(b['components']), b['unchanged_during_read']) for b in result['boards']])
