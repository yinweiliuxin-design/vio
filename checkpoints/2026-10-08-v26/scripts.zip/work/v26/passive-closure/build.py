import copy
import hashlib
import html
import json
import math
import re
import shutil
import unicodedata
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
ENGINE = ROOT / 'outputs/SmartVio-V26-Engineering'
OUT = ENGINE / 'audit/passive-closure'
NOW = datetime.now(timezone.utc).isoformat()


def dump(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normal(text):
    return ''.join(c for c in unicodedata.normalize('NFKC', text) if unicodedata.category(c) != 'Cf')


sources = {s['id']: s for s in read(OUT / 'source-evidence.json')}


def evidence(sid, pages, section):
    s = sources[sid]
    return {'source_id': sid, 'manufacturer_url': s['manufacturer_url'], 'path': s['path'],
            'sha256': s['sha256'], 'pdf_pages': pages, 'section': section}


data_path = ENGINE / 'electrical/native-components.json'
native_bytes = data_path.read_bytes()
native = json.loads(native_bytes)
SOURCE_SHA = hashlib.sha256(native_bytes).hexdigest()
snapshot_path = WORK / ('native-' + SOURCE_SHA[:16] + '.json')
if not snapshot_path.exists():
    snapshot_path.write_bytes(native_bytes)
byref = {c['ref']: c for c in native}
assert len(byref) == len(native)
refs = sorted([r for r, c in byref.items() if c.get('type') in ('C', 'L', 'FB', 'CMC', 'XTAL')],
              key=lambda r: (re.sub(r'\d', '', r), int(re.search(r'\d+', r).group())))
old = read(OUT.parent / 'critical-passives/proposal.json')
old_catalog = {c['candidate']['mpn']: c['candidate'] for c in old['components'] if c.get('candidate')}
mag_patch = read(OUT / 'magnetics-clock-patch.json')
mag_byref = {c['ref']: c for c in mag_patch['changes']}
pcb_snap = read(OUT / 'pcb-readonly-snapshot.json')

KEM_LANDS = {'0603': (0.8, [0.95, 1.0], [3.1, 1.5]),
             '1206': (1.5, [1.15, 1.8], [4.7, 2.3]),
             '2220': (2.65, [1.5, 5.4], [7.3, 5.9])}
YC_LANDS = {'0603': (0.75, [0.8, 0.9], [2.7, 1.5]),
            '0805': (0.925, [0.95, 1.4], [3.2, 2.1])}


def two_pad_land(center, size):
    return [{'number': '1', 'center_xy_mm': [-center, 0], 'size_xy_mm': size},
            {'number': '2', 'center_xy_mm': [center, 0], 'size_xy_mm': size}]


def c0g_bound(uf, tol=0.05):
    # Full rated temperature span, plus one published post-environment shift allowance.
    shift = max(.003, .25e-6 / uf)
    return {'cap_nominal_uF': uf, 'cap_min_uF': uf * (1 - tol) * 0.997 * (1 - shift),
            'cap_max_uF': uf * (1 + tol) * 1.003 * (1 + shift),
            'tolerance_fraction': tol, 'temperature_range_C': [-55, 125],
            'tcc_ppm_per_C': 30, 'reference_C': 25, 'max_delta_T_C': 100,
            'temperature_factor_min_max': [0.997, 1.003],
            'post_environment_shift_fraction': shift,
            'post_environment_basis': 'Maximum of 0.3% or 0.25pF; one manufacturer qualification allowance',
            'environment_scope': 'One published qualification allowance, not arbitrary combined or unlimited sequential damage',
            'aging_percent_per_decade_hour': 0, 'dc_bias_factor': 1.0,
            'dc_bias_basis': 'KEM_C0G_SMD pp1-2: no capacitance change with applied rated DC voltage',
            'frequency_scope': 'Capacitance at manufacturer LCR test frequency (1kHz for >1nF, 1MHz for <=1nF); NOT impedance/ESR guarantee over switching band',
            'evidence_class': 'SPECIFICATION_BASED_STANDARD_TEST_CAPACITANCE_BOUND',
            'formula_min': 'Cnom*(1-tol)*(1-30e-6*100)*(1-max(0.003,0.25pF/Cnom))',
            'formula_max': 'Cnom*(1+tol)*(1+30e-6*100)*(1+max(0.003,0.25pF/Cnom))'}


catalog = {}
cap_specs = [
    ('CC0603KRX7R7BB104', 0.1, 10, 16, 'X7R', '0603'),
    ('CC0603KRX7R9BB104', 0.1, 10, 50, 'X7R', '0603'),
    ('CC0603KRX7R7BB105', 1, 10, 16, 'X7R', '0603'),
    ('CC0805KKX7R7BB105', 1, 10, 16, 'X7R', '0805'),
    ('CC0603KRX7R7BB225', 2.2, 10, 16, 'X7R', '0603'),
    ('CC0805KKX7R7BB225', 2.2, 10, 16, 'X7R', '0805'),
    ('CC0805KKX7R6BB475', 4.7, 10, 10, 'X7R', '0805'),
    ('CC0805KKX5R6BB106', 10, 10, 10, 'X5R', '0805'),
    ('CC0805MKX5R6BB226', 22, 20, 10, 'X5R', '0805'),
    ('C0603C103J3GACTU', 0.01, 5, 25, 'C0G', '0603'),
    ('C0603C102J5GACTU', 0.001, 5, 50, 'C0G', '0603'),
    ('C0603C222J5GACTU', 0.0022, 5, 50, 'C0G', '0603'),
    ('C0603C472J5GACTU', 0.0047, 5, 50, 'C0G', '0603'),
    ('C0603C300J5GACTU', 0.000030, 5, 50, 'C0G', '0603'),
    ('C1206C104J3GACTU', 0.1, 5, 25, 'C0G', '1206'),
    ('C2220C474J5GACTU', 0.47, 5, 50, 'C0G', '2220'),
]
for mpn, uf, tol, volts, dielectric, case in cap_specs:
    txt = normal(read(WORK / 'text' / (mpn + '.json'))[0]['text'])
    assert mpn in re.sub(r'\s+', '', txt), mpn
    assert f'{volts} VDC' in txt or f'{volts}VDC' in txt, mpn
    dimensions = {k: [float(a), float(b)] for k, a, b in re.findall(
        r'([LWT])\s+([\d.]+)mm\s*\+/-([\d.]+)mm', txt)}
    assert set(dimensions) == set('LWT'), mpn
    maximum = [sum(dimensions[k]) for k in 'LWT']
    kem = mpn.startswith('C0') or mpn.startswith('C1') or mpn.startswith('C2')
    if kem:
        center, pads, courtyard = KEM_LANDS[case]
        land_evidence = evidence('KEM_C0G_SMD', [12], 'Table3 density B; C is pad center distance, Y along body, X across body')
        land_status = 'EXACT_SERIES_MANUFACTURER_RECOMMENDATION'
    else:
        center, pads, courtyard = YC_LANDS[case]
        land_evidence = evidence('YAGEO_MLCC_LAND', [18], 'Table14 reflow MLCC body-size land; GP CC selected body dimensions checked separately')
        land_status = 'MANUFACTURER_SAME_BODY_SIZE_CROSS_GRADE_LAND_ADAPTATION_NOT_EXACT_CC_SERIES_ENDORSEMENT'
    part = {'mpn': mpn, 'manufacturer': 'KEMET / YAGEO Group' if kem else 'YAGEO',
            'kind': 'MLCC', 'nominal_uF': uf, 'tolerance_percent': tol, 'rated_voltage_V': volts,
            'dielectric': dielectric, 'temperature_range_C': [-55, 85 if dielectric == 'X5R' else 125],
            'package_eia': case, 'body_lwh_max_mm': maximum, 'height_max_mm': maximum[2],
            'land': {'pads': two_pad_land(center, pads), 'courtyard_xy_mm': courtyard,
                     'status': land_status, 'evidence': land_evidence},
            'purchasing': {'order_code_in_manufacturer_pdf': True, 'rohs': True, 'termination': 'Tin',
                           'stock_and_quote_checked': False, 'procurement_approved': False},
            'evidence': [evidence(mpn, [1], 'Exact code, value, tolerance, voltage, L/W/T, packaging')],
            'cap_bound': c0g_bound(uf, tol / 100) if kem else None,
            'standard_test_specification_ceff_min_uF': None,
            'arbitrary_working_frequency_ceff_min_uF': None,
            'esr_switching_band_max_ohm': None}
    if kem:
        part['evidence'].append(evidence('KEM_C0G_SMD', [1, 2, 4, 12, 14], 'DC/time invariance, TCC/DF, post-environment limits, land and qualification scope'))
        part['standard_test_specification_ceff_min_uF'] = part['cap_bound']['cap_min_uF']
    else:
        sid = 'YAGEO_X5R' if dielectric == 'X5R' else 'YAGEO_X7R'
        part['evidence'].append(evidence(sid, [1], 'Class-II dielectric; temperature definition is NOT DC-bias combined guarantee'))
        part['dc_bias'] = {'guaranteed_retention_fraction': None, 'current_ceff_min_uF': None,
                           'safe_credit_toward_guaranteed_min_uF': 0,
                           'reason': 'No quantitative combined bias/temperature/aging lower limit for exact MPN; larger nominal alone is not proof'}
        part['zero_bias_initial_temp_only_uF'] = [uf * (1 - tol / 100) * .85, uf * (1 + tol / 100) * 1.15]
    catalog[mpn] = part

for mpn, uf, case, maxima, center, pads, courtyard, esr, ripple in [
    ('T520A226M010ATE080', 22, '3216-18', [3.4, 1.8, 1.8], 1.31, [1.8, 1.23], [4.92, 2.3], .080, 1.2),
    ('T520U476M010ATE055', 47, '6032-15', [6.3, 3.4, 1.5], 2.47, [2.37, 2.23], [7.82, 4.0], .055, 1.6),
]:
    txt = normal(read(WORK / 'text' / (mpn + '.json'))[0]['text'])
    assert mpn in re.sub(r'\s+', '', txt)
    catalog[mpn] = {'mpn': mpn, 'manufacturer': 'KEMET / YAGEO Group', 'kind': 'POLARIZED_POLYMER_TANTALUM',
                    'nominal_uF': uf, 'tolerance_percent': 20, 'rated_voltage_V': 10,
                    'dielectric': 'POLYMER_TANTALUM', 'temperature_range_C': [-55, 105],
                    'package_eia': case, 'body_lwh_max_mm': maxima, 'height_max_mm': maxima[2],
                    'polarity': 'Pad1 anode (+), pad2 cathode (-); cathode must remain GND',
                    'land': {'pads': two_pad_land(center, pads), 'courtyard_xy_mm': courtyard,
                             'status': 'EXACT_SERIES_MANUFACTURER_DENSITY_B',
                             'evidence': evidence('KEM_POLYMER', [9, 37], 'T520 case drawing and density-B land; terminal polarity')},
                    'cap_bound': None, 'standard_test_specification_ceff_min_uF': None,
                    'arbitrary_working_frequency_ceff_min_uF': None,
                    'qualification_only_budget': {'initial_min_uF_120Hz_25C': uf * .8,
                        'stacked_min_uF': uf * .8 * .7 * .8,
                        'stacked_max_uF': uf * 1.2 * 1.3 * 1.35,
                        'factors': {'tolerance_min': .8, 'temperature_test_min': .7,
                                    'endurance_test_min': .8, 'temperature_test_max': 1.3,
                                    'humidity_test_max': 1.35},
                        'status': 'CONSERVATIVE_QUALIFICATION_STACK_NOT_GUARANTEED_OPERATING_CEFF',
                        'missing': ['No quantitative bias factor over operating voltage',
                                    'No guaranteed capacitance-vs-frequency lower bound at converter frequencies',
                                    'Individual environmental tests do not warrant arbitrary sequential in-service stresses']},
                    'esr_25C_100kHz_max_ohm': esr, 'ripple_45C_100kHz_max_A': ripple,
                    'purchasing': {'order_code_in_manufacturer_pdf': True, 'rohs': True,
                                   'MSL': 3, 'stock_and_quote_checked': False, 'procurement_approved': False},
                    'evidence': [evidence(mpn, [1], 'Exact MPN, dims, ratings and packaging'),
                                 evidence('KEM_POLYMER', [3, 4, 5, 6, 9, 23, 37], 'Ordering, test conditions/limits, exact22/47uF rows, land')]}


def voltage(c):
    nets = [p.get('net') for p in c['pins']]
    if 'VBUS_RAW' in nets:
        return {'normal_or_fault_design_budget_V': 30, 'budget_class': 'ASSUMED_FAULT_SCENARIO_NOT_CLAMP_LIMIT', 'guaranteed_transient_upper_V': None}
    if 'USB_5V_SAFE' in nets:
        return {'static_accepted_input_comparator_envelope_V': 5.889424444444445,
                'normal_design_budget_V': 6, 'budget_class': '6V_ASSUMED_STATIC_BUDGET;5.8894V_THRESHOLD_CALC_NOT_TRANSIENT_CLAMP',
                'guaranteed_transient_upper_V': None}
    if 'SYS' in nets or 'PACK_PLUS' in nets:
        return {'normal_design_budget_V': 4.5 if 'SYS' in nets else 4.25,
                'budget_class': 'BQ24074_REGULATED_SYS_STEADY_MAX4.5V' if 'SYS' in nets else 'ASSUMED_CELL_PLUS_CHARGE_MARGIN',
                'guaranteed_transient_upper_V': None}
    if any(n in ('HP_CPP', 'HP_CPN', 'DAC_CPP', 'DAC_CPN') for n in nets):
        return {'differential_design_budget_V': 6.9, 'budget_class': 'ASSUMED_CONSERVATIVE_TWO_PIN_ENVELOPE_2*3.45V_NOT_MEASURED',
                'guaranteed_transient_upper_V': None}
    if any(n in ('HP_NEG', 'HP_POS', 'DAC_NEG', 'USB_VREF') for n in nets):
        return {'absolute_static_design_budget_V': 3.6, 'budget_class': 'ASSUMED_INTERNAL_REGULATOR_MARGIN', 'guaranteed_transient_upper_V': None}
    if any(n in ('ADC_1V8', 'DAC_1V8', 'VCAP1', 'VCAP2') for n in nets):
        return {'absolute_static_design_budget_V': 3.45, 'budget_class': 'ASSUMED_CONSERVATIVE_SUPPLY_RAIL_LIMIT_NOT_INTERNAL_REGULATOR_SPEC', 'guaranteed_transient_upper_V': None}
    if any(n in ('V3D', 'V3LOAD', 'V3A', 'MCU_VDDA') for n in nets):
        return {'assumed_system_max_V': 3.45, 'tps63070_calculated_static_feedback_max_V': 3.3652069669669665,
                'budget_class': 'PARENT3.45V_DESIGN_BUDGET_INCLUDES_MARGIN;NOT_MANUFACTURER_TRANSIENT_GUARANTEE', 'guaranteed_transient_upper_V': None}
    return {'assumed_normal_rail_budget_V': 4.5, 'external_signal_or_fault_envelope_known': False,
            'budget_class': 'CONSERVATIVE_NORMAL_BUDGET_ONLY;EXTERNAL_AUDIO_PIEZO_AND_PULLUP_FAULTS_UNBOUNDED', 'guaranteed_transient_upper_V': None}


def nominal(c):
    m = re.search(r'([\d.]+)\s*(uF|nF|pF|u)', c['value'], re.I)
    if not m:
        raise ValueError(c)
    return float(m[1]) * {'uf': 1, 'u': 1, 'nf': .001, 'pf': .000001}[m[2].lower()]


UF_TO_MPN = {0.01: 'C0603C103J3GACTU', 0.001: 'C0603C102J5GACTU', .0022: 'C0603C222J5GACTU',
             .0047: 'C0603C472J5GACTU', .00003: 'C0603C300J5GACTU', .47: 'C2220C474J5GACTU',
             4.7: 'CC0805KKX7R6BB475', 10: 'CC0805KKX5R6BB106', 22: 'CC0805MKX5R6BB226'}
BANKS = {'C303': [.47, .47, .1], 'C304': [.47] * 5,
         'C701': [.47] * 5, 'C702': [.47] * 5,
         'C807': [.47] * 5, 'C808': [.47] * 5,
         'C1502': [.47] * 3, 'C1902': [.47] * 5}
COG_100 = {'C101', 'C1302', 'C811', 'C830', 'C831', 'C832'}
hard_min = {'C121': 4.7, 'C211': 4.7, 'C212': 4.7, 'C501': 1, 'C502': 4.7, 'C503': 4.7,
            'C1102': 4.7, 'C1104': None, 'C1105': None, 'C1501': 1, 'C1502': .3, 'C1902': 1}
selected = {}
for ref in refs:
    c = byref[ref]
    if c['type'] != 'C':
        continue
    uf = nominal(c)
    if ref in BANKS:
        mpn = 'C2220C474J5GACTU'
    elif ref in ('C1102', 'C1106'):
        mpn = 'T520A226M010ATE080'
    elif uf == .1:
        mpn = 'C1206C104J3GACTU' if ref in COG_100 else ('CC0603KRX7R9BB104' if ref in ('C401', 'C1002', 'C1401') else 'CC0603KRX7R7BB104')
    elif uf == 1:
        mpn = 'CC0805KKX7R7BB105' if '0805' in c.get('package', '') else 'CC0603KRX7R7BB105'
    elif uf == 2.2:
        mpn = 'CC0805KKX7R7BB225' if '0805' in c.get('package', '') else 'CC0603KRX7R7BB225'
    else:
        mpn = next(v for k, v in UF_TO_MPN.items() if math.isclose(uf, k, rel_tol=1e-8))
    selected[ref] = mpn

new_components = []
bank_results = {}
next_ref = 2301
for ref, values in BANKS.items():
    c = byref[ref]
    refs_in_bank = [ref]
    for uf in values[1:]:
        while f'C{next_ref}' in byref:
            next_ref += 1
        r = f'C{next_ref}'
        next_ref += 1
        mpn = 'C2220C474J5GACTU' if uf == .47 else 'C1206C104J3GACTU'
        part = catalog[mpn]
        new_components.append({'ref': r, 'type': 'C', 'value': f'{uf}uF C0G {part["rated_voltage_V"]}V 5%',
                               'mpn': mpn, 'manufacturer': part['manufacturer'],
                               'package': part['package_eia'], 'pins': copy.deepcopy(c['pins']),
                               'bank_anchor': ref, 'selection_status': 'SELECTED_DESIGN_ECO_PARENT_ACCEPTANCE_REQUIRED',
                               'application_approved': False, 'procurement_approved': False, 'physical_tests_executed': 0})
        selected[r] = mpn
        refs_in_bank.append(r)
    uf = sum(values)
    bank_results[ref] = {'refs': refs_in_bank, 'values_uF': values, 'nominal_uF': uf,
                         'bound': c0g_bound(uf), 'not_present_in_current_native': True,
                         'geometry_status': 'ECO_LAND_READY_PLACEMENT_AND_ROUTING_NOT_VERIFIED',
                         'current_anchor_nominal_uF': nominal(c), 'net_pair': [p.get('net') for p in c['pins']]}
for r, mpn, net, reason in [('C2351', 'T520U476M010ATE055', 'V3D', 'Additional output bulk for TPS63070; NOT a guaranteed converter-band Ceff floor'),
                           ('C2352', 'CC0603KRX7R7BB104', 'V3D', 'Local HF ceramic at TPS63070 output; polymer bulk alone does not replace HF ceramic')]:
    assert r not in byref and not any(c['ref'] == r for c in new_components)
    p = catalog[mpn]
    new_components.append({'ref': r, 'type': 'C', 'value': f'{p["nominal_uF"]}uF {p["dielectric"]} {p["rated_voltage_V"]}V',
                           'mpn': mpn, 'manufacturer': p['manufacturer'], 'package': p['package_eia'],
                           'pins': [{'number': '1', 'name': '1', 'net': net}, {'number': '2', 'name': '2', 'net': 'GND'}],
                           'reason': reason, 'selection_status': 'SELECTED_DESIGN_ECO_PARENT_ACCEPTANCE_REQUIRED',
                           'application_approved': False, 'procurement_approved': False, 'physical_tests_executed': 0})
    selected[r] = mpn

options = []
option_groups = [('C1102', 11, 4.7), ('C1104+C1105', 42, 18), ('C501', 3, 1), ('C502', 11, 4.7),
                 ('C503', 11, 4.7), ('C121', 11, 4.7), ('C211', 11, 4.7), ('C212', 11, 4.7), ('C1501', 3, 1)]
for anchor, count, minimum in option_groups:
    bound = c0g_bound(.47 * count)
    options.append({'anchors': anchor.split('+'), 'status': 'MATH_BOUND_OPTION_NOT_SELECTED_FOR_PRIMARY_ECO',
                    'mpn': 'C2220C474J5GACTU', 'count_total': count, 'connection': 'All in parallel across original two nodes, replace original capacitor(s), not add to their unknown upper Ceff',
                    'nominal_uF': .47 * count, 'min_uF': bound['cap_min_uF'], 'max_uF': bound['cap_max_uF'],
                    'required_min_uF': minimum, 'mathematical_minimum_pass': bound['cap_min_uF'] >= minimum,
                    'max_body_area_sum_mm2': count * 6.1 * 5.4,
                    'manufacturer_density_B_courtyard_area_sum_mm2': count * 7.3 * 5.9,
                    'height_max_mm': 1.85,
                    'unclosed': ['No proof this large bank fits present board', 'Placement parasitic/ESR/frequency behavior not guaranteed',
                                 'Nominal value change and transient/inrush impact require parent/PCB circuit ECO'],
                    'extra_for_C1501': 'This min-only bank does not satisfy TI recommended 10uF VPWR nominal' if anchor == 'C1501' else None,
                    'physical_tests_executed': 0, 'procurement_approved': False})


def application(c, part):
    ref = c['ref']
    nets = [p.get('net') for p in c['pins']]
    checks = []
    if ref in BANKS:
        bound = bank_results[ref]['bound']
    else:
        bound = part.get('cap_bound')
    minimum = bound['cap_min_uF'] if bound else None
    maximum = bound['cap_max_uF'] if bound else None
    requirement = {'nominal_uF_before': nominal(c), 'minimum_effective_uF': hard_min.get(ref),
                   'criterion_class': 'EXPLICIT_DESIGN_MINIMUM' if ref in hard_min else 'NOMINAL_OR_DEVICE_RECOMMENDATION_NOT_A_PUBLISHED_HARD_MINIMUM'}
    if ref in ('C303', 'C304'):
        requirement.update(minimum_effective_uF=None, ratio='C304_min >= C303_max')
        checks.append('Bank ratio CLOSED at declared standard-test C bounds; switching-band ESR/ripple, layout loop and charge-pump performance remain unverified')
    elif ref in ('C807', 'C808'):
        requirement.update(minimum_effective_uF=1.76, maximum_effective_uF=2.64, esr_limit_ohm=.1,
                           device_evidence=evidence('STM32H743', [106, 211], 'VCAP external capacitance 2.2uF +/-20%; ESR<100mohm'))
        checks.append('C window CLOSED for bank; DF-derived ESR at 25C/1kHz only, NOT proof of regulator-band ESR<100mohm')
    elif ref in ('C701', 'C702'):
        checks.append('2.35uF C0G bank replaces 2.2uF nominal; DAC charge-pump ripple/ESR and low-inductance placement not proven')
    elif ref == 'C1901':
        checks.append('CT capacitance bounds CLOSED for proposed C0G25V; TPS22918 slew equation is approximate/typical, NOT guaranteed startup time')
    elif ref == 'C1902':
        checks.append('Proposed 2.35uF bank min>=1uF CLOSED for parent3.45V static assumed rail; inrush/VIN droop and CIN/CL ratio are separate open system checks')
    elif ref in ('C1903', 'C1904', 'C1921', 'C1922'):
        checks.append('Exact parent X7R16V MPN retained; no guaranteed current biased Ceff minimum. Decoupling placement needed; not approved merely because nominal100nF exists')
    elif ref in ('C1102', 'C1104', 'C1105', 'C1106'):
        checks.append('Formal MPN selected; effective C at DC rail/temperature/switching frequency not guaranteed. Polymer qualification budget is conditional, strict C0G replacement option separately costed')
        if ref in ('C1104', 'C1105'):
            requirement.update(total_direct_output_min_uF=18, basis='max initial L=1.5*1.2=1.8uH; TI Ceff>=10*Leff; also datasheet15uF minimum')
        if ref == 'C1106':
            checks.append('V3A capacitor after FB is not direct converter COUT; include in switched-domain QOD budget')
    elif ref in ('C501', 'C502', 'C503'):
        checks.append('BQ24074 IN1..10uF, OUT/BAT4.7..47uF effective recommendation; exact selected MLCC Ceff unknown, not approved; SYS transient and total input capacitance still open')
    elif ref == 'C1501':
        checks.append('Native min1..10uF is not enough to claim TI application closure: TPD2S703-Q1 p21 recommends10uF VPWR; selected2.2uF unknown Ceff remains HOLD')
    elif ref == 'C1502':
        requirement.update(minimum_effective_uF=.3, maximum_effective_uF=3)
        checks.append('Proposed1.41uF bank bounds within .3..3uF; VREF remains dedicated USB_VREF. Mode1 timing formula uses typical22mA and cannot guarantee enable time')
    elif ref in ('C812', 'C813'):
        checks.append('C0G load-cap bounds CLOSED, but CL=(C1*C2)/(C1+C2)+Cstray; unknown actual stray and startup gm margin prevent clock application approval')
    elif ref in ('C1001', 'C1302', 'C1303'):
        checks.append('C0G timing-cap bounds CLOSED; total delay still includes controller current/threshold and resistor tolerances')
    elif ref in ('C121', 'C211', 'C212'):
        checks.append('>=4.7uF required audio coupling; exact10uF MLCC bias/aging bound absent, HOLD; strict C0G bank option11x470nF available but not placed')
    elif any(n in ('ADC_1V8', 'DAC_1V8', 'ADC_VREF') for n in nets):
        checks.append('Internal LDO/reference bypass, not an external power input; preserve nets. Regulator stability and biased Ceff not established from nominal alone')
    elif any(n and ('AC' in n or n in ('PZ_LIMIT', 'PU_BIAS', 'HP_IN_L', 'HP_IN_R')) for n in nets):
        checks.append('Signal-coupling/static normal voltage assumption does not bound external jack/piezo fault or audio distortion; unclosed biased capacitance/corner-frequency budget')
    elif part['dielectric'] == 'C0G':
        checks.append('C0G capacitance budget CLOSED; RC/ADC-settling or debounce system target not supplied, not an unconditional application approval')
    else:
        checks.append('Exact MPN/ratings selected; biased Ceff min unknown. Nominal bypass recommendation is not proof of retained100nF/1uF or rail transient performance')
    min_check = None if not requirement.get('minimum_effective_uF') or minimum is None else minimum >= requirement['minimum_effective_uF']
    max_check = None if not requirement.get('maximum_effective_uF') or maximum is None else maximum <= requirement['maximum_effective_uF']
    return {'role_and_nets': nets, 'requirement': requirement, 'voltage_envelope': voltage(c),
            'proposed_bank_or_part_bound': bound, 'proposed_ceff_min_uF_at_declared_test_conditions': minimum,
            'proposed_ceff_max_uF_at_declared_test_conditions': maximum,
            'minimum_check': min_check, 'maximum_check': max_check,
            'capacity_subrequirement_status': 'SPEC_BOUND_CLOSED_IN_PROPOSED_ECO_ONLY' if bound else 'HOLD_NO_GUARANTEED_OPERATING_CEFF_MIN',
            'open_application_checks': checks, 'application_approved': False}


rows = []
changes = []
mag_integration = []
for change in mag_patch['changes']:
    ref = change['ref']
    differences = {k: {'current': byref[ref].get(k), 'selected': v}
                   for k, v in change['set_fields'].items() if byref[ref].get(k) != v}
    mag_integration.append({'ref': ref, 'current_mpn': byref[ref].get('mpn'),
                            'selected_mpn': change['set_fields']['mpn'],
                            'selected_fields_already_in_current_native': not differences,
                            'differences': differences, 'original_patch_source_sha256': mag_patch['source_sha256'],
                            'application_approved': False, 'physical_tests_executed': 0})
    if differences:
        rebased = copy.deepcopy(change)
        rebased['guard'] = {k: copy.deepcopy(byref[ref].get(k)) for k in change['set_fields']}
        changes.append(rebased)
all_lands = copy.deepcopy(read(OUT / 'land-handoff.json'))
all_lands['entries'] = [x for x in all_lands['entries'] if x['ref'] in mag_byref]
all_lands['source_sha256'] = SOURCE_SHA
all_lands['cap_banks_warning'] = 'Selected C0G banks and polymer additions require placement ECO; all are design-only. Review new-components.json and correction-patch.json.'
for ref in refs:
    c = byref[ref]
    if c['type'] != 'C':
        patch = mag_byref[ref]
        rows.append({'ref': ref, 'kind': c['type'], 'current_mpn': c.get('mpn'),
                     'current_value': c['value'], 'current_pins': copy.deepcopy(c['pins']),
                     'selected_mpn': patch['set_fields']['mpn'],
                     'selection_status': 'MPN_MANUFACTURER_LAND_CLOSED_APPLICATION_CONDITIONAL',
                     'current_ceff_min_uF': None, 'application_approved': False,
                     'procurement_approved': False, 'physical_tests_executed': 0,
                     'manufacturer_land': patch['manufacturer_land'], 'remaining_checks': patch['remaining_checks']})
        continue
    part = catalog[selected[ref]]
    app = application(c, part)
    observations = [{'path': b['path'], 'classification': b['classification'],
                     'sha256': b['sha256_before'], 'geometry': b['components'][ref]}
                    for b in pcb_snap['boards'] if ref in b['components']]
    row = {'ref': ref, 'kind': 'C', 'current_mpn': c.get('mpn'), 'current_value': c['value'],
           'current_package': c.get('package'), 'current_pins': copy.deepcopy(c['pins']),
           'current_ceff_min_uF': None,
           'current_ceff_basis': 'No complete current exact-MPN biased/temperature/aging lower bound established; proposed bank is NOT current hardware',
           'selected_mpn': selected[ref], 'selected_part': part,
           'selection_status': app['capacity_subrequirement_status'], 'application_audit': app,
           'bank': bank_results.get(ref), 'actual_named_board_observations': observations,
           'application_approved': False, 'procurement_approved': False, 'physical_tests_executed': 0}
    rows.append(row)
    fields = {'mpn': selected[ref], 'manufacturer': part['manufacturer'],
              'package': part['package_eia'] + '; max ' + 'x'.join(f'{v:g}' for v in part['body_lwh_max_mm']) + 'mm; manufacturer-land review in passive-closure',
              'passiveAudit': {'sourceSha256': SOURCE_SHA, 'status': app['capacity_subrequirement_status'],
                               'procurementApproved': False, 'physicalTestsExecuted': 0}}
    if ref in BANKS:
        fields['value'] = '.47uF C0G 50V 5%; physical anchor of ' + str(bank_results[ref]['nominal_uF']) + 'uF parallel bank'
    elif ref in ('C1102', 'C1106'):
        fields['value'] = '22uF polymer tantalum 10V 20%; polarity1=rail,2=GND; guaranteed operating Ceff HOLD'
    elif part['dielectric'] == 'C0G':
        fields['value'] = f'{part["nominal_uF"]:g}uF C0G {part["rated_voltage_V"]}V 5%'
    changes.append({'ref': ref, 'guard': {k: copy.deepcopy(c.get(k)) for k in fields}, 'set_fields': fields,
                    'source_pins_guard': copy.deepcopy(c['pins']),
                    'pins_not_replaced': True, 'nets_unchanged': True,
                    'requires_new_components': bank_results.get(ref, {}).get('refs', [ref])[1:],
                    'automatic_approval': False, 'physical_tests_executed': 0})
    all_lands['entries'].append({'ref': ref, 'selected_mpn': selected[ref], 'manufacturer': part['manufacturer'],
                                 'body_lwh_max_mm': part['body_lwh_max_mm'], 'pads': part['land']['pads'],
                                 'land_status': part['land']['status'], 'land_evidence': part['land']['evidence'],
                                 'requires_geometry_delta': True, 'applied_to_global_pcb': False,
                                 'application_approved': False, 'physical_tests_executed': 0})

for c in new_components:
    p = catalog[c['mpn']]
    all_lands['entries'].append({'ref': c['ref'], 'selected_mpn': c['mpn'], 'manufacturer': p['manufacturer'],
                                 'body_lwh_max_mm': p['body_lwh_max_mm'], 'pads': p['land']['pads'],
                                 'pin_net_map': {x['number']: x['net'] for x in c['pins']},
                                 'land_status': p['land']['status'], 'land_evidence': p['land']['evidence'],
                                 'applied_to_global_pcb': False, 'physical_tests_executed': 0})

# Sum caps reachable on switched supply, with conservative extra storage through ICs/dividers.
reachable_nets = {'V3LOAD', 'V3A', 'ADC_1V8', 'ADC_VREF', 'DAC_1V8', 'HP_NEG', 'HP_POS', 'DAC_NEG',
                  'HP_CPP', 'HP_CPN', 'DAC_CPP', 'DAC_CPN', 'VMID_DIV', 'RF_CHIP_EN'}
qod_rows = []
for c in [byref[r] for r in refs if byref[r]['type'] == 'C'] + new_components:
    if not any(p.get('net') in reachable_nets for p in c['pins']):
        continue
    p = catalog[selected[c['ref']]]
    maximum = p['cap_bound']['cap_max_uF'] if p['cap_bound'] else (p['qualification_only_budget']['stacked_max_uF'] if p['kind'] == 'POLARIZED_POLYMER_TANTALUM' else p['zero_bias_initial_temp_only_uF'][1])
    qod_rows.append({'ref': c['ref'], 'mpn': selected[c['ref']], 'max_uF_budget': maximum,
                     'bound_class': 'MANUFACTURER_C0G_BOUND' if p['cap_bound'] else 'ASSUMED_ENGINEERING_UPPER_NOT_GUARANTEED_OPERATING_CEFF',
                     'pin_nets': [v.get('net') for v in c['pins']],
                     'note': 'Conservatively counts internal-rail/coupling storage too; equivalent discharge capacitance/voltage need circuit-dependent treatment'})
qod_total = sum(r['max_uF_budget'] for r in qod_rows)
qod = {'rows': qod_rows, 'external_cap_budget_uF': qod_total, 'native_original_external_nominal_uF_not_a_max': sum(nominal(byref[r]) for r in refs if byref[r]['type'] == 'C' and any(p.get('net') in reachable_nets for p in byref[r]['pins'])),
       'module_internal_allowance_uF': 10, 'module_internal_allowance_status': 'ASSUMED_NOT_MANUFACTURER_BOUND',
       'budget_with_assumed_module_allowance_uF': qod_total + 10,
       'below_parent_conservative_200uF_budget': qod_total + 10 < 200,
       'guaranteed_total_cl_max_uF': None, 'closure': 'CONDITIONAL_BUDGET_ONLY_NOT_GUARANTEED_TOTAL_MAX',
       'critical_note': 'TPS22918 p14 200uF rule is for internal QOD alone. Parent series1k mitigates current but does not prove module/internal or DC-bias maximum.',
       'resistor_current_upper_at3p45V_mA_assuming1percent_1k': 3.45 / 990 * 1000,
       'qod_initial_energy_of_direct_cap_bank_mJ_if_all_at3p45V': .5 * qod_total * 1e-6 * 3.45 ** 2 * 1000,
       'energy_status': 'ASSUMED_COMMON_VOLTAGE_RC_MODEL_NOT_PULSE_RATING_APPROVAL',
       'remaining': ['Unknown guaranteed internal module capacitance', 'Class-II biased maximum and post-environment combined bound',
                     'Different stored voltages, active internal rails/back-power paths, and resistor pulse rating',
                     'CIN/CL ratio and unpowered discharge return through load switch body diode'],
       'evidence': [evidence('TPS22918', [13, 14, 17, 19], 'QOD200uF conditional rule, external resistor, typical CT equation and input-output ratio')],
       'physical_tests_executed': 0}

cp = {'C303': bank_results['C303'], 'C304': bank_results['C304'],
      'ratio_check': bank_results['C304']['bound']['cap_min_uF'] >= bank_results['C303']['bound']['cap_max_uF'],
      'minimum_storage_minus_max_flying_uF': bank_results['C304']['bound']['cap_min_uF'] - bank_results['C303']['bound']['cap_max_uF'],
      'status': 'CAPACITANCE_RATIO_CLOSED_IN_PROPOSED_C0G_ECO;ESR_RIPPLE_LAYOUT_OPEN',
      'evidence': [evidence('TPA6132A2', [15, 17], 'Storage>=flying, low-ESR ceramic, nominal/placement recommendations')]}
vcap = {'refs': ['C807', 'C808'], 'bank_each_uF': 2.35, 'bound_each': c0g_bound(2.35),
        'required_window_uF': [1.76, 2.64], 'capacitance_window_pass': 1.76 <= c0g_bound(2.35)['cap_min_uF'] and c0g_bound(2.35)['cap_max_uF'] <= 2.64,
        'esr_25C_1kHz_initial_bound_ohm': .001 / (2 * math.pi * 1000 * (2.35 * .95 * 1e-6)),
        'esr_converter_or_regulator_band_bound_ohm': None,
        'status': 'CAPACITANCE_WINDOW_CLOSED_IN_PROPOSED_ECO;ALL_BAND_ESR_AND_LAYOUT_NOT_CLOSED',
        'evidence': [evidence('STM32H743', [106, 211], '2.2uF +/-20%, ESR<100mohm'), evidence('KEM_C0G_SMD', [4], 'DF<=0.1% at25C/1kHz; do not extrapolate ESR')], 'physical_tests_executed': 0}

counts = dict(Counter(r['selection_status'] for r in rows))
closure_counts = {'existing_scope': len(rows), 'existing_capacitors': sum(r['kind'] == 'C' for r in rows),
                  'existing_magnetics_clock': sum(r['kind'] != 'C' for r in rows),
                  'magnetics_clock_selected_fields_already_merged': sum(x['selected_fields_already_in_current_native'] for x in mag_integration),
                  'exact_mpn_selection_existing': len(rows),
                  'proposed_capacitance_standard_test_bound_existing_anchors': sum(r['selection_status'] == 'SPEC_BOUND_CLOSED_IN_PROPOSED_ECO_ONLY' for r in rows),
                  'existing_capacitors_without_proposed_guaranteed_ceff_min': sum(r['selection_status'] == 'HOLD_NO_GUARANTEED_OPERATING_CEFF_MIN' for r in rows),
                  'proposed_new_capacitors': len(new_components),
                  'current_capacitor_ceff_min_proven': sum(r.get('current_ceff_min_uF') is not None for r in rows),
                  'full_application_approved': 0, 'procurement_approved': 0,
                  'physical_tests_executed': 0}
common = {'generated_utc': NOW, 'source_path': str(data_path.relative_to(ROOT)), 'source_sha256': SOURCE_SHA,
          'source_part_count': len(native), 'source_pin_count': sum(len(c['pins']) for c in native),
          'scope_count': len(refs), 'scope_refs': refs, 'physical_tests_executed': 0,
          'global_native_pcb_firmware_written': False, 'procurement_approved': False}
dump('application-audit.json', dict(common, schema='smartvio-v26-every-ref-passive-application-audit/1.0', rows=rows,
                                  status_counts=counts, closure_counts=closure_counts, full_application_approved_count=0,
                                  current_guaranteed_ceff_min_count=sum(r.get('current_ceff_min_uF') is not None for r in rows),
                                  warning='Proposed bound is not current native/assembled hardware; no current missing-min capacitor marked approved'))
dump('proposal.json', dict(common, schema='smartvio-v26-passive-formal-design-selection/1.0',
                           status='FORMAL_MPN_SELECTION_WITH_SCOPED_ECO_AND_HONEST_PARTIAL_CLOSURE',
                           per_ref=rows, part_catalog=list(catalog.values()), selected_parallel_banks=bank_results,
                           closure_counts=closure_counts, magnetics_clock_parent_integration=mag_integration,
                           charge_pump=cp, vcap=vcap, qod=qod, source_evidence_manifest='source-evidence.json',
                           application_approved=False, correction_patch='correction-patch.json', new_components='new-components.json'))
dump('correction-patch.json', dict(common, schema='smartvio-v26-passive-field-patch/1.0', changes=changes,
                                  instructions='Parent-only design integration. Check field AND source_pins_guard before each ref. Refuse drift. Banks require anchor AND all mandatory companions atomically. Never replace whole native. No capacitor pin/net field replaced. No application approval.',
                                  applied=False, new_components_file='new-components.json',
                                  manufacturer_land_file='land-handoff.json', source_drift_reconciliation='source-followup.json'))
merge_changes = [x for x in changes if x['ref'] not in BANKS and x['ref'] not in ('C1102', 'C1106')]
dump('mpn-package-patch.json', dict(common, schema='smartvio-v26-passive-nominal-preserving-selection-patch/1.0',
                                  changes=merge_changes, applied=False,
                                  excludes=list(BANKS) + ['C1102', 'C1106'],
                                  instructions='Nominal capacitance and nets are preserved. MPN/voltage/dielectric/land may change. Parent accepts design selection only, not Ceff or manufacturing approval. Check per-field and pin guards. Bank and polarized substitutions excluded: see correction-patch.json.',
                                  full_application_approved=False))
dump('magnetics-clock-integration.json', dict(common, rows=mag_integration,
                                           note='Original delivered magnetic patch preserved; merged fields observed from current source, not replayed when already equal.'))
dump('new-components.json', dict(common, schema='smartvio-v26-selected-passive-additions/1.0',
                                count=len(new_components), components=new_components, applied=False,
                                integration='Bank companions are mandatory atomically with their anchor changes; do not merge just anchor MPN or nominal. C2351/2 are the selected conditional bulk/HF ECO.'))
dump('strict-ceff-options.json', dict(common, schema='smartvio-v26-strict-ceff-mathematical-replacement-options/1.0',
                                    options=options, selected_for_primary_eco=False,
                                    reason='Large C0G banks close standard-test C minima, but area/routing and cost are not accepted. Never silently apply these or count their floor in primary/current Ceff.'))
pin_delta = []
original_fl = {p['number']: p for p in byref['FL1501']['pins']}
for p in mag_byref['FL1501']['set_fields']['pins']:
    if original_fl[p['number']].get('net') != p.get('net'):
        pin_delta.append({'ref': 'FL1501', 'manufacturer_pin': p['number'],
                          'before_net': original_fl[p['number']].get('net'), 'after_net': p.get('net'),
                          'reason': 'Physical manufacturer numbering 1-4/2-3; logical DP and DM series paths preserved'})
dump('authorized-net-deltas.json', dict(common, schema='smartvio-v26-passive-scoped-net-deltas/1.0',
                                       authorization='User V26 instruction permits circuit delta proposals in exclusive directory, not live global mutation',
                                       new_nets=[], physical_manufacturer_pin_remap=pin_delta,
                                       parallel_companions_use_existing_nets=True,
                                       untouched_parent_nets=['V3LOAD', 'AUDIO_PWR_EN', 'AUDIO_BUS_EN', 'PACK_NTC', 'NTC_COLD_DIV', 'CHARGE_GATE'],
                                       global_applied=False))
dump('land-handoff.json', all_lands)
dump('calculations.json', dict(common, charge_pump=cp, vcap=vcap, qod=qod,
                               tps63070={'initial_Lmax_uH': 1.8, 'TI_min_Cout_uF': 15, 'TI_equation_required_uF': 18,
                                         'nominal_output_MLCC_uF': 44, 'added_polymer_nominal_uF': 47,
                                         'guaranteed_operating_Cout_min_uF': None,
                                         'polymer_qualification_budget_uF_not_Ceff_guarantee': catalog['T520U476M010ATE055']['qualification_only_budget'],
                                         'evidence': [evidence('TPS63070', [4, 17, 18, 19], 'Effective capacitance requirement, loop/ripple and inductor-current sizing')]},
                               clock={'CL_pF': 18, 'load_caps_each_nominal_pF': 30, 'load_caps_each_bound_pF': [c0g_bound(.00003)['cap_min_uF'] * 1e6, c0g_bound(.00003)['cap_max_uF'] * 1e6],
                                      'nominal_stray_needed_pF': 3, 'actual_stray_pF': None, 'CL_guaranteed_pass': False,
                                      'startup_drive_margin_pass': False,
                                      'formula': 'CL=C812*C813/(C812+C813)+Cstray', 'temperature_limiter': 'ABM8 B2 -20..70C'}))

# Preserve initial before; record authorized parent ECO separately instead of falsifying scoped unchanged.
initial = read(WORK / 'native-input-snapshot.json')
initial_map = {c['ref']: c for c in initial}
followup = {'schema': 'smartvio-v26-parent-followup/1.0', 'initial_snapshot_sha256': sha(WORK / 'native-input-snapshot.json'),
            'selection_snapshot_sha256': SOURCE_SHA, 'initial_part_count': len(initial), 'latest_part_count': len(native),
            'added_by_parent_refs': [r for r in byref if r not in initial_map],
            'changed_by_parent_refs': [r for r in byref if r in initial_map and byref[r] != initial_map[r]],
            'observed_latest_parent_context': {r: byref[r] for r in ('U1901', 'U1902', 'C1901', 'C1902', 'C1903', 'C1904', 'U1921', 'U1922', 'C1921', 'C1922', 'R1921', 'R1923', 'R1924', 'R1601') if r in byref},
            'scoped_unchanged_since_initial_snapshot': False, 'global_written_by_this_worker': False,
            'parent_authorized_changes_preserved': True}
dump('source-followup.json', followup)

pretty = OUT / 'Passive_V26_ManufacturerLand.pretty'
pretty.mkdir(exist_ok=True)
unique_lands = {p['mpn']: {'body_lwh_max_mm': p['body_lwh_max_mm'], 'pads': p['land']['pads'],
                         'evidence': [p['land']['evidence']]} for p in catalog.values()}
for m in mag_patch['changes']:
    unique_lands[m['set_fields']['mpn']] = m['manufacturer_land']
for mpn, land in unique_lands.items():
    name = re.sub(r'[^a-zA-Z0-9_-]', '_', mpn)
    w, h, height = land['body_lwh_max_mm']
    fp = [f'(footprint "{name}" (version 20241229) (generator "v26_passive_closure")',
          '(layer "F.Cu") (attr smd)',
          f'(descr "Design-stage manufacturer land; not assembled/physical approval; max height {height:g} mm")',
          f'(property "Reference" "REF**" (at 0 {-h/2-1:g}) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))',
          f'(property "Value" "{mpn}" (at 0 {h/2+1:g}) (layer "F.Fab") (effects (font (size 0.8 0.8) (thickness 0.12))))',
          f'(fp_rect (start {-w/2:g} {-h/2:g}) (end {w/2:g} {h/2:g}) (stroke (width 0.1) (type default)) (fill none) (layer "F.Fab"))']
    for pad in land['pads']:
        x, y = pad['center_xy_mm']
        a, b = pad['size_xy_mm']
        fp.append(f'(pad "{pad["number"]}" smd rect (at {x:g} {y:g}) (size {a:g} {b:g}) (layers "F.Cu" "F.Paste" "F.Mask"))')
    extent_x = max(w/2, max(abs(p['center_xy_mm'][0]) + p['size_xy_mm'][0]/2 for p in land['pads'])) + .25
    extent_y = max(h/2, max(abs(p['center_xy_mm'][1]) + p['size_xy_mm'][1]/2 for p in land['pads'])) + .25
    fp.append(f'(fp_rect (start {-extent_x:g} {-extent_y:g}) (end {extent_x:g} {extent_y:g}) (stroke (width 0.05) (type default)) (fill none) (layer "F.CrtYd"))')
    fp.append(')')
    (pretty / (name + '.kicad_mod')).write_text('\n'.join(fp) + '\n', encoding='ascii')
dump('footprint-index.json', {'library': 'Passive_V26_ManufacturerLand.pretty', 'units': 'mm',
                              'source': unique_lands, 'global_installed': False, 'assembly_approved': False,
                              'physical_tests_executed': 0})

verification = dict(common, schema='smartvio-v26-passive-closure-verification/1.0',
                    exact_ref_coverage_count=len(rows), selected_existing_mpn_count=len(rows),
                    selected_new_component_count=len(new_components), original_manufacturer_pdf_count=len(sources),
                    status_counts=counts, current_guaranteed_ceff_min_count=0, full_application_approved_count=0,
                    closure_counts=closure_counts, metadata_nominal_preserving_changes_count=len(merge_changes),
                    charge_pump_ratio_check=cp['ratio_check'], vcap_capacitance_window_check=vcap['capacitance_window_pass'],
                    full_ESR_ripple_transient_verification=False, procurement_approval=False,
                    current_native_unchanged_during_build=data_path.read_bytes() == native_bytes,
                    source_snapshot_preserved=str(snapshot_path.relative_to(ROOT)),
                    report='report.html', math_options='strict-ceff-options.json',
                    note='Design closure is granular. Ceff bounds only apply to proposed accepted complete banks and declared test conditions. Phys0 is not a test pass.')
dump('verification.json', verification)

body_rows = []
for row in rows:
    app = row.get('application_audit', {})
    lower = app.get('proposed_ceff_min_uF_at_declared_test_conditions')
    text = '; '.join(app.get('open_application_checks', row.get('remaining_checks', [])))
    body_rows.append('<tr>' + ''.join(f'<td>{html.escape(str(v))}</td>' for v in (
        row['ref'], row.get('current_mpn') or '-', row['selected_mpn'], row['selection_status'],
        'UNKNOWN', f'{lower:.9g}' if lower is not None else 'HOLD', text)) + '</tr>')
source_rows = ''.join(f'<li>{html.escape(s["id"])}: <a href="{html.escape(s["path"])}">original PDF</a> / <a href="{html.escape(s["manufacturer_url"])}">manufacturer</a> / SHA256 {s["sha256"]}</li>' for s in sources.values())
report = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>SmartVio V26 Passive Closure</title><style>body{font:14px system-ui;margin:24px;color:#202020}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:7px;text-align:left;vertical-align:top}th{background:#eee}a{color:#005a92}li{overflow-wrap:anywhere}code{overflow-wrap:anywhere}</style><h1>SmartVio V26 passive closure</h1>'
report += f'<p>Source {len(native)} parts / {verification["source_pin_count"]} pins; {len(refs)} scoped existing refs, {len(new_components)} selected additions. Phys0. No procurement or full application approval. Source SHA256 <code>{SOURCE_SHA}</code>.</p>'
report += '<p>Current Ceff minimum remains UNKNOWN; proposed C0G bounds do not alter current native hardware. MPN selection, mathematical capacitor budget, frequency/ESR, mechanical integration and physical validation are separate states.</p>'
report += '<p>Closure counts: <code>' + html.escape(json.dumps(closure_counts)) + '</code>. No overall PASS.</p>'
report += f'<p>C303 bank 1.04uF: {cp["C303"]["bound"]["cap_min_uF"]:.9g}..{cp["C303"]["bound"]["cap_max_uF"]:.9g}uF. C304 bank 2.35uF: {cp["C304"]["bound"]["cap_min_uF"]:.9g}..{cp["C304"]["bound"]["cap_max_uF"]:.9g}uF. Ratio criterion passes. VCAP same2.35uF bank passes1.76..2.64uF; switching-band ESR remains open.</p>'
report += f'<p>QOD external design budget {qod_total:.6g}uF + assumed module10uF = {qod_total+10:.6g}uF. This is NOT guaranteed maximum CL. External1k resistor exists; the TI200uF internal-only rule must not be misquoted as an unconditional device limit.</p>'
report += '<p>' + ' / '.join(f'<a href="{f}">{f}</a>' for f in ['proposal.json', 'verification.json', 'application-audit.json', 'mpn-package-patch.json', 'correction-patch.json', 'new-components.json', 'authorized-net-deltas.json', 'land-handoff.json', 'strict-ceff-options.json', 'calculations.json', 'source-followup.json', 'source-evidence.json', 'magnetics-clock-patch.json', 'magnetics-clock-integration.json', 'footprint-index.json']) + '</p>'
report += '<table><thead><tr><th>Ref</th><th>Current MPN</th><th>Selected MPN</th><th>Partial Closure</th><th>Current Ceff Min</th><th>Proposed Bound Min (uF)</th><th>Remaining Checks</th></tr></thead><tbody>' + ''.join(body_rows) + '</tbody></table><h2>Original Manufacturer Evidence</h2><ul>' + source_rows + '</ul></html>'
(OUT / 'report.html').write_text(report, encoding='utf-8')
print('BUILD', len(refs), len(new_components), counts, 'QOD_BUDGET', qod_total + 10, 'SOURCE', SOURCE_SHA)
