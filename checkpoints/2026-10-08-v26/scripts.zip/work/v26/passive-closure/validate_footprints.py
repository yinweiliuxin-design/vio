import hashlib
import json
import os
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/audit/passive-closure'
os.environ['KICAD_CONFIG_HOME'] = str(WORK / 'kicad-config')
os.environ['KICAD_DOCUMENTS_HOME'] = str(WORK / 'documents')
import pcbnew as pcb

index = json.loads((OUT / 'footprint-index.json').read_text(encoding='utf-8'))
library = OUT / index['library']
rows = []
for mpn, land in index['source'].items():
    name = re.sub(r'[^a-zA-Z0-9_-]', '_', mpn)
    path = library / (name + '.kicad_mod')
    before = path.read_bytes()
    footprint = pcb.FootprintLoad(str(library), name)
    assert footprint is not None, name
    pads = {p.GetNumber(): p for p in footprint.Pads()}
    assert set(pads) == {p['number'] for p in land['pads']}, name
    for desired in land['pads']:
        actual = pads[desired['number']]
        xy = [pcb.ToMM(actual.GetPosition().x), pcb.ToMM(actual.GetPosition().y)]
        size = [pcb.ToMM(actual.GetSize().x), pcb.ToMM(actual.GetSize().y)]
        assert all(abs(a-b) <= .000001 for a, b in zip(xy, desired['center_xy_mm'])), (name, xy)
        assert all(abs(a-b) <= .000001 for a, b in zip(size, desired['size_xy_mm'])), (name, size)
    assert before == path.read_bytes()
    rows.append({'mpn': mpn, 'path': str(path.relative_to(OUT)),
                 'sha256': hashlib.sha256(before).hexdigest(), 'kicad_load_success': True,
                 'pad_numbers_coordinates_and_sizes_match_handoff': True, 'written_to_global_pcb': False})

result = {'schema': 'smartvio-v26-passive-footprint-format-verification/1.0',
          'count': len(rows), 'rows': rows, 'verification_scope': 'Generated local library parsing and numeric pad-coordinate checks only',
          'placement_routing_assembly_acceptance': False, 'manufacturing_release': False,
          'physical_tests_executed': 0, 'global_pcb_written': False}
(OUT / 'footprint-verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
verification_path = OUT / 'verification.json'
verification = json.loads(verification_path.read_text(encoding='utf-8'))
verification['footprint_file_format_verification'] = {'report': 'footprint-verification.json',
                                                     'loaded_and_pad_checked_count': len(rows),
                                                     'not_board_assembly_approval': True}
verification_path.write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('FOOTPRINTS_LOADED_PAD_CHECKED', len(rows), 'ASSEMBLY_APPROVED', False, 'PHYSICAL_TESTS', 0)
