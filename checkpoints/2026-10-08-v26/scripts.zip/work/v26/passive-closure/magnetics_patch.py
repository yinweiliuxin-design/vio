import copy
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/audit/passive-closure'
path = OUT.parents[1] / 'electrical/native-components.json'
data = path.read_bytes()
native = json.loads(data)
byref = {r['ref']: r for r in native}
lands = json.loads((OUT / 'land-handoff.json').read_text(encoding='utf-8'))
changes = []
for row in lands['entries']:
    if row['ref'] not in ('L1101', 'FB1101', 'FL1501', 'L1501', 'L1502', 'Y801'):
        continue
    c = byref[row['ref']]
    fields = {'mpn': row['selected_mpn'],
              'manufacturer': row['manufacturer'],
              'package': 'Manufacturer land; max body ' + 'x'.join(str(v) for v in row['body_lwh_max_mm']) + ' mm; see audit/passive-closure/land-handoff.json'}
    if row['ref'] == 'FL1501':
        pins = {p['number']: copy.deepcopy(p) for p in c['pins']}
        mapping = {'1': ('DP_IN', 'USB_DP_CONN'), '2': ('DM_IN', 'USB_DM_CONN'),
                   '3': ('DM_OUT', 'USB_DM_CMC'), '4': ('DP_OUT', 'USB_DP_CMC')}
        for n, (name, net) in mapping.items():
            pins[n].update(name=name, net=net, manufacturerNumber=n, footprintPad=n,
                           pinAuditStatus='V26_MANUFACTURER_DRAWING_REVIEWED_DESIGN_STAGE')
        fields['pins'] = list(pins.values())
    changes.append({'ref': c['ref'], 'guard': {k: copy.deepcopy(c.get(k)) for k in fields},
                    'set_fields': fields, 'nominal_value_unchanged': True,
                    'logical_signal_path_unchanged': True,
                    'manufacturer_land': row,
                    'design_status': 'MPN_AND_LAND_SELECTED_APPLICATION_LIMITS_STILL_RECORDED',
                    'application_approved': False, 'procurement_approved': False,
                    'physical_tests_executed': 0,
                    'remaining_checks': {'L1101': ['Hot inductance/current envelope and converter stability; former 4x4x2 limit needs explicit mechanical delta'],
                                         'FB1101': ['Loaded impedance and rail drop/EMC under real load; 120ohm specification is zero-bias'],
                                         'FL1501': ['USB differential insertion loss/eye/ESD layout; 90ohm is typical, guaranteed minimum 65ohm'],
                                         'L1501': ['Pair is +/-2% each, not factory matched; USB eye at full path'],
                                         'L1502': ['Pair is +/-2% each, not factory matched; USB eye at full path'],
                                         'Y801': ['B2 -20..70C limits; measured/extracted stray CL and oscillator startup/drive margins']}[c['ref']]})
doc = {'schema': 'smartvio-v26-passive-field-patch/1.0', 'generated_utc': datetime.now(timezone.utc).isoformat(),
       'source_path': str(path.relative_to(ROOT)), 'source_sha256': hashlib.sha256(data).hexdigest(),
       'source_part_count': len(native), 'source_pin_count': sum(len(c['pins']) for c in native),
       'application': 'Field-level guarded parent integration only; never overwrite whole native or unrelated pins/nets',
       'applied': False, 'physical_tests_executed': 0, 'changes': changes}
(OUT / 'magnetics-clock-patch.json').write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PATCH_READY', doc['source_part_count'], doc['source_pin_count'], doc['source_sha256'])
