"""Apply guarded, field-level component review patches without replacing nets."""
import copy
import hashlib
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
source = ROOT / 'electrical/native-components.json'
parts = json.loads(source.read_text(encoding='utf-8'))
by = {c['ref']: c for c in parts}
before = hashlib.sha256(source.read_bytes()).hexdigest()
applied, skipped, pin_ecos = [], [], []
for name in sys.argv[1:]:
    path = Path(name).resolve()
    patch = json.loads(path.read_text(encoding='utf-8'))
    for change in patch['changes']:
        c = by[change['ref']]
        fields = change['set_fields']
        if all(c.get(k) == v for k, v in fields.items()):
            skipped.append({'ref': c['ref'], 'reason': 'ALREADY_APPLIED'})
            continue
        for k, v in change['guard'].items():
            if c.get(k) != v:
                raise ValueError(f"Guard mismatch {c['ref']}.{k}: {c.get(k)!r} != {v!r}")
        assert 'ref' not in fields
        if 'pins' in fields:
            assert c['ref'] == 'FL1501' and 'pins' in change['guard']
            assert c['mpn'] is None and fields['mpn'] == 'ACM2012H-900-2P-T06'
            assert {p['net'] for p in c['pins']} == {p['net'] for p in fields['pins']}
            pin_ecos.append({'ref': c['ref'], 'before': copy.deepcopy(c['pins']), 'after': copy.deepcopy(fields['pins']),
                             'reason': 'Manufacturer winding/pad numbering replaces placeholder. The same four endpoint networks are retained.'})
        c.update(copy.deepcopy(fields))
        c.setdefault('fieldReviewHistory', []).append({'patch': str(path.relative_to(ROOT)), 'designStatus': change.get('design_status'), 'applicationApproved': change.get('application_approved', False)})
        applied.append({'ref': c['ref'], 'fields': sorted(fields), 'patch': str(path.relative_to(ROOT))})
source.write_text(json.dumps(parts, ensure_ascii=False, indent=2), encoding='utf-8')
after = hashlib.sha256(source.read_bytes()).hexdigest()
report = {'beforeSha256': before, 'afterSha256': after, 'applied': applied, 'skipped': skipped, 'pinsAndNetsUnchanged': not pin_ecos, 'authorizedPinEcos': pin_ecos}
out = ROOT / 'audit/system-v26/field-merge-log.json'
prior = json.loads(out.read_text(encoding='utf-8')) if out.exists() else []
prior.append(report)
out.write_text(json.dumps(prior, ensure_ascii=False, indent=2), encoding='utf-8')
(ROOT / 'audit/system-v26/native-revision.json').write_text(json.dumps({'parts': len(parts), 'pins': sum(len(c['pins']) for c in parts), 'sha256': after}, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
