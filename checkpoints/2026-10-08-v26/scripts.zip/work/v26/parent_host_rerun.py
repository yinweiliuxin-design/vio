"""Independently execute current host regressions and verify delivered target hashes."""
import hashlib
import json
import re
from pathlib import Path
import subprocess
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
FW = ROOT / 'firmware'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest().upper()
source_hash = sha(ROOT / 'electrical/native-components.json')
completion = json.loads((FW / 'verification/f01-f02-completion.json').read_text(encoding='utf-8-sig'))
assert completion['nativeSourceSha256'].upper() == source_hash
artifact_checks = []
for entry in completion['artifacts'] + completion['inputSafetySourceHashes']:
    path = Path(entry['Path'])
    assert path.resolve().is_relative_to(FW.resolve())
    actual = sha(path)
    assert actual == entry['Hash'].upper(), ('Current artifact mismatch', str(path))
    artifact_checks.append({'path': path.relative_to(ROOT).as_posix(), 'sha256': actual})
programs = sorted((BASE / 'work/v26/firmware/build').glob('*-HOST-ONLY.exe'))
assert len(programs) == 9, [p.name for p in programs]
results = []
for program in programs:
    cp = subprocess.run([str(program)], capture_output=True, text=True, encoding='utf-8', timeout=90)
    assert cp.returncode == 0, (program.name, cp.stdout, cp.stderr)
    lines = [line for line in cp.stdout.splitlines() if line.startswith('{')]
    if lines:
        assert len(lines) == 1, (program.name, cp.stdout)
        counts = json.loads(lines[0])
    else:
        match = re.fullmatch(r'PASS diagnostics groups=(\d+) assertions=(\d+) PCM_operations=(\d+) hardware_tests=0\s*', cp.stdout)
        assert program.name == 'test_diagnostics-HOST-ONLY.exe' and match, (program.name, cp.stdout)
        counts = dict(zip(['groups','assertions','PCM_operations'], map(int, match.groups())))
        counts['hardware_tests'] = 0
    assert not counts.get('failed', 0) and counts.get('hardware_tests') == 0
    results.append({'program': program.name, 'sha256': sha(program), 'exitCode': cp.returncode,
                    'result': counts})
record = {'verifiedUTC': datetime.now(timezone.utc).isoformat(), 'sourceSha256': source_hash.lower(),
          'suiteCount': len(results), 'groups': sum(r['result']['groups'] for r in results),
          'assertions': sum(r['result']['assertions'] for r in results),
          'allNineHostProgramsPass': True, 'currentTargetAndSafetyInputHashesPass': True,
          'artifactChecks': artifact_checks, 'results': results, 'physicalTests': 0,
          'productionApproved': False}
(ROOT / 'verification/parent-host-rerun-v26.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps({k:record[k] for k in ['sourceSha256','suiteCount','groups','assertions',
                  'allNineHostProgramsPass','currentTargetAndSafetyInputHashesPass','physicalTests']}, indent=2))
