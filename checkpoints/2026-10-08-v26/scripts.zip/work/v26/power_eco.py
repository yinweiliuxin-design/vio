"""Capture V26 USB wake and sequenced audio-domain changes atomically."""
import copy
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'audit/system-v26'
OUT.mkdir(parents=True, exist_ok=True)
source = ROOT / 'electrical/native-components.json'
before = json.loads(source.read_text(encoding='utf-8'))
by = {c['ref']: copy.deepcopy(c) for c in before}
changes = []
evidence = {
    'diode': {'url': 'https://assets.nexperia.com/documents/data-sheet/BAS116.pdf', 'section': 'Table2:1A,2NC,3K; Table7:leakage/forward; Fig8:reflow land'},
    'switch': {'url': 'https://www.ti.com/lit/ds/symlink/tps22918.pdf', 'section': 'Section5 pin functions;6.3 ON thresholds;8.3.2 discharge;8.3.3 CT'},
    'isolation': {'url': 'https://www.ti.com/lit/ds/symlink/tmux1511.pdf', 'section': 'PW pin functions;1.5..5.5V supply;powered-off protection'},
    'buck': {'url': 'https://www.ti.com/lit/ds/symlink/tps63070.pdf', 'section': '7.5 EN thresholds .77.. .83V rising, .67.. .73V falling;EN leakage .2uA'}
}

def pin(ref, number):
    return next(p for p in by[ref]['pins'] if p['number'] == str(number))

def net(ref, number, old, new):
    p = pin(ref, number)
    assert p['net'] == old, (ref, number, p['net'], old)
    changes.append({'ref': ref, 'pin': str(number), 'before': old, 'after': new})
    p['net'] = new

def add(ref, kind, value, mpn, package, terminals, proof=None):
    assert ref not in by
    c = {'ref': ref, 'type': kind, 'value': value, 'mpn': mpn, 'package': package,
         'sheet': 'A32', 'release': 'ENGINEERING_REVIEW_NOT_MANUFACTURING_RELEASE',
         'procurementApproved': False, 'pins': []}
    for n, name, nnet, ptype in terminals:
        p = {'number': str(n), 'name': name, 'net': nnet, 'electricalType': ptype,
             'footprintPad': str(n)}
        if proof:
            p.update({'evidence': evidence[proof], 'pinAuditStatus': 'VERIFIED_OFFICIAL'})
        c['pins'].append(p)
    by[ref] = c
    changes.append({'ref': ref, 'action': 'add', 'mpn': mpn})
    return c

def resistor(ref, value, mpn, a, b):
    return add(ref, 'R', value, mpn, '0603;1%;0.1W', [(1,'1',a,'passive'),(2,'2',b,'passive')])

net('U1301', 6, 'SYS_ENABLE', 'PWR_LTC_EN')
net('R1103', 2, 'SYS_ENABLE', 'PWR_LTC_EN')
by['R1103'].update({'value': '33k 1%', 'mpn': 'RC0603FR-0733KL',
                  'note': 'Pull up only the isolated LTC enable node. Never bridge D1301.'})
by['R1103'].pop('bomEvidence', None)
for ref, anode in [('D1301', 'PWR_LTC_EN'), ('D1302', 'USB_WAKE_A')]:
    add(ref, 'D', 'low-leakage enable OR', 'BAS116,215', 'SOT23;max body3.0x1.4x1.1mm',
        [(1,'A',anode,'passive'),(2,'NC',None,'no_connect'),(3,'K','SYS_ENABLE','passive')], 'diode')
resistor('R1303', '33k 1%', 'RC0603FR-0733KL', 'USB_5V_SAFE', 'USB_WAKE_A')
resistor('R1304', '100k 1%', 'RC0603FR-07100KL', 'SYS_ENABLE', 'GND')
by['U1301']['note'] = 'LTC EN is isolated by D1301; USB wake can hold the MCU on in charge-only mode after LTC KILL. Long press disables performance loads, not the USB-powered housekeeping domain.'

net('U801', 1, None, 'AUDIO_PWR_EN')
pin('U801', 1).update({'name':'PE2_AUDIO_PWR_EN','electricalType':'output'})
net('U801', 7, None, 'AUDIO_BUS_EN')
pin('U801', 7).update({'name':'PE8_AUDIO_BUS_EN','electricalType':'output'})
add('U1901', 'IC', 'sequenced performance-domain supply', 'TPS22918DBVR', 'SOT23-6 DBV;max1.45mm height',
    [(1,'VIN','V3D','power_in'),(2,'GND','GND','power_in'),(3,'ON','AUDIO_PWR_EN','input'),
     (4,'CT','LOAD_CT','passive'),(5,'QOD','LOAD_QOD','passive'),(6,'VOUT','V3LOAD','power_out')], 'switch')
resistor('R1911', '100k 1%', 'RC0603FR-07100KL', 'AUDIO_PWR_EN', 'GND')
resistor('R1912', '1k 1%', 'RC0603FR-071KL', 'V3LOAD', 'LOAD_QOD')
resistor('R1913', '100k 1%', 'RC0603FR-07100KL', 'AUDIO_BUS_EN', 'GND')
for ref,value,mpn,a in [('C1901','10nF C0G 50V','CC0603JRNPO9BN103','LOAD_CT'),
                       ('C1902','2.2uF X7R 16V; effective>=1uF','CC0603KRX7R7BB225','V3D'),
                       ('C1903','100nF X7R 16V','CC0603KRX7R7BB104','V3LOAD')]:
    add(ref, 'C', value, mpn, '0603; exact DC-bias reviewed in passive-closure',
        [(1,'1',a,'passive'),(2,'2','GND','passive')])
add('U1902', 'IC', 'audio I2C powered-domain isolation', 'TMUX1511PWR', 'TSSOP14 PW;maxheight1.2mm',
    [(1,'SEL1','AUDIO_BUS_EN','input'),(2,'S1','I2C_SDA','passive'),(3,'D1','I2C_AUDIO_SDA','passive'),
     (4,'SEL2','AUDIO_BUS_EN','input'),(5,'S2','I2C_SCL','passive'),(6,'D2','I2C_AUDIO_SCL','passive'),
     (7,'GND','GND','power_in'),(8,'D3','GND','passive'),(9,'S3','GND','passive'),(10,'SEL3','GND','input'),
     (11,'D4','GND','passive'),(12,'S4','GND','passive'),(13,'SEL4','GND','input'),(14,'VDD','V3D','power_in')], 'isolation')
net('U601',23,'I2C_SDA','I2C_AUDIO_SDA')
net('U601',24,'I2C_SCL','I2C_AUDIO_SCL')
for ref,number in [('U601',13),('U601',14),('U701',11),('U701',20),('U901',3),
                   ('FB1101',1),('C606',1),('C607',1),('C608',1),('C714',1),
                   ('C715',1),('C902',1),('C903',1),('R902',2),('J902',1)]:
    net(ref,number,'V3D','V3LOAD')
by['J902']['note'] = 'Factory target-voltage reference is V3LOAD, not V3D. No adapter voltage injection when performance rail is off. Enable PE2 only after fixture safety checks, hold STM reset for ROM boot only after a controlled rail supply mode.'

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

selected = [c for c in by.values() if c not in before]
write(OUT/'corrected-components.json', selected)
write(OUT/'authorized-net-deltas.json', changes)
write(source, list(by.values()))
write(OUT/'native-revision.json', {'parts':len(by),'pins':sum(len(c['pins']) for c in by.values()),
                                'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})

# The cold-temperature forward drop is a design bound to validate, not a
# nonexistent manufacturer guarantee. Leakage uses a specified hot limit.
rp_hi, rd_lo, rd_hi = 33000*1.01,100000*.99,100000*1.01
vf_bound=1.5
min_manual=(3.0-vf_bound)*rd_lo/(rd_lo+rp_hi)-.2e-6*rd_hi
min_usb=(4.1-vf_bound)*rd_lo/(rd_lo+rp_hi)-.2e-6*rd_hi
off_bound=.4+(.2e-6+2*80e-9)*rd_hi
assert min_manual>.83 and min_usb>.83 and off_bound<.67
calc = {'manualEnableLowerVUnderAssumedForwardBound':min_manual,
        'usbEnableLowerVUnderAssumedForwardBound':min_usb,
        'offUpperV':off_bound,'risingThresholdMaxV':.83,'fallingThresholdMinV':.67,
        'diodeForwardDesignBoundV':vf_bound,
        'forwardBoundScope':'1.5V assumed cold/process envelope;datasheet VF max1.25V at150mA,25C;cold qualification still required',
        'hotReverseLeakageEachA':80e-9,'enableInputLeakageA':.2e-6,
        'LtcSinkCurrentUpperA':4.45/(33000*.99),
        'wakeResistorWorstPowerW':5.84**2/(33000*.99),
        'loadSwitchWorstResistanceOhmAt3V3_105C':.08,
        'performanceDomainCurrentAllocationA':.65,
        'switchConductionLossAllocationW':.65**2*.08,
        'switchDropAllocationV':.65*.08,
        'CTtypicalRiseTimeMs':3.3*(.55*10000+30)/1000,
        'loadOutputCapMaxAllocationF':150e-6,
        'typicalInrushCapOnlyA':150e-6*3.3/(3.3*(.55*10000+30)/1e6),
        'QODseriesResistorWorstInitialCurrentA':3.45/(1000*.99),
        'QODresistorWorstInitialPowerW':3.45**2/(1000*.99),
        'QODenergyMaxJ':.5*150e-6*3.45**2,
        'usb100BootBudget':{'maximumInputA':.1,'V3DloadAllocationA':.06,'V3DmaxV':3.45,
                           'conversionEfficiencyAssumption':.70,'USBminV':4.35,'overheadAllocationA':.005,
                           'allocatedInputA':3.45*.06/(.70*4.35)+.005,
                           'scope':'allocation only,not guaranteed STM32 maximum;audioADC,DAC,ESP off;early HSI8MHz and measured startup required'},
        'chargerThermalScreen':{'USBmaxV':5.25,'batteryPrechargeExampleV':3.0,
                                'chargeUpperAllocationA':.198,'estimatedChargeDropLossW':(5.25-3.0)*.198,
                                'scope':'conservative screen excluding system-path loss;actual current automatically reduced in precharge/DPPM/thermal regulation'},
        'status':'DESIGN_CALCULATIONS_WITH_DECLARED_BOUNDS_NO_PHYSICAL_TEST'}
assert calc['usb100BootBudget']['allocatedInputA']<.1
write(OUT/'calculations.json',calc)
write(OUT/'sequence.json',{'coldBoot':['Default CHARGE_ALLOW,PE2,PE8,RF and allaudio outputs low before runtime init.',
    'USB100 mode remains00;raw source loss is not inferred from eFuse output zero.',
    'Read nonvolatile fault journal;start independent watchdog;set HSI8MHz charge housekeeping.',
    'Check current authorized source,pack configuration,NTC/sensor freshness and supply before charge authorization.'],
    'performanceOn':['Require authorized source/battery budget.','PE2 high;wait>=50ms provisional and measure V3LOAD;no data injection during ramp.',
                     'PE8 high;configure ADC;start/validate clocks and DMA while muted.','Enable outputs only after valid frames and qualified load configuration.'],
    'performanceOff':['Mute allaudio;PORT/HP/SPK and RF low.','PE8 low;stop DMA,clocks and UART;drive pins low/analog.',
                      'PE2 low;wait discharge before factory reset/connector work.'],
    'userOffWithUSB':['Release LTC KILL after performanceOff,USB_OR holds housekeeping alive.',
                      'Charge-only allowed only with valid pack/NTC/sensors and no latchedfault;do not release fault simply on USBsafe=0.'],
    'status':'CAPTURED_HARDWARE_SEQUENCE_TARGET_IMPLEMENTATION_AND_BENCH_VALIDATION_SEPARATE'})
print(json.dumps({'parts':len(by),'newOrChanged':len(selected),'pins':sum(len(c['pins']) for c in by.values()),'netDeltas':len(changes)},ensure_ascii=False))
