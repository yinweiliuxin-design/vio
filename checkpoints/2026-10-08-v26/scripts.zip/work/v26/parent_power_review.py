"""Independent arithmetic and original-record checks for unapplied power ECOs."""
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
A = ROOT / 'audit/power-closure-v26'
source = ROOT / 'electrical/native-components.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
native = read(source)
byref = {c['ref']: c for c in native}
guards = read(A / 'original-ref-net-guards.json')
assert guards['source_sha256'] == sha(source)
for row in guards['records']:
    assert row['original_record'] == byref[row['ref']]
    assert native[row['array_index']]['ref'] == row['ref']
    digest = hashlib.sha256(json.dumps(byref[row['ref']], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert digest == row['original_record_canonical_sha256']

checks = read(A / 'verification.json')['checks']
assert len(checks) == 15 and all(checks.values())
for name, expected in read(A / 'artifact-hashes.json').items():
    p = (A / name).resolve()
    assert p.is_relative_to(A.resolve()) and sha(p) == expected

budget = read(A / 'same-corner-pack-budget.json')
assert budget['source_sha256'] == sha(source)
for row in budget['rows']:
    v, eta, r = row['loaded_SYS_V'], row['both_efficiencies_assumed'], row['speaker_R_ohm']
    independent = .65 * 3.45 / (v * eta) + 1 / (r * v * eta) + .010
    assert math.isclose(independent, row['total_A'], abs_tol=1e-12)

charge = read(A / 'charge-calculations.json')
independent = []
for choice in charge['choices']:
    ri, rt, tm = [choice[k] for k in ['RISET_ohm', 'RITERM_ohm', 'RTMR_ohm']]
    ri_min_loaded = 1 / (1 / (ri * .995) + 1 / 9700000)
    iterm_max = .0375 * rt * 1.005 / ri_min_loaded * 1000
    timer_min = 10 * (tm * .995 / 1000) * 36 / 3600
    timer_max = 10 * (tm * 1.005 / 1000) * 60 / 3600
    assert math.isclose(iterm_max, choice['termination_nonUSB100_mA_min_nom_max'][2], abs_tol=1e-12)
    assert math.isclose(timer_min, choice['fast_timer_h_min_nom_max'][0], abs_tol=1e-12)
    assert math.isclose(timer_max, choice['fast_timer_h_min_nom_max'][2], abs_tol=1e-12)
    assert iterm_max < 10 and not choice['normal_charging_authorized']
    independent.append({'choice': choice['id'], 'ITERMmaxModel_mA': iterm_max,
                        'fastCountedTimer_h': [timer_min, timer_max]})

cap = read(A / 'compact-ceff-proposals.json')
result = {'verifiedUTC': datetime.now(timezone.utc).isoformat(), 'sourceSha256': sha(source),
          'sourceComponents': len(native), 'originalComponentGuardsVerified': len(guards['records']),
          'all15StructuredChecksReexecuted': True, 'auditArtifactHashesVerified': True,
          'sameCornerCurrentIndependentlyRecomputed': True, 'chargerIndependentArithmetic': independent,
          'globalElectricalOrBoardECOApplied': False, 'normalChargeAllowed': False,
          'disposition': 'AUDIT_CORRECTIONS_MERGED_PROPOSALS_ONLY_NOT_PRODUCTION_BOM',
          'limitations': ['Typical capacitor curves and allocated drift/aging are not combined guarantees.',
                          'C807/C808 remain HOLD; no VCAP approval is inferred from15 arithmetic checks.',
                          'Fast charge needs actual source grant, thermal layout and persistent session cap.',
                          'No full1000mAh charge completion or current/thermal hardware result is claimed.'],
          'physicalTests': 0, 'productionApproved': False}
(ROOT / 'audit/system-v26/parent-power-review.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
