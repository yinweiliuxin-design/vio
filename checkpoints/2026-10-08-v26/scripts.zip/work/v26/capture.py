"""Rebuild V26 native sheets from the current, merged pin-level source."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
EDA = ROOT / 'eda'
parts = json.loads((ROOT / 'electrical/native-components.json').read_text(encoding='utf-8'))
by = {c['ref']: c for c in parts}
old = json.loads((ROOT / 'reference/v25-circuits.json').read_text(encoding='utf-8'))
sheets = []
consumed = set()
for s in old:
    ns = {k: copy.deepcopy(v) for k, v in s.items() if k != 'components'}
    ns['components'] = [by[c['ref']] for c in s['components'] if c['ref'] in by]
    consumed.update(c['ref'] for c in ns['components'])
    if ns['components']:
        sheets.append(ns)
for c in parts:
    if c['ref'] in consumed:
        continue
    sid = c.get('sheet', 'A34')
    s = next((s for s in sheets if s['id'] == sid), None)
    if s is None:
        s = {'id': sid, 'title': {'A32': 'USB wake and sequenced performance domain',
                                'A33': 'Independent NTC charging window'}.get(sid, 'V26 additions'),
             'components': []}
        sheets.append(s)
    s['components'].append(c)
    consumed.add(c['ref'])
assert consumed == set(by)
(ROOT / 'reference/v26-circuits.json').write_text(json.dumps(sheets, ensure_ascii=False, indent=2), encoding='utf-8')
template = ROOT / 'reproduce/capture-template.py'
if not template.exists():
    original = (BASE / 'outputs/SmartVio-V25-Engineering/reproduce/capture_library.py').read_text(encoding='utf-8')
    template.write_text(original.split('\ndef main():', 1)[0], encoding='utf-8')
src = template.read_text(encoding='utf-8')
src = src.replace('v25-circuits.json', 'v26-circuits.json').replace('V25', 'V26')
src = src.replace("    sid = uid(name + project)\n", "    sid = uid(name + project)\n    compact = len(components) <= 12 and max(len(c['pins']) for c in components) <= 32\n    cols = 3 if compact else 4\n    paper = 'A3' if compact else 'A2'\n")
src = src.replace('(paper "A2")\\n\'\n    s += f\'(title_block', '(paper "{paper}")\\n\'\n    s += f\'(title_block')
src = src.replace('    heights = [32., 32., 32., 32.]', '    heights = [32.] * cols')
src = src.replace('col = min(range(4), key=lambda i: heights[i])', 'col = min(range(cols), key=lambda i: heights[i])')
src = src.replace('x, y = 78 + col * 140, heights[col] + h / 2 + 10', 'x, y = (65 + col * 130 if compact else 78 + col * 140), heights[col] + h / 2 + 10')
src = src.replace('if heights[col] > 365:', 'if heights[col] > (245 if compact else 365):')
src += '\nif __name__ == "__main__":\n    raise SystemExit("Helper module only. Rebuild current native source using work/v26/capture.py; never reset it from an old circuit list.")\n'
(ROOT / 'reproduce/capture_library.py').write_text(src, encoding='utf-8')
spec = importlib.util.spec_from_file_location('capture_v26', ROOT / 'reproduce/capture_library.py')
lib = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lib)
uid, q, fx = lib.uid, lib.q, lib.fx
rootuuid = uid('SmartVio')
flaglib = '(symbol "SmartVio:PWR_FLAG" (power) (pin_names (offset 0) hide) (in_bom no) (on_board no) (property "Reference" "#FLG" (at 0 0 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at 0 2.54 0) (effects (font (size 1 1)))) (symbol "PWR_FLAG_1_1" (pin power_out line (at 0 0 90) (length 0) (name "pwr" (effects (font (size 1 1)))) (number "1" (effects (font (size 1 1)))))))'
root = f'(kicad_sch (version 20260101) (generator "smartvio_v26_review") (uuid {rootuuid}) (paper "A2") (lib_symbols {flaglib})\n'
root += lib.text('SmartVio V26 - Native engineering capture / NOT RELEASED', 20, 18, 3)
root += lib.text('Current revision only. Read index.html and verification. Physical tests are not represented by ERC.', 20, 26, 1.3)
for i, s in enumerate(sheets):
    name, pageid = s['id'], uid(s['id']+'sheet')
    x, y = 20+(i % 4)*140, 40+(i // 4)*55
    root += f'(sheet (at {x} {y}) (size 120 32) (stroke (width 0.254) (type default)) (fill (color 0 0 0 0)) (uuid {pageid})\n'
    root += f'(property "Sheetname" {q(name+" "+s["title"])} (at {x} {y-2} 0) (effects (font (size 1.1 1.1)) (justify left bottom)))\n'
    root += f'(property "Sheetfile" {q(name+".kicad_sch")} (at {x} {y+34} 0) (effects (font (size 1.1 1.1)) (justify left top)))\n'
    root += f'(instances (project "SmartVio" (path "/{rootuuid}" (page "{i+2}")))))\n'
    (EDA / (name+'.kicad_sch')).write_text(lib.capture(name, s['components'], name+' '+s['title'], pageid, parent_uuid=rootuuid), encoding='utf-8')
root += lib.text('Supply declarations: external VBUS and GND; passive-filtered V3A/MCU_VDDA. No ERC exclusions.', 20, 375, 1.2)
for i, net in enumerate(['GND', 'V3A', 'MCU_VDDA', 'VBUS_RAW']):
    x, y, ref = 50.8+i*100.33, 386.08, '#FLG'+str(i+1)
    root += f'(symbol (lib_id "SmartVio:PWR_FLAG") (at {x} {y} 0) (unit 1) (in_bom no) (on_board no) (uuid {uid(ref)}) (property "Reference" {q(ref)} (at {x} {y} 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at {x} {y-3.81} 0) {fx}) (instances (project "SmartVio" (path "/{rootuuid}" (reference {q(ref)}) (unit 1)))))\n'
    root += f'(global_label {q(net)} (shape passive) (at {x} {y} 0) {fx} (uuid {uid(ref+net)}))\n'
root += '(sheet_instances (path "/" (page "1"))))\n'
(EDA / 'SmartVio.kicad_sch').write_text(root, encoding='utf-8')
(EDA / 'SmartVio.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "smartvio_v26_review")\n'+''.join(lib.library(c, False) for c in parts)+flaglib.replace('SmartVio:PWR_FLAG', 'PWR_FLAG')+')\n', encoding='utf-8')
(EDA / 'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "SmartVio") (type "KiCad") (uri "${KIPRJMOD}/SmartVio.kicad_sym") (options "") (descr "V26 current native review symbols")))', encoding='utf-8')
(EDA / 'SmartVio.kicad_pro').write_text(json.dumps({'meta': {'filename': 'SmartVio.kicad_pro', 'version': 1}, 'erc': {'erc_exclusions': []}}, indent=2), encoding='utf-8')
summary = {'revision': 'V26', 'sheets': len(sheets)+1, 'components': len(parts),
           'pins': sum(len(c['pins']) for c in parts),
           'sourceSha256': hashlib.sha256((ROOT / 'electrical/native-components.json').read_bytes()).hexdigest(),
           'release': 'NOT_RELEASED', 'physicalTestCount': 0}
(ROOT / 'verification/capture-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
