"""Isolate the new engineering revision without changing the V25 delivery."""
import json
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
OLD = BASE / 'outputs/SmartVio-V25-Engineering'
NEW = BASE / 'outputs/SmartVio-V26-Engineering'
if NEW.exists():
    raise SystemExit('V26 already exists; bootstrap will not overwrite it')
shutil.copytree(OLD, NEW)
history = NEW / 'historical-v25'
history.mkdir()
for name in ('index.html', 'bom.html', 'controls.html', 'FACTORY-HANDOFF.txt', 'SHA256SUMS.json'):
    if (NEW / name).exists():
        shutil.move(str(NEW / name), str(history / name))
state = {
    'revision': 'V26',
    'basis': 'V25',
    'status': 'WORK_IN_PROGRESS_NOT_RELEASED',
    'physicalTestsExecuted': 0,
    'scope': 'No waiting dependency on violin-factory geometry or supplier samples in this revision. Manufacturing capability remains a declared process assumption, not a signed approval.',
    'inheritedFiles': 'Copied V25 files retain historical status until replaced and reverified. Never interpret their dates or PASS values as V26 verification.'
}
(NEW / 'revision-state.json').write_text(json.dumps(state, indent=2), encoding='utf-8')
print(NEW)
