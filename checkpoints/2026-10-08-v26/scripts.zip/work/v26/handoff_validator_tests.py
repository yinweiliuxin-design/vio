"""Bounded checkpoint checks; comprehensive handoff fixtures remain pending.

Run with python -B work/v26/handoff_validator_tests.py. All transient data stays
under workspace/tmp. This suite does not inspect changing live boards or SDKs.
"""
import ast
import io
import json
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import validate_handoff as validator

BASE = Path(__file__).resolve().parents[2]
REPORT = BASE / 'outputs/SmartVio-V26-Engineering/verification/handoff-validator-negative-tests.json'
PENDING = [
    'Build minimum normative five-board/four-CAM handoff fixture and verify integrity PASS.',
    'Replace old DRC and regenerate broad manifest; verify internal report SHA rejection.',
    'Tamper DRC counts and current summary independently.',
    'Alter ARM/ESP artifacts, safety inputs and parent actual hashes independently.',
    'Promote release booleans in normative fixture; verify integrity PASS and production exit2.',
    'Verify external RT1921 against real schema without requiring a PCB footprint.',
    'Check fully regenerated handoff after parent completes current board snapshot.',
    'Packaging must include verification/erc.json and verification/capture-map-sync-v26.json; current package.py omits them.',
    'Review package path containment and evidence aliases before accepting untrusted handoffs.',
]


class CheckpointTests(unittest.TestCase):
    def test_validator_syntax(self):
        ast.parse(Path(validator.__file__).read_text(encoding='utf-8'))

    def test_quoted_kicad_atoms(self):
        self.assertEqual(validator.sexpr('(root (property "Value" "a (b)"))'),
                         ['root', ['property', 'Value', 'a (b)']])

    def test_malformed_kicad_rejected(self):
        for text in ('(root', '(root))', '(root) (extra)', 'atom'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                validator.sexpr(text)

    def test_integrity_and_production_exit_separate(self):
        result = {'integrity': 'PASS', 'manufactureRelease': False,
                  'declaredManufactureRelease': True, 'productionBlockers': ['DRC_NOT_CLOSED:main']}
        self.assertEqual(validator.exit_code(result), 0)
        self.assertEqual(validator.exit_code(result, True), 2)

    def test_integrity_failure_has_priority(self):
        self.assertEqual(validator.exit_code({'integrity': 'FAIL', 'manufactureRelease': True}, True), 1)

    def test_missing_handoff_fails_closed(self):
        temp_root = BASE / 'tmp'
        temp_root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='v26-validator-checkpoint-', dir=temp_root) as folder:
            result = validator.validate(Path(folder))
            self.assertEqual(result['integrity'], 'FAIL')
            self.assertFalse(result['manufactureRelease'])
            self.assertEqual(validator.exit_code(result, True), 1)


if __name__ == '__main__':
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(CheckpointTests))
    report = {
        'schema': 'smartvio.v26.handoff-validator-checkpoint.1',
        'checkedUTC': datetime.now(timezone.utc).isoformat(),
        'checkpointStatus': 'SAVED_INCOMPLETE_USER_STOPPED_EXPANSION',
        'limitedChecks': 'PASS' if result.wasSuccessful() else 'FAIL',
        'testsRun': result.testsRun,
        'failures': len(result.failures),
        'errors': len(result.errors),
        'testOutput': stream.getvalue(),
        'validatorSHA256': validator.sha(Path(validator.__file__)),
        'testSHA256': validator.sha(Path(__file__)),
        'pending': PENDING,
        'fullHandoffContentBindingValidated': False,
        'normativeFixtureProductionGateValidated': False,
        'normalCharging': 'DISABLED',
        'productionApproved': False,
        'hardwareApproved': False,
        'remotePushed': False,
        'originalProjectGitRepositoryDetected': False,
        'cloudHandoffEdited': False,
    }
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(stream.getvalue(), end='')
    print(str(REPORT))
    raise SystemExit(0 if result.wasSuccessful() else 1)
