"""Synchronize two reviewed zero-ohm MPN fields without changing native copper."""
import copy
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE / 'work/v26/parser-tools'))
import sexpdata as sx

ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
PCB = ROOT / 'pcb-work'
board = PCB / 'SmartVio-usb-v26-final.kicad_pcb'
source = ROOT / 'electrical/native-components.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
key = lambda n: str(n[0]) if isinstance(n, list) and n else ''
children = lambda n, k: [v for v in n if key(v) == k]
components = {c['ref']: c for c in json.loads(source.read_text(encoding='utf-8-sig'))}
before = sx.loads(board.read_text(encoding='utf-8'))
after = copy.deepcopy(before)
changes = []
for fp in children(after, 'footprint'):
    props = {p[1]: p for p in children(fp, 'property')}
    ref = props['Reference'][2]
    if ref not in ['R403', 'R404']:
        continue
    expected = components[ref]['mpn']
    assert expected == 'RC0603JR-070RL'
    previous = props['MPN'][2]
    assert previous in ['', expected], (ref, previous)
    if previous != expected:
        props['MPN'][2] = expected
        changes.append({'ref': ref, 'field': 'MPN', 'before': previous, 'after': expected})
restored = copy.deepcopy(after)
for fp in children(restored, 'footprint'):
    props = {p[1]: p for p in children(fp, 'property')}
    if props['Reference'][2] in [c['ref'] for c in changes]:
        props['MPN'][2] = next(c['before'] for c in changes if c['ref'] == props['Reference'][2])
assert restored == before, 'Unexpected geometry, connectivity or field change'
backup = PCB / 'verification/pre-parent-local/SmartVio-usb-before-zeroohm-metadata.kicad_pcb'
backup.parent.mkdir(exist_ok=True)
if changes:
    assert not backup.exists(), 'Preserve the original synchronization snapshot'
    backup.write_bytes(board.read_bytes())
    board.write_text(sx.dumps(after) + '\n', encoding='utf-8')
    assert sx.loads(board.read_text(encoding='utf-8')) == after
record = {'sourceSHA256': sha(source), 'boardSHA256': sha(board), 'changes': changes,
          'onlyTwoMPNFieldsChanged': True, 'nativeDRCRequired': True,
          'productionApproved': False}
(PCB / 'verification/usb-zeroohm-metadata-sync.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record, indent=2))
