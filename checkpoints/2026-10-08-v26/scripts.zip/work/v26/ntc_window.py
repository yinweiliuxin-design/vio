"""Capture an independent charger temperature inhibit and calculate corners."""
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'audit/system-v26'
source = ROOT / 'electrical/native-components.json'
old = json.loads(source.read_text(encoding='utf-8'))
by = {c['ref']: copy.deepcopy(c) for c in old}
assert not set(['U1921', 'R1921', 'R1922', 'C1921']) & set(by)
proof = {'url': 'https://www.ti.com/lit/ds/symlink/tps3700.pdf',
         'section': 'DDC pin functions; 6.5 threshold/startup limits; 7.3 comparator polarity'}
changes = []

def add(ref, kind, value, mpn, package, pp):
    pins = [{'number': str(n), 'name': name, 'net': net, 'electricalType': typ,
             'footprintPad': str(n)} for n, name, net, typ in pp]
    c = {'ref': ref, 'type': kind, 'value': value, 'mpn': mpn,
         'package': package, 'sheet': 'A33', 'pins': pins,
         'release': 'ENGINEERING_REVIEW_NOT_MANUFACTURING_RELEASE',
         'procurementApproved': False}
    if kind == 'IC':
        for p in pins:
            p.update({'evidence': proof, 'pinAuditStatus': 'VERIFIED_OFFICIAL'})
    by[ref] = c
    changes.append({'ref': ref, 'action': 'add', 'mpn': mpn})

add('U1921', 'IC', 'independent pack NTC window inhibits charge gate', 'TPS3700DDCR',
    'DDC SOT23-6; official land required',
    [(1, 'OUTA', 'CHARGE_GATE', 'open_collector'), (2, 'GND', 'GND', 'power_in'),
     (3, 'INA+', 'PACK_NTC', 'input'), (4, 'INB-', 'NTC_COLD_DIV', 'input'),
     (5, 'VDD', 'SYS', 'power_in'), (6, 'OUTB', 'CHARGE_GATE', 'open_collector')])
add('R1921', 'R', '301k 1%', 'RC0603FR-07301KL', '0603;1%;0.1W',
    [(1, '1', 'PACK_NTC', 'passive'), (2, '2', 'NTC_COLD_DIV', 'passive')])
add('R1922', 'R', '100k 1%', 'RC0603FR-07100KL', '0603;1%;0.1W',
    [(1, '1', 'NTC_COLD_DIV', 'passive'), (2, '2', 'GND', 'passive')])
add('C1921', 'C', '100nF X7R 16V', 'CC0603KRX7R7BB104', '0603',
    [(1, '1', 'SYS', 'passive'), (2, '2', 'GND', 'passive')])
assert by['R1601']['value'].startswith('1k')
by['R1601'].update({'value': '4.7k 1%', 'mpn': 'RC0603FR-074K7L',
                   'note': 'Limits MCU versus TPS3700 open-drain sink to <0.75mA; hardware inhibit always wins.'})
by['R1601'].pop('bomEvidence', None)
changes.append({'ref': 'R1601', 'action': 'value', 'before': '1k', 'after': '4.7k'})
by['U501']['note'] = ('BQ24074 native TS protection remains active. TPS3700 adds a narrower independent '
                      'window on the same NTC, with 401k divider loading included. CHG status alone '
                      'does not prove charging during a TS fault. Selected pack must meet the specified NTC envelope.')

def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

write(source, list(by.values()))
write(OUT / 'ntc-corrected-components.json', [by[r] for r in ['U1921', 'R1921', 'R1922', 'C1921', 'R1601', 'U501']])
write(OUT / 'ntc-authorized-net-deltas.json', changes)
write(OUT / 'native-revision.json', {'parts': len(by), 'pins': sum(len(c['pins']) for c in by.values()),
                                   'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})

def temp(r, r25, beta):
    return 1 / (1 / 298.15 + math.log(r / r25) / beta) - 273.15

def corners(beta_nom, rtol, btol):
    results = {'hotTripC': [], 'coldTripC': [], 'hotReleaseC': [], 'coldReleaseC': []}
    for its, top, bottom, ia, ib, r25, beta in itertools.product(
            [72e-6, 78e-6], [301000*.99, 301000*1.01], [100000*.99, 100000*1.01],
            [-25e-9, 25e-9], [-15e-9, 15e-9], [10000*(1-rtol), 10000*(1+rtol)],
            [beta_nom*(1-btol), beta_nom*(1+btol)]):
        # INA input bias is a load at TS. INB bias shifts both TS loading and its divided reading.
        for category, thresholds in [('hotTripC', [.387, .400]), ('hotReleaseC', [.396, .404])]:
            for threshold in thresholds:
                vts = threshold
                vb = (vts/top - ib) / (1/top + 1/bottom)
                intc = its - ia - (vts - vb)/top
                results[category].append(temp(vts/intc, r25, beta))
        for category, thresholds in [('coldTripC', [.396, .404]), ('coldReleaseC', [.387, .400])]:
            for threshold in thresholds:
                vb = threshold
                vts = vb*(1+top/bottom) + ib*top
                intc = its - ia - (vts-vb)/top
                results[category].append(temp(vts/intc, r25, beta))
    return {k: {'min': min(v), 'max': max(v), 'cornerCount': len(v)} for k, v in results.items()}

envelopes = []
for beta, rtol, btol in [(3435, .01, .01), (3950, .01, .01), (3435, .05, .03)]:
    c = corners(beta, rtol, btol)
    approved = c['hotTripC']['max'] < 45 and c['coldTripC']['min'] > 0
    envelopes.append({'R25Ohm': 10000, 'BetaK': beta, 'R25Tolerance': rtol,
                      'BetaTolerance': btol, 'bounds': c, 'inside0to45DesignWindow': approved})
assert envelopes[0]['inside0to45DesignWindow'] and envelopes[1]['inside0to45DesignWindow']
write(OUT / 'ntc-window-calculations.json', {
    'status': 'CALCULATED_WITH_SPECIFIED_NTC_ENVELOPES_NOT_PACK_QUALIFICATION',
    'source': proof, 'TSCurrentA': {'min': 72e-6, 'max': 78e-6},
    'dividerLoadingOhmNominal': 401000,
    'NTCRequiredEnvelope': '10k R25 +/-1%, B3435 or B3950 +/-1%; selection must match exact supplier specifications',
    'evaluatedEnvelopes': envelopes,
    'comparatorGateSinkUpperA': 3.45/(4700*.99),
    'gateEnabledLowerV': 3.3*(100000*.99)/(100000*.99+4700*1.01),
    'comparatorPORmaxSeconds': .000450,
    'unpoweredInputMaxV': 5.84, 'comparatorInputRatedMaxV': 6.5,
    'faultBehavior': [
        'Hot/cold outputs clamp CHARGE_GATE even if MCU command is high; Q1601 releases CE high.',
        'NTC open trips cold; NTC short trips hot; default CHARGE_ALLOW low until sensor validation.',
        'Hardware trip automatically releases in its hysteresis band; MCU fault journal still requires explicit safe recovery.',
        'Shorted Q1601 is not covered by this single inhibit and leaves only BQ native TS; no single-fault safety certification is claimed.'
    ],
    'limitations': [
        'Input-bias maximum test conditions and resistor temperature coefficients require final application review.',
        'Beta equation is an engineering approximation, not the supplier full R/T table.',
        'No actual thermistor, battery, temperature sweep or charging test has been run.'
    ]})
print(json.dumps({'parts': len(by), 'pins': sum(len(c['pins']) for c in by.values()),
                  'windowCorners': envelopes}, ensure_ascii=False))
