"""Candidate local native-copper repairs, subject to a new strict DRC."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path
import pcbnew as p

ROOT = Path(__file__).resolve().parents[2] / 'outputs/SmartVio-V26-Engineering/pcb-work'
parser = argparse.ArgumentParser()
parser.add_argument('kind', choices=['usb', 'audio'])
args = parser.parse_args()
src = ROOT / f'SmartVio-{args.kind}-v26-final.kicad_pcb'
dst = ROOT / f'SmartVio-{args.kind}-v26-parent-local.kicad_pcb'
b = p.LoadBoard(str(src))
before = {t.m_Uuid.AsString(): t.GetNetname() for t in b.GetTracks()}
pad_before = {(f.GetReference(), pad.GetNumber(), pad.GetPosition().x, pad.GetPosition().y): pad.GetNetname()
              for f in b.GetFootprints() for pad in f.Pads()}
held = []
paths = ([('VBUS_RAW', [(12, 11.6246), (12, 11.05), (12.3522, 11.05), (12.3522, 11.2724)])] if args.kind == 'usb' else
         [('GND', [(25.5, 11), (25.5, 12.8)]), ('GND', [(44, 11), (44, 12.8)])])
for net, pts in paths:
    for start, end in zip(pts, pts[1:]):
        t = p.PCB_TRACK(b)
        t.SetStart(p.VECTOR2I(p.FromMM(start[0]), p.FromMM(start[1])))
        t.SetEnd(p.VECTOR2I(p.FromMM(end[0]), p.FromMM(end[1])))
        t.SetLayer(p.B_Cu)
        t.SetWidth(p.FromMM(0.2))
        t.SetNetCode(b.FindNet(net).GetNetCode())
        b.Add(t)
        held.append(t)
assert all(t.GetNetname() == before[t.m_Uuid.AsString()] for t in b.GetTracks() if t.m_Uuid.AsString() in before)
p.SaveBoard(str(dst), b)
saved = p.LoadBoard(str(dst))
assert all(t.GetNetname() == before[t.m_Uuid.AsString()] for t in saved.GetTracks() if t.m_Uuid.AsString() in before)
pad_after = {(f.GetReference(), pad.GetNumber(), pad.GetPosition().x, pad.GetPosition().y): pad.GetNetname()
             for f in saved.GetFootprints() for pad in f.Pads()}
assert pad_before == pad_after, 'Do not accept a CAD edit that changes any original pad net'
for ext in ['.kicad_pro', '.kicad_dru']:
    if src.with_suffix(ext).exists():
        shutil.copy2(src.with_suffix(ext), dst.with_suffix(ext))
(ROOT / 'verification' / f'parent-{args.kind}-local-eco.json').write_text(json.dumps({
    'sourceBoardSha256': hashlib.sha256(src.read_bytes()).hexdigest(), 'candidate': str(dst),
    'paths': paths, 'traceWidthMm': 0.2, 'layer': 'B.Cu', 'strictDRCRequired': True,
    'allNetsAndPadsPreserved': True, 'manufactureRelease': False}, indent=2), encoding='utf-8')
print(dst)
