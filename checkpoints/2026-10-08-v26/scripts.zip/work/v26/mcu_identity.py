"""Correct and independently validate physical LQFP100 port identities."""
import hashlib
import json
import re
from pathlib import Path

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V26-Engineering'
source=ROOT/'electrical/native-components.json'
parts=json.loads(source.read_text(encoding='utf-8'))
c=next(c for c in parts if c['ref']=='U801')
p=next(p for p in c['pins'] if p['number']=='7')
assert p['name']=='PE8_AUDIO_BUS_EN' and p['net']=='AUDIO_BUS_EN'
p.update({'name':'PC13_AUDIO_BUS_EN','nativeName':'PC13','footprintPad':'7',
          'pinAuditStatus':'VERIFIED_OFFICIAL',
          'evidence':{'url':'https://www.st.com/resource/en/datasheet/stm32h743vi.pdf',
                      'section':'DS12110 Rev11 Figure5 LQFP100:7PC13,38PE8; Tables52/149 backup IO current limits'},
          'applicationConstraints':'Low-speed selector only;~35uA resistor plus leakage,never LED drive;not PE8.'})
source.write_text(json.dumps(parts,ensure_ascii=False,indent=2),encoding='utf-8')
out=ROOT/'audit/system-v26'
(out/'mcu-pin7-correction.json').write_text(json.dumps({'ref':'U801','pin':'7','before':'PE8_AUDIO_BUS_EN',
    'after':'PC13_AUDIO_BUS_EN','netChanged':False,'firmwarePort':'C','firmwareBit':13,
    'evidence':p['evidence'],'reason':'Independent package identity check; ERC cannot detect GPIO naming mistakes'},indent=2),encoding='utf-8')
seq=out/'sequence.json'
j=json.loads(seq.read_text(encoding='utf-8'))
for key,value in j.items():
    if isinstance(value,list):j[key]=[s.replace('PE8','PC13') for s in value]
seq.write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf-8')
(out/'native-revision.json').write_text(json.dumps({'parts':len(parts),'pins':sum(len(x['pins']) for x in parts),
    'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2),encoding='utf-8')
print(json.dumps({'pin7Corrected':True,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest()}))
