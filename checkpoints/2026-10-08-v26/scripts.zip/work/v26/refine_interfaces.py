"""Refine the temperature margin and classify manufactured copper endpoints."""
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'audit/system-v26'
source = ROOT / 'electrical/native-components.json'
parts = json.loads(source.read_text(encoding='utf-8'))
by = {c['ref']:copy.deepcopy(c) for c in parts}
assert by['R1921']['value']=='169k 1%'
by['R1921'].update({'value':'158k 1%','mpn':'RC0603FR-07158KL',
                    'note':'Increase cold-side guard margin versus 169k preliminary choice.'})
endpoints=[]
for ref in ['J101','J801','J901','J902','J1801','J1802','J1921']:
    c=by[ref]
    c.update({'fabricatedFeature':True,'procurementClass':'PCB_COPPER_SOLDER_ENDPOINT',
              'mpn':None,'candidateManufacturer':'Fabricated with PCB; not purchased connector',
              'package':f'{len(c["pins"])} electrical pads,1.5mm pitch,0.9x0.9mm SMD copper;F.Cu/F.Mask;no F.Paste',
              'applicationReview':{'status':'ENDPOINT_CONNECTION_DEFINED','hotPlug':False,
                                   'assembly':'Solder de-energized wire, strain relieve; verify polarity and continuity before power',
                                   'physicalVerified':False}})
    for p in c['pins']:
        p['footprintPad']=p['number']
        p['evidence']={'source':'pcb-work/SmartVioV25.pretty/WirePads_*_P1.5.kicad_mod',
                       'section':'Manufactured endpoint pad geometry, not manufacturer part identity'}
        p['pinAuditStatus']='FABRICATED_ENDPOINT_DEFINED'
    endpoints.append({'ref':ref,'pads':[(p['number'],p['net']) for p in c['pins']],
                      'stockItem':False,'test':'Continuity, insulation, polarity and strain relief; not yet executed'})
def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
write(source,list(by.values()))
write(OUT/'internal-endpoints.json',endpoints)
write(OUT/'interface-refinement.json',{'resistor':{'ref':'R1921','before':'169k','after':'158k','pinsChanged':False},
                                      'endpoints':endpoints})
write(OUT/'native-revision.json',{'parts':len(by),'pins':sum(len(c['pins']) for c in by.values()),
                                'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
# Recalculate the exact same corner model with the revised cold divider.
calculation=(BASE/'work/v26/ntc_independent.py').read_text(encoding='utf-8').split('def temp(',1)[1]
calculation='def temp('+calculation.replace('169000','158000')
exec(compile(calculation,str(BASE/'work/v26/ntc_independent.py'),'exec'))
