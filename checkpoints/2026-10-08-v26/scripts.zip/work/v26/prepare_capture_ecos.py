"""Prepare current schematic fields; physical parity is verified separately."""
import json
import sys
from pathlib import Path

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V26-Engineering'
sys.path.insert(0,str(BASE/'work/v26/parser-tools'))
import sexpdata as sx
S=sx.Symbol
parts={c['ref']:c for c in json.loads((ROOT/'electrical/native-components.json').read_text(encoding='utf-8'))}
file=ROOT/'electrical/footprint-map.json'
mapping=json.loads(file.read_text(encoding='utf-8'))
for ref in ['J501','K1201','K1202','R403','R404','R601']:
    mapping[ref]['mpn']=parts[ref]['mpn']
    mapping[ref]['value']=parts[ref]['value']
mapping['J501']['id']=parts['J501']['footprint']
file.write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding='utf-8')
for folder in ['eda','pcb-work']:
    table=ROOT/folder/'fp-lib-table'
    tree=sx.loads(table.read_text())
    if not any(isinstance(x,list) and [S('name'),'SmartVio_Battery_Revision'] in x for x in tree):
        tree.append([S('lib'),[S('name'),'SmartVio_Battery_Revision'],[S('type'),'KiCad'],
                     [S('uri'),'${KIPRJMOD}/../audit/selection/battery-revision/footprints/SmartVio_Battery_Revision.pretty'],
                     [S('options'),''],[S('descr'),'JST official drawing land; assembly review required']])
        table.write_text(sx.dumps(tree)+'\n',encoding='utf-8')
print('Prepared schematic fields and portable library tables. Native board parity not asserted here.')
