"""Render all schematic pages and inspect bounds; no hardware claims."""
import json
import subprocess
from pathlib import Path
import pdfplumber
from PIL import Image, ImageChops, ImageDraw

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'verification/pdf-pages-v26'
OUT.mkdir(exist_ok=True)
pdf = ROOT / 'drawings/SmartVio-V26-Schematic-REVIEW.pdf'
poppler = Path('<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe')
cp = subprocess.run([str(poppler), '-scale-to', '1100', '-png', str(pdf), str(OUT/'page')], capture_output=True, text=True)
assert cp.returncode == 0, cp.stderr
images = sorted(OUT.glob('page-*.png'))
results = []
with pdfplumber.open(pdf) as document:
    assert len(document.pages) == len(images) == 24
    for i, (page, filename) in enumerate(zip(document.pages, images), 1):
        outside = [c['text'] for c in page.chars if c['x0'] < -0.5 or c['x1'] > page.width+0.5 or c['top'] < -0.5 or c['bottom'] > page.height+0.5]
        image = Image.open(filename).convert('RGB')
        bbox = ImageChops.difference(image, Image.new('RGB', image.size, image.getpixel((0,0)))).getbbox()
        results.append({'page': i, 'textOutsidePage': outside, 'renderedContentBox': bbox, 'textCharacters': len(page.chars), 'pass': bool(bbox) and bool(page.chars) and not outside})
montage = Image.new('RGB', (1320, 4*264), 'white')
draw = ImageDraw.Draw(montage)
for i, filename in enumerate(images):
    tile = Image.open(filename).convert('RGB')
    tile.thumbnail((216,240))
    x,y = (i%6)*220, (i//6)*264
    montage.paste(tile,(x,y+20))
    draw.text((x+8,y+3), f'Page {i+1}', fill='black')
montage.save(ROOT/'verification/schematic-montage-v26.png')
report = {'pages': len(results), 'results': results, 'pass': all(r['pass'] for r in results),
          'scope': 'Rendering/nonblank/text bounds only; visual review additionally required. No electrical or physical approval.'}
(ROOT/'verification/pdf-render-check-v26.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'pages':len(results),'pass':report['pass'],'outsidePageCount':sum(len(r['textOutsidePage']) for r in results)}))
