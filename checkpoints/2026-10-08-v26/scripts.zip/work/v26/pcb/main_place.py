"""Greedy area-first legalizer retaining all sides/orientations and manufacturer geometry."""
import copy
import json
import shutil
import numpy as np
from main_ast import *
src=OUT/'SmartVio-main-v26-final.kicad_pcb';tree=read(src)
source=OUT.parent/'electrical/native-components.json';sourcehash=sha(source)
assert sourcehash=='587358f65402f79e200a5991e694b35c95370abecb3aabd0c1c0513aa372917f'
inventory=json.loads((OUT/'verification/final-inventory-main.json').read_text())
assert inventory['boardSHA256']==sha(src)
fps={f['ref']:f for f in inventory['footprints']}
locked={r for r in fps if r.startswith(('U','J','H_')) or r in ['L1101','Y801']}
placed={};new={};moves=[]
gap=.05
def rect(f,xy):
    x,y=f['xyMm'];dx,dy=xy[0]-x,xy[1]-y
    b=f['courtyardBBoxMm'];return np.array([b[0]+dx,b[1]+dy,b[2]+dx,b[3]+dy])
for r in locked:placed[r]=rect(fps[r],fps[r]['xyMm']);new[r]=fps[r]['xyMm']
def conflicts(box,side):
    return [r for r,q in placed.items() if fps[r]['side']==side and box[0]<q[2]+gap and box[2]>q[0]-gap and box[1]<q[3]+gap and box[3]>q[1]-gap]
lock_collisions=[]
for r in locked:
    for t in conflicts(placed[r],fps[r]['side']):
        if t!=r and r<t:lock_collisions.append([r,t])
assert not lock_collisions,lock_collisions
critical={'C1101','C1103','C1107','C1301','C501','C503','C604','C605','C606','C801','C802','C803','C804','C805','C807','C808','C809','C810','C1902','C1903','C1904','C1921','C1922'}
unplaced=sorted(set(fps)-locked,key=lambda r:(0 if r in critical else 1,-(fps[r]['courtyardBBoxMm'][2]-fps[r]['courtyardBBoxMm'][0])*(fps[r]['courtyardBBoxMm'][3]-fps[r]['courtyardBBoxMm'][1])))
for r in unplaced:
    f=fps[r];origin=np.array(f['xyMm']);box=rect(f,origin);side=f['side'];ymax=24.25 if side=='F' else 38.6
    if not conflicts(box,side) and box[0]>=.4 and box[1]>=.4 and box[2]<=71.6 and box[3]<=ymax:
        placed[r]=box;new[r]=list(origin);continue
    off=box-np.array([*origin,*origin]);xs=np.arange(.4-off[0],71.6-off[2]+.001,.25);ys=np.arange(.4-off[1],ymax-off[3]+.001,.25)
    xx,yy=np.meshgrid(xs,ys);xy=np.column_stack([xx.ravel(),yy.ravel()]);valid=np.ones(len(xy),dtype=bool)
    boxes=np.column_stack([xy[:,0]+off[0],xy[:,1]+off[1],xy[:,0]+off[2],xy[:,1]+off[3]])
    for t,q in placed.items():
        if fps[t]['side']!=side:continue
        valid &= ~((boxes[:,0]<q[2]+gap)&(boxes[:,2]>q[0]-gap)&(boxes[:,1]<q[3]+gap)&(boxes[:,3]>q[1]-gap))
    candidates=np.where(valid)[0];assert len(candidates),(r,'No legal site on same side with manufacturer court unchanged')
    distance=np.sum((xy[candidates]-origin)**2,axis=1)
    i=candidates[np.argmin(distance)];new[r]=[round(v,6) for v in xy[i]];placed[r]=boxes[i]
    moves.append({'ref':r,'beforeXYMm':f['xyMm'],'afterXYMm':new[r],'displacementMm':float(np.sqrt(np.min(distance))),
                  'side':side,'courtBefore':f['courtyardBBoxMm'],'courtAfter':placed[r].tolist()})
before=copy.deepcopy(tree)
removed=[q for q in tree if key(q) in ['segment','arc','via']]
tree[:]=[q for q in tree if key(q) not in ['segment','arc','via']]
for fp in kids(tree,'footprint'):
    child(fp,'at')[1:3]=new[ref(fp)]
for zone in kids(tree,'zone'):
    zone[:]=[q for q in zone if key(q) not in ['filled_polygon','fill_segments']]
dst=DEST/'SmartVio-main-v26-replaced-clean.kicad_pcb';write(dst,tree)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(src.with_suffix(ext),dst.with_suffix(ext))
(DEST/'fp-lib-table').write_text((OUT/'fp-lib-table').read_text().replace('${KIPRJMOD}/','${KIPRJMOD}/../'))
report={'input':str(src),'inputSHA256':sha(src),'boardPath':str(dst),'boardSHA256':sha(dst),'sourceSHA256':sourcehash,
 'method':'Critical decouplers first, then area-first local legalizer, nearest legal 0.25mm site, same side/orientation, .05mm court gap. IC/interface/inductor/crystal anchors fixed.',
 'moves':moves,'removedCopperItems':len(removed),'removedCopperByNet':{n:sum(child(q,'net')[1]==n for q in removed) for n in sorted({child(q,'net')[1] for q in removed})},
 'boundaryUnchanged':kids(before,'gr_line')==kids(tree,'gr_line'),'manufacturerLandsUnchanged':all([q for q in a if key(q)!='at']==[q for q in z if key(q)!='at'] for a,z in zip(kids(before,'footprint'),kids(tree,'footprint'))),
 'sourceValuesAndNetAssignmentsUnchanged':all(kids(a,'pad')==kids(z,'pad') for a,z in zip(kids(before,'footprint'),kids(tree,'footprint'))),
 'J501PlasticCourtyardOverhangMm':.275,'note':'Existing J501 plastic courtyard overhang retained; copper remains checked by actual DRC. Mechanical fit/decoupling loop qualification pending.',
 'productionApproved':False}
(DEST/'placement-change.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'moves':len(moves),'maxDisplacementMm':max(q['displacementMm'] for q in moves),'removedCopperItems':len(removed),'output':str(dst)}))

