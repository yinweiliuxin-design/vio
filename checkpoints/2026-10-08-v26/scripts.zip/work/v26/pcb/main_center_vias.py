"""Center only DRC-identified endpoints and verify existing native pad groups."""
import argparse
import copy
import math
import os
import shutil
import subprocess
import sys
import uuid as uid
from main_ast import *

for name, folder in [('KICAD_CONFIG_HOME', 'config'), ('KICAD_DOCUMENTS_HOME', 'documents'), ('DOCUMENTS_HOME', 'documents')]:
    os.environ[name] = str(WORK / folder)
import pcbnew as p

ap = argparse.ArgumentParser()
ap.add_argument('board', type=Path)
ap.add_argument('--name', required=True)
a = ap.parse_args()
dst = DEST / (a.name + '.kicad_pcb')
before = read(a.board)
tree = copy.deepcopy(before)
objs = objects(tree)
drc = json.loads((OUT / 'verification' / (a.board.stem + '-strict-drc.json')).read_text())
changes = []
for v in drc['violations']:
    if v['type'] != 'track_not_centered_on_via':
        continue
    track, via = [objs[i['uuid']] for i in v['items']]
    assert key(track) == 'segment' and key(via) == 'via'
    assert child(track, 'net')[1] == child(via, 'net')[1]
    center = child(via, 'at')[1:]
    end = min([child(track, k) for k in ['start', 'end']], key=lambda e: math.dist(e[1:], center))
    distance = math.dist(end[1:], center)
    assert distance <= child(via, 'size')[1] / 2, 'Endpoint does not overlap the reported via'
    changes.append({'trackUUID': uuid(track), 'viaUUID': uuid(via), 'endpoint': key(end),
                    'oldXY': end[1:], 'newXY': center, 'movementMm': distance})
    other = child(track, 'end' if key(end) == 'start' else 'start')
    length = math.dist(end[1:], other[1:])
    # Keep the long route's original corridor; make only a short centering jog.
    if length > 1:
        old_end, far_end = end[1:], other[1:]
        knee = [round(old_end[i] + .3 * (far_end[i] - old_end[i]) / length, 6) for i in range(2)]
        remainder = copy.deepcopy(track)
        child(remainder, key(end))[1:] = knee
        child(remainder, 'uuid')[1] = str(uid.uuid4())
        other[1:] = knee
        tree.append(remainder)
        changes[-1]['localJogXY'] = knee
        changes[-1]['remainderUUID'] = uuid(remainder)
    end[1:] = center
write(dst, tree)
for ext in ['.kicad_pro', '.kicad_dru']:
    shutil.copyfile(a.board.with_suffix(ext), dst.with_suffix(ext))

def groups(path):
    b = p.LoadBoard(str(path.resolve()))
    b.BuildConnectivity()
    conn = b.GetConnectivity()
    result = set()
    for f in b.GetFootprints():
        for pad in f.Pads():
            if not pad.GetNetname():
                continue
            group = tuple(sorted(str(q.m_Uuid.AsString()) for q in conn.GetConnectedItems(pad) if q.Type() == p.PCB_PAD_T))
            if len(group) > 1:
                result.add(group)
    return result

initial = groups(a.board)
for script, args in [('main_refill_safe.py', [str(dst)]), ('check_final_stage.py', ['--board', str(dst)])]:
    r = subprocess.run([sys.executable, str(WORK / script), *args], capture_output=True, text=True, timeout=90)
    assert r.returncode == 0, (r.stdout, r.stderr)
final = groups(dst)
splits = [g for g in initial if not any(set(g).issubset(h) for h in final)]
assert not splits, 'Previously connected native pad group split'
new_drc = json.loads((OUT / 'verification' / (dst.stem + '-strict-drc.json')).read_text())
assert not any(v['severity'] == 'error' for v in new_drc['violations'])
assert not new_drc['ignored_checks']
report = {'inputSHA256': sha(a.board), 'outputSHA256': sha(dst), 'changes': changes,
          'originalConnectedPadGroupCount': len(initial), 'allOriginalConnectedPadGroupsPreserved': True,
          'errors': 0, 'warnings': len(new_drc['violations']), 'unconnected': len(new_drc['unconnected_items']),
          'ignoredChecks': [], 'productionApproved': False}
dst.with_suffix('.center-vias.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
