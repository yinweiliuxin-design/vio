"""TI package drawing land patterns, distinct DBV and DDC pin geometry."""
import json
import os
from pathlib import Path
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/pcb-work'
for key, folder in [('KICAD_CONFIG_HOME', 'config'), ('KICAD_DOCUMENTS_HOME', 'documents'), ('DOCUMENTS_HOME', 'documents')]:
    os.environ[key] = str(WORK / folder)
import pcbnew as p
lib = OUT / 'SmartVioV26.pretty'
pt = lambda x, y: p.VECTOR2I(p.FromMM(x), p.FromMM(y))
specs = [
    {'name': 'TI_DBV0006A_Official', 'x': 1.3, 'heightMaxMm': 1.45,
     'source': 'https://www.ti.com/lit/ds/symlink/tps22918.pdf', 'page': 28,
     'drawing': '4214840/G 08/2024', 'ref': 'U1901'},
    {'name': 'TI_DDC0006A_Official', 'x': 1.35, 'heightMaxMm': 1.1,
     'source': 'https://www.ti.com/lit/ds/symlink/tps3700-q1.pdf', 'page': 24,
     'drawing': '4214841/E 08/2024', 'ref': 'U1921',
     'note': 'Package drawing DDC0006A is shared; Q1 appendix used for land geometry only, not a change to the selected TPS3700DDCR.'}]
for spec in specs:
    f = p.FOOTPRINT(None)
    f.SetFPID(p.LIB_ID('SmartVioV26', spec['name']))
    f.SetReference('REF**')
    f.SetValue(spec['name'])
    f.SetAttributes(p.FP_SMD)
    f.SetLibDescription(spec['drawing'] + '; ' + spec['source'])
    for layer, hx, hy in [(p.F_Fab, .875, 1.525), (p.F_CrtYd, spec['x'] + .80, 1.775)]:
        shape = p.PCB_SHAPE(f)
        shape.SetShape(p.SHAPE_T_RECT)
        shape.SetStart(pt(-hx, -hy))
        shape.SetEnd(pt(hx, hy))
        shape.SetLayer(layer)
        shape.SetWidth(p.FromMM(.05))
        f.Add(shape)
    for n, x, y in [('1', -spec['x'], -.95), ('2', -spec['x'], 0), ('3', -spec['x'], .95),
                    ('4', spec['x'], .95), ('5', spec['x'], 0), ('6', spec['x'], -.95)]:
        d = p.PAD(f)
        d.SetNumber(n)
        d.SetAttribute(p.PAD_ATTRIB_SMD)
        d.SetShape(p.PAD_SHAPE_ROUNDRECT)
        d.SetRoundRectRadiusRatio(.05 / .6)
        d.SetSize(pt(1.1, .6))
        d.SetPosition(pt(x, y))
        d.SetLocalSolderMaskMargin(p.FromMM(.07))
        layers = p.LSET()
        for layer in (p.F_Cu, p.F_Paste, p.F_Mask):
            layers.AddLayer(layer)
        d.SetLayerSet(layers)
        f.Add(d)
    p.FootprintSave(str(lib), f)
    spec['padSizeMm'] = [1.1, .6]
    spec['pitchMm'] = .95
    spec['maskExpansionMm'] = .07
    spec['cornerRadiusMm'] = .05
(OUT / 'verification/v26-eco-manufacturer-lands.json').write_text(json.dumps(specs, indent=2))
print(json.dumps(specs, indent=2))
