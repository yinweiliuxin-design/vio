"""Apply manufacturer land ECOs to copied native boards; never edit the source graph."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2];OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
from process_rules import configure
ap=argparse.ArgumentParser();ap.add_argument('--board',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--signal-width',type=float,default=.15);a=ap.parse_args()
assert a.output.resolve().is_relative_to(OUT.resolve())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
lib=OUT/'SmartVioV26.pretty';lib.mkdir(exist_ok=True)
tvsname='TI_DPY0002A_1x0.6mm_P0.7mm_NSMD'
tvslib=OUT.parent/'audit/controls-protection/footprints/Controls_Protection_Official.pretty'
# The native library-type detector needs an existing footprint in a new directory.
shutil.copyfile(tvslib/(tvsname+'.kicad_mod'),lib/(tvsname+'.kicad_mod'))
proposal=json.loads((OUT.parent/'audit/critical-passives/proposal.json').read_text())
candidates={c['ref']:c['candidate'] for c in proposal['components'] if c['ref'] in ('L1101','FB1101')}
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
def rectangle(f,layer,x,y):
    s=p.PCB_SHAPE(f);s.SetShape(p.SHAPE_T_RECT);s.SetStart(pt(-x,-y));s.SetEnd(pt(x,y));s.SetLayer(layer);s.SetWidth(p.FromMM(.05));f.Add(s)
def passive(ref,name,mpn,body,maximum,padsize,centers):
    f=p.FOOTPRINT(None);f.SetFPID(p.LIB_ID('SmartVioV26',name));f.SetReference('REF**');f.SetValue(mpn);f.SetAttributes(p.FP_SMD)
    rectangle(f,p.F_Fab,body[0]/2,body[1]/2);rectangle(f,p.F_CrtYd,maximum[0]/2+.25,maximum[1]/2+.25)
    for number,x in enumerate(centers,1):
        d=p.PAD(f);d.SetNumber(str(number));d.SetAttribute(p.PAD_ATTRIB_SMD);d.SetShape(p.PAD_SHAPE_ROUNDRECT);d.SetRoundRectRadiusRatio(.1)
        d.SetPosition(pt(x,0));d.SetSize(pt(*padsize));layers=p.LSET()
        for layer in (p.F_Cu,p.F_Paste,p.F_Mask):layers.AddLayer(layer)
        d.SetLayerSet(layers);f.Add(d)
    f.SetLibDescription('Manufacturer recommended land; V26 selected candidate, electrical/process review separate.')
    p.FootprintSave(str(lib),f)
    return f
lands={}
lands['L1101']=passive('L1101','Coilcraft_XGL4020_Official','XGL4020-152MEC',(4,4),(4.3,4.3),(.98,3.4),(-1.675,1.675))
lands['FB1101']=passive('FB1101','WE_742792625_Official','742792625',(1.6,.8),(1.8,1),(.7,.7),(-.95,.95))
tvs=p.FootprintLoad(str(tvslib),tvsname)
tvs.SetFPID(p.LIB_ID('SmartVioV26',tvsname));p.FootprintSave(str(lib),tvs)
for r in range(1201,1208):lands['D'+str(r)]=tvs
b=p.LoadBoard(str(a.board.resolve()));changes=[]
for old in list(b.GetFootprints()):
    ref=old.GetReference()
    if ref not in lands:continue
    template=lands[ref];name=str(template.GetFPID().GetLibItemName())
    f=p.FootprintLoad(str(lib),name);f.SetFPID(p.LIB_ID('SmartVioV26',name))
    oldnet={d.GetNumber():d.GetNetname() for d in old.Pads() if d.GetNumber()}
    position=p.VECTOR2I(old.GetPosition());f.SetPosition(position);b.Add(f)
    if old.IsFlipped():f.Flip(position,False)
    f.SetOrientation(old.GetOrientation());f.SetReference(ref);f.SetValue(old.GetValue())
    f.Reference().SetVisible(False);f.Value().SetVisible(False)
    for d in f.Pads():
        if oldnet.get(d.GetNumber()):d.SetNet(b.FindNet(oldnet[d.GetNumber()]))
    assert {d.GetNumber():d.GetNetname() for d in f.Pads() if d.GetNumber()}==oldnet
    changes.append({'ref':ref,'oldFootprint':str(old.GetFPID().GetUniStringLibId()),'newFootprint':str(f.GetFPID().GetUniStringLibId()),
                    'samePinNetMap':oldnet,'placementAndSideUnchanged':True})
    b.Remove(old)
configure(p,b,a.output,a.board.with_suffix('.kicad_pro'))
projectpath=a.output.with_suffix('.kicad_pro');project=json.loads(projectpath.read_text())
project['net_settings']['classes'][0]['track_width']=a.signal_width
b.GetDesignSettings().m_NetSettings.GetDefaultNetclass().SetTrackWidth(p.FromMM(a.signal_width))
projectpath.write_text(json.dumps(project,indent=2))
b.BuildConnectivity()
if len(list(b.Zones())):p.ZONE_FILLER(b).Fill(b.Zones())
p.SaveBoard(str(a.output),b)
record={'input':str(a.board),'inputSHA256':sha(a.board),'output':str(a.output),'outputSHA256':sha(a.output),
        'sourceSHA256':sha(OUT.parent/'electrical/native-components.json'),'changes':changes,
        'signalRoutingWidthMm':a.signal_width,'minimumWidthAndClearanceUnchangedMm':.15,'productionApproved':False,
        'sourceNotEdited':True,'reconnectAndNativeDRCRequired':True}
(OUT/'verification'/('v26-'+a.output.stem+'-land-eco.json')).write_text(json.dumps(record,indent=2))
patch=[]
for ref,c in candidates.items():
    patch.append({'ref':ref,'set':{'mpn':c['mpn'],'package':c['package']},'pinsAndNetsUnchanged':True,
                  'candidateOnly':True,'electricalApprovalRequired':True,'sourceEvidence':c['evidence']})
(OUT/'passive-selection-patch.json').write_text(json.dumps({'sourceSHA256':record['sourceSHA256'],'changes':patch,
    'inductorNote':'XGL4020-152MEC is the exact documented manufacturer ordering code; C4 suffix not independently found. Isat5.3A at20percent drop/25C and DCRmax14.3mohm require parent load/temperature review.',
    'productionApproved':False},indent=2))
(OUT/'fp-lib-table').write_text('(fp_lib_table\n (lib (name "SmartVioV25") (type "KiCad") (uri "${KIPRJMOD}/SmartVioV25.pretty") (options "") (descr "Retained native candidates"))\n (lib (name "SmartVioV26") (type "KiCad") (uri "${KIPRJMOD}/SmartVioV26.pretty") (options "") (descr "V26 manufacturer land ECOs"))\n)\n')
print(json.dumps({'board':str(a.output),'changes':len(changes),'tracksAndVias':len(list(b.GetTracks())),'sourceNotEdited':True}))
