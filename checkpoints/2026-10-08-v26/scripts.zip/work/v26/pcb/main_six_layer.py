"""A six-layer same-envelope routing alternative with two ground references, not fab approval."""
import argparse
import copy
import shutil
from main_ast import *

ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);ap.add_argument('--name',required=True);a=ap.parse_args()
before=read(a.board);tree=copy.deepcopy(before)
tree[:]=[q for q in tree if key(q) not in ['segment','arc','via']]
layers=child(tree,'layers');non_cu=[q for q in layers[1:] if not q[1].endswith('.Cu')]
layers[:]=[S('layers'),*[ [n,name,S('signal')] for n,name in [(0,'F.Cu'),(4,'In1.Cu'),(6,'In2.Cu'),(8,'In3.Cu'),(10,'In4.Cu'),(2,'B.Cu')] ],*non_cu]
for zone in kids(tree,'zone'):
    zone[:]=[q for q in zone if key(q)!='filled_polygon']
    if not child(zone,'keepout') and child(zone,'layer')[1]=='In2.Cu':
        child(zone,'layer')[1]='In4.Cu'
setup=child(tree,'setup');old=child(setup,'stackup')
if old:setup.remove(old)
stack=[S('stackup')]
sequence=[('F.Cu',.035),('dielectric 1',.08),('In1.Cu',.035),('dielectric 2',.16),
          ('In2.Cu',.035),('dielectric 3',.31),('In3.Cu',.035),('dielectric 4',.16),
          ('In4.Cu',.035),('dielectric 5',.08),('B.Cu',.035)]
assert abs(sum(v for _,v in sequence)-1)<1e-9
for name,thickness in sequence:
    if name.endswith('.Cu'):
        layer=[S('layer'),name,[S('type'),'copper'],[S('thickness'),thickness]]
    else:
        layer=[S('layer'),name,[S('type'),'core' if name=='dielectric 3' else 'prepreg'],
               [S('thickness'),thickness],[S('material'),'FR4'],[S('epsilon_r'),4.2],[S('loss_tangent'),.02]]
    stack.append(layer)
stack.append([S('copper_finish'),'ENIG']);setup.append(stack)
dst=DEST/(a.name+'.kicad_pcb');assert not dst.exists();write(dst,tree)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(a.board.with_suffix(ext),dst.with_suffix(ext))
assert kids(before,'footprint')==kids(tree,'footprint'),'No footprint move or land reduction permitted'
record={'sourceSHA256':sha(OUT.parent/'electrical/native-components.json'),'inputSHA256':sha(a.board),
        'boardSHA256':sha(dst),'layers':6,'nominalBoardThicknessMm':1,'copperUmPerLayer':35,
        'dielectricThicknessesMm':[.08,.16,.31,.16,.08],'dedicatedGroundLayers':['In1.Cu','In4.Cu'],
        'footprintsPadsAndPlacementPreserved':True,'impedanceParameters':'FR4 4.2/tanD.02 are preliminary model assumptions, not laminate certification.',
        'stackupPurchaseApproved':False,'productionApproved':False,'nativeDRCRequired':True}
dst.with_suffix('.six-layer.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record,indent=2))
