"""Use pcbnew only to calculate zone fills, then graft fill expressions into the untouched AST."""
import argparse
import os
from main_ast import *
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);a=ap.parse_args();before=read(a.board)
assert a.board.resolve().is_relative_to(DEST.resolve())
b=p.LoadBoard(str(a.board.resolve()))
expected={u:child(n,'net')[1] if child(n,'net') else '' for u,n in objects(before).items()}
def native_nets():return {str(q.m_Uuid.AsString()):q.GetNetname() for q in [*b.GetTracks(),*b.Zones(),*[d for f in b.GetFootprints() for d in f.Pads()]]}
pre=native_nets();pre_diff=[{'uuid':u,'expected':n,'loaded':pre.get(u)} for u,n in expected.items() if pre.get(u)!=n]
assert not pre_diff,pre_diff[:5]
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());post=native_nets()
assert pre==post,'Zone filling changed in-memory net assignment'
temporary=a.board.with_name(a.board.stem+'-pcbnew-serialization-check.kicad_pcb');p.SaveBoard(str(temporary),b)
saved=read(temporary);saved_diff=audit(before,saved)
original_zones={uuid(q):q for q in kids(before,'zone')}
for z in kids(saved,'zone'):
    target=original_zones[uuid(z)]
    target[:]=[q for q in target if key(q) not in ['filled_polygon','fill_segments']]
    target.extend(q for q in z if key(q) in ['filled_polygon','fill_segments'])
assert not audit(read(a.board),before),'Grafting zone fills changed original pad/copper geometry or net assignments'
write(a.board,before)
(a.board.with_suffix('.safe-fill.json')).write_text(json.dumps({'boardPath':str(a.board),'boardSHA256':sha(a.board),'preAndPostFillMemoryNetsIdentical':True,
 'pcbnewSaveDifferences':saved_diff,'originalCopperAndPadNetGeometryPreserved':True,'method':'Only cached filled_polygon/fill_segments from native fill grafted into original AST. All original expressions otherwise retained.','productionApproved':False},indent=2))
print(json.dumps({'savedDifferencesIntercepted':len(saved_diff),'netGeometryPreserved':True,'board':str(a.board)}))
