"""Export clean main placement using three route layers and one solid GND reference plane."""
import argparse
import os
from main_ast import *
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
from specctra import loads as dloads,dumps as ddumps
ap=argparse.ArgumentParser();ap.add_argument('--all-layers',action='store_true');ap.add_argument('--board',type=Path,default=DEST/'SmartVio-main-v26-replaced-clean.kicad_pcb');ap.add_argument('--name');a=ap.parse_args()
board=a.board.resolve();assert board.is_relative_to(DEST.resolve());pro=board.with_suffix('.kicad_pro')
config=json.loads(pro.read_text());rules=config['board']['design_settings']['rules']
rules.update({'min_via_diameter':.35,'min_through_hole_diameter':.15})
config['net_settings']['classes'][0].update({'track_width':.15,'via_diameter':.35,'via_drill':.15})
pro.write_text(json.dumps(config,indent=2)+'\n')
b=p.LoadBoard(str(board.resolve()))
dsn=DEST/((a.name or 'main-clean-'+('4layers' if a.all_layers else '3layers'))+'.dsn')
assert p.ExportSpecctraDSN(b,str(dsn.resolve()))
text=dsn.read_text().replace('(string_quote ")','(string_quote __QUOTE__)')
tree=dloads(text);tree[1]='SmartVio-main-clean';structure=child(tree,'structure');removed=[]
for q in list(kids(structure,'plane')):
    layer=child(q,'polygon')[1]
    if a.all_layers or layer=='In2.Cu':structure.remove(q);removed.append(q)
encoded=ddumps(tree).replace('(string_quote __QUOTE__)','(string_quote ")')+'\n'
dsn.write_text(encoded)
router_layers=[q[1] for q in kids(structure,'layer')]
ground_layers=[child(q,'polygon')[1] for q in kids(structure,'plane')]
record={'sourceSHA256':sha(OUT.parent/'electrical/native-components.json'),'boardPath':str(board),'boardSHA256':sha(board),'dsnSHA256':sha(dsn),
 'viaDiameterMm':.35,'viaDrillMm':.15,'signalWidthMm':.15,'clearanceMm':.15,'annularRingMm':.1,
 'copperLayerCount':len(router_layers),'retainedRouterPlaneLayers':ground_layers,
 'planeStrategy':'Retained reference planes: '+','.join(ground_layers)+'; other enabled copper layers available for routing. Actual refill and return-path review required.',
 'removedRouterPlanes':removed,'nativeZonesUnchanged':True,'processEvidence':'https://www.pcbway.com/hdi-pcb.html',
 'samePublishedAdvancedMechanicalProcessAsPriorV26':True,'processPurchaseApproved':False,'productionApproved':False}
dsn.with_suffix('.contract.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
