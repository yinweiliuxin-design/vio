"""Compare actual native connected-pad groups before selecting a routed candidate."""
import argparse
import os
from main_ast import *

for name, folder in [('KICAD_CONFIG_HOME', 'config'), ('KICAD_DOCUMENTS_HOME', 'documents'), ('DOCUMENTS_HOME', 'documents')]:
    os.environ[name] = str(WORK / folder)
import pcbnew as p

ap = argparse.ArgumentParser()
ap.add_argument('baseline', type=Path)
ap.add_argument('candidate', type=Path)
a = ap.parse_args()

def groups(path):
    b = p.LoadBoard(str(path.resolve()))
    b.BuildConnectivity()
    conn = b.GetConnectivity()
    result = set()
    for f in b.GetFootprints():
        for pad in f.Pads():
            if not pad.GetNetname():
                continue
            group = tuple(sorted(str(q.m_Uuid.AsString()) for q in conn.GetConnectedItems(pad) if q.Type() == p.PCB_PAD_T))
            if len(group) > 1:
                result.add(group)
    return result

old, new = groups(a.baseline), groups(a.candidate)
splits = [g for g in old if not any(set(g).issubset(h) for h in new)]
record = {'baselineSHA256': sha(a.baseline), 'candidateSHA256': sha(a.candidate),
          'baselineConnectedPadGroups': len(old), 'candidateConnectedPadGroups': len(new),
          'splitOriginalPadGroups': splits, 'allOriginalConnectedPadGroupsPreserved': not splits,
          'scope': 'Native connectivity graph, not timing, layout or physical qualification.'}
a.candidate.with_suffix('.baseline-connectivity.json').write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
assert not splits
