"""Main-only checkpoint; never reads stale other-board inventories or promotes a final."""
import argparse
from collections import Counter
import re
import xml.etree.ElementTree as ET
from main_ast import *
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);ap.add_argument('--expected-source-sha',required=True);a=ap.parse_args();board=a.board.resolve()
assert board.is_relative_to(DEST.resolve())
tree=read(board);sourcepath=OUT.parent/'electrical/native-components.json';source={q['ref']:q for q in json.loads(sourcepath.read_text(encoding='utf-8-sig'))}
assert sha(sourcepath)==a.expected_source_sha
route_basis_path=DEST/'source-587358f6.json';old_source=json.loads(route_basis_path.read_text(encoding='utf-8-sig'))
topology=lambda cs:{(c['ref'],p['number']):(p['net'],p.get('footprintPad') or p['number']) for c in cs for p in c['pins']}
assert topology(old_source)==topology(source.values()),'Source topology changed; fresh ECO review required'
mapping=json.loads((OUT/'footprint-map.json').read_text());harness={ref:record['pins'] for record in json.loads((OUT/'proposed-harness.json').read_text()) for ref in record['pair']}
xmlpath=OUT.parent/'verification/native-netlist.xml';xml=ET.parse(xmlpath).getroot();ids={e.attrib['ref']:e.findtext('footprint','') for e in xml.findall('./components/comp')}
diff=[];id_diff=[];value_diff=[];mpn_diff=[];function_diff=[];geometry_diff=[]
selected=read(OUT/'SmartVio-main-v26-final.kicad_pcb');selected_fps={ref(f):f for f in kids(selected,'footprint')}
for f in kids(tree,'footprint'):
    r=ref(f);c=source.get(r);aliases=mapping[r].get('pinAliases',{});padnets={}
    for pad in kids(f,'pad'):padnets.setdefault(pad[1],set()).add(child(pad,'net')[1] if child(pad,'net') else None)
    expected={aliases.get(pin['number'],pin.get('footprintPad') or pin['number']):pin['net'] or None for pin in c['pins']} if c else harness[r]
    for number in set(expected)|set(padnets):
        if padnets.get(number,set())!={expected.get(number)}:diff.append({'ref':r,'pad':number,'expected':expected.get(number),'actual':sorted(padnets.get(number,set()),key=str)})
    if c:
        props={p[1]:p[2] for p in kids(f,'property')}
        if props['Value']!=c['value']:value_diff.append(r)
        if (props.get('MPN') or None)!=(c.get('mpn') or None):mpn_diff.append(r)
        if f[1]!=ids[r]:id_diff.append({'ref':r,'actual':f[1],'schematic':ids[r]})
        for pin in c['pins']:
            number=aliases.get(pin['number'],pin.get('footprintPad') or pin['number'])
            for pad in kids(f,'pad'):
                if pad[1]==number and (child(pad,'pinfunction') or [None,''])[1]!=pin.get('nativeName',pin['name']):function_diff.append({'ref':r,'pad':number})
    if [q for q in f if key(q)!='at']!=[q for q in selected_fps[r] if key(q)!='at']:geometry_diff.append(r)
drcpath=OUT/'verification'/(board.stem+'-strict-drc.json');drc=json.loads(drcpath.read_text());assert not drc['ignored_checks']
by_net=Counter()
for q in drc['unconnected_items']:
    match=re.search(r'\[([^]]+)\]',q['items'][0]['description'])
    by_net[match[1] if match else 'unresolved']+=1
tracks=kids(tree,'segment');vias=kids(tree,'via');zones=kids(tree,'zone')
record={'boardPath':str(board),'relativePackPath':str(board.relative_to(OUT.parent)).replace('\\','/'),'boardSHA256':sha(board),
 'sourceSHA256':sha(sourcepath),'routeBasisSourceSHA256':sha(route_basis_path),'currentVsRouteBasisPinNetDifferences':[],
 'schematicExportSHA256':sha(xmlpath),'projectSHA256':sha(board.with_suffix('.kicad_pro')),
 'footprints':len(kids(tree,'footprint')),'tracks':len(tracks),'vias':len(vias),'zones':sum(not child(z,'keepout') for z in zones),
 'drcPath':str(drcpath),'drcSHA256':sha(drcpath),'errors':sum(q['severity']=='error' for q in drc['violations']),
 'warnings':sum(q['severity']=='warning' for q in drc['violations']),'unconnected':len(drc['unconnected_items']),'ignoredChecks':drc['ignored_checks'],
 'violationTypes':dict(Counter(q['type'] for q in drc['violations'])),'unconnectedByNet':dict(by_net.most_common()),
 'parity':{'padNetDifferences':diff,'schematicFootprintIdDifferences':id_diff,'valueDifferences':value_diff,'mpnDifferences':mpn_diff,'pinFunctionDifferences':function_diff,
 'unexpectedFootprintChangesAgainstSelected':[r for r in geometry_diff if r not in ['J501','R1101','R1302','C1902','K1201','K1202','R601']]},
 'expectedExplicitECOFootprintChanges':[r for r in geometry_diff if r in ['J501','R1101','R1302','C1902','K1201','K1202','R601']],
 'powerWidthsMm':{n:sorted({child(q,'width')[1] for q in tracks if child(q,'net')[1]==n}) for n in ['PACK_PLUS','SYS','V3D','V3LOAD','V3A','USB_5V_SAFE']},
 'selectedMainUnchangedSHA256':sha(OUT/'SmartVio-main-v26-final.kicad_pcb'),'baseline':{'errors':268,'warnings':143,'unconnected':306},
 'productionApproved':False,'normalChargeAllowed':False,'physicalSamplesTested':0,'promotedToSelectedFinal':False,'camFiles':[],
 'blockers':['Native remaining connections and warnings must be closed; no manufacturing export for this incomplete main.',
 'Automatic signal-width routing is not power-rail current, switching-loop, analog-return, USB SI or RF approval.',
 'No manufacturer lands or source values reduced to fit; revised locations require local decoupling/stack review.']}
record['parity']['passed']=not any(record['parity'].values())
board.with_suffix('.review.json').write_text(json.dumps(record,indent=2)+'\n');(DEST/'board-progress.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['boardSHA256','errors','warnings','unconnected','parity','promotedToSelectedFinal']},indent=2))
