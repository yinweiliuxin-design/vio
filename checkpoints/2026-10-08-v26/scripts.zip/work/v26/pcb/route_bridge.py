"""KiCad native DSN/SES bridge with an immutable board/pad/net contract."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
from specctra import power_class, loads, dumps, child

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'documents')
os.environ['DOCUMENTS_HOME']=str(WORK/'documents')
import pcbnew as p

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def writable(path):
    path=path.resolve()
    if not (path.is_relative_to(OUT.resolve()) or path.is_relative_to(WORK.resolve())):
        raise ValueError('Output outside the PCB worker ownership roots: '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    return path
def inventory(board):
    return sorted((f.GetReference(),d.GetNumber(),d.GetNetname(),d.GetPosition().x,d.GetPosition().y,f.GetLayer())
                  for f in board.GetFootprints() for d in f.Pads() if d.GetNumber())
parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=['export','import'])
parser.add_argument('--board',type=Path,required=True)
parser.add_argument('--dsn',type=Path,required=True)
parser.add_argument('--ses',type=Path)
parser.add_argument('--output',type=Path)
parser.add_argument('--ack-tentative-netlist',action='store_true')
parser.add_argument('--power-width',type=float)
parser.add_argument('--remove-routing-planes',action='store_true')
args=parser.parse_args()
board=p.LoadBoard(str(args.board.resolve()))
meta=writable(args.dsn.with_suffix('.contract.json'))
if args.mode=='export':
    if not args.ack_tentative_netlist:
        raise SystemExit('This engineering input is not a released netlist. Explicit --ack-tentative-netlist required.')
    powernets=[]
    if args.power_width:
        assert args.power_width>=.2,'Power width must not narrow the routing class'
        powernets=['PACK_PLUS','SYS','USB_5V_SAFE','V3D','V3A','BUCK_L1','BUCK_L2']
        nc=p.NETCLASS('Power');nc.SetClearance(p.FromMM(.15));nc.SetTrackWidth(p.FromMM(args.power_width));nc.SetViaDiameter(p.FromMM(.6));nc.SetViaDrill(p.FromMM(.3))
        for n in powernets:
            net=board.FindNet(n)
            if net:net.SetNetClass(nc)
        pro=args.board.with_suffix('.kicad_pro')
        config=json.loads(pro.read_text())
        settings=config['net_settings']
        settings['classes']=[c for c in settings['classes'] if c['name']!='Power']+[{'name':'Power','clearance':.15,'track_width':args.power_width,'via_diameter':.6,'via_drill':.3}]
        settings['netclass_patterns']=[{'pattern':n,'netclass':'Power'} for n in powernets]
        pro.write_text(json.dumps(config,indent=2))
    assert p.ExportSpecctraDSN(board,str(writable(args.dsn)))
    native_dsn_hash=digest(args.dsn)
    removed_planes=[]
    if args.remove_routing_planes:
        tree=loads(args.dsn.read_text());structure=child(tree,'structure')
        removed_planes=[q for q in structure if isinstance(q,list) and q[0]=='plane']
        structure[:]=[q for q in structure if q not in removed_planes]
        args.dsn.write_text(dumps(tree)+'\n')
    if args.power_width:
        encoded,powernets=power_class(args.dsn.read_text(),powernets,args.power_width)
        args.dsn.write_text(encoded)
    record={'boardPath':str(args.board.resolve()),'boardSHA256':digest(args.board),'dsnSHA256':digest(args.dsn),
            'kicad':p.GetBuildVersion(),'padInventory':inventory(board),'inputStatus':'TENTATIVE_ENGINEERING_ONLY',
            'powerRouterWidthMm':args.power_width,'powerNets':powernets,'powerRatingApproved':False,
            'nativeExportDSNSHA256':native_dsn_hash,'routingPlaneOutlinesRemoved':removed_planes,
            'nativeCopperZonesPreservedForPostImportRefill':True}
    meta.write_text(json.dumps(record,indent=2))
    print(json.dumps({k:v for k,v in record.items() if k!='padInventory'},indent=2))
else:
    contract=json.loads(meta.read_text())
    assert contract['boardSHA256']==digest(args.board),'Board changed after DSN export; refusing stale session'
    assert contract['dsnSHA256']==digest(args.dsn),'DSN changed after export; regenerate contract'
    if not args.ses or not args.output:raise SystemExit('--ses and --output required')
    if args.output.resolve()==args.board.resolve():raise SystemExit('Import must write a separate candidate')
    before=inventory(board)
    footprint_positions={f.GetReference():(f.GetPosition(),f.GetOrientationDegrees()) for f in board.GetFootprints()}
    pad_positions={d.m_Uuid.AsString():d.GetPosition() for f in board.GetFootprints() for d in f.Pads()}
    assert p.ImportSpecctraSES(board,str(args.ses.resolve())),'Native SES importer rejected file'
    after=inventory(board)
    quantization=[]
    if before!=after:
        writable(args.output.with_suffix('.import-difference.json')).write_text(json.dumps({
            'beforeOnly':[q for q in before if q not in after],
            'afterOnly':[q for q in after if q not in before]},indent=2))
        # DSN micrometre serialization can round a native nanometre coordinate.
        assert len(before)==len(after)
        for a,z in zip(before,after):
            assert a[:3]==z[:3] and a[5]==z[5]
            assert max(abs(a[3]-z[3]),abs(a[4]-z[4]))<=5,'Non-quantization placement change'
            if a!=z:quantization.append({'before':a,'imported':z})
        for f in board.GetFootprints():
            oldpos,oldangle=footprint_positions[f.GetReference()]
            assert f.GetOrientationDegrees()==oldangle
            f.SetPosition(oldpos)
            for d in f.Pads():d.SetPosition(pad_positions[d.m_Uuid.AsString()])
        after=inventory(board)
    assert before==after,'Pad positions or nets changed during session import'
    p.SaveBoard(str(writable(args.output)),board)
    if args.board.with_suffix('.kicad_pro').exists():
        shutil.copyfile(args.board.with_suffix('.kicad_pro'),writable(args.output.with_suffix('.kicad_pro')))
    loaded=p.LoadBoard(str(args.output.resolve()))
    assert inventory(loaded)==before,'Saved native board changed pad/net inventory'
    result={'output':str(args.output),'inputBoardSHA256':digest(args.board),'dsnSHA256':digest(args.dsn),
            'sesSHA256':digest(args.ses),'outputSHA256':digest(args.output),
            'footprints':len(list(board.GetFootprints())),'tracksAndVias':len(list(board.GetTracks())),
            'padNetPositionInventoryUnchanged':True,'drcStatus':'NOT_YET_RUN','productionRelease':'HOLD'}
    result['restoredNativeNanometreQuantization']=quantization
    writable(args.output.with_suffix('.import.json')).write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
