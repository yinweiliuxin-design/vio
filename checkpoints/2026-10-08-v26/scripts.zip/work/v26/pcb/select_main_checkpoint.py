"""Select a verified engineering checkpoint without granting manufacturing release."""
import argparse
import shutil
from datetime import datetime, timezone
from main_ast import *

ap = argparse.ArgumentParser()
ap.add_argument('candidate', type=Path)
ap.add_argument('--baseline', type=Path, required=True)
a = ap.parse_args()
candidate = a.candidate.resolve()
baseline = a.baseline.resolve()
assert candidate.is_relative_to(DEST.resolve()) and baseline.is_relative_to(DEST.resolve())
review = json.loads(candidate.with_suffix('.review.json').read_text())
connectivity = json.loads(candidate.with_suffix('.baseline-connectivity.json').read_text())
report_path = OUT / 'verification' / (candidate.stem + '-strict-drc.json')
drc = json.loads(report_path.read_text())
source_hash = sha(OUT.parent / 'electrical/native-components.json')
assert review['sourceSHA256'] == source_hash
assert review['boardSHA256'] == connectivity['candidateSHA256'] == sha(candidate)
assert connectivity['baselineSHA256'] == sha(baseline)
assert connectivity['allOriginalConnectedPadGroupsPreserved'] and not connectivity['splitOriginalPadGroups']
assert review['parity']['passed']
assert not drc['ignored_checks'] and not drc['violations']
assert drc['source'] == candidate.name and len(drc['unconnected_items']) == review['unconnected']
assert review['drcSHA256'] == sha(report_path)
assert review['projectSHA256'] == sha(candidate.with_suffix('.kicad_pro'))
tree = read(candidate)
assert len([l for l in child(tree, 'layers')[1:] if l[1].endswith('.Cu')]) == 4
selected = OUT / 'SmartVio-main-v26-final.kicad_pcb'
before_hash = sha(selected)
archive = OUT / 'verification/pre-parent-local' / ('before-resume-selection-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
assert not archive.exists()
archive.mkdir(parents=True)
for ext in ['.kicad_pcb', '.kicad_pro', '.kicad_dru']:
    old = selected.with_suffix(ext)
    if old.exists():
        shutil.copy2(old, archive / old.name)
    shutil.copy2(candidate.with_suffix(ext), old)
assert sha(selected) == sha(candidate)
record = {'selectedUTC': datetime.now(timezone.utc).isoformat(), 'sourceSHA256': source_hash,
          'previousSelectedSHA256': before_hash, 'selectedSHA256': sha(selected),
          'candidateRelativePackPath': candidate.relative_to(OUT.parent).as_posix(),
          'baselineRelativePackPath': baseline.relative_to(OUT.parent).as_posix(),
          'archiveRelativePackPath': archive.relative_to(OUT.parent).as_posix(),
          'candidateReviewSHA256': sha(candidate.with_suffix('.review.json')),
          'baselineConnectivitySHA256': sha(candidate.with_suffix('.baseline-connectivity.json')),
          'errors': 0, 'warnings': 0, 'unconnected': review['unconnected'], 'parityPassed': True,
          'copperLayers': 4, 'status': 'SELECTED_ENGINEERING_CHECKPOINT_NOT_FABRICATION_RELEASE',
          'normalChargeAllowed': False, 'productionApproved': False, 'physicalTests': 0,
          'CAMFiles': [], 'limitations': review['blockers']}
(OUT / 'verification/main-resume-selection.json').write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
