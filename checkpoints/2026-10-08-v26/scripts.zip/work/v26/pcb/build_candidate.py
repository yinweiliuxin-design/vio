"""Build native V25 placement candidates. No fabrication outputs are generated."""
import argparse
import csv
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
import shutil
from process_rules import configure

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/pcb-work'
V24 = ROOT / 'outputs/SmartVio-V24-NativeEDA'
LIB = ROOT / 'work/v24/tools/kicad/share/kicad/footprints'
os.environ['KICAD_CONFIG_HOME'] = str(WORK / 'config')
os.environ['KICAD_DOCUMENTS_HOME'] = str(WORK / 'documents')
os.environ['DOCUMENTS_HOME'] = str(WORK / 'documents')
import pcbnew as p

mm = p.FromMM
pt = lambda x,y: p.VECTOR2I(mm(x),mm(y))
parser = argparse.ArgumentParser()
parser.add_argument('--components',type=Path,default=V24/'electrical/native-components.json')
parser.add_argument('--output-dir',type=Path,default=OUT)
args = parser.parse_args()
assert args.output_dir.resolve().is_relative_to(OUT.resolve()),'Output outside worker root'
OUT=args.output_dir.resolve()
for folder in (OUT, OUT/'SmartVioV25.pretty', OUT/'verification', OUT/'routing', OUT/'sources'):
    folder.mkdir(parents=True,exist_ok=True)
LOCAL = OUT/'SmartVioV25.pretty'
shutil.copyfile(LIB/'Resistor_SMD.pretty/R_0603_1608Metric.kicad_mod',LOCAL/'R_0603_1608Metric.kicad_mod')
parts = json.loads(args.components.read_text(encoding='utf-8-sig'))
power_path = ROOT/'outputs/SmartVio-V26-Engineering/audit/power/corrected-components.json'
power_changes = power_path.with_name('changes.json')
if power_path.exists() and args.components.resolve()==(V24/'electrical/native-components.json').resolve():
    merged={c['ref']:c for c in parts}
    merged.update({c['ref']:c for c in json.loads(power_path.read_text(encoding='utf-8-sig'))})
    for ref in json.loads(power_changes.read_text(encoding='utf-8-sig'))['remove']:
        merged.pop(ref,None)
    parts=list(merged.values())
audio_root=ROOT/'outputs/SmartVio-V26-Engineering/audit/audio'
if (audio_root/'corrected-components.json').exists() and args.components.resolve()==(V24/'electrical/native-components.json').resolve():
    merged={c['ref']:c for c in parts}
    merged.update({c['ref']:c for c in json.loads((audio_root/'corrected-components.json').read_text(encoding='utf-8-sig'))})
    parts=list(merged.values())
byref = {c['ref']:c for c in parts}
oldmap = json.loads((V24/'electrical/footprint-map.json').read_text(encoding='utf-8-sig'))
mapping = {}
sources = json.loads((WORK/'sources.json').read_text())


def write_json(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def shape(parent,a,b,layer,width=.05):
    s = p.PCB_SHAPE(parent)
    s.SetShape(p.SHAPE_T_SEGMENT)
    s.SetStart(pt(*a)); s.SetEnd(pt(*b)); s.SetLayer(layer); s.SetWidth(mm(width))
    parent.Add(s)


def rect(parent,x0,y0,x1,y1,layer):
    v=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
    for a,b in zip(v,v[1:]+v[:1]):
        shape(parent,a,b,layer)


def layers(*items):
    result=p.LSET()
    for layer in items:
        result.AddLayer(layer)
    return result


def pad(fp,num,x,y,w,h,drill=None,paste=True,circle=False):
    d=p.PAD(fp); d.SetNumber(str(num)); d.SetPosition(pt(x,y)); d.SetSize(pt(w,h))
    d.SetShape(p.PAD_SHAPE_CIRCLE if circle else p.PAD_SHAPE_ROUNDRECT)
    if not circle:
        d.SetRoundRectRadiusRatio(min(.2,.05/min(w,h)))
    if drill:
        d.SetAttribute(p.PAD_ATTRIB_PTH if num else p.PAD_ATTRIB_NPTH)
        d.SetDrillSize(pt(*drill))
        ls=p.LSET.AllCuMask();ls.AddLayer(p.F_Mask);ls.AddLayer(p.B_Mask);d.SetLayerSet(ls)
        if drill[0]!=drill[1]:
            d.SetDrillShape(p.PAD_DRILL_SHAPE_OBLONG)
    else:
        d.SetAttribute(p.PAD_ATTRIB_SMD)
        d.SetLayerSet(layers(p.F_Cu,p.F_Mask,*([p.F_Paste] if paste else [])))
    fp.Add(d)
    return d


def custom(name,w,h,body=None):
    fp=p.FOOTPRINT(None); fp.SetFPID(p.LIB_ID('SmartVioV25',name)); fp.SetReference('REF**'); fp.SetValue(name)
    fp.SetAttributes(p.FP_SMD)
    rect(fp,-w/2,-h/2,w/2,h/2,p.F_CrtYd)
    bw,bh=body or (w-.5,h-.5)
    rect(fp,-bw/2,-bh/2,bw/2,bh/2,p.F_Fab)
    fp.Reference().SetVisible(False); fp.Value().SetVisible(False)
    return fp


def save(fp):
    p.FootprintSave(str(LOCAL),fp)
    return str(fp.GetFPID().GetLibItemName())


def qfn(name,ep,span=2.8,length=.6,width=.24):
    fp=custom(name,3.9,3.9,(3,3))
    for i in range(4):
        v=-.75+i*.5
        pad(fp,1+i,-span/2,v,length,width)
        pad(fp,5+i,v,span/2,width,length)
        pad(fp,9+i,span/2,-v,length,width)
        pad(fp,13+i,-v,-span/2,width,length)
    d=pad(fp,17,0,0,ep,ep,paste=False)
    for x,y in itertools.product((-.25*ep,.25*ep),repeat=2):
        a=pad(fp,'',x,y,.42*ep,.42*ep)
        a.SetLayerSet(layers(p.F_Paste))
    return save(fp)


qfn('TI_RGT0016C_BQ24074_EP17',1.68)
qfn('TI_RTE0016C_TPA6132_EP17',1.68)
qfn('TI_RTE0016B_TPA6132_EP17_ALTERNATE',1.6)
qfn('MAX_T1633_4_TENTATIVE_LAND_EP17',1.23,2.9,.75,.30)

# Composite same-number pads preserve the L-shaped manufacturer copper.
fp=custom('TI_RPW0010A_TPS259470',2.9,2.9,(2,2))
for n,x,y,w,h in [(1,-.9,-.7,.6,.3),(1,-.725,-.875,.25,.65),
 (2,-.9,-.225,.6,.25),(3,-.9,.225,.6,.25),(4,-.9,.7,.6,.3),(4,-.725,.875,.25,.65),
 (5,-.25,0,.3,2.4),(6,.25,0,.3,2.4),(7,.9,.7,.6,.3),(7,.725,.875,.25,.65),
 (8,.9,.225,.6,.25),(9,.9,-.225,.6,.25),(10,.9,-.7,.6,.3),(10,.725,-.875,.25,.65)]:
    pad(fp,n,x,y,w,h)
save(fp)

fp=custom('TI_RNM0015A_TPS63070',3.6,3.9,(2.5,3))
for n,x,y,w,h in [(1,-1.15,-.75,.6,.25),(2,-1.15,-.25,.6,.25),(3,-1.15,.25,.6,.25),(4,-1.15,.75,.6,.25),
 (5,-.725,1.4,.25,.6),(6,-.225,1.4,.25,.6),
 (7,.275,1.4,.25,.6),(7,.525,1.225,.75,.25),(8,.775,1.4,.25,.6),
 (9,.775,.5,1.35,.25),(10,.6,0,1.7,.25),(11,.775,-.5,1.35,.25),
 (12,.775,-1.4,.25,.6),(12,.525,-1.225,.75,.25),(13,.275,-1.4,.25,.6),
 (14,-.225,-1.4,.25,.6),(15,-.725,-1.4,.25,.6)]:
    d=pad(fp,n,x,y,w,h)
    if 7<=n<=13:
        d.SetLocalSolderMaskMargin(mm(-.05))
save(fp)

fp=custom('TI_YFF0009_TPD2S300',1.9,1.9,(1.4,1.4))
for row,y in zip('ABC',(-.4,0,.4)):
    for col,x in enumerate((-.4,0,.4),1):
        d=pad(fp,row+str(col),x,y,.23,.23,circle=True)
        d.SetLocalSolderMaskMargin(mm(.025))
save(fp)

fp=custom('GCT_USB4120_03_C_DRAWING_A6',10,6.4,(8.94,4.3))
# A1/A12 and B1/B12 are the two outer positions; no fictitious A2/A3 contacts.
for n,x in zip(('A1','A4','A5','A6','A7','A8','A9','A12'),(-2.75,-1.25,-.75,-.25,.25,.75,1.25,2.75)):
    pad(fp,n,x,-.87,.3,1.1)
for n,x in zip(('B12','B9','B8','B7','B6','B5','B4','B1'),(-2.75,-1.25,-.75,-.25,.25,.75,1.25,2.75)):
    pad(fp,n,x,.87,.3,1.1)
for x,y in itertools.product((-2.4,2.4),(-2.15,2.15)):
    pad(fp,'SH',x,y,1.35,1.1,drill=(.85,.6))
for x in (-3.75,3.75):
    pad(fp,'',x,0,.52,.52,drill=(.52,.52),circle=True)
save(fp)

fp=custom('Lumberg1503_18_BODY_ONLY_UNRESOLVED_PINS',18.2,12.8,(17.2,11.8))
fp.SetAttributes(p.FP_EXCLUDE_FROM_BOM | p.FP_EXCLUDE_FROM_POS_FILES)
save(fp)
fp=custom('Inductor_4x4_TENTATIVE',4.8,4.8,(4,4))
pad(fp,1,-1.55,0,1.5,3.4); pad(fp,2,1.55,0,1.5,3.4);save(fp)
fp=custom('CMC_2012_TENTATIVE_PINOUT',2.7,2,(2,1.2))
for n,x,y in [(1,-.8,-.4),(2,.8,-.4),(3,-.8,.4),(4,.8,.4)]:
    pad(fp,n,x,y,.6,.5)
save(fp)
fp=custom('TPD1E10B06_DPY_TENTATIVE',1.7,1.2,(1,.6))
pad(fp,1,-.35,0,.4,.65);pad(fp,2,.35,0,.4,.65);save(fp)


def wire_fp(count,name=None,pitch=1.5,padsize=.9):
    name=name or f'WirePads_{count}_P{pitch}'
    fp=custom(name,(count-1)*pitch+padsize+.6,padsize+.6)
    for i in range(count):
        pad(fp,str(i+1),(i-(count-1)/2)*pitch,0,padsize,padsize,paste=False)
    return save(fp)


special={
 'U301':('TI_RTE0016C_TPA6132_EP17','DRAWING_MATCH_PACKAGE_VARIANT_PENDING',.8,'tpa6132a2',{'EP':'17'}),
 'U501':('TI_RGT0016C_BQ24074_EP17','MANUFACTURER_LAND_DIMENSIONS_REVIEWED',1.0,'bq24074',{'EP':'17'}),
 'U1001':('TI_RPW0010A_TPS259470','MANUFACTURER_COMPOSITE_LAND_REVIEWED',1.,'tps25947',{}),
 'U1101':('TI_RNM0015A_TPS63070','MANUFACTURER_COMPOSITE_LAND_REVIEWED',1.,'tps63070',{}),
 'U1401':('TI_YFF0009_TPD2S300','MANUFACTURER_LAND_DIMENSIONS_REVIEWED',.625,'tpd2s300',{}),
 'U902':('MAX_T1633_4_TENTATIVE_LAND_EP17','OUTLINE_REVIEWED_EXACT_90_0031_LAND_PENDING',.8,'max98357a',{'EP':'17'}),
 'J401':('GCT_USB4120_03_C_DRAWING_A6','MANUFACTURER_LAND_DIMENSIONS_REVIEWED',6.5,'usb4120',{}),
}
shutil.copyfile(WORK/'sources/ESP32-MINI-1U.kicad_mod',LOCAL/'ESP32-MINI-1U.kicad_mod')
special['U901']=('ESP32-MINI-1U','MANUFACTURER_LIBRARY_AND_DRAWING_REVIEWED',2.4,'esp32-mini-1',{})
for r in ('J102','J201','J202','J301'):
    special[r]=('Lumberg1503_18_BODY_ONLY_UNRESOLVED_PINS','BODY_ENVELOPE_ONLY_NO_ELECTRICAL_PADS',17.,'1503_18',{})
audio_names={'U101':'TI_PW0014A_Official','U201':'TI_PW0014A_Official','U601':'TI_DBT0030A_Official',
             'U701':'TI_PW0020A_Official','U301':'TI_RTE0016C_Official','U902':'ADI_T1633_4_Official',
             'U401':'ST_USBLC6_2SC6_SOT23_6L_Official','U1401':'TI_YFF0009_Official','U1501':'TI_DGS0010A_Official'}
if (audio_root/'footprint-specifications.json').exists():
    audio_specs={s['name']:s for s in json.loads((audio_root/'footprint-specifications.json').read_text())}
    for ref,name in audio_names.items():
        sp=audio_specs[name]
        source=audio_root/sp['file']
        shutil.copyfile(source,LOCAL/source.name)
        if ref=='U902':
            # The audit uses EP; local integration contract uses physical CAD pad 17.
            af=p.FootprintLoad(str(LOCAL),name)
            for d in af.Pads():
                if d.GetNumber()=='EP':d.SetNumber('17')
            af.SetFPID(p.LIB_ID('SmartVioV25',name));p.FootprintSave(str(LOCAL),af)

usbrefs={r for r in byref if int(re.sub(r'\D','',r) or 0)//100 in (4,14,15)}
coverrefs={r for r,c in byref.items() if c['type'] in ('SW','POT','LED','SPK')}
sensorrefs={'U1801','C1801','J1802'}
audiorefs={'J102','J201','J202','J301'}
partitions={r:('usb' if r in usbrefs else 'cover' if r in coverrefs else 'sensor' if r in sensorrefs else 'audio' if r in audiorefs else 'main') for r in byref}


def mapping_for(c):
    r=c['ref']; src=None; alias={}; h=1.2; review='LIBRARY_GEOMETRY_ONLY_MPN_ASSEMBLY_REVIEW_PENDING'
    if r in special:
        name,review,h,source,alias=special[r]
        src=sources[source]
    elif r in coverrefs:
        size={'SW':(6,6),'POT':(12,8),'LED':(2.5,1.5),'SPK':(11,11)}[c['type']]
        fp=custom('ENVELOPE_'+r+'_NO_APPROVED_MPN',*size)
        fp.SetAttributes(p.FP_EXCLUDE_FROM_BOM | p.FP_EXCLUDE_FROM_POS_FILES)
        name=save(fp);h={'SW':2.,'POT':6.3,'LED':.8,'SPK':3.1}[c['type']]
        review='COVER_MECHANICAL_ENVELOPE_NO_ELECTRICAL_PADS'
    else:
        sourceid=oldmap.get(r,{}).get('sourceId')
        if c['type']=='R' and not sourceid:sourceid='Resistor_SMD:R_0603_1608Metric'
        if c['type']=='SSR':
            sourceid='OptoDevice:Panasonic_APV-AQY_SSOP-4_4.45x2.65mm_P1.27mm'; h=1.8
        elif c['type']=='XTAL':
            sourceid='Crystal:Crystal_SMD_3225-4Pin_3.2x2.5mm';h=1.0
        elif c['type']=='TVS':
            name='TPD1E10B06_DPY_TENTATIVE';h=.4;review='TENTATIVE_UNREVIEWED_LAND'
        elif c['type']=='CMC':
            name='CMC_2012_TENTATIVE_PINOUT';h=1.;review='TENTATIVE_NO_MPN_OR_PINOUT'
        elif r=='L1101':
            name='Inductor_4x4_TENTATIVE';h=2.;review='TENTATIVE_NO_MPN_OR_PAD_DRAWING'
        elif c['type'] in ('L','FB'):
            sourceid='Inductor_SMD:L_0603_1608Metric';h=.95
        elif r=='J501':
            sourceid='Connector_JST:JST_GH_SM03B-GHS-TB_1x03-1MP_P1.25mm_Horizontal';h=4.25
            review='PROPOSED_KEYED_CONNECTOR_MATING_HARNESS_UNAPPROVED'
        elif c['type'] in ('J','CONN','TEST'):
            name=wire_fp(len(c['pins']));h=.8;review='DEFINED_SOLDER_ENDPOINT_NOT_ORIGINAL_CONNECTOR'
        if sourceid:
            lib,name=sourceid.split(':');src=sourceid
            shutil.copyfile(LIB/(lib+'.pretty')/(name+'.kicad_mod'),LOCAL/(name+'.kicad_mod'))
        if c['type']=='R':h=.55
        if c['type']=='C':h=1.45 if '0805' in name else .9
        if r=='U1801':h=.8
    if r in audio_names and (audio_root/'footprint-specifications.json').exists():
        name=audio_names[r];src=audio_specs[name]['provenance'];review='AUDIO_AUDIT_MANUFACTURER_LAND_REVIEWED'
        if r=='U301':review='DRAWING_MATCH_RTE0016B_C_ASSIGNMENT_HOLD'
    return {'footprint':'SmartVioV25:'+name,'source':src,'review':review,'heightMaxMm':h,
            'pinAliases':alias,'board':partitions[r],'fabricationApproved':False}


for c in parts:
    mapping[c['ref']]=mapping_for(c)


def board(name,w,h,layers_count=2,t=1.):
    b=p.BOARD();b.SetCopperLayerCount(layers_count); b.GetDesignSettings().SetBoardThickness(mm(t))
    rect(b,0,0,w,h,p.Edge_Cuts)
    text=p.PCB_TEXT(b);text.SetText(name.upper()+' V25: TENTATIVE NETLIST / NOT FOR FABRICATION')
    text.SetPosition(pt(w/2,-2));text.SetLayer(p.Dwgs_User);text.SetTextSize(pt(.7,.7));text.SetTextThickness(mm(.1));b.Add(text)
    return b


specs={'main':(72,39,4,1.),'usb':(24,22,2,1.),'audio':(73.4,14,2,1.),'sensor':(16,10,2,.8),'cover':(148,49,2,.4)}
boards={name:board(name,*s) for name,s in specs.items()}
netsets={}
for name,b in boards.items():
    netsets[name]={}
    for n in sorted({pin['net'] for c in parts for pin in c['pins'] if pin['net']}):
        ni=p.NETINFO_ITEM(b,n);b.Add(ni);netsets[name][n]=ni
fps={}
for c in parts:
    m=mapping[c['ref']]; name=m['board'];b=boards[name]
    fp=p.FootprintLoad(str(LOCAL),m['footprint'].split(':')[1]);fp.SetFPID(p.LIB_ID('SmartVioV25',m['footprint'].split(':')[1]))
    fp.SetReference(c['ref']);fp.SetValue(c['mpn'] or c['value']);fp.Reference().SetVisible(False);fp.Value().SetVisible(False)
    pins={m['pinAliases'].get(pin['number'],pin['number']):pin['net'] for pin in c['pins']}
    actual={d.GetNumber() for d in fp.Pads() if d.GetNumber()}
    for d in fp.Pads():
        n=pins.get(d.GetNumber())
        if n:d.SetNet(netsets[name][n])
    m['missingPhysicalPads']=sorted(set(pins)-actual)
    m['extraPhysicalPads']=sorted(actual-set(pins))
    b.Add(fp);fps[c['ref']]=fp


def bbox(fp):
    layer=p.B_CrtYd if fp.IsFlipped() else p.F_CrtYd
    bb=fp.GetLayerBoundingBox(layers(layer))
    return [p.ToMM(bb.GetX()),p.ToMM(bb.GetY()),p.ToMM(bb.GetRight()),p.ToMM(bb.GetBottom())]


def overlap(a,b,gap=.05):
    return a[0]<b[2]+gap and a[2]+gap>b[0] and a[1]<b[3]+gap and a[3]+gap>b[1]


occupied={name:{'F':[],'B':[]} for name in boards}
# Physical lead tails and audio PCB consume this volume above the main board.
occupied['main']['F'].append(('AUDIO_BOARD_NO_COMPONENT_ZONE',[-.5,24.5,72.5,39]))
placement={}


def place(r,x,y,angle=0,side='F',fixed=False):
    fp=fps[r];m=mapping[r];name=m['board']
    fp.SetPosition(pt(x,y));fp.SetOrientationDegrees(angle)
    if (side=='B')!=fp.IsFlipped():fp.Flip(pt(x,y),False)
    bb=bbox(fp)
    placement[r]={'board':name,'xMm':x,'yMm':y,'rotationDeg':angle,'side':side,'courtyardMm':bb,'heightMaxMm':m['heightMaxMm'],'fixed':fixed}
    occupied[name][side].append((r,bb))


fixed={
 'U801':(31.4,11.3,0,'F'),'U901':(48,10,0,'F'),
 'U601':(10.7,6,0,'F'),'U701':(10.7,16,0,'F'),
 'R691':(12.5,7,0,'B'),
 'U101':(18.65,5,0,'F'),'U201':(18.65,14,0,'F'),'U301':(18,21,0,'F'),
 'U501':(59,5,0,'F'),'U1001':(65,5,0,'F'),'U1101':(60,13,0,'F'),
 'L1101':(67,13,0,'F'),'U902':(59,21,0,'F'),'U1301':(67,21,0,'F'),
 'U1701':(18,20,0,'B'),'U1702':(18,12,0,'B'),'U1703':(18,5,0,'B'),
 'J501':(3.45,14,90,'F'),'Y801':(26,3,0,'B'),
 'J401':(12,4,0,'F'),'U1401':(5,9,0,'F'),'U1501':(12,12,0,'F'),
 'U401':(19,12,0,'F'),'FL1501':(12,8.75,0,'F'),
 'U1801':(10,5,0,'F'),'C1801':(13,7,0,'F'),'J1802':(4,5,90,'F'),
 'J102':(9.2,7,0,'F'),'J201':(27.5,7,0,'F'),'J202':(45.8,7,0,'F'),'J301':(64.1,7,0,'F'),
}
for i,r in enumerate(['K1201','K1202','K1203','K1204','K1205','K1206','K1207']):
    fixed[r]=([3.6,10.4,24,31,38,45,52][i],22.25,0,'F')
for i,r in enumerate(sorted(coverrefs)):
    c=byref[r]
    if c['type']=='POT':
        fixed[r]=(15+16*list(sorted(x for x in coverrefs if byref[x]['type']=='POT')).index(r),13,0,'F')
    elif c['type']=='SW':
        fixed[r]=(10+9*list(sorted(x for x in coverrefs if byref[x]['type']=='SW')).index(r),31,0,'F')
    elif c['type']=='LED':fixed[r]=(14+16*int(r[-1]),22,0,'F')
    else:fixed[r]=(132,25,0,'F')
for r,pos in fixed.items():
    if r in fps:place(r,*pos,fixed=True)

# Endpoints are explicit proposed wiring additions, never silently substituted socket pads.
links=[]
for remote in ('audio','usb','cover'):
    remote_nets={pin['net'] for c in parts if partitions[c['ref']]==remote for pin in c['pins'] if pin['net']}
    main_nets={pin['net'] for c in parts if partitions[c['ref']]=='main' for pin in c['pins'] if pin['net']}
    shared=sorted(remote_nets&main_nets)
    if remote=='usb':
        ordered=['GND','USB_DM_MCU','USB_DP_MCU','V3D','CC_FAULT_N','USB_DATA_DISABLE',
                 'USB_DATA_FAULT_N','USB_5V_SAFE','VBUS_RAW']
        assert set(ordered)==set(shared),'USB harness inventory changed; review grouping'
        shared=ordered
    # Small groups leave ground stitching and cable grouping to the corrected schematic.
    for k in range(0,len(shared),6):
        signals=shared[k:k+6]
        for name,suffix in (('main','M'),(remote,'R')):
            ref=f'H_{remote.upper()}_{k//6+1}_{suffix}'
            fname=wire_fp(len(signals))
            fp=p.FootprintLoad(str(LOCAL),fname);fp.SetFPID(p.LIB_ID('SmartVioV25',fname));fp.SetReference(ref);fp.SetValue('PROPOSED_HARNESS_ENDPOINT')
            fp.Reference().SetVisible(False);fp.Value().SetVisible(False)
            for d in fp.Pads():d.SetNet(netsets[name][signals[int(d.GetNumber())-1]])
            boards[name].Add(fp);fps[ref]=fp
            mapping[ref]={'board':name,'footprint':'SmartVioV25:'+fname,'heightMaxMm':1.,'review':'NEW_WIRING_PROPOSAL_REQUIRES_SCHEMATIC','pinAliases':{},'fabricationApproved':False}
        links.append({'pair':[f'H_{remote.upper()}_{k//6+1}_M',f'H_{remote.upper()}_{k//6+1}_R'],'pins':dict(enumerate(signals,1))})


def target(ref):
    number=int(re.sub(r'\D','',ref) or 0)
    group=number//100
    owner={1:'U101',2:'U201',3:'U301',5:'U501',6:'U601',7:'U701',8:'U801',9:'U901',10:'U1001',11:'U1101',12:'K1204',13:'U1301',16:'U501',17:'U1702',18:'U1701',19:'U501'}.get(group)
    if owner in placement:
        q=placement[owner];return(q['xMm'],q['yMm'])
    return (12,16) if mapping[ref]['board']=='usb' else (36,20)


unplaced=[]
remaining=[r for r in fps if r not in placement]
remaining.sort(key=lambda r:(-(bbox(fps[r])[2]-bbox(fps[r])[0])*(bbox(fps[r])[3]-bbox(fps[r])[1]),r))
for r in remaining:
    fp=fps[r];name=mapping[r]['board'];w,h,*_=specs[name]
    tx,ty=target(r);best=None
    if name=='cover': sides=['B']
    elif name=='audio':sides=['B']
    elif name=='main' and mapping[r]['heightMaxMm']>1.5:sides=['F']
    else:sides=['F','B']
    for side in sides:
        fp.SetPosition(pt(0,0));fp.SetOrientationDegrees(0)
        if (side=='B')!=fp.IsFlipped():fp.Flip(pt(0,0),False)
        bb=bbox(fp);hw=(bb[2]-bb[0])/2;hh=(bb[3]-bb[1])/2
        offsetx=(bb[0]+bb[2])/2;offsety=(bb[1]+bb[3])/2
        # A 0.5 mm placement grid, with courtyard gap checked independently.
        candidates=[(xi/2-offsetx,yi/2-offsety)
                    for xi in range(math.ceil((hw+.35)*2),math.floor((w-hw-.35)*2)+1)
                    for yi in range(math.ceil((hh+.35)*2),math.floor((h-hh-.35)*2)+1)]
        candidates.sort(key=lambda xy:(xy[0]-tx)**2+(xy[1]-ty)**2)
        for x,y in candidates:
            b=[bb[0]+x,bb[1]+y,bb[2]+x,bb[3]+y]
            if any(overlap(b,o) for _,o in occupied[name][side]):continue
            cost=(x-tx)**2+(y-ty)**2+(35 if side=='B' and name=='main' else 0)
            if best is None or cost<best[0]:best=(cost,x,y,side)
            break
    if best is None:
        unplaced.append(r)
        # Deliberately fail rather than park hidden parts outside the real board.
        continue
    _,x,y,side=best
    place(r,x,y,0,side)
if unplaced:
    write_json(OUT/'verification/unplaced.json',unplaced)
    raise RuntimeError('No legal courtyard location for: '+','.join(unplaced))

# Pairwise geometric checks are independent of the placement algorithm.
collisions=[];edge=[]
for name,b in boards.items():
    w,h,*_=specs[name]
    for side in ('F','B'):
        for (ra,a),(rb,z) in itertools.combinations(occupied[name][side],2):
            if overlap(a,z,gap=0):collisions.append({'board':name,'side':side,'refs':[ra,rb]})
    for r,q in placement.items():
        if q['board']!=name:continue
        a=q['courtyardMm']
        if min(a[0],a[1])<0 or a[2]>w or a[3]>h:edge.append({'ref':r,'board':name,'courtyardMm':a})
    configure(p,b,OUT/f'SmartVio-{name}-tentative.kicad_pcb')
    p.SaveBoard(str(OUT/f'SmartVio-{name}-tentative.kicad_pcb'),b)
    # A successful re-load is required for each generated native file.
    reloaded=p.LoadBoard(str(OUT/f'SmartVio-{name}-tentative.kicad_pcb'))
    assert len(list(reloaded.GetFootprints()))==len(list(b.GetFootprints()))
    if name!='cover':
        ok=p.ExportSpecctraDSN(b,str(OUT/'routing'/f'{name}-tentative.dsn'))
        if not ok:raise RuntimeError('DSN export failed: '+name)

(OUT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "SmartVioV25") (type "KiCad") (uri "${KIPRJMOD}/SmartVioV25.pretty") (options "") (descr "Engineering candidates; see footprint-review.json")))\n')
write_json(OUT/'native-components-TENTATIVE-snapshot.json',parts)
write_json(OUT/'footprint-review.json',mapping)
write_json(OUT/'verification/unplaced.json',unplaced)
write_json(OUT/'placement.json',placement)
write_json(OUT/'board-partition.json',partitions)
write_json(OUT/'proposed-harness.json',links)
with (OUT/'placement.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=['ref','board','xMm','yMm','rotationDeg','side','heightMaxMm','courtyardMm','fixed'])
    writer.writeheader();writer.writerows({'ref':r,**q} for r,q in placement.items())
source_hashes={path.name:sha(path) for path in (WORK/'sources').glob('*') if path.is_file()}
write_json(OUT/'sources/source-hashes.json',source_hashes)
write_json(OUT/'sources/source-urls.json',sources)
write_json(OUT/'verification/placement-check.json',{
 'status':'TENTATIVE_NETLIST_UNROUTED_NOT_FOR_FABRICATION','kicadVersion':p.GetBuildVersion(),
 'inputFile':str(args.components),'inputSHA256':sha(args.components),
 'auditInputs':{str(f.relative_to(ROOT)):sha(f) for f in (power_path,power_changes,audio_root/'corrected-components.json',audio_root/'footprint-specifications.json') if f.exists()},
 'counts':{name:{'footprints':len(list(b.GetFootprints())),'tracks':len(list(b.GetTracks())),'outlineMm':specs[name][:2]} for name,b in boards.items()},
 'originalComponents':len(parts),'allOriginalRefsAccounted':set(byref).issubset(mapping),
 'unplaced':unplaced,'courtyardCollisions':collisions,'courtyardOutsideBoard':edge,
 'mainHeightBudgetViolations':[r for r,q in placement.items() if q['board']=='main' and q['side']=='B' and q['heightMaxMm']>1.5],
 'mainAboveAudioZoneViolations':[r for r,q in placement.items() if q['board']=='main' and q['side']=='F' and q['courtyardMm'][3]>24.5],
 'noProductionGerbers':True,'netlistElectricallyApproved':False,'fullAssemblyCollisionApproved':False,
 'note':'Physical courtyards do not validate electrical design, routing, battery fit, connector pinout or tolerances.'})
print(json.dumps({'boards':{n:len(list(b.GetFootprints())) for n,b in boards.items()},'collisions':collisions,'edge':edge},indent=2))
