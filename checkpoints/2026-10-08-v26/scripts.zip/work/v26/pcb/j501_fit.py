"""Evaluate actual official KiCad JST PH land against the main placement."""
import hashlib
import json
import os
from pathlib import Path
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
lib=ROOT/'work/v24/tools/kicad/share/kicad/footprints/Connector_JST.pretty'
name='JST_PH_B3B-PH-SM4-TB_1x03-1MP_P2.00mm_Vertical'
board=OUT/'SmartVio-main-v26-315-seeded.kicad_pcb'
b=p.LoadBoard(str(board));old=next(f for f in b.GetFootprints() if f.GetReference()=='J501')
f=p.FootprintLoad(str(lib),name);f.SetReference('J501_FIT_STUDY');b.Add(f)
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
ls=p.LSET();ls.AddLayer(p.F_CrtYd)
def box(g):
    bb=g.GetLayerBoundingBox(ls)
    return tuple(p.ToMM(v) for v in (bb.GetX(),bb.GetY(),bb.GetRight(),bb.GetBottom()))
boxes={g.GetReference():box(g) for g in b.GetFootprints() if not g.IsFlipped() and g not in (f,old)}
def conflicts():
    bb=box(f)
    refs=[ref for ref,q in boxes.items() if bb[0]<q[2]+.1 and bb[2]>q[0]-.1 and bb[1]<q[3]+.1 and bb[3]>q[1]-.1]
    edge=bb[0]<.15 or bb[1]<.15 or bb[2]>71.85 or bb[3]>24.5
    return bb,refs,edge
f.SetPosition(old.GetPosition());f.SetOrientation(old.GetOrientation())
original=conflicts();legal=[];best=[]
for angle in (0,90,180,270):
    f.SetOrientationDegrees(angle)
    for x in range(16,273,2):
        for y in range(16,89,2):
            xx=x/4;yy=y/4;f.SetPosition(pt(xx,yy));bb,refs,edge=conflicts()
            if edge:continue
            cost=abs(xx-p.ToMM(old.GetPosition().x))+abs(yy-p.ToMM(old.GetPosition().y))
            q={'xyMm':[xx,yy],'angle':angle,'courtyardMm':bb,'conflictingRefs':refs,'distanceFromOldMm':cost}
            if not refs:legal.append(q)
            best.append(q)
best.sort(key=lambda q:(len(q['conflictingRefs']),q['distanceFromOldMm']))
legal.sort(key=lambda q:q['distanceFromOldMm'])
record={'sourceSHA256':hashlib.sha256((OUT.parent/'electrical/native-components.json').read_bytes()).hexdigest(),
        'sourceBoard':str(board),'officialKiCadFootprint':str(lib/(name+'.kicad_mod')),
        'manufacturerSource':'https://www.jst-mfg.com/product/pdf/eng/ePH.pdf',
        'currentRatingA':2,'requiredWireGauge':'AWG24 and correct PH crimp/housing',
        'nominalMatedHeightMm':8,'mainFrontZMm':-14,'estimatedMatedTopZMm':-6,
        'estimatedHeightFitsCupButNotApproved':True,'backsideRejected':'8mm mated height would pass below existing nominal cup floor',
        'unchangedPositionTrial':{'courtyardMm':original[0],'conflictingRefs':original[1],'edgeOrRaisedAudioAreaConflict':original[2]},
        'frontLegalPlacementsFound':len(legal),'bestFrontPlacements':legal[:5] if legal else best[:5],
        'currentGHRated1A':True,'currentGHNotPermittedForClaimed2A':True,
        'pinNetMapUnchangedIfSelected':{d.GetNumber():d.GetNetname() for d in old.Pads() if d.GetNumber() in ('1','2','3')},
        'candidateChangeRequiresPackReroute':True,'productionApproved':False}
(OUT/'verification/j501-ph-physical-fit.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
