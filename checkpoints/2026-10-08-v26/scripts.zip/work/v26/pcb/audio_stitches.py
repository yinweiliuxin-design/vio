"""Physically stitch the jack board ground planes; never waive disconnected islands."""
import json
import math
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
src=OUT/'SmartVio-audio-v26-routed-fixed.kicad_pcb';dst=OUT/'SmartVio-audio-v26-closed.kicad_pcb'
b=p.LoadBoard(str(src));added=[]
zones=[z for z in b.Zones() if z.GetNetname()=='GND' and not z.GetIsRuleArea()]
polys=[z.GetFilledPolysList(z.GetLayer()) for z in zones]
connected_pairs=set()
for x in [q*.5 for q in range(2,145)]:
    for y in [q*.5 for q in range(2,27)]:
        pos=p.VECTOR2I(p.FromMM(x),p.FromMM(y))
        indices=[next((i for i in range(poly.OutlineCount()) if poly.Contains(pos,i)),None) for poly in polys]
        if None in indices or tuple(indices) in connected_pairs:continue
        ring=[p.VECTOR2I(p.FromMM(x+.34*math.cos(a*math.pi/8)),p.FromMM(y+.34*math.sin(a*math.pi/8))) for a in range(16)]
        if not all(poly.Contains(q,i) for poly,i in zip(polys,indices) for q in ring):continue
        connected_pairs.add(tuple(indices))
        via=p.PCB_VIA(b);via.SetPosition(pos);via.SetWidth(p.FromMM(.6));via.SetDrill(p.FromMM(.3))
        via.SetViaType(p.VIATYPE_THROUGH);via.SetLayerPair(p.F_Cu,p.B_Cu);via.SetNet(b.FindNet('GND'));b.Add(via)
        added.append({'xyMm':[x,y],'diameterMm':.6,'drillMm':.3})
for z in zones:z.SetIslandRemovalMode(p.ISLAND_REMOVAL_MODE_ALWAYS)
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(dst),b)
for ext in ['.kicad_pro','.kicad_dru']:
    if src.with_suffix(ext).exists():shutil.copyfile(src.with_suffix(ext),dst.with_suffix(ext))
(OUT/'verification/audio-ground-stitches.json').write_text(json.dumps({'physicalVias':added,
 'orphanCopperPolicy':'Physically remove unconnected zone islands on refill; no DRC check ignored',
 'nativeDRCRequired':True,'productionApproved':False},indent=2))
print(json.dumps(added))
