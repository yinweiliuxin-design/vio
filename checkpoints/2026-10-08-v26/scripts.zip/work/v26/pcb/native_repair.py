"""Scoped native copper repair with fixed fabrication rules and an external DRC gate."""
import argparse
import heapq
import json
import math
import os
from pathlib import Path
import shutil
import time
import numpy as np
from PIL import Image, ImageDraw

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'documents')
os.environ['DOCUMENTS_HOME']=str(WORK/'documents')
import pcbnew as p

ap=argparse.ArgumentParser()
ap.add_argument('--board',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--net',action='append',default=[])
ap.add_argument('--drc',type=Path)
ap.add_argument('--bridge',action='store_true')
ap.add_argument('--max-seconds',type=float,default=180)
ap.add_argument('--width-net',action='append',default=[])
args=ap.parse_args()
assert args.output.resolve().is_relative_to(OUT.resolve())
b=p.LoadBoard(str(args.board.resolve()))
LAYERS=list(b.GetEnabledLayers().CuStack())
S=20
edge=b.GetBoardEdgesBoundingBox()
W=math.ceil(p.ToMM(edge.GetRight())*S)+1
H=math.ceil(p.ToMM(edge.GetBottom())*S)+1
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
xy=lambda q:(p.ToMM(q.x),p.ToMM(q.y))
report={'input':str(args.board),'output':str(args.output),'clearanceMm':.15,'signalWidthMm':.15,'viaDiameterMm':.6,'viaDrillMm':.3,'repairs':[],'failures':[]}
original=list(b.GetTracks())
held=[]
deadline=time.monotonic()+args.max_seconds
netwidths={n:float(w) for n,w in (q.split('=',1) for q in args.width_net)}
assert all(w>=.15 for w in netwidths.values())
report['netWidthOverridesMm']=netwidths
outlines=p.SHAPE_POLY_SET()
assert b.GetBoardPolygonOutlines(outlines,False,None,False,True),'Native board outline including physical cutouts invalid'
def coordinates(chain):return [tuple(v*S for v in xy(chain.CPoint(i))) for i in range(chain.PointCount())]
holes=[coordinates(outlines.Hole(i,j)) for i in range(outlines.OutlineCount()) for j in range(outlines.HoleCount(i))]
keepouts=[]
for parent in [b,*b.GetFootprints()]:
    for zone in parent.Zones():
        if zone.GetIsRuleArea() and zone.GetDoNotAllowTracks():
            keepouts.append((zone.GetLayerSet(),[coordinates(zone.Outline().Outline(i)) for i in range(zone.Outline().OutlineCount())]))

def inventory():
    return sorted((f.GetReference(),d.GetNumber(),d.GetNetname(),d.GetPosition().x,d.GetPosition().y,f.GetLayer()) for f in b.GetFootprints() for d in f.Pads())
before=inventory()

def mask(net,extra):
    ims=[Image.new('1',(W,H),0) for _ in LAYERS]
    draws=[ImageDraw.Draw(im) for im in ims]
    for draw in draws:draw.rectangle((0,0,W-1,H-1),outline=1,width=math.ceil((.25+extra)*S))
    for draw in draws:
        for contour in holes:
            draw.polygon(contour,fill=1)
            draw.line(contour+[contour[0]],fill=1,width=math.ceil(2*(.5+extra)*S))
    for layer,draw in zip(LAYERS,draws):
        for ls,contours in keepouts:
            if not ls.Contains(layer):continue
            for contour in contours:
                draw.polygon(contour,fill=1)
                draw.line(contour+[contour[0]],fill=1,width=math.ceil(2*extra*S))
    def circle(draw,x,y,r):draw.ellipse(((x-r)*S,(y-r)*S,(x+r)*S,(y+r)*S),fill=1)
    for t in b.GetTracks():
        if t.GetNetname()==net:continue
        x,y=xy(t.GetStart());xx,yy=xy(t.GetEnd());via=isinstance(t,p.PCB_VIA)
        r=p.ToMM(t.GetWidth(p.F_Cu) if via else t.GetWidth())/2+extra
        for layer,draw in zip(LAYERS,draws):
            if not via and t.GetLayer()!=layer:continue
            draw.line((x*S,y*S,xx*S,yy*S),fill=1,width=math.ceil(2*r*S))
            circle(draw,x,y,r);circle(draw,xx,yy,r)
    for f in b.GetFootprints():
        for pad in f.Pads():
            if pad.GetNetname()==net:continue
            x,y=xy(pad.GetPosition());ww=p.ToMM(pad.GetSize().x)/2+extra;hh=p.ToMM(pad.GetSize().y)/2+extra
            a=math.radians(pad.GetOrientationDegrees())
            corners=[((x+u*math.cos(a)+v*math.sin(a))*S,(y-u*math.sin(a)+v*math.cos(a))*S) for u,v in [(-ww,-hh),(ww,-hh),(ww,hh),(-ww,hh)]]
            for layer,draw in zip(LAYERS,draws):
                if pad.IsOnLayer(layer):draw.polygon(corners,fill=1)
    return np.stack([np.asarray(im,dtype=bool) for im in ims])

def path(start,goal,net,width=.15):
    if time.monotonic()>deadline:raise RuntimeError('bounded native repair time limit')
    blocked=mask(net,.15+width/2+.04)
    vias=np.any(mask(net,.15+.3+.04),axis=0)
    a=(start[0],round(start[1]*S),round(start[2]*S));z=(goal[0],round(goal[1]*S),round(goal[2]*S))
    if blocked[a[0],a[2],a[1]] or blocked[z[0],z[2],z[1]]:raise RuntimeError('terminal obstructed')
    def heuristic(q):return math.hypot(q[1]-z[1],q[2]-z[2])+(45 if q[0]!=z[0] else 0)
    queue=[(heuristic(a),0,a)];cost={a:0};prev={};count=0
    while queue:
        _,g,q=heapq.heappop(queue)
        if g!=cost[q]:continue
        if q==z:
            ans=[q]
            while q in prev:q=prev[q];ans.append(q)
            return list(reversed(ans))
        layer,x,y=q;count+=1;neighbors=[]
        if count%1000==0 and time.monotonic()>deadline:raise RuntimeError('bounded native repair time limit')
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
            xx,yy=x+dx,y+dy
            if not(0<=xx<W and 0<=yy<H) or blocked[layer,yy,xx]:continue
            if dx and dy and (blocked[layer,y,xx] or blocked[layer,yy,x]):continue
            neighbors.append(((layer,xx,yy),math.hypot(dx,dy)))
        if not vias[y,x]:neighbors.extend(((l,x,y),45) for l in range(len(LAYERS)) if l!=layer)
        for n,c in neighbors:
            ng=g+c
            if ng<cost.get(n,float('inf')):cost[n]=ng;prev[n]=q;heapq.heappush(queue,(ng+heuristic(n),ng,n))
        if count>2000000:raise RuntimeError('search limit')
    raise RuntimeError('no path under fixed .15/.6/.3 rules; reachable '+str(len(cost)))

def add_path(a,z,net,width=.15):
    netcode=b.FindNet(net).GetNetCode();raw=path(a,z,net,width);way=[raw[0]]
    for i in range(1,len(raw)-1):
        u,v,w=raw[i-1:i+2]
        if tuple(v[j]-u[j] for j in range(3))!=tuple(w[j]-v[j] for j in range(3)):way.append(v)
    way.append(raw[-1]);created=[]
    def track(start,end,layer):
        if start==end:return
        t=p.PCB_TRACK(b);t.SetStart(pt(*start));t.SetEnd(pt(*end));t.SetWidth(p.FromMM(width));t.SetLayer(layer);t.SetNetCode(netcode);b.Add(t);created.append(t);held.append(t)
    track(a[1:],(raw[0][1]/S,raw[0][2]/S),LAYERS[a[0]])
    existing_vias=[t for t in b.GetTracks() if isinstance(t,p.PCB_VIA) and t.GetNetname()==net]
    def coordinate(q):
        point=(q[1]/S,q[2]/S)
        nearby=[t for t in existing_vias if math.dist(point,xy(t.GetPosition()))<.08]
        if nearby:return xy(min(nearby,key=lambda t:math.dist(point,xy(t.GetPosition()))).GetPosition())
        return point
    for u,v in zip(way,way[1:]):
        aa=coordinate(u);zz=coordinate(v)
        if u[0]!=v[0]:
            if any(math.dist(aa,xy(t.GetPosition()))<.001 for t in existing_vias):continue
            t=p.PCB_VIA(b);t.SetPosition(pt(*aa));t.SetWidth(p.FromMM(.6));t.SetDrill(p.FromMM(.3));t.SetLayerPair(p.F_Cu,p.B_Cu);t.SetViaType(p.VIATYPE_THROUGH);t.SetNetCode(netcode);b.Add(t);created.append(t);held.append(t)
        else:track(aa,zz,LAYERS[u[0]])
    track(coordinate(raw[-1]),z[1:],LAYERS[z[0]])
    report['repairs'].append({'net':net,'from':a,'to':z,'segmentsAndVias':len(created)})
    print('Connected '+net,flush=True)
    return created

def endpoint(d):
    layer=next(layer for layer in LAYERS if d.IsOnLayer(layer)) if d.GetAttribute()==p.PAD_ATTRIB_SMD else p.F_Cu
    return (LAYERS.index(layer),*xy(d.GetPosition()))

if args.drc:
    drc=json.loads(args.drc.read_text())
    dangling={v['items'][0]['uuid'] for v in drc['violations'] if v['type']=='via_dangling'}
    for t in original:
        if str(t.m_Uuid.AsString()) in dangling:b.Remove(t)
    if args.bridge:
        lookup={str(t.m_Uuid.AsString()):t for t in b.GetTracks()}
        lookup.update({str(d.m_Uuid.AsString()):d for f in b.GetFootprints() for d in f.Pads()})
        for issue in drc['unconnected_items']:
            if any(x['uuid'] not in lookup for x in issue['items']):
                report['failures'].append({'reason':'Zone-island item requires whole-net repair, not a synthetic endpoint', 'items':issue['items']})
                continue
            u,v=[lookup[x['uuid']] for x in issue['items']]
            def locations(item):
                if isinstance(item,p.PAD):return [endpoint(item)]
                return [(LAYERS.index(item.GetLayer()),*xy(q)) for q in [item.GetStart(),item.GetEnd()]]
            pairs=sorted([(math.dist(a[1:],z[1:]),a,z) for a in locations(u) for z in locations(v)])
            succeeded=False
            for _,a,z in pairs:
                try:add_path(a,z,u.GetNetname(),netwidths.get(u.GetNetname(),.15));succeeded=True;break
                except RuntimeError as ex:reason=str(ex)
            if not succeeded:report['failures'].append({'net':u.GetNetname(),'reason':reason})

for net in args.net:
    removed=[t for t in b.GetTracks() if t.GetNetname()==net]
    held.extend(removed)
    for t in removed:b.Remove(t)
    pads=[(f.GetReference(),d.GetNumber(),endpoint(d)) for f in b.GetFootprints() for d in f.Pads() if d.GetNetname()==net]
    connected=[pads.pop(0)];added=[]
    try:
        while pads:
            pairs=sorted((math.dist(a[2][1:],z[2][1:]),i,j) for i,a in enumerate(connected) for j,z in enumerate(pads))
            succeeded=False
            for _,i,j in pairs:
                try:added.extend(add_path(connected[i][2],pads[j][2],net,netwidths.get(net,.15)));connected.append(pads.pop(j));succeeded=True;break
                except RuntimeError:continue
            if not succeeded:raise RuntimeError('cannot escape '+str([x[:2] for x in pads]))
    except RuntimeError as ex:
        for t in added:b.Remove(t)
        for t in removed:b.Add(t)
        report['failures'].append({'net':net,'reason':str(ex),'originalCopperRestored':True})
assert inventory()==before,'Repair changed footprint pad positions or assigned nets'
p.SaveBoard(str(args.output),b)
if args.board.with_suffix('.kicad_pro').exists():shutil.copyfile(args.board.with_suffix('.kicad_pro'),args.output.with_suffix('.kicad_pro'))
if args.board.with_suffix('.kicad_dru').exists():shutil.copyfile(args.board.with_suffix('.kicad_dru'),args.output.with_suffix('.kicad_dru'))
(OUT/'verification'/(args.output.stem+'-repair.json')).write_text(json.dumps(report,indent=2))
print(json.dumps({'repairs':len(report['repairs']),'failures':report['failures'],'drc':'REQUIRED'},indent=2))
