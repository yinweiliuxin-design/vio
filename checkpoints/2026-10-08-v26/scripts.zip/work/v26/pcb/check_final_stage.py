"""Run actual native DRC and retain each stage as a separate file."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
ap=argparse.ArgumentParser();ap.add_argument('--board',type=Path,required=True)
ap.add_argument('--refill',action='store_true');a=ap.parse_args()
assert a.board.resolve().is_relative_to(OUT.resolve())
project=a.board.with_suffix('.kicad_pro')
backup=OUT/'verification'/(project.stem+'-rules-before-strict.json')
if not backup.exists():shutil.copyfile(project,backup)
settings=json.loads(project.read_text())
design=settings['board']['design_settings']
severities=design['rule_severities']
required=['missing_courtyard','track_not_centered_on_via','tuning_profile_track_geometries',
          'footprint_filters_mismatch','footprint_type_mismatch']
changed={k:severities.get(k) for k in required}
for k in required:severities[k]='warning'
for k,v in list(severities.items()):
    if v=='ignore':severities[k]='warning'
assert not design.get('drc_exclusions'), 'Final DRC must not silently exclude individual items'
project.write_text(json.dumps(settings,indent=2)+'\n')
if a.refill:
    subprocess.run([str(ROOT/'work/v24/tools/kicad/bin/python.exe'),str(WORK/'refill_existing.py'),str(a.board)],check=True)
target=OUT/'verification'/(a.board.stem+'-strict-drc.json')
run=subprocess.run([str(ROOT/'work/v24/tools/kicad/bin/kicad-cli.exe'),'pcb','drc','--format','json','-o',str(target),str(a.board.resolve())],capture_output=True,text=True)
assert target.exists(),run.stdout+run.stderr
d=json.loads(target.read_text());assert not d['ignored_checks'],d['ignored_checks']
(OUT/'verification'/(a.board.stem+'-strict-policy.json')).write_text(json.dumps({
 'boardPath':str(a.board.resolve()),'originalPolicyPath':str(backup.resolve()),
 'requestedChecksNowWarning':required,'previousRequestedSeverities':changed,
 'ignoredChecks':d['ignored_checks'],'individualExclusions':design.get('drc_exclusions',[]),
 'manufacturingRulesUnchanged':True,'productionApproved':False},indent=2))
print(json.dumps({'board':str(a.board),'drc':str(target),'ignoredChecks':d['ignored_checks'],
 'errors':sum(q['severity']=='error' for q in d['violations']),'warnings':sum(q['severity']=='warning' for q in d['violations']),
 'unconnected':len(d['unconnected_items']),'types':{t:sum(q['type']==t for q in d['violations']) for t in sorted({q['type'] for q in d['violations']})}},indent=2))
