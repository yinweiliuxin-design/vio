"""Re-place two real inductors and remove two identified new-land copper conflicts."""
import json
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
src=OUT/'SmartVio-usb-v26-final-input.kicad_pcb';dst=OUT/'SmartVio-usb-v26-local-input.kicad_pcb'
b=p.LoadBoard(str(src));drc=json.loads((OUT/'verification/v26-usb-final-input-drc.json').read_text())
rip={item['uuid'] for q in drc['violations'] if q['type']=='clearance' and any('C1501' in i['description'] or 'C403' in i['description'] for i in q['items']) for item in q['items'] if item['description'].startswith('Track')}
held=[];changes=[]
for t in list(b.GetTracks()):
    if t.m_Uuid.AsString() in rip:held.append(t);b.Remove(t)
fps={f.GetReference():f for f in b.GetFootprints()};ls=p.LSET();ls.AddLayer(p.F_CrtYd)
def box(f):return f.GetLayerBoundingBox(ls)
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
for ref in ('L1501','L1502'):
    f=fps[ref]
    options=sorted(((abs(x-16)+abs(y-8.5),x,y,angle) for x in [i/4 for i in range(61,87)] for y in [i/4 for i in range(28,41)] for angle in (0,90,180,270)))
    for _,x,y,angle in options:
        f.SetPosition(pt(x,y));f.SetOrientationDegrees(angle);bb=box(f)
        if any(bb.Intersects(box(g)) for r,g in fps.items() if r!=ref and not g.IsFlipped()):continue
        conflict=False
        for pad in f.Pads():
            test=pad.GetBoundingBox();test.Inflate(p.FromMM(.16))
            if any(t.GetNetname()!=pad.GetNetname() and (isinstance(t,p.PCB_VIA) or t.GetLayer()==p.F_Cu) and test.Intersects(t.GetBoundingBox()) for t in b.GetTracks()):conflict=True;break
        if conflict:continue
        break
    else:raise RuntimeError('No checked legal front position for '+ref)
    changes.append({'ref':ref,'xyMm':[x,y],'angle':angle,'side':'F'})
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(dst),b)
for ext in ('.kicad_pro','.kicad_dru'):shutil.copyfile(src.with_suffix(ext),dst.with_suffix(ext))
(OUT/'verification/usb-local-placement.json').write_text(json.dumps({'changes':changes,'rippedTrackUUIDs':sorted(rip),'productionApproved':False},indent=2))
print(json.dumps(changes,indent=2))
