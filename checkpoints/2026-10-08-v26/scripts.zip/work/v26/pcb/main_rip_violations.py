"""Remove only explicitly reported clearance-invalid segments from a repair candidate."""
import argparse
import shutil
from main_ast import *
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);ap.add_argument('drc',type=Path);ap.add_argument('--name',required=True);a=ap.parse_args()
tree=read(a.board);drc=json.loads(a.drc.read_text());lookup=objects(tree);remove={}
for v in drc['violations']:
    if v['severity']!='error':continue
    assert v['type']=='clearance'
    segments=[lookup.get(i['uuid']) for i in v['items'] if key(lookup.get(i['uuid']))=='segment']
    assert segments,'No trace that can be ripped without changing a pad or via'
    for q in segments:remove[uuid(q)]={'net':child(q,'net')[1],'reason':v['description'],'segment':signature(q)}
tree[:]=[q for q in tree if key(q)!='segment' or uuid(q) not in remove]
dst=DEST/(a.name+'.kicad_pcb');write(dst,tree)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(a.board.with_suffix(ext),dst.with_suffix(ext))
dst.with_suffix('.rip.json').write_text(json.dumps({'inputSHA256':sha(a.board),'outputSHA256':sha(dst),'removed':remove,'reason':'Widened fanout traces conflicted with native clearance; rip for actual reroute, never reduce the rule'},indent=2))
print(json.dumps({'removed':len(remove),'output':str(dst)}))
