"""Try a local supply escape, retaining original routed input for native DRC."""
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2];OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
src=OUT/'SmartVio-power-prototype-critical-clean.kicad_pcb'
dst=OUT/'SmartVio-power-prototype-sys-escape.kicad_pcb'
b=p.LoadBoard(str(src));net=b.FindNet('SYS').GetNetCode()
t=p.PCB_TRACK(b);t.SetStart(pt(44.8625,10.025));t.SetEnd(pt(44.8625,9.2));t.SetWidth(p.FromMM(.2));t.SetLayer(p.F_Cu);t.SetNetCode(net);b.Add(t)
v=p.PCB_VIA(b);v.SetPosition(pt(44.8625,9.2));v.SetWidth(p.FromMM(.6));v.SetDrill(p.FromMM(.3));v.SetViaType(p.VIATYPE_THROUGH);v.SetLayerPair(p.F_Cu,p.B_Cu);v.SetNetCode(net);b.Add(v)
p.SaveBoard(str(dst),b);shutil.copyfile(src.with_suffix('.kicad_pro'),dst.with_suffix('.kicad_pro'))
print(dst)
