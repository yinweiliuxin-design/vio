"""Remove actual dangling copper only when native pad-to-pad connected groups are preserved."""
import argparse
import copy
import os
import shutil
import subprocess
import sys
from main_ast import *
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);ap.add_argument('--name',required=True)
ap.add_argument('--individual',action='store_true');a=ap.parse_args()
dst=DEST/(a.name+'.kicad_pcb');shutil.copyfile(a.board,dst)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(a.board.with_suffix(ext),dst.with_suffix(ext))

def groups(path):
    b=p.LoadBoard(str(path.resolve()));b.BuildConnectivity();conn=b.GetConnectivity();result=set()
    for f in b.GetFootprints():
        for pad in f.Pads():
            if not pad.GetNetname():continue
            group=tuple(sorted(str(q.m_Uuid.AsString()) for q in conn.GetConnectedItems(pad) if q.Type()==p.PCB_PAD_T))
            if len(group)>1:result.add(group)
    return result

def run_checks():
    for script,params in [('main_refill_safe.py',[str(dst)]),('check_final_stage.py',['--board',str(dst)])]:
        result=subprocess.run([sys.executable,str(WORK/script),*params],capture_output=True,text=True,timeout=90)
        assert result.returncode==0,(script,result.stdout,result.stderr)
    return json.loads((OUT/'verification'/(dst.stem+'-strict-drc.json')).read_text())

initial_groups=groups(a.board);history=[];drc=run_checks()
for iteration in range(12):
    before=read(dst);tree=copy.deepcopy(before);objs=objects(tree)
    removals={v['items'][0]['uuid']:v['type'] for v in drc['violations'] if v['type'] in ['track_dangling','via_dangling']}
    if not removals:break
    skipped={}
    if a.individual:
        accepted={}
        for ident,kind in removals.items():
            candidate=[q for q in tree if key(q) not in ['segment','via','arc'] or uuid(q)!=ident]
            write(dst,candidate)
            connected=groups(dst)
            splits=[g for g in initial_groups if not any(set(g).issubset(h) for h in connected)]
            if splits:
                skipped[ident]={'type':kind,'reason':'Native connected pad group would split'}
                write(dst,tree)
            else:
                tree=candidate;accepted[ident]=kind
        removals=accepted
        if not removals:
            history.append({'iteration':iteration,'individualRemovalsSkipped':skipped});break
    else:
        tree[:]=[q for q in tree if key(q) not in ['segment','via','arc'] or uuid(q) not in removals]
    write(dst,tree);after_groups=groups(dst)
    splits=[list(g) for g in initial_groups if not any(set(g).issubset(h) for h in after_groups)]
    if splits:
        write(dst,before);history.append({'iteration':iteration,'rejectedRemovalIds':removals,'reason':'Native connected pad group split','groups':splits});drc=run_checks();break
    new_drc=run_checks()
    if any(v['severity']=='error' for v in new_drc['violations']):
        write(dst,before);history.append({'iteration':iteration,'rejectedRemovalIds':removals,'reason':'New native DRC error'});drc=run_checks();break
    history.append({'iteration':iteration,'removed':removals,'unconnected':len(new_drc['unconnected_items']),
                    'individualRemovalsSkipped':skipped,
                    'warnings':sum(v['severity']=='warning' for v in new_drc['violations']),'nativePadConnectivityPreserved':True});drc=new_drc
    print(json.dumps({'iteration':iteration,'removed':len(removals),'unconnected':len(drc['unconnected_items']),'warnings':len(drc['violations'])}),flush=True)
report={'input':str(a.board),'inputSHA256':sha(a.board),'output':str(dst),'outputSHA256':sha(dst),'history':history,
 'allOriginalNativeConnectedPadGroupsPreserved':not any('rejectedRemovalIds' in h for h in history),
 'originalConnectedPadGroupCount':len(initial_groups),'finalConnectedPadGroupCount':len(groups(dst)),
 'errors':sum(v['severity']=='error' for v in drc['violations']),'warnings':sum(v['severity']=='warning' for v in drc['violations']),
 'unconnected':len(drc['unconnected_items']),'ignoredChecks':drc['ignored_checks'],'productionApproved':False}
dst.with_suffix('.cleanup.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='history'},indent=2))
