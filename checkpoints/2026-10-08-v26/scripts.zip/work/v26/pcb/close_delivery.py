"""Write the bounded, current-revision native evidence and selected CAM index; no release claim."""
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
from specctra import loads,child
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work';PACK=OUT.parent;VERIFY=OUT/'verification'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rel=lambda p:p.resolve().relative_to(PACK.resolve()).as_posix()
sourcepath=PACK/'electrical/native-components.json';source=json.loads(sourcepath.read_text(encoding='utf-8-sig'))
sourcehash=sha(sourcepath);assert sourcehash=='587358f65402f79e200a5991e694b35c95370abecb3aabd0c1c0513aa372917f'
mapping=json.loads((OUT/'footprint-map.json').read_text());paritypath=VERIFY/'current-native-parity.json';parity=json.loads(paritypath.read_text())
assert parity['sourceSHA256']==sourcehash and not parity['sourceExportPinNetDifferences'] and not parity['sourceExportReferenceDifferences']
required=['missing_courtyard','track_not_centered_on_via','tuning_profile_track_geometries','footprint_filters_mismatch','footprint_type_mismatch']
boards=[];cam_index=[]
blockers={
 'main':['306 actual native unconnected items; 58 shorting-item errors and 19 courtyard overlaps. Whole main board is DRAFT, not electrically connected or geometrically valid.',
         'Current exact larger capacitor, magnetic and connector lands intersect inherited copper and nearby parts; placement must be rebuilt without shrinking manufacturer pads.',
         '315-source advanced autoroute produced no SES. Its 225 algorithm-unrouted figure is NOT native-board progress and was not imported.',
         'High-current buck/charger/efuse/load-domain loops and thermal EPs need manual placement/width/return review; inherited 0.15/0.2mm routing is not current-qualified.',
         'Analog input/ADC/DAC isolation, off-domain I2C/data states, USB harness SI/return, RF feed/ground and complete 72x39x1mm assembly stack remain unqualified.'],
 'usb':['One real VBUS_RAW copper break with two associated dangling-track warnings remains; no CAM exported.',
        'Expanded C403 land required removal of intersecting old VBUS copper. .6/.3 mechanical-via repair and .4/.2mm route attempts were terminal-obstructed; no short or fake connection added.',
        'U1401 B2 GND now physically escapes through a .25/.10mm F-to-In1 filled/capped laser microvia. 1+2+1 HDI, not conventional through-via fabrication.',
        'USB DP/DM are correctly adjacent in the internal header and CMC numbering is corrected, but route/pair/cable 90-ohm SI, ESD coordination, rail ampacity and transient behavior remain HOLD.'],
 'audio':['Two actual GND pour-island connections remain after real signal routing, manufacturer cutouts and legal stitching; no CAM exported.',
          'All six Kycon electrical terminals are physical plated slots, with true cutouts. Ground return across cutout/long signal barriers needs explicit corridor/routing review; no orphan-island or unconnected check ignored.',
          'TRS/TS physical plug continuity, NO detect switch sample behavior, cutout tolerances and 14.9mm jack stack remain HOLD.'],
 'cover':['Zero native violations and unconnected items is only a local geometry/connectivity result, not assembly or circuit release.',
          'Actual Alps four-pad switches/roller contacts/retention cutouts, Kingbright polarity and speaker pressure contacts are included. Button cap/preload/stops, speaker polarity/pressure and 0.4mm board stiffness require physical review.',
          'SPK_P and SPK_N are .6mm native traces; ampacity, BTL load/HPF and harness durability remain unqualified.'],
 'sensor':['Zero native violations and unconnected items is only a local geometry/connectivity result.',
           'Sensor accuracy, thermal coupling, solder endpoints, cable termination and final assembly are not approved.']}
for kind in ['main','usb','audio','cover','sensor']:
    inventory=json.loads((VERIFY/('final-inventory-'+kind+'.json')).read_text());board=Path(inventory['boardPath'])
    assert board.name=='SmartVio-'+kind+'-v26-final.kicad_pcb' and sha(board)==inventory['boardSHA256']
    pro=board.with_suffix('.kicad_pro');policy=json.loads(pro.read_text())['board']['design_settings']
    assert all(policy['rule_severities'][k]=='warning' for k in required)
    assert 'ignore' not in policy['rule_severities'].values() and not policy.get('drc_exclusions')
    drcpath=VERIFY/(board.stem+'-strict-drc.json');d=json.loads(drcpath.read_text());assert not d['ignored_checks']
    errors=sum(q['severity']=='error' for q in d['violations']);warnings=sum(q['severity']=='warning' for q in d['violations'])
    pd=next(q for q in parity['boards'] if q['kind']==kind)
    assert all(not pd[k] for k in ['pinNetDifferences','candidateHarnessDifferences','valueDifferences','mpnDifferences','padSetDifferences','pinFunctionDifferences'])
    manifest=OUT/'cam-review-v26-current'/kind/'CAM-manifest.json'
    cam=[]
    if kind in ['cover','sensor']:
        assert errors==warnings==len(d['unconnected_items'])==0 and manifest.exists()
        mc=json.loads(manifest.read_text());assert mc['boardSHA256']==sha(board) and not mc['productionApproved']
        for file in mc['CAM']:
            path=Path(file['path']);assert path.exists() and sha(path)==file['sha256']
        cam=mc['CAM']
        cam_index.append({'kind':kind,'directoryPath':str(manifest.parent.resolve()),'directoryRelativePackPath':rel(manifest.parent),
          'manifestPath':str(manifest.resolve()),'manifestRelativePackPath':rel(manifest),'manifestSHA256':sha(manifest),'boardSHA256':sha(board),'files':cam,'productionApproved':False})
    else:assert not manifest.exists(),'Blocked board must not have selected current CAM'
    companions=[{'path':str(board.with_suffix(ext).resolve()),'relativePackPath':rel(board.with_suffix(ext)),'sha256':sha(board.with_suffix(ext))} for ext in ['.kicad_pcb','.kicad_pro','.kicad_dru']]
    boards.append({'kind':kind,'board':board.name,'boardPath':str(board.resolve()),'relativePackPath':rel(board),'boardSHA256':sha(board),
      'sourceSHA256':sourcehash,'sourceBasis':'Actual current pads/net/value/MPN inventory compared with current JSON and native XML; inherited routing basis is separately retained',
      'nativeFiles':companions,'footprints':inventory['footprintCount'],'tracks':inventory['trackCount'],'vias':inventory['viaCount'],
      'nativeZoneObjects':inventory['zoneCount'],'copperZones':inventory['zoneCount']-(1 if kind=='main' else 0),'boardRuleAreas':1 if kind=='main' else 0,
      'layers':inventory['copperLayers'],'thicknessMm':inventory['thicknessMm'],'unconnected':len(d['unconnected_items']),
      'drc':{'reportPath':str(drcpath.resolve()),'relativePackPath':rel(drcpath),'reportSHA256':sha(drcpath),'version':d['kicad_version'],
        'errors':errors,'warnings':warnings,'unconnectedErrors':len(d['unconnected_items']),'totalErrorsIncludingUnconnected':errors+len(d['unconnected_items']),
        'violationsByType':dict(Counter(q['type'] for q in d['violations'])),'ignoredChecks':d['ignored_checks'],
        'requestedFiveChecks':{k:policy['rule_severities'][k] for k in required},'individualExclusions':policy.get('drc_exclusions',[]),
        'customRulesPath':str(board.with_suffix('.kicad_dru').resolve()),'manufacturingRules':policy['rules'],
        'ruleScope':'No blanket ignores. Existing explicit local land/laser-process constraints retained and disclosed; these are fabrication assumptions, not manufacturing approval.'},
      'parity':pd,'CAM':cam,'CAMManifestPath':str(manifest.resolve()) if cam else None,'CAMDirectoryRelativePackPath':rel(manifest.parent) if cam else None,
      'status':'LOCAL_CONNECTIVITY_GEOMETRY_CLOSED_ENGINEERING_CAM_HOLD' if cam else 'DRAFT_ROUTING_OR_GEOMETRY_BLOCKED_NO_CAM',
      'blockers':blockers[kind],'productionApproved':False})
# Preserve exact DRC overlap items plus numerical physical land/courtyard boxes.
main=boards[0];main_drc=json.loads(Path(main['drc']['reportPath']).read_text())
collision_records=[]
for issue in main_drc['violations']:
    if issue['type']!='courtyards_overlap':continue
    refs=[q['description'].removeprefix('Footprint ') for q in issue['items']]
    collision_records.append({'refs':refs,'items':issue['items'],'placements':[{'ref':ref,'id':mapping[ref]['id'],
       'mpn':mapping[ref]['mpn'],'xyMm':mapping[ref]['xyMm'],'side':mapping[ref]['side'],
       'courtyardBBoxMm':mapping[ref]['courtyardBBoxMm'],'pads':mapping[ref]['physicalPads']} for ref in refs]})
critical_caps={c['ref']:c for c in source if c['ref'] in ['C501','C502','C503','C1102','C1103','C1104','C1105','C1106','C1107','C601','C602','C603','C604','C1902','C1903','C1921']}
decoupling=[]
for ref,c in critical_caps.items():
    cap=mapping[ref];nets={p['net'] for p in cap['physicalPads'] if p['net'] and p['net']!='GND'}
    nearest=[]
    for target in ['U501','U1101','U601','U1901','U1921']:
        fp=mapping[target]
        pairs=[(math.dist(a['xyMm'],z['xyMm']),a['number'],z['number'],a['net']) for a in cap['physicalPads'] for z in fp['physicalPads'] if a['net'] in nets and a['net']==z['net']]
        if pairs:
            dist,pad,pin,net=min(pairs);nearest.append({'ic':target,'icPin':pin,'capPad':pad,'net':net,'padCenterStraightDistanceMm':dist})
    decoupling.append({'ref':ref,'mpn':cap['mpn'],'xyMm':cap['xyMm'],'side':cap['side'],'courtyardBBoxMm':cap['courtyardBBoxMm'],'matchingSupplyPinDistances':nearest,'loopQualified':False})
geometry={'boardPath':main['boardPath'],'boardSHA256':main['boardSHA256'],'sourceSHA256':sourcehash,
 'currentCourtyardOverlapCount':len(collision_records),'collisions':collision_records,'criticalCapacitorPlacementAudit':decoupling,
 'baselineV25':{'unconnected':219,'warnings':127,'errors':0,'sourceSHA256':'72ae4e7478b3184a50a32783ac7704fbcf23aafa1197f089a666b7c7699a35bd','scope':'Older 292-source geometry, five checks ignored; not comparable as a current design pass'},
 'currentV26':{'unconnected':306,'warnings':143,'errors':268,'deltaUnconnected':87,'deltaWarnings':16,'deltaGeometryErrors':268},
 'causes':['316-source adds power-domain isolation, independent NTC reference/window and R826; changed nets require real rip-up/new copper.',
  'Exact selected capacitors grow to manufacturer lands including 1206 sizes; old trace/pad endpoints and former placements are invalid.',
  'J501 now has real Molex MP mechanical nails that intersect old PACK_NTC copper; current source parity does not fix copper shorts.',
  'Official TVS lands shrink to .3x.5mm. Old approaching traces require real reconnection, not silent footprint substitution.',
  'L1101 is 4.3x4.3x2.1mm maximum, not former generic 4x4x2 budget. F-board y>=24.5 is reserved for audio board/pin tails; backside height/stack must be respected.'],
 'fitConclusion':'Current placement is demonstrably invalid. This does NOT prove all possible 72x39mm two-sided placements impossible; repacking/critical-loop placement and full assembly modeling are still required.',
 'manufacturerPadsShrunkToForcePass':False,'productionApproved':False}
(VERIFY/'main-placement-technical-blocks.json').write_text(json.dumps(geometry,indent=2))
official=PACK/'audit/controls-protection/footprints/Controls_Protection_Official.pretty/TI_DPY0002A_1x0.6mm_P0.7mm_NSMD.kicad_mod'
def land_signature(path):
    tree=loads(path.read_text());pads=[q for q in tree if isinstance(q,list) and q[0]=='pad']
    return sorted((q[1],tuple(float(x) for x in child(q,'at')[1:3]),tuple(float(x) for x in child(q,'size')[1:]),
       q[2],q[3],tuple(sorted(child(q,'layers')[1:])),float(child(q,'roundrect_rratio')[1]),
       float(child(q,'solder_mask_margin')[1])) for q in pads)
tvs=[]
for ref in ['D120'+str(n) for n in range(1,8)]:
    entry=mapping[ref];pads=entry['physicalPads']
    tests={'twoPads':len(pads)==2,'numbers1and2':{p['number'] for p in pads}=={'1','2'},
      'size0_3x0_5':all(p['sizeMm']==[.3,.5] for p in pads),
      'centersPlusMinus0_35':sorted(p['relativeXYMm'] for p in pads)==[[-.35,0.0],[.35,0.0]],
      'mask0_07':all(p['maskMarginMm']==.07 for p in pads),'corner0_05':all(p['cornerRadiusMm']==.05 for p in pads),
      'libraryPadSignatureMatchesParentOfficial':land_signature(Path(entry['landSource']['libraryFile']))==land_signature(official)}
    tvs.append({'ref':ref,'id':entry['id'],'pads':pads,'tests':tests,'numericLandPass':all(tests.values()),
       'libraryBytesMatchParentOfficial':sha(Path(entry['landSource']['libraryFile']))==sha(official),
       'byteDifferenceReason':'Native KiCad serialization adds UUID/default fields and normalizes layer order; compared structured pad signatures, not raw bytes',
       'routeConnectivityApproved':False})
tvsreport={'sourceSHA256':sourcehash,'boardSHA256':main['boardSHA256'],'officialFile':str(official.resolve()),'officialSHA256':sha(official),
 'entries':tvs,'allSevenNumericLandPass':all(t['numericLandPass'] for t in tvs),'scope':'Actual native numbers/centers/copper/mask/corners plus parent official structured pad-signature match; main routing and protection coordination remain HOLD','productionApproved':False}
(VERIFY/'tvs-final-numeric-landcheck.json').write_text(json.dumps(tvsreport,indent=2));assert tvsreport['allSevenNumericLandPass']
usb=next(b for b in boards if b['kind']=='usb');usb_tree=loads(Path(usb['boardPath']).read_text())
microvias=[v for v in usb_tree if isinstance(v,list) and v[0]=='via' and 'micro' in v]
assert len(microvias)==1
micro=microvias[0];ball=next(p for p in mapping['U1401']['physicalPads'] if p['number']=='B2')
assert [float(x) for x in child(micro,'at')[1:3]]==ball['xyMm']
assert [s.strip('"') for s in child(micro,'layers')[1:]]==['F.Cu','In1.Cu'] and child(micro,'filling')[1]=='yes' and child(micro,'capping')[1]=='yes'
assert float(child(micro,'size')[1])==.25 and float(child(micro,'drill')[1])==.1 and ball['net']=='GND'
usbdrc=json.loads(Path(usb['drc']['reportPath']).read_text())
b2_errors=[q for q in usbdrc['violations']+usbdrc['unconnected_items'] if any('B2' in i['description'] for i in q['items'])]
b2report={'sourceSHA256':sourcehash,'boardPath':usb['boardPath'],'boardSHA256':usb['boardSHA256'],'actualB2Pad':ball,
 'actualMicroviaNativeSExpression':micro,'nativeStackup':child(child(usb_tree,'setup'),'stackup'),
 'microviaProcess':'1+2+1 HDI, .25mm copper pad/.10mm laser hole, .08mm outer dielectric, filled and capped F-In1',
 'nativeStrictB2RelatedErrorsOrUnconnected':b2_errors,'strictWholeUsbUnconnected':usb['unconnected'],'ignoredChecks':[],
 'scope':'B2 physical escape is present and is not in actual native DRC/unconnected list. Remaining USB VBUS break still blocks CAM.',
 'processCapabilityReference':'https://jlcpcb.com/help/article/hdi-pcb-capabilities-faq','productionApproved':False}
(VERIFY/'usb-final-b2-microvia-evidence.json').write_text(json.dumps(b2report,indent=2));assert not b2_errors
camidxpath=VERIFY/'CAM-index-v26-current.json';camidxpath.write_text(json.dumps({'sourceSHA256':sourcehash,'status':'ONLY_SELECTED_CURRENT_ENGINEERING_CAM_NOT_RELEASED_ASSEMBLY','boards':cam_index,'excludedHistoricalDirectories':['engineering-export','V25 CAM copies','old power prototype'],'productionApproved':False},indent=2))
contracts=[]
for name in ['main-final-292-bounded.contract.json','main-v26-continuation.contract.json','main-v26-315-advanced.contract.json']:
    path=OUT/'routing'/name;contract=json.loads(path.read_text())
    contracts.append({'path':str(path.resolve()),'sha256':sha(path),'boardPath':contract['boardPath'],'boardSHA256':contract['boardSHA256'],'dsnSHA256':contract['dsnSHA256'],
      'contractPreserved':True,'sesExists':path.with_name(path.name.replace('.contract.json','.ses')).exists()})
process_run=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-Command',
    "@(Get-CimInstance Win32_Process -Filter \"Name = 'java.exe' OR Name = 'python.exe'\" | Where-Object { $_.CommandLine -match 'freerouting|native_repair\\.py' } | Select-Object ProcessId,Name,CommandLine) | ConvertTo-Json -Depth 3"],capture_output=True,text=True,check=True)
active=json.loads(process_run.stdout) if process_run.stdout.strip() else []
assert not active,('Router still running',active)
(VERIFY/'router-final-process-check.json').write_text(json.dumps({'checkedUTC':datetime.now(timezone.utc).isoformat(),'matchingRouterProcesses':active,'allTaskOwnedRouterJobsStopped':True},indent=2))
summary={'generatedUTC':datetime.now(timezone.utc).isoformat(),'status':'V26_CURRENT_NATIVE_DRAFT_MAIN_UNRELEASED_BOUNDED_FINAL',
 'sourcePath':str(sourcepath.resolve()),'sourceSHA256':sourcehash,'sourceComponents':len(source),'sourcePins':sum(len(c['pins']) for c in source),
 'sourceNets':len({p['net'] for c in source for p in c['pins'] if p['net']}),
 'route_basis':'c3cf838f184bc2a50f5ec8f46a998342dc6cf1402db8976f6b50a1c9844f19c6',
 'routeBasisScope':'Inherited main-292 copper basis, not the current source. Source hashes/contracts were not rewritten to pretend current routing.',
 'lastAttemptedRouteSourceSHA256':'1d7c0a10465a6595b03866f3604ac77d1cdbb3a53f721ca4111a1afebd258fda',
 'lastAttemptedRouteImported':False,'routingContracts':contracts,'routersStatus':'STOPPED; no long router restarted during final closure',
 'routerLogs':[str((WORK/q).resolve()) for q in ['main-continuation-router.log','main-315-router.log']],
 'routerAlgorithmFigureNotNativeResult':{'unrouted':225,'violations':96,'SESProduced':False,'usedForNativeSummary':False},
 'mainBaselineComparison':geometry['baselineV25'],'mainCurrentComparison':geometry['currentV26'],
 'footprintMapPath':str((OUT/'footprint-map.json').resolve()),'footprintMapSHA256':sha(OUT/'footprint-map.json'),
 'currentNativeParityPath':str(paritypath.resolve()),'currentNativeParitySHA256':sha(paritypath),
 'currentSourceVsSchematicPinNetDifferences':parity['sourceExportPinNetDifferences'],'currentSourceVsSchematicReferenceDifferences':parity['sourceExportReferenceDifferences'],
 'captureFootprintSyncPending':True,'captureFootprintUpdatesRequired':parity['captureFootprintMetadataUpdatesRequired'],
 'mapValidForCaptureFields':'All 329 populated native footprints resolve to actual local library files; 315 current source refs plus 14 separate harness features. RT1921 deliberately remains external with no PCB Footprint field.',
 'externalSourceRefs':['RT1921'],'globalElectricalFilesModifiedByWorker':False,
 'relativePackPathBase':'outputs/SmartVio-V26-Engineering','canonicalSummaryRelativePackPath':'pcb-work/verification/final-summary.json',
 'CAMIndexPath':str(camidxpath.resolve()),'CAMIndexRelativePackPath':rel(camidxpath),'CAMIndexSHA256':sha(camidxpath),
 'CAMReviewRootPath':str((OUT/'cam-review-v26-current').resolve()),'selectedCAMBoardKinds':['cover','sensor'],
 'mainCAMExported':False,'usbCAMExported':False,'audioCAMExported':False,'boards':boards,
 'allSelectedIgnoredChecks':[],'newlyEnabledDRCChecks':required,
 'geometryReviewPath':str((VERIFY/'main-placement-technical-blocks.json').resolve()),
 'tvsNumericLandPath':str((VERIFY/'tvs-final-numeric-landcheck.json').resolve()),
 'usbB2EvidencePath':str((VERIFY/'usb-final-b2-microvia-evidence.json').resolve()),
 'passiveApplicationHold':{'manufacturerLandsAppliedToCurrentBoard':True,'74EffectiveCapacitanceClaimsNotGuaranteed':True,'10RefsRequireUnmergedCapacitorBanks':True,'new30CapacitorBankPartsNotApplied':True,'allBoardPassiveApplicationPASS':False},
 'assemblyReference':'z=0 is the existing violin BACK mounting plane; module controls face outward, not toward the bridge/string front.',
 'assemblyHolds':['Main72x39x1, existingcup76x43x18/oldcavity78x47x22, cover148x49, no new cavity; total thickness<=25 and external<=5mm except rollers still need full 3D/sample proof.',
   '5mm upper cover plus <=6mm screw does not prove wood engagement. Recessed seats/head/flange/washer/wood thickness/pilot/torque/pullout remain HOLD.',
   'J501 is a 1.25mm Molex PicoBlade library proposal, not a demonstrated 2A pack interface. Manufacturer land/current/derating and pack operation limit still need closure.',
   'Engineering CAM on two subsidiary boards cannot be interpreted as complete SmartVio assembly release.'],
 'historicalPowerPrototype':'Retained V25 82-part power prototype and its old 0/0 DRC/CAM are historical only, not current V26 power-domain/NTC/passive parity. Excluded from selected current CAM.',
 'productionApproved':False,'writeFreezeAfterDelivery':True}
for target in [VERIFY/'final-summary.json',OUT/'final-summary.json',OUT/'v26-final-summary.json']:
    target.write_text(json.dumps(summary,indent=2)+'\n')
progress={'generatedUTC':summary['generatedUTC'],'status':'FROZEN_FINAL_REVIEW_HOLD','sourceSHA256':sourcehash,'routersStatus':'STOPPED',
 'finalSummaryPath':str((VERIFY/'final-summary.json').resolve()),'boards':[{'kind':b['kind'],'boardPath':b['boardPath'],'boardSHA256':b['boardSHA256'],
 'errors':b['drc']['errors'],'warnings':b['drc']['warnings'],'unconnected':b['unconnected'],'ignoredChecks':[],'productionApproved':False} for b in boards]}
(OUT/'board-progress.json').write_text(json.dumps(progress,indent=2));(WORK/'delivery-final-state.json').write_text(json.dumps(progress,indent=2))
readme=['# V26 Final PCB Review Snapshot','', 'ENGINEERING HOLD. productionApproved=false. No complete-product or assembly release.','',
 'Current source SHA256: `'+sourcehash+'`','', '| Board | Errors | Warnings | Unconnected | Selected CAM |','|---|---:|---:|---:|---|']
for b in boards:readme.append('| '+b['kind']+' | '+str(b['drc']['errors'])+' | '+str(b['drc']['warnings'])+' | '+str(b['unconnected'])+' | '+('Engineering review only' if b['CAM'] else 'NONE / BLOCKED')+' |')
readme+=['','Counts separate geometric violations from unconnected errors. All five requested categories are warning; ignored_checks=[] and no item exclusions on every selected board.',
 '','## Selected Files','', 'Only `SmartVio-{main,usb,audio,cover,sensor}-v26-final.kicad_pcb/.kicad_pro/.kicad_dru` are current selected review boards. Previous variants are historical, not alternative release files.',
 '','Machine-readable index: `verification/final-summary.json`; identical alias: `v26-final-summary.json`. Board/project/rule hashes and exact source/parity/CAM paths are in that index.',
 '','Current CAM only: `cam-review-v26-current/cover/CAM-manifest.json` and `cam-review-v26-current/sensor/CAM-manifest.json`. Each contains Gerbers, Excellon PTH/NPTH drill/maps, F.Paste/B.Paste and native/manual-filtered positions from the same hashed final board. Empty paste layers may be normal. Do NOT package inherited `engineering-export` or historical power CAM as current V26.',
 '','## Integration','',
 '1. Sync all current source refs from `footprint-map.json` into capture Footprint fields; IDs resolve through this `fp-lib-table` and the two parent audit libraries. Do not assign a PCB footprint to battery-bonded external RT1921. Candidate H_* harnesses are separate fabricated copper features, not original capture purchased parts.',
 '2. Regenerate native capture/export and strict ERC. This worker verified actual current JSON/XML pin-net parity and five-board pad/value/MPN/pin identity parity; native schematic footprint/filter metadata parity remains pending that parent regeneration.',
 '3. Repack main using actual manufacturer lands and the exact 19 courtyard pairs/bboxes in `verification/main-placement-technical-blocks.json`; remove intersecting old copper. Do not shrink pads or relax clearances. Place critical decouplers/loops and thermal paths before renewed routing.',
 '4. Close the remaining audio GND returns and USB VBUS copper break before CAM. B2 is physically laser-via escaped, not ignored. Process assumptions and explicit scoped rules are recorded, but SI/ampacity/ESD/fab qualification remains HOLD.',
 '5. New DSN must be exported from the new real seed and locked contract. Import SES only against unchanged pad inventory/DSN/input hashes, then refill and run full strict DRC plus source parity. Prior contract hashes remain unchanged; no 315 SES was produced.',
 '','## Technical Limits','',
 'V25 219 unconnected /127 warnings /0 geometry errors was an older 292-source snapshot with five categories ignored. Current V26 has306 unconnected /143 warnings /268 geometry errors after actual power-domain/independent-NTC/selection/passive lands. This is NOT main closure. Real larger pads/connector nails intersect retained old routes; exact source parity alone does not prove connected copper.',
 '','Current placement is invalid, but all possible 72x39 placements have not been proved impossible. Front y>=24.5 is reserved for the audio board/tails. Exact capacitor/connector growth, backside height and return corridors require re-layout plus full 3D stack.',
 '','TVS actual numeric land and B2 escape evidence: `verification/tvs-final-numeric-landcheck.json`, `verification/usb-final-b2-microvia-evidence.json`. All seven TI lands are .3x.5mm, centers+/- .35mm, mask .07mm, corners .05mm; protection application/routing remains HOLD.',
 '','74 effective capacitance bounds are not guaranteed;10refs require banks not integrated. The30 new bank parts were not silently added. Main high-current rails/loops are not qualified by .15/.2mm autoroutes. PicoBlade is not a proved2A interface.',
 '','z=0 is the existing violin BACK mounting plane. Recessed fastener seats/effective wood engagement/wood thickness/torque and complete envelope remain HOLD.',
 '','All task-owned routers stopped. No ongoing router result is promised. Worker stops writing after final delivery.']
(OUT/'V26-FINAL-REVIEW.md').write_text('\n'.join(readme)+'\n')
print(json.dumps({'sourceSHA256':sourcehash,'boards':progress['boards'],'summary':str((VERIFY/'final-summary.json').resolve()),'CAMIndex':str(camidxpath.resolve()),'productionApproved':False},indent=2))
