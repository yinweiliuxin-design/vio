"""One bounded task-owned native DSN route, with persistent logs and explicit process cleanup."""
import argparse
import subprocess
import time
from main_ast import *
ap=argparse.ArgumentParser();ap.add_argument('dsn',type=Path);ap.add_argument('--seconds',type=int,default=180);ap.add_argument('--passes',type=int,default=1);ap.add_argument('--fanout-passes',type=int,default=1);a=ap.parse_args()
dsn=a.dsn.resolve();assert dsn.is_relative_to(DEST.resolve());ses=dsn.with_suffix('.ses');log=dsn.with_suffix('.router.log')
java=WORK/'java25/jdk-25.0.4.1+1-jre/bin/java.exe'
cmd=[str(java),'-Xmx6g','-Djava.awt.headless=true','-Duser.home='+str(WORK/'router-home'),'-jar',str(WORK/'freerouting-2.4.1.jar'),
 '--gui.enabled=false','--api_server.enabled=false','--mcp_server.enabled=false','--router.fanout.max_passes='+str(a.fanout_passes),
 '--user_data_path='+str(WORK/'router-data'),'--router.job_timeout=00:'+str(max(1,(a.seconds-20)//60)).zfill(2)+':'+str(max(1,a.seconds-20)%60).zfill(2),'--router.automatic_neckdown=false',
 '--router.neck_width_um=150','--router.strict_drc=true','-da','-l','en','-de',str(dsn),'-do',str(ses),'-mp',str(a.passes),'-mt','1']
start=time.monotonic();timedout=False
with log.open('w',encoding='utf-8') as stream:
    proc=subprocess.Popen(cmd,cwd=WORK,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    print(json.dumps({'pid':proc.pid,'dsn':str(dsn),'deadlineSeconds':a.seconds,'log':str(log)}),flush=True)
    try:
        while proc.poll() is None:
            if time.monotonic()-start>a.seconds:timedout=True;proc.terminate();break
            time.sleep(1)
        try:proc.wait(timeout=5)
        except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)
    finally:
        if proc.poll() is None:proc.kill();proc.wait(timeout=5)
record={'dsnPath':str(dsn),'dsnSHA256':sha(dsn),'sesPath':str(ses) if ses.exists() else None,'sesSHA256':sha(ses) if ses.exists() else None,
 'logPath':str(log),'logSHA256':sha(log),'pid':proc.pid,'returnCode':proc.returncode,'seconds':time.monotonic()-start,'boundedTimeout':timedout,'processStopped':True}
dsn.with_suffix('.job.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2));print('\n'.join(log.read_text().splitlines()[-12:]))
