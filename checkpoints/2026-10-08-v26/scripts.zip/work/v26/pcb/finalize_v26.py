"""Bounded current-source geometry snapshot, no source graph edits or CAM claims."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import argparse
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
source=OUT.parent/'electrical/native-components.json';sourcebytes=source.read_bytes()
parts={c['ref']:c for c in json.loads(sourcebytes.decode('utf-8-sig'))}
capslib=OUT.parent/'audit/passive-closure/Passive_V26_ManufacturerLand.pretty'
sellib=OUT.parent/'audit/selection/SmartVio_V26_Selection.pretty'
mpnindex=json.loads((capslib.parent/'footprint-index.json').read_text())['source']
mapping=json.loads((OUT/'footprint-map.json').read_text())
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
boards={'main':'SmartVio-main-v26-315-seeded.kicad_pcb','usb':'SmartVio-usb-v26-repaired.kicad_pcb',
        'audio':'SmartVio-audio-v26-selection.kicad_pcb','cover':'SmartVio-cover-v26-selection.kicad_pcb',
        'sensor':'SmartVio-sensor-delivery-HOLD.kicad_pcb'}
records=[]
ap=argparse.ArgumentParser();ap.add_argument('--kind',choices=tuple(boards),required=True);a=ap.parse_args()
table=OUT/'fp-lib-table';txt=table.read_text();idx=txt.rfind(')')
if 'name "Passive_V26_ManufacturerLand"' not in txt:
    txt=txt[:idx]+' (lib (name "Passive_V26_ManufacturerLand") (type "KiCad") (uri "${KIPRJMOD}/../audit/passive-closure/Passive_V26_ManufacturerLand.pretty") (options "") (descr "Selected manufacturer lands; effective-capacitance gates remain"))\n'+txt[idx:];table.write_text(txt)
for kind,filename in boards.items():
    if kind!=a.kind:continue
    src=OUT/filename
    if not src.exists() and kind=='sensor':src=OUT/'SmartVio-sensor-final-HOLD.kicad_pcb'
    dst=OUT/('SmartVio-'+kind+'-v26-final-input.kicad_pcb');b=p.LoadBoard(str(src));changes=[];held=[]
    if kind=='main':
        ref='R826';c=parts[ref];f=p.FootprintLoad(str(OUT/'SmartVioV25.pretty'),'R_0603_1608Metric')
        f.SetFPID(p.LIB_ID('SmartVioV25','R_0603_1608Metric'));f.SetReference(ref);b.Add(f);f.Flip(pt(0,0),False)
        f.SetPosition(pt(67,36));f.SetOrientationDegrees(0)
        mapping[ref]={'id':'SmartVioV25:R_0603_1608Metric','board':'main','pinAliases':{},'heightMaxMm':.55,
                      'review':'Authorized R826 SYS to PWR_PB 10k added; board continuity review required','release':'HOLD'}
        for d in f.Pads():
            pin=next(pin for pin in c['pins'] if pin['number']==d.GetNumber());d.SetNet(b.FindNet(pin['net']))
        changes.append({'ref':ref,'op':'add','xyMm':[67,36],'side':'B'})
    if kind=='usb':
        for t in list(b.GetTracks()):
            if t.GetNetname() in ('USB_DP_CMC','USB_DM_CMC','USB_DP_OVP_IN','USB_DM_OVP_IN'):
                held.append(t);b.Remove(t)
    for old in list(b.GetFootprints()):
        ref=old.GetReference()
        if ref not in parts:continue
        c=parts[ref];name=(c.get('mpn') or '').replace('.','_').replace('/','_')
        selectedlib=capslib;nick='Passive_V26_ManufacturerLand'
        if ref=='J501':
            name='Molex_PicoBlade_53261-0371_1x03-1MP_P1.25mm_Horizontal';selectedlib=sellib;nick='SmartVio_V26_Selection'
        file=selectedlib/(name+'.kicad_mod')
        if file.exists():
            f=p.FootprintLoad(str(selectedlib),name);f.SetFPID(p.LIB_ID(nick,name));f.SetReference(ref)
            position=p.VECTOR2I(old.GetPosition());f.SetPosition(position);b.Add(f)
            if old.IsFlipped():f.Flip(position,False)
            f.SetOrientation(old.GetOrientation())
            expected={mapping.get(ref,{}).get('pinAliases',{}).get(pin['number'],pin['number']):pin for pin in c['pins']}
            assert {d.GetNumber() for d in f.Pads() if d.GetNumber()}==set(expected),(ref,file)
            for d in f.Pads():
                if d.GetNumber() not in expected:continue
                pin=expected[d.GetNumber()];d.SetNet(b.FindNet(pin['net']) if pin['net'] else b.FindNet(0));d.SetPinFunction(pin.get('nativeName',pin['name']))
            mapping[ref]['id']=nick+':'+name;mapping[ref]['geometryChangeApplied']=True
            mapping[ref]['manufacturerLandPatternApproved']=ref!='J501'
            mapping[ref]['physicalFitApproved']=False
            if c.get('mpn') in mpnindex:mapping[ref]['heightMaxMm']=mpnindex[c['mpn']]['body_lwh_max_mm'][2]
            changes.append({'ref':ref,'op':'manufacturer-land-replace','before':str(old.GetFPID().GetUniStringLibId()),
                            'after':nick+':'+name,'sourceFileSHA256':hashlib.sha256(file.read_bytes()).hexdigest()})
            b.Remove(old)
        else:f=old
        f.SetValue(c['value']);f.SetField('MPN',c.get('mpn') or '');f.GetField('MPN').SetVisible(False)
        f.Reference().SetVisible(False);f.Value().SetVisible(False)
        aliases=mapping.get(ref,{}).get('pinAliases',{})
        desired={aliases.get(pin['number'],pin['number']):pin for pin in c['pins']}
        for d in f.Pads():
            if d.GetNumber() in desired:
                pin=desired[d.GetNumber()];d.SetPinFunction(pin.get('nativeName',pin['name']))
        if kind=='usb' and ref in ('L1501','L1502'):
            position=pt(16,7.85 if ref=='L1501' else 9.55)
            if f.IsFlipped():f.Flip(f.GetPosition(),False)
            f.SetPosition(position);f.SetOrientationDegrees(0)
            changes.append({'ref':ref,'op':'move-short-paired-inductor-area','side':'F','xyMm':[16,7.85 if ref=='L1501' else 9.55]})
    for suffix in ('.kicad_pro','.kicad_dru'):
        if src.with_suffix(suffix).exists():shutil.copyfile(src.with_suffix(suffix),dst.with_suffix(suffix))
    if kind=='audio':
        dst.with_suffix('.kicad_dru').write_text('''(version 1)
(rule "Kycon recommended cutout land local edge budget"
  (condition "A.Type == 'Pad' && (A.memberOfFootprint('J102') || A.memberOfFootprint('J201') || A.memberOfFootprint('J202') || A.memberOfFootprint('J301'))")
  (constraint edge_clearance (min 0.300mm)))
''')
    b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(dst),b)
    drc=OUT/'verification'/('v26-'+kind+'-final-input-drc.json')
    run=subprocess.run([str(ROOT/'work/v24/tools/kicad/bin/kicad-cli.exe'),'pcb','drc','--format','json','-o',str(drc),str(dst)],capture_output=True,text=True)
    assert drc.exists(),run.stdout+run.stderr
    d=json.loads(drc.read_text())
    record={'kind':kind,'input':str(src),'board':str(dst),'sourceSHA256':hashlib.sha256(sourcebytes).hexdigest(),
            'changes':changes,'errors':sum(q['severity']=='error' for q in d['violations']),
            'warnings':sum(q['severity']=='warning' for q in d['violations']),'unconnected':len(d['unconnected_items']),
            'productionApproved':False,'actualCurrentSource':True}
    records.append(record)
(OUT/'footprint-map.json').write_text(json.dumps(mapping,indent=2))
table=OUT/'fp-lib-table';txt=table.read_text();idx=txt.rfind(')')
if 'name "Passive_V26_ManufacturerLand"' not in txt:
    txt=txt[:idx]+' (lib (name "Passive_V26_ManufacturerLand") (type "KiCad") (uri "${KIPRJMOD}/../audit/passive-closure/Passive_V26_ManufacturerLand.pretty") (options "") (descr "Selected manufacturer lands; effective-capacitance gates remain"))\n'+txt[idx:];table.write_text(txt)
(OUT/'verification'/('v26-final-input-'+a.kind+'.json')).write_text(json.dumps(records[0],indent=2))
assert hashlib.sha256(source.read_bytes()).hexdigest()==hashlib.sha256(sourcebytes).hexdigest(),'Source changed during snapshot; rerun after parent freeze'
print(json.dumps([{k:q[k] for k in ('kind','board','sourceSHA256','errors','warnings','unconnected')} for q in records],indent=2))
