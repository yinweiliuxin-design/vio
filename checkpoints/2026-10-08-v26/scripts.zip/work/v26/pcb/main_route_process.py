"""Apply an explicit advanced mechanical via capability to a new route candidate."""
import hashlib
import json
import os
from pathlib import Path
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
src=OUT/'SmartVio-main-v26-315-seeded.kicad_pcb'
dst=OUT/'SmartVio-main-v26-315-route-input.kicad_pcb'
b=p.LoadBoard(str(src));ds=b.GetDesignSettings()
ds.m_ViasMinSize=p.FromMM(.35);ds.m_MinThroughDrill=p.FromMM(.15)
nc=ds.m_NetSettings.GetDefaultNetclass()
nc.SetTrackWidth(p.FromMM(.15));nc.SetViaDiameter(p.FromMM(.35));nc.SetViaDrill(p.FromMM(.15))
config=json.loads(src.with_suffix('.kicad_pro').read_text())
rules=config['board']['design_settings']['rules']
rules.update({'min_via_diameter':.35,'min_through_hole_diameter':.15})
config['net_settings']['classes'][0].update({'track_width':.15,'via_diameter':.35,'via_drill':.15})
dst.with_suffix('.kicad_pro').write_text(json.dumps(config,indent=2))
p.SaveBoard(str(dst),b)
record={'board':str(dst),'sourceSHA256':hashlib.sha256((OUT.parent/'electrical/native-components.json').read_bytes()).hexdigest(),
 'inputSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'process':'4 layers 1mm, advanced mechanical .15mm drill / .35mm copper via',
 'processSource':'https://www.pcbway.com/hdi-pcb.html','aspectRatio':1/.15,'publishedMaximumAspectRatio':14,
 'clearanceMmUnchanged':.15,'minTraceWidthMmUnchanged':.15,'annularRingMm':.1,
 'holeToForeignCopperMmUnchanged':.25,'holeToHoleMmUnchanged':.25,
 'retainedExistingLargeVias':True,'powerViaCurrentCapacityNotQualified':True,
 'planesStrategy':'DSN excludes solid GND plane outlines to allow 4-layer continuation. Native In1/In2 GND zones are preserved and refilled after import. Plane continuity/reference return review required.',
 'candidateOnly':True,'productionApproved':False}
(OUT/'verification/main-v26-advanced-process.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
