"""Move one identified via and its attached track endpoints, retaining all net assignments."""
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
src=OUT/'SmartVio-usb-v26-closed.kicad_pcb';dst=OUT/'SmartVio-usb-v26-repair-input.kicad_pcb'
b=p.LoadBoard(str(src));via=next(t for t in b.GetTracks() if str(t.m_Uuid.AsString())=='c102871b-7e2f-4078-becf-35db269d1c15')
old=via.GetPosition();new=p.VECTOR2I(p.FromMM(7.45),p.FromMM(11.05))
for t in b.GetTracks():
    if t.GetNetname()!=via.GetNetname() or isinstance(t,p.PCB_VIA):continue
    if t.GetStart()==old:t.SetStart(new)
    if t.GetEnd()==old:t.SetEnd(new)
via.SetPosition(new);p.SaveBoard(str(dst),b)
for ext in ['.kicad_pro','.kicad_dru']:
    if src.with_suffix(ext).exists():shutil.copyfile(src.with_suffix(ext),dst.with_suffix(ext))
print('Via and attached endpoints moved +0.05,+0.05 mm; native DRC required')
