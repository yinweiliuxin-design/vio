"""Export review-only CAM after native geometry/connectivity gate, never release."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2];OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser()
ap.add_argument('--board',type=Path,required=True);ap.add_argument('--drc',type=Path,required=True)
ap.add_argument('--output-dir',type=Path,required=True)
ap.add_argument('--kind',choices=['cover','sensor','usb','audio'],required=True)
a=ap.parse_args();assert a.output_dir.resolve().is_relative_to(OUT.resolve())
a.output_dir.mkdir(parents=True,exist_ok=True)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
drc=json.loads(a.drc.read_text());assert not drc['ignored_checks'],'No ignored DRC categories allowed for selected CAM'
assert not drc['violations'] and not drc['unconnected_items'],'CAM gate requires zero native violations and unconnected items'
assert drc['source']==a.board.name
parity=json.loads((OUT/'verification/current-native-parity.json').read_text())
verified=next(q for q in parity['boards'] if q['kind']==a.kind)
assert verified['boardSHA256']==sha(a.board)
assert all(not verified[k] for k in ['pinNetDifferences','candidateHarnessDifferences','valueDifferences','mpnDifferences','padSetDifferences','pinFunctionDifferences'])
b=p.LoadBoard(str(a.board.resolve()));before=sha(a.board)
cli=ROOT/'work/v24/tools/kicad/bin/kicad-cli.exe'
def run(*args):
    q=subprocess.run([str(cli),*map(str,args)],capture_output=True,text=True)
    assert q.returncode==0,q.stdout+q.stderr
    print(q.stdout,flush=True)
layers=['F.Cu']+(['In1.Cu','In2.Cu'] if b.GetCopperLayerCount()==4 else [])+['B.Cu','F.Paste','B.Paste','F.Mask','B.Mask','F.Silkscreen','B.Silkscreen','Edge.Cuts']
run('pcb','export','gerbers','--layers',','.join(layers),'--exclude-refdes','--exclude-value','--check-zones','--output',a.output_dir,a.board)
run('pcb','export','drill','--output',a.output_dir,'--excellon-units','mm','--excellon-separate-th','--generate-map','--map-format','gerberx2','--generate-report','--report-path',a.output_dir/'drill-report.txt',a.board)
pos=a.output_dir/'positions-native-all.csv'
run('pcb','export','pos','--format','csv','--units','mm','--side','both','--output',pos,a.board)
for side in ['F','B']:
    mirror=['--mirror'] if side=='B' else []
    run('pcb','export','svg','--layers',f'{side}.Fab,{side}.Silkscreen,Edge.Cuts',
        '--sketch-pads-on-fab-layers','--mode-single','--fit-page-to-board',
        '--exclude-drawing-sheet',*mirror,'--output',a.output_dir/f'assembly-{side}-review.svg',a.board)
rows=list(csv.DictReader(pos.open(newline='',encoding='utf-8-sig')))
manual={f.GetReference() for f in b.GetFootprints() if 'WirePads' in str(f.GetFPID().GetUniStringLibId()) or f.GetReference()=='LS901'}
assembly=[r for r in rows if r['Ref'] not in manual]
with (a.output_dir/'positions-assembly-candidates.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(assembly)
placement_classes={}
parts=[]
for fp in b.GetFootprints():
    ref=fp.GetReference()
    smd=any(pad.GetAttribute()==p.PAD_ATTRIB_SMD for pad in fp.Pads())
    pth=any(pad.GetAttribute()==p.PAD_ATTRIB_PTH for pad in fp.Pads())
    category=('MANUAL_ENDPOINT_OR_SPRING_CONTACT' if ref in manual else
              'SMT_WITH_PTH_MECHANICAL' if smd and pth else 'SMT_CANDIDATE' if smd else 'THROUGH_HOLE_CANDIDATE')
    placement_classes[ref]=category
    try:mpn=fp.GetFieldText('MPN')
    except KeyError:mpn=None
    parts.append({'ref':ref,'value':fp.GetValue(),'mpn':mpn or None,'footprint':str(fp.GetFPID().GetUniStringLibId()),
                  'assemblyClass':category,'purchaseItem':ref not in manual,'processApproved':False})
for filename,allowed in [('positions-smt-candidates.csv',{'SMT_CANDIDATE','SMT_WITH_PTH_MECHANICAL'}),
                         ('positions-through-hole-candidates.csv',{'THROUGH_HOLE_CANDIDATE'})]:
    with (a.output_dir/filename).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader()
        w.writerows(r for r in rows if placement_classes[r['Ref']] in allowed)
(a.output_dir/'board-assembly-BOM.json').write_text(json.dumps({'boardSHA256':before,'sourceSHA256':parity['sourceSHA256'],
    'components':parts,'note':'Actual saved board BOM, separated SMT/PTH/manual. This does not qualify solder process or approve ordering.',
    'productionApproved':False},indent=2))
specific=('Separate control-cover PCB only, NOT the complete SmartVio product.\n'
    'Uses actual Alps switch/roller lands and cutouts, LED polarity and speaker reference spring contacts.\n'
    'Speaker tracks SPK_P/SPK_N are 0.6mm; pressure/polarity/contact fixture, acoustics and cable qualification remain HOLD.\n'
    '0.4mm board stiffness, roller/button support/preload, 148x49 envelope, wood fasteners and complete assembly stack remain HOLD.\n'
    'Internal solder endpoints and LS901 spring-contact assembly are manual operations, not automatic placements.\n') if a.kind=='cover' else (
    'Separate temperature sensor board only, NOT the complete SmartVio product.\n'
    'Sensor accuracy, thermal coupling, cable/connector termination and final assembly remain HOLD.\n'
    'J1802 is a manual solder endpoint, not a selected catalog connector or placement component.\n')
if a.kind == 'usb':
    specific = ('Separate USB interface board only, NOT the complete SmartVio product.\n'
        'Four layers; U1401 center B2 GND uses F.Cu-to-In1.Cu laser microvia.\n'
        'Requires filled/capped via-in-pad HDI DFM; do not substitute a through via.\n'
        'Impedance, ESD/transient coordination, assembly yield and electrical testing remain HOLD.\n')
elif a.kind == 'audio':
    specific = ('Separate four-jack audio interface board only, NOT the complete SmartVio product.\n'
        'Kycon STX-353K7A-6N-KTTR six plated slots and mandatory body cutouts are present.\n'
        'Jack insertion face is normal to this PCB; board placement must follow mechanical assembly drawing.\n'
        'TRS/TS contact compatibility, detection, current rating, plugging forces and support remain HOLD.\n'
        'Position rows include through-hole jack candidates; do not treat all entries as SMT placements.\n')
specific += ('Assembly-F is viewed from top; Assembly-B is mirrored and viewed from bottom. '
    'These are native land/body/polarity review plots, not approved assembly instructions. '
    'Match reference, pin1, CPL origin/rotation and manufacturer orientation before programming placement.\n')
(a.output_dir/'HOLD.txt').write_text('ENGINEERING REVIEW EXPORT ONLY. productionApproved=false.\n'
    'Do not order production or claim product release. Native DRC/parity do not approve the circuit or assembly.\n'
    +specific+
    'B.Paste may be empty when no bottom SMD parts exist. No electrical, mechanical or production approval.\n')
jobfiles=list(a.output_dir.glob('*.gbrjob'))
assert len(jobfiles)==1
job=json.loads(jobfiles[0].read_text())
gerbers=[a.output_dir/f['Path'] for f in job['FilesAttributes']]
assert len(gerbers)==len(layers), 'Gerber job must include all layers'
for f in gerbers:
    text=f.read_text();assert '%FSL' in text and '%MOMM*%' in text and 'M02*' in text
assert len(list(a.output_dir.glob('*_Paste.g?*')))==2
assert list(a.output_dir.glob('*.drl'))
assert sha(a.board)==before,'CAM export mutated the native board'
files=[{'path':str(f.resolve()),'relativePackPath':f.resolve().relative_to(OUT.parent.resolve()).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(a.output_dir.glob('*')) if f.is_file() and f.name!='CAM-manifest.json']
record={'productionApproved':False,'status':'ENGINEERING_HOLD_REVIEW_EXPORT',
    'kind':a.kind,'sourceSHA256':parity['sourceSHA256'],'boardPath':str(a.board.resolve()),'boardRelativePackPath':a.board.resolve().relative_to(OUT.parent.resolve()).as_posix(),
    'boardSHA256':before,'nativeDRCPath':str(a.drc.resolve()),'nativeDRCSHA256':sha(a.drc),
    'parityPath':str((OUT/'verification/current-native-parity.json').resolve()),'paritySHA256':sha(OUT/'verification/current-native-parity.json'),
    'layers':layers,'nativePositionRows':len(rows),'assemblyCandidatePositionRows':len(assembly),'manualTerminalRefs':sorted(manual),
    'gerberLayerFilesValidated':len(gerbers),'ignoredChecks':drc['ignored_checks'],
    'vias':sum(isinstance(t,p.PCB_VIA) for t in b.GetTracks()),'CAM':files,
    'blockingApproval':specific}
(a.output_dir/'CAM-manifest.json').write_text(json.dumps(record,indent=2))
print(json.dumps({'files':len(files),'positionRows':len(rows),'assemblyRows':len(assembly),'productionApproved':False}))
