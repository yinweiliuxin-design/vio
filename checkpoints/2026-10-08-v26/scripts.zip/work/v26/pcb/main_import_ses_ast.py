"""Import verified Freerouting session copper by explicit net name, preserving native placement/pads."""
import argparse
import copy
import re
import shutil
import uuid as uuidlib
from main_ast import *
from specctra import loads as dloads,child as dchild
ap=argparse.ArgumentParser();ap.add_argument('dsn',type=Path);ap.add_argument('--output-name',default='SmartVio-main-v26-routed-clean');a=ap.parse_args()
dsn=a.dsn;contract=json.loads(dsn.with_suffix('.contract.json').read_text());src=Path(contract['boardPath']);ses=dsn.with_suffix('.ses')
assert sha(src)==contract['boardSHA256'] and sha(dsn)==contract['dsnSHA256']
assert ses.exists();original=read(src);tree=copy.deepcopy(original)
old_copper=[q for q in tree if key(q) in ['segment','arc','via']]
tree=[q for q in tree if key(q) not in ['segment','arc','via']]
non_copper=copy.deepcopy(tree)
session=dloads(ses.read_text().replace('(string_quote ")','(string_quote __QUOTE__)'))
routes=dchild(session,'routes');resolution=dchild(routes,'resolution');assert resolution[1]=='um';scale=1000*float(resolution[2])
netnames={child(p,'net')[1] for fp in kids(tree,'footprint') for p in kids(fp,'pad') if child(p,'net')}
copper_layers=[q[1] for q in child(tree,'layers')[1:] if q[1].endswith('.Cu')]
assert copper_layers[0]=='F.Cu' and copper_layers[-1]=='B.Cu'
library=dchild(routes,'library_out');stacks={q[1].strip('"'):q for q in library if isinstance(q,list) and q[0]=='padstack'}
added=[]
for net in dchild(routes,'network_out'):
    if not isinstance(net,list) or net[0]!='net':continue
    name=net[1].strip('"');assert name in netnames,name
    for item in net[2:]:
        if item[0]=='wire':
            path=dchild(item,'path');layer=path[1].strip('"');width=float(path[2])/scale
            coords=[float(v)/scale for v in path[3:]];assert len(coords)%2==0
            points=[[round(coords[i],6),round(-coords[i+1],6)] for i in range(0,len(coords),2)]
            for u,v in zip(points,points[1:]):
                if u==v:continue
                added.append([S('segment'),[S('start'),*u],[S('end'),*v],[S('width'),width],
                              [S('layer'),layer],[S('net'),name],[S('uuid'),str(uuidlib.uuid4())]])
        elif item[0]=='via':
            ident=item[1].strip('"');match=re.fullmatch(r'Via\[(\d+)-(\d+)\]_(\d+):(\d+)_um',ident)
            assert match,('Unsupported via identifier, require explicit library interpretation',ident)
            lo,hi,diameter,drill=map(int,match.groups());assert (lo,hi)==(0,len(copper_layers)-1)
            stack=stacks[ident];circles=[dchild(q,'circle') for q in stack if isinstance(q,list) and q[0]=='shape']
            assert all(abs(float(q[2])/scale-diameter/1000)<1e-6 for q in circles)
            added.append([S('via'),[S('at'),round(float(item[2])/scale,6),round(-float(item[3])/scale,6)],
                          [S('size'),diameter/1000],[S('drill'),drill/1000],[S('layers'),'F.Cu','B.Cu'],
                          [S('net'),name],[S('uuid'),str(uuidlib.uuid4())]])
        else:raise RuntimeError(('Unexpected SES copper record',item[0]))
tree.extend(added);dst=DEST/(a.output_name+'.kicad_pcb');write(dst,tree)
assert tree[:-len(added)]==non_copper
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(src.with_suffix(ext),dst.with_suffix(ext))
dsn_counts={n:sum(child(q,'net')[1]==n for q in added) for n in sorted({child(q,'net')[1] for q in added})}
record={'boardPath':str(dst),'boardSHA256':sha(dst),'sourceSHA256':contract['sourceSHA256'],'routeContractSHA256':sha(dsn.with_suffix('.contract.json')),
 'sesSHA256':sha(ses),'tracks':sum(key(q)=='segment' for q in added),'vias':sum(key(q)=='via' for q in added),'copperItemsByNet':dsn_counts,
 'originalPlacementPadASTPreserved':True,'replacedSeedCopperItems':len(old_copper),'netGeometryPreservation':'Direct SES net-name import; original non-copper board expressions unchanged. Native fill and DRC still required.',
 'productionApproved':False}
dst.with_suffix('.import.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='copperItemsByNet'},indent=2))
