"""Deterministic staggered BQ24074 escapes using the unchanged .15/.6/.3 rules."""
import json
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'documents')
os.environ['DOCUMENTS_HOME']=str(WORK/'documents')
import pcbnew as p
src=OUT/'SmartVio-power-prototype-open-fanout.kicad_pcb'
dst=OUT/'SmartVio-power-prototype-charger-seeded.kicad_pcb'
b=p.LoadBoard(str(src))
f=next(f for f in b.GetFootprints() if f.GetReference()=='U501')
pads={d.GetNumber():d for d in f.Pads()}
point=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
record=[]
routes={'1':[(15.6,8.25),(14,8.25)],'2':[(15.6,8.75),(15,8.75),(14.75,9),(14.5,9)],
        '3':[(15.6,9.25),(15,9.25),(14.75,9),(14.5,9)],'4':[(15.6,9.75),(13.2,9.75)],
        '5':[(16.25,10.4),(16.25,11),(15.85,11.4),(15.85,11.8)],
        '6':[(16.75,10.4),(16.75,13)],
        '7':[(17.25,10.4),(17.25,11),(18.15,11.9),(18.15,12)],
        '8':[(17.75,10.4),(17.75,9.5),(17,9.5),(17,9)],
        '9':[(18.4,9.75),(20.8,9.75)],
        '10':[(18.4,9.25),(19,9.25),(19.25,9),(19.5,9)],
        '11':[(18.4,8.75),(19,8.75),(19.25,9),(19.5,9)],
        '12':[(18.4,8.25),(20,8.25)],'13':[(17.75,7.6),(17.75,6)],
        '16':[(16.25,7.6),(16.25,6)],'17':[(17,9)]}
vias={}
for num,points in routes.items():
    pad=pads[num];net=pad.GetNetname();netcode=pad.GetNetCode()
    assert pad.GetPosition()==point(*points[0])
    for a,z in zip(points,points[1:]):
        t=p.PCB_TRACK(b);t.SetStart(point(*a));t.SetEnd(point(*z));t.SetWidth(p.FromMM(.2 if num in ('2','3','10','11','13','8') else .15));t.SetLayer(p.F_Cu);t.SetNetCode(netcode);b.Add(t)
    loc=points[-1]
    if loc not in vias:
        v=p.PCB_VIA(b);v.SetPosition(point(*loc));v.SetWidth(p.FromMM(.6));v.SetDrill(p.FromMM(.3));v.SetLayerPair(p.F_Cu,p.B_Cu);v.SetViaType(p.VIATYPE_THROUGH);v.SetNetCode(netcode);b.Add(v);vias[loc]=net
    else:assert vias[loc]==net
    record.append({'pin':num,'net':net,'pointsMm':points})
p.SaveBoard(str(dst),b)
shutil.copyfile(src.with_suffix('.kicad_pro'),dst.with_suffix('.kicad_pro'))
(OUT/'verification/charger-fanout.json').write_text(json.dumps({'source':str(src),'board':str(dst),'fanout':record,'thermalViaAssembly':'HOLD_SOLDER_WICKING_AND_PASTE_REVIEW','drc':'REQUIRED'},indent=2))
print('Saved native staggered charger fanout; DRC required')
