"""Main-only proposed JST/SSR same-net ECO; keep all unaffected native copper expressions."""
import argparse
import copy
import os
import shutil
from main_ast import *
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);ap.add_argument('--name',required=True);ap.add_argument('--proposal',action='store_true');a=ap.parse_args()
revision=OUT.parent/'audit/selection/battery-revision';oldsource=json.loads((DEST/'source-587358f6.json').read_text(encoding='utf-8-sig'))
currentpath=OUT.parent/'electrical/native-components.json';current=json.loads(currentpath.read_text(encoding='utf-8-sig'));old={q['ref']:q for q in oldsource};new={q['ref']:q for q in current}
assert set(old)==set(new)
topology=lambda records:{(q['ref'],pin['number']):(pin['net'],pin.get('footprintPad') or pin['number']) for q in records for pin in q['pins']}
assert topology(oldsource)==topology(current),'Unexpected global pin/net change'
patch={q['ref']:q for q in json.loads((revision/'corrected-components.proposal.json').read_text())}
records=patch if a.proposal else new
assert records['J501']['mpn']=='S3B-PH-SM4-TB(LF)(SN)'
board=p.LoadBoard(str(a.board.resolve()));tree=read(a.board);baseline=copy.deepcopy(tree);native={f.GetReference():f for f in board.GetFootprints()}
temp=p.BOARD();netobjects={}
for name in sorted({d.GetNetname() for f in board.GetFootprints() for d in f.Pads()}):
    if name:
        obj=p.NETINFO_ITEM(temp,name);temp.Add(obj);netobjects[name]=obj
library=revision/'footprints/SmartVio_Battery_Revision.pretty';land=library/'JST_PH_S3B_PH_SM4_TB_OfficialLand_3P.kicad_mod'
placement={'J501':(65.775,19.275,0),'R1101':(59.3,15.65,90),'R1302':(64,25.25,0),'C1902':(58.6,25.05,0)}
changed=[]
for r in placement:
    if r=='J501':
        f=p.FootprintLoad(str(library),'JST_PH_S3B_PH_SM4_TB_OfficialLand_3P');assert f
        f.SetReference(r);f.SetValue(records[r]['value']);f.SetFPID(p.LIB_ID(*records[r]['footprint'].split(':',1)))
        temp.Add(f);f.Flip(p.VECTOR2I(0,0),p.FLIP_DIRECTION_LEFT_RIGHT)
    else:
        f=p.Cast_to_FOOTPRINT(native[r].Duplicate(False));temp.Add(f)
    x,y,angle=placement[r];f.SetPosition(p.VECTOR2I(p.FromMM(x),p.FromMM(y)));f.SetOrientationDegrees(angle)
    c=records[r] if r in records else new[r];pins={str(pin.get('footprintPad') or pin['number']):pin for pin in c['pins']}
    for d in f.Pads():
        pin=pins[d.GetNumber()];d.SetNet(netobjects[pin['net']] if pin['net'] else temp.FindNet(0));d.SetPinFunction(pin.get('nativeName',pin['name']));d.SetPinType(pin.get('electricalType','passive'))
    changed.append(f)
isolated=DEST/(a.name+'-isolated-footprint-transform.kicad_pcb');p.SaveBoard(str(isolated),temp)
converted={ref(f):f for f in kids(read(isolated),'footprint')};originalfps={ref(f):f for f in kids(tree,'footprint')}
for r,f in converted.items():
    c=records[r] if r in records else new[r]
    props={q[1]:q for q in kids(f,'property')}
    if r=='J501':
        mp=copy.deepcopy(next(q for q in kids(originalfps[r],'property') if q[1]=='MPN'));mp[2]=c['mpn'];f.append(mp)
        child(props['Reference'],'at')[1:3]=[0,0]
    child(f,'uuid')[1]=uuid(originalfps[r])
    tree[tree.index(originalfps[r])]=f
for r in ['K1201','K1202']:
    f=next(f for f in kids(tree,'footprint') if ref(f)==r);c=records[r]
    for q in kids(f,'property'):
        if q[1]=='Value':q[2]=c['value']
        if q[1]=='MPN':q[2]=c['mpn']
zero_ohm=[]
for f in kids(tree,'footprint'):
    if ref(f) in ['R403','R404','R601']:
        prop=next(q for q in kids(f,'property') if q[1]=='MPN');prop[2]='RC0603JR-070RL';zero_ohm.append(ref(f))

def box(fp):
    ls=p.LSET();ls.AddLayer(p.B_CrtYd if fp.IsFlipped() else p.F_CrtYd);q=fp.GetLayerBoundingBox(ls)
    return [p.ToMM(v) for v in [q.GetLeft(),q.GetTop(),q.GetRight(),q.GetBottom()]]
regions=[(f.GetLayer(),box(f)) for f in changed]+[(native[r].GetLayer(),box(native[r])) for r in placement]
removed=[]
for q in list(tree):
    if key(q) not in ['segment','via']:continue
    net=child(q,'net')[1];pts=[child(q,'at')[1:3]] if key(q)=='via' else [child(q,'start')[1:3],child(q,'end')[1:3]]
    bb=[min(z[0] for z in pts),min(z[1] for z in pts),max(z[0] for z in pts),max(z[1] for z in pts)]
    radius=(child(q,'size') if key(q)=='via' else child(q,'width'))[1]/2+.15
    hit=net in ['PACK_PLUS','PACK_NTC','BUCK_FB']
    for layer,bounds in regions:
        if key(q)!='via' and child(q,'layer')[1]!=p.LayerName(layer):continue
        if bb[0]-radius<bounds[2] and bb[2]+radius>bounds[0] and bb[1]-radius<bounds[3] and bb[3]+radius>bounds[1]:hit=True
    if hit:tree.remove(q);removed.append({'uuid':uuid(q),'net':net,'geometry':signature(q)})
dst=DEST/(a.name+'.kicad_pcb');write(dst,tree)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(a.board.with_suffix(ext),dst.with_suffix(ext))
table=read(DEST/'fp-lib-table')
if not any((child(q,'name') or [None,None])[1]=='SmartVio_Battery_Revision' for q in kids(table,'lib')):
    table.append([S('lib'),[S('name'),'SmartVio_Battery_Revision'],[S('type'),'KiCad'],[S('uri'),'${KIPRJMOD}/../../audit/selection/battery-revision/footprints/SmartVio_Battery_Revision.pretty'],[S('options'),''],[S('descr'),'Official JST manufacturer-land proposal']]);write(DEST/'fp-lib-table',table)
report={'input':str(a.board),'inputSHA256':sha(a.board),'output':str(dst),'outputSHA256':sha(dst),'routeBasisSourceSHA256':sha(DEST/'source-587358f6.json'),'currentSourceSHA256':sha(currentpath),
 'proposalOnlyNotGlobalSourceMerged':a.proposal,'currentAgainstOriginalTopologyDifferences':[],'landPath':str(land),'landSHA256':sha(land),'placement':placement,
 'removedCopper':removed,'zeroOhmMPNUpdatedOnThisBoard':zero_ohm,'scope':'Explicit same-net J501 manufacturer land replacement, K1201/2 and on-main zero-ohm MPN metadata, three local relocations, local copper rip-up for reroute. No selected board edits.',
 'heightAndMatingHold':'Back edge connector must be outside battery body projection; 5.5mm nominal height and mating/strain-relief volume require full stack clearance. No body/pad shrink.',
 'productionApproved':False,'nativeDRCRequired':True}
dst.with_suffix('.eco.json').write_text(json.dumps(report,indent=2));print(json.dumps({'output':str(dst),'removedCopper':len(removed),'proposal':a.proposal}))
