"""Publish only measured native progress and read-only selection status."""
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
path=OUT/'board-progress.json';record=json.loads(path.read_text())
source=OUT.parent/'electrical/native-components.json';parts=json.loads(source.read_text(encoding='utf-8-sig'))
record.update({'updatedUTC':datetime.now(timezone.utc).isoformat(),'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),
               'sourceComponents':len(parts),'sourcePins':sum(len(c['pins']) for c in parts)})
reports={'main':('SmartVio-main-v26-315-seeded.kicad_pcb','main-v26-315-seeded-drc.json'),
         'usb':('SmartVio-usb-v26-HDI-ground.kicad_pcb','usb-v26-HDI-ground-drc.json'),
         'power':('SmartVio-power-prototype-v26-HOLD.kicad_pcb','power-v26-drc.json')}
for kind,(board,drc) in reports.items():
    dp=OUT/'verification'/drc;bp=OUT/board
    if not dp.exists() or not bp.exists():continue
    d=json.loads(dp.read_text());record[kind].update({'boardPath':str(bp.resolve()),
        'boardSHA256':hashlib.sha256(bp.read_bytes()).hexdigest(),'nativeDRCPath':str(dp.resolve()),
        'errors':sum(v['severity']=='error' for v in d['violations']),'warnings':sum(v['severity']=='warning' for v in d['violations']),
        'unconnected':len(d['unconnected_items']),'ignoredChecks':d['ignored_checks']})
selection=OUT.parent/'audit/selection'
record['selection']['artifacts']=[f.relative_to(OUT.parent).as_posix() for f in sorted(selection.rglob('*')) if f.is_file() and f.suffix=='.json'] if selection.exists() else []
record['selection']['state']='READ_ONLY_MONITORED; integrate only reviewed source/physical patches' if record['selection']['artifacts'] else 'WAITING_FOR_STATUS_ARTIFACT; other CAD work continues'
record['stage']='V26_SOURCE_315_MERGED_MAIN_ADVANCED_CONTINUATION_ROUTING_AND_USB_LAND_REWORK'
record['main']['sourceIntegration']='22 new actual main footprints incl isolated NTC reference/window; RT1921 remains external battery sensor. Original chargefault R1901..3 preserved. 47 real GND plane taps. U801.7 pinfunction PC13_AUDIO_BUS_EN, .38 PE8_CC_FAULT_N.'
record['main']['violationCategories']={'via_dangling':125,'track_dangling':7}
record['main']['routeInput']='SmartVio-main-v26-315-route-input.kicad_pcb'
record['usb']['state']='U1401_B2_PHYSICALLY_CONNECTED_VIA_FILLED_CAPPED_LASER_F_IN1; 0 native violations and 0 unconnected under explicit scoped HDI rules; FL1501 land/pin ECO and paired-route review still HOLD, no CAM export yet'
record['TVS']['state']='APPLIED_TO_REAL_MAIN_NEW_NATIVE: 7 official0.3x0.5 lands, +/-0.35 centers, mask+0.07; current pad/net graph unchanged by footprint ECO'
record['routerProcesses']=[{'kind':'main-315-advanced','sourceSHA256':'1d7c0a10465a6595b03866f3604ac77d1cdbb3a53f721ca4111a1afebd258fda','passes':30,'timeout':'00:30:00',
                            'dsn':'routing/main-v26-315-advanced.dsn','log':'work/v26/pcb/main-315-router.log','state':'RUNNING_ROUTING_STAGE; fanout completed0.4s;336 router unrouted items at start, not a native DRC count'}]
record['stoppedRouters']=[{'dsn':'routing/main-v26-continuation.dsn','log':'work/v26/pcb/main-continuation-router.log',
                          'reason':'Stopped own Java28064 after12minutes fanout with no SES or native progress', 'sesProduced':False}]
path.write_text(json.dumps(record,indent=2));print(path)
