"""Apply only explicit native DRC width and unused-via corrections."""
import argparse
import json
import os
from pathlib import Path
import shutil

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:
    os.environ[name]=str(WORK/folder)
import pcbnew as p

ap=argparse.ArgumentParser()
ap.add_argument('--board',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--drc',type=Path,required=True)
a=ap.parse_args()
assert a.output.resolve().is_relative_to(OUT.resolve())
b=p.LoadBoard(str(a.board.resolve()))
drc=json.loads(a.drc.read_text())
changes=[]
tracks={t.m_Uuid.AsString():t for t in b.GetTracks()}
for issue in drc['violations']:
    if issue['type'] not in ('track_width','via_dangling','track_dangling'):continue
    t=tracks[issue['items'][0]['uuid']]
    if issue['type']=='track_width':
        assert not isinstance(t,p.PCB_VIA)
        old=p.ToMM(t.GetWidth())
        assert old<.15
        t.SetWidth(p.FromMM(.15))
        changes.append({'type':'widen','net':t.GetNetname(),'uuid':t.m_Uuid.AsString(),'oldMm':old,'newMm':.15})
    elif issue['type']=='via_dangling':
        assert isinstance(t,p.PCB_VIA)
        changes.append({'type':'remove-unused-via','net':t.GetNetname(),'uuid':t.m_Uuid.AsString()})
        b.Remove(t)
    elif p.ToMM(t.GetLength())<=.01:
        changes.append({'type':'remove-sub-10um-dangling-stub','net':t.GetNetname(),'uuid':t.m_Uuid.AsString()})
        b.Remove(t)
p.SaveBoard(str(a.output),b)
shutil.copyfile(a.board.with_suffix('.kicad_pro'),a.output.with_suffix('.kicad_pro'))
(OUT/'verification'/(a.output.stem+'-cleanup.json')).write_text(json.dumps({'changes':changes,'drc':'REQUIRED_AFTER_MODIFICATION'},indent=2))
print(json.dumps(changes,indent=2))
