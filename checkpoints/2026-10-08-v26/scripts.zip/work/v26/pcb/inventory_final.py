"""Read one saved native board per process, avoiding multi-board SWIG lifetime hazards."""
import argparse
from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('--kind',required=True);ap.add_argument('--board',type=Path,required=True);a=ap.parse_args()
b=p.LoadBoard(str(a.board.resolve()))
libs={'SmartVioV25':OUT/'SmartVioV25.pretty','SmartVioV26':OUT/'SmartVioV26.pretty',
      'SmartVio_Battery_Revision':OUT.parent/'audit/selection/battery-revision/footprints/SmartVio_Battery_Revision.pretty',
      'SmartVio_V26_Selection':OUT.parent/'audit/selection/SmartVio_V26_Selection.pretty',
      'Passive_V26_ManufacturerLand':OUT.parent/'audit/passive-closure/Passive_V26_ManufacturerLand.pretty'}
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
xy=lambda v:[round(p.ToMM(v.x),6),round(p.ToMM(v.y),6)]
fps=[];library_objects=[]
for f in b.GetFootprints():
    fid=str(f.GetFPID().GetUniStringLibId());nick,name=fid.split(':',1)
    libfile=libs[nick]/(name+'.kicad_mod') if nick in libs else None
    pads=[]
    for d in f.Pads():
        # Native world coordinates include all flip/orientation transforms.
        pads.append({'number':d.GetNumber(),'net':d.GetNetname() or None,'pinFunction':d.GetPinFunction(),
          'relativeXYMm':xy(d.GetFPRelativePosition()),'shape':int(d.GetShape()),'cornerRadiusMm':round(p.ToMM(d.GetRoundRectCornerRadius()),6),
          'xyMm':xy(d.GetPosition()),'sizeMm':xy(d.GetSize()),'drillMm':xy(d.GetDrillSize()),
          'orientationDegrees':round(d.GetOrientationDegrees(),6),'copperLayers':[p.LayerName(layer) for layer in b.GetEnabledLayers().CuStack() if d.IsOnLayer(layer)],
          'type':int(d.GetAttribute()),'maskMarginMm':round(p.ToMM(d.GetLocalSolderMaskMargin()),6) if d.GetLocalSolderMaskMargin() is not None else None})
    courts=[g.GetBoundingBox() for g in f.GraphicalItems() if g.GetLayer() in [p.F_CrtYd,p.B_CrtYd]]
    courtbox=None
    if courts:courtbox=[min(p.ToMM(q.GetLeft()) for q in courts),min(p.ToMM(q.GetTop()) for q in courts),max(p.ToMM(q.GetRight()) for q in courts),max(p.ToMM(q.GetBottom()) for q in courts)]
    try:mpn=f.GetFieldText('MPN')
    except KeyError:mpn=None
    library_match=None
    fps.append({'ref':f.GetReference(),'id':fid,'value':f.GetValue(),'mpnField':mpn,
       'side':'B' if f.IsFlipped() else 'F','xyMm':xy(f.GetPosition()),'orientationDegrees':f.GetOrientationDegrees(),
       'pads':pads,'courtyardBBoxMm':courtbox,'libraryFile':str(libfile.resolve()) if libfile else None,
       'libraryFileExists':bool(libfile and libfile.exists()),'libraryFileSHA256':sha(libfile) if libfile and libfile.exists() else None})
    fps[-1]['embeddedPadGeometryMatchesLibrary']=library_match
tracks=list(b.GetTracks());vias=[t for t in tracks if isinstance(t,p.PCB_VIA)]
segments=[t for t in tracks if not isinstance(t,p.PCB_VIA)]
record={'kind':a.kind,'boardPath':str(a.board.resolve()),'boardSHA256':sha(a.board),
 'projectPath':str(a.board.with_suffix('.kicad_pro').resolve()),'projectSHA256':sha(a.board.with_suffix('.kicad_pro')),
 'copperLayers':b.GetCopperLayerCount(),'thicknessMm':p.ToMM(b.GetDesignSettings().GetBoardThickness()),
 'footprintCount':len(fps),'trackCount':len(segments),'viaCount':len(vias),'zoneCount':len(list(b.Zones())),
 'tracksByNet':dict(Counter(t.GetNetname() for t in segments)),
 'widthsMmByNet':{n:sorted({round(p.ToMM(t.GetWidth()),6) for t in segments if t.GetNetname()==n}) for n in sorted({t.GetNetname() for t in segments})},
 'viaInventory':[{'xyMm':xy(t.GetPosition()),'net':t.GetNetname(),'diameterMm':p.ToMM(t.GetWidth(p.F_Cu)),'drillMm':p.ToMM(t.GetDrill()),'type':int(t.GetViaType())} for t in vias],
 'footprints':fps,'productionApproved':False}
path=OUT/'verification'/('final-inventory-'+a.kind+'.json');path.write_text(json.dumps(record,indent=2))
print(json.dumps({k:record[k] for k in ['kind','footprintCount','trackCount','viaCount','zoneCount','boardSHA256']}))
