"""Merge authorized source pin changes, rip affected shared copper, add real ECO parts."""
import hashlib
import json
import math
import os
import argparse
from pathlib import Path
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
from process_rules import configure
ap=argparse.ArgumentParser()
ap.add_argument('--board',type=Path,default=OUT/'SmartVio-main-v26-eco-seeded.kicad_pcb')
ap.add_argument('--output',type=Path,default=OUT/'SmartVio-main-v26-current-seeded.kicad_pcb')
a=ap.parse_args();src=a.board;dst=a.output
assert dst.resolve().is_relative_to(OUT.resolve())
sourcefile=OUT.parent/'electrical/native-components.json'
parts={c['ref']:c for c in json.loads(sourcefile.read_text(encoding='utf-8-sig'))}
mapping=json.loads((OUT/'footprint-map.json').read_text())
review=json.loads((OUT/'final-292/footprint-review.json').read_text())
b=p.LoadBoard(str(src));fps={f.GetReference():f for f in b.GetFootprints()}
oldparts=set(fps);oldsource=set(review)
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
for net in sorted({pin['net'] for c in parts.values() for pin in c['pins'] if pin['net']}):
    if not b.FindNet(net):b.Add(p.NETINFO_ITEM(b,net))
changes=[];ripnets=set();added=[];held=[]
def padsmap(f):return {d.GetNumber():d.GetNetname() or None for d in f.Pads() if d.GetNumber()}
def bind(f,c):
    aliases=mapping.get(c['ref'],{}).get('pinAliases',{})
    desired={aliases.get(pin['number'],pin['number']):pin['net'] for pin in c['pins']}
    for d in f.Pads():
        n=d.GetNumber()
        if n not in desired:continue
        net=desired[n];old=d.GetNetname() or None
        if old!=net:
            changes.append({'ref':c['ref'],'pin':n,'before':old,'after':net})
            if old:ripnets.add(old)
            if net:ripnets.add(net)
            d.SetNet(b.FindNet(net) if net else b.FindNet(0))
    f.SetValue(c['value']);f.SetField('MPN',c.get('mpn','') or '');f.GetField('MPN').SetVisible(False)
    pinfunctions={aliases.get(pin['number'],pin['number']):pin.get('name',pin.get('function','')) for pin in c['pins']}
    for d in f.Pads():
        if d.GetNumber() in pinfunctions:d.SetPinFunction(pinfunctions[d.GetNumber()])
    f.Reference().SetVisible(False);f.Value().SetVisible(False)
for ref in set(parts)&set(fps):bind(fps[ref],parts[ref])
existingrip=set(ripnets)
for t in list(b.GetTracks()):
    if t.GetNetname() in ripnets:held.append(t);b.Remove(t)
def courtyard(f):
    ls=p.LSET();ls.AddLayer(p.B_CrtYd if f.IsFlipped() else p.F_CrtYd)
    bb=f.GetLayerBoundingBox(ls)
    return tuple(p.ToMM(v) for v in (bb.GetX(),bb.GetY(),bb.GetRight(),bb.GetBottom()))
def fits(f):
    box=courtyard(f)
    if box[0]<.15 or box[1]<.15 or box[2]>71.85 or box[3]>38.85:return False
    for g in b.GetFootprints():
        if g==f or g.GetReference()==f.GetReference() or g.IsFlipped()!=f.IsFlipped():continue
        q=courtyard(g)
        if box[0]<q[2]+.1 and box[2]>q[0]-.1 and box[1]<q[3]+.1 and box[3]>q[1]-.1:return False
    return True
positions={'U1901':(60,28),'U1902':(10,31),'D1301':(67,27),'D1302':(67,33),
           'R1303':(63,33),'R1304':(64,30),'R1911':(56.5,27),'R1912':(56.5,30),
           'R1913':(14,34),'C1901':(63.5,27),'C1902':(59,24),'C1903':(61,32)}
positions.update({'U1921':(48,29),'U1922':(44,34),'R1921':(49,34),'R1922':(53,34),
                  'R1923':(44,31),'R1924':(48,36),'C1921':(48,26),'C1922':(40,34),
                  'C1904':(10,27),'J1921':(39,36)})
mapping['RT1921']={'board':'battery_surface','placement':'EXTERNAL_BATTERY_CONTACT_SENSOR',
                   'id':None,'pinAliases':{},'release':'HOLD','physicalFitApproved':False,
                   'note':'Semitec103AT-2 wired through J1921; not populated on main PCB'}
newrefs=set(parts)-oldsource
for ref in sorted(newrefs,key=lambda r:(0 if r.startswith('U') else 1,r)):
    if ref in fps:continue
    if ref=='RT1921':continue
    c=parts[ref]
    if c['type']=='IC' and ref=='U1902':
        name=str(fps['U1702'].GetFPID().GetLibItemName());lib=OUT/'SmartVioV25.pretty';nick='SmartVioV25'
    elif ref in ('U1901','U1921'):
        name='TI_DBV0006A_Official' if ref=='U1901' else 'TI_DDC0006A_Official';lib=OUT/'SmartVioV26.pretty';nick='SmartVioV26'
    elif ref=='U1922':name='SOT-23';lib=OUT/'SmartVioV25.pretty';nick='SmartVioV25'
    elif ref=='J1921':name='WirePads_2_P1.5';lib=OUT/'SmartVioV25.pretty';nick='SmartVioV25'
    elif c['type']=='D':name='SOT-23';lib=OUT/'SmartVioV25.pretty';nick='SmartVioV25'
    elif c['type']=='R':name='R_0603_1608Metric';lib=OUT/'SmartVioV25.pretty';nick='SmartVioV25'
    elif c['type']=='C':name='C_0603_1608Metric';lib=OUT/'SmartVioV25.pretty';nick='SmartVioV25'
    else:raise ValueError('New component requires explicit physical mapping '+ref)
    f=p.FootprintLoad(str(lib),name);assert f is not None,(ref,name)
    f.SetReference(ref);f.SetFPID(p.LIB_ID(nick,name));b.Add(f);f.Flip(pt(0,0),False);f.SetOrientationDegrees(0)
    preferred=positions[ref]
    options=sorted(((abs(x-preferred[0])+abs(y-preferred[1]),x,y) for x in [z/2 for z in range(8,139)] for y in [z/2 for z in range(48,75)]))
    for _,x,y in options:
        f.SetPosition(pt(x,y))
        if fits(f):break
    else:raise RuntimeError('No legal courtyard placement for '+ref)
    mapping[ref]={'id':nick+':'+name,'review':'V26_AUTHORIZED_SOURCE_ECO; PHYSICAL_PACKAGE_PINSET_REVIEW',
                  'board':'main','placement':'CANDIDATE_MAIN','pinAliases':{},'release':'HOLD','physicalFitApproved':False,
                  'manufacturerLandPatternApproved':ref in ('U1901','U1921'),
                  'heightMaxMm':1.45 if ref in ('U1901','U1922') else 1.2 if ref=='U1902' else 1.1 if ref=='U1921' or c['type']=='D' else .9}
    bind(f,c);fps[ref]=f
    assert set(padsmap(f))=={pin['number'] for pin in c['pins']},ref
    added.append({'ref':ref,'footprint':nick+':'+name,'xyMm':[x,y],'side':'B','courtyardMm':courtyard(f)})
for f in b.GetFootprints():
    r=f.GetReference()
    if r in mapping and str(f.GetFPID().GetUniStringLibId()).startswith('SmartVioV26:'):
        mapping[r]['id']=str(f.GetFPID().GetUniStringLibId());mapping[r]['review']='V26_MANUFACTURER_LAND_ECO_APPLIED_RECONNECT_AND_PROCESS_REVIEW'
        mapping[r]['geometryChangeApplied']=True
        if r.startswith('D120'):mapping[r]['heightMaxMm']=.4
        if r=='L1101':mapping[r]['heightMaxMm']=2.1
        if r=='FB1101':mapping[r]['heightMaxMm']=1.0
(OUT/'footprint-map.json').write_text(json.dumps(mapping,indent=2))
configure(p,b,dst,src.with_suffix('.kicad_pro'))
proj=dst.with_suffix('.kicad_pro');config=json.loads(proj.read_text());config['net_settings']['classes'][0]['track_width']=.15
proj.write_text(json.dumps(config,indent=2));b.GetDesignSettings().m_NetSettings.GetDefaultNetclass().SetTrackWidth(p.FromMM(.15))
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(dst),b)
record={'sourceSHA256':hashlib.sha256(sourcefile.read_bytes()).hexdigest(),'components':len(parts),
        'board':str(dst),'footprints':len(list(b.GetFootprints())),'tracksAndVias':len(list(b.GetTracks())),
    'changedPadNetAssignments':changes,'rippedSharedNetNames':sorted(existingrip),'rippedTracksAndVias':len(held),
        'added':added,'D1301D1302':'BAS116,215; physical1A2NC3K; not BAT54',
        'preservedOldChargeFaultResistors':['R1901','R1902','R1903'],
        'newDomainResistors':['R1911','R1912','R1913'],'productionApproved':False,'nativeDRC':'REQUIRED'}
(OUT/'verification'/('merge-'+dst.stem+'.json')).write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k not in ('changedPadNetAssignments','added')},indent=2))
