"""Bridge real F/B ground pours with explicit physical stitching vias."""
import json
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
src=OUT/'SmartVio-cover-v26-routed-fixed.kicad_pcb';dst=OUT/'SmartVio-cover-v26-grounded-fixed.kicad_pcb'
b=p.LoadBoard(str(src));added=[]
for x,y in [(100,10),(100,40),(70,44),(4,44)]:
    via=p.PCB_VIA(b);via.SetPosition(p.VECTOR2I(p.FromMM(x),p.FromMM(y)));via.SetWidth(p.FromMM(.6));via.SetDrill(p.FromMM(.3))
    via.SetViaType(p.VIATYPE_THROUGH);via.SetLayerPair(p.F_Cu,p.B_Cu);via.SetNet(b.FindNet('GND'));b.Add(via)
    added.append({'net':'GND','xyMm':[x,y],'diameterMm':.6,'drillMm':.3,'layers':['F.Cu','B.Cu']})
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(dst),b)
shutil.copyfile(src.with_suffix('.kicad_pro'),dst.with_suffix('.kicad_pro'))
if src.with_suffix('.kicad_dru').exists():shutil.copyfile(src.with_suffix('.kicad_dru'),dst.with_suffix('.kicad_dru'))
(OUT/'verification/cover-ground-stitches.json').write_text(json.dumps({'physicalVias':added,'nativeDRCRequired':True,'productionApproved':False},indent=2))
print(dst)
