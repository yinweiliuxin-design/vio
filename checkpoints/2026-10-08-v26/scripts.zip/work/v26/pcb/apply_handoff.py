"""Apply reviewed manufacturer lands and current source physical numbering."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('--board',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--ref',action='append',required=True);ap.add_argument('--rip-net',action='append',default=[])
a=ap.parse_args();assert a.output.resolve().is_relative_to(OUT.resolve())
source=OUT.parent/'electrical/native-components.json'
parts={c['ref']:c for c in json.loads(source.read_text(encoding='utf-8-sig'))}
handoff=OUT.parent/'audit/passive-closure/land-handoff.json'
entries={e['ref']:e for e in json.loads(handoff.read_text())['entries']}
names={'L1101':'Coilcraft_XGL4020_Official','FB1101':'WE_742792625_Official',
       'FL1501':'TDK_ACM2012H_Official','L1501':'Coilcraft_0603HP_Official',
       'L1502':'Coilcraft_0603HP_Official','Y801':'Abracon_ABM8_Official'}
lib=OUT/'SmartVioV26.pretty';pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
for ref in a.ref:
    spec=entries[ref];f=p.FOOTPRINT(None);f.SetFPID(p.LIB_ID('SmartVioV26',names[ref]));f.SetReference('REF**');f.SetValue(spec['selected_mpn']);f.SetAttributes(p.FP_SMD)
    f.SetLibDescription('; '.join(e['manufacturer_url'] for e in spec['evidence']))
    mx,my,mz=spec['body_lwh_max_mm']
    padextents=[(abs(d['center_xy_mm'][0])+d['size_xy_mm'][0]/2,abs(d['center_xy_mm'][1])+d['size_xy_mm'][1]/2) for d in spec['pads']]
    for layer,hx,hy in [(p.F_Fab,mx/2,my/2),(p.F_CrtYd,max(mx/2,max(q[0] for q in padextents))+.25,max(my/2,max(q[1] for q in padextents))+.25)]:
        sh=p.PCB_SHAPE(f);sh.SetShape(p.SHAPE_T_RECT);sh.SetLayer(layer);sh.SetStart(pt(-hx,-hy));sh.SetEnd(pt(hx,hy));sh.SetWidth(p.FromMM(.05));f.Add(sh)
    for row in spec['pads']:
        d=p.PAD(f);d.SetNumber(row['number']);d.SetAttribute(p.PAD_ATTRIB_SMD);d.SetShape(p.PAD_SHAPE_RECT)
        d.SetPosition(pt(*row['center_xy_mm']));d.SetSize(pt(*row['size_xy_mm']));ls=p.LSET()
        for layer in (p.F_Cu,p.F_Mask,p.F_Paste):ls.AddLayer(layer)
        d.SetLayerSet(ls);f.Add(d)
    p.FootprintSave(str(lib),f)
b=p.LoadBoard(str(a.board.resolve()));mapping=json.loads((OUT/'footprint-map.json').read_text());changes=[];held=[]
for t in list(b.GetTracks()):
    if t.GetNetname() in a.rip_net:held.append(t);b.Remove(t)
for old in list(b.GetFootprints()):
    ref=old.GetReference()
    if ref not in a.ref:continue
    spec=entries[ref];c=parts[ref];name=names[ref];f=p.FootprintLoad(str(lib),name);f.SetReference(ref);f.SetFPID(p.LIB_ID('SmartVioV26',name))
    position=p.VECTOR2I(old.GetPosition());f.SetPosition(position);b.Add(f)
    if old.IsFlipped():f.Flip(position,False)
    f.SetOrientation(old.GetOrientation());f.Reference().SetVisible(False);f.Value().SetVisible(False)
    oldmap={d.GetNumber():d.GetNetname() or None for d in old.Pads() if d.GetNumber()}
    for d in f.Pads():
        pin=next(pin for pin in c['pins'] if pin['number']==d.GetNumber())
        d.SetNet(b.FindNet(pin['net']) if pin['net'] else b.FindNet(0));d.SetPinFunction(pin['name'])
    mapping[ref].update({'id':'SmartVioV26:'+name,'pinAliases':{},'geometryChangeApplied':True,
                        'manufacturerLandPatternApproved':True,'heightMaxMm':spec['body_lwh_max_mm'][2],
                        'sourceEvidence':spec['evidence'],'physicalFitApproved':False,'release':'HOLD'})
    changes.append({'ref':ref,'oldPhysicalPinNets':oldmap,'currentPhysicalPinNets':{d.GetNumber():d.GetNetname() or None for d in f.Pads()},
                    'physicalPinRenumbering':ref=='FL1501','physicalLand':spec,'xyMm':[p.ToMM(position.x),p.ToMM(position.y)],'placementSideAnglePreserved':True})
    b.Remove(old)
for f in b.GetFootprints():
    if f.GetReference() in parts:
        c=parts[f.GetReference()];f.SetValue(c['value']);f.SetField('MPN',c.get('mpn') or '');f.GetField('MPN').SetVisible(False)
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(a.output),b)
for suffix in ('.kicad_pro','.kicad_dru'):
    if a.board.with_suffix(suffix).exists():shutil.copyfile(a.board.with_suffix(suffix),a.output.with_suffix(suffix))
(OUT/'footprint-map.json').write_text(json.dumps(mapping,indent=2))
record={'input':str(a.board),'output':str(a.output),'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'landHandoffSHA256':hashlib.sha256(handoff.read_bytes()).hexdigest(),'changes':changes,
        'rippedNets':a.rip_net,'rippedTracksAndVias':len(held),'nativeDRCRequired':True,'productionApproved':False}
(OUT/'verification'/('land-'+a.output.stem+'.json')).write_text(json.dumps(record,indent=2))
print(json.dumps({'output':str(a.output),'changes':len(changes),'rippedTracksAndVias':len(held),'sourceSHA256':record['sourceSHA256']}))
