"""Remove physically orphaned pour islands, without adding unconnected stitching copper."""
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
src=OUT/'SmartVio-audio-v26-routed-fixed.kicad_pcb';dst=OUT/'SmartVio-audio-v26-final-groundclean.kicad_pcb'
b=p.LoadBoard(str(src))
for z in b.Zones():
    if not z.GetIsRuleArea():z.SetIslandRemovalMode(p.ISLAND_REMOVAL_MODE_ALWAYS)
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(dst),b)
for ext in ['.kicad_pro','.kicad_dru']:
    if src.with_suffix(ext).exists():shutil.copyfile(src.with_suffix(ext),dst.with_suffix(ext))
print(dst)
