"""Independent charger/power/telemetry routing prototype, not the full product."""
import argparse
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
from process_rules import configure

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'documents')
os.environ['DOCUMENTS_HOME']=str(WORK/'documents')
import pcbnew as p
mm=p.FromMM
pt=lambda x,y:p.VECTOR2I(mm(x),mm(y))
parser=argparse.ArgumentParser();parser.add_argument('--open-fanout',action='store_true');args=parser.parse_args()
parts=json.loads((ROOT/'outputs/SmartVio-V26-Engineering/electrical/native-components.json').read_text(encoding='utf-8-sig'))
mapping=json.loads((OUT/'footprint-review.json').read_text())
selected=[c for c in parts if int(re.sub(r'\D','',c['ref']))//100 in (5,10,11,13,16,17,19)]
main=p.LoadBoard(str(OUT/'SmartVio-main-tentative.kicad_pcb'))
board=p.BOARD();board.SetCopperLayerCount(4);board.GetDesignSettings().SetBoardThickness(mm(1))
def rect(parent,x0,y0,x1,y1,layer):
    corners=[(x0,y0),(x1,y0),(x1,y1),(x0,y1)]
    for a,b in zip(corners,corners[1:]+corners[:1]):
        s=p.PCB_SHAPE(parent);s.SetShape(p.SHAPE_T_SEGMENT);s.SetStart(pt(*a));s.SetEnd(pt(*b));s.SetWidth(mm(.05));s.SetLayer(layer);parent.Add(s)
rect(board,0,0,58,38,p.Edge_Cuts)
allnets={pin['net'] for c in selected for pin in c['pins'] if pin['net']}
ns={}
for n in sorted(allnets):
    ni=p.NETINFO_ITEM(board,n);board.Add(ni);ns[n]=ni
fps={}
for c in selected:
    m=mapping[c['ref']]
    fp=p.FootprintLoad(str(OUT/'SmartVioV25.pretty'),m['footprint'].split(':')[1]);fp.SetReference(c['ref']);fp.SetValue(c['mpn'] or c['value'])
    fp.SetFPID(p.LIB_ID('SmartVioV25',m['footprint'].split(':')[1]))
    pinmap={m['pinAliases'].get(v['number'],v['number']):v['net'] for v in c['pins']}
    for d in fp.Pads():
        if pinmap.get(d.GetNumber()):d.SetNet(ns[pinmap[d.GetNumber()]])
    fp.Reference().SetVisible(False);fp.Value().SetVisible(False)
    board.Add(fp);fps[c['ref']]=fp

othernets={v['net'] for c in parts if c not in selected for v in c['pins'] if v['net']}
interfaces=sorted(allnets & othernets)
endpoints={}
for i in range(0,len(interfaces),6):
    group=interfaces[i:i+6];r='JP'+str(i//6+1)
    fp=p.FOOTPRINT(board);fp.SetReference(r);fp.SetValue('PROTOTYPE_EXTERNAL_NETS')
    fp.SetFPID(p.LIB_ID('SmartVioV25','PROTO_'+r));fp.SetAttributes(p.FP_SMD)
    for j,n in enumerate(group):
        d=p.PAD(fp);d.SetNumber(str(j+1));d.SetSize(pt(1.1,1.8));d.SetPosition(pt((j-(len(group)-1)/2)*2,0));d.SetShape(p.PAD_SHAPE_RECT);d.SetAttribute(p.PAD_ATTRIB_SMD)
        ls=p.LSET();ls.AddLayer(p.F_Cu);ls.AddLayer(p.F_Mask);d.SetLayerSet(ls);d.SetNet(ns[n]);fp.Add(d)
    rect(fp,-len(group),-1.2,len(group),1.2,p.F_CrtYd)
    fp.Reference().SetVisible(False);fp.Value().SetVisible(False)
    p.FootprintSave(str(OUT/'SmartVioV25.pretty'),fp)
    board.Add(fp);fps[r]=fp;endpoints[r]=dict(enumerate(group,1))

def bb(fp):
    ls=p.LSET();ls.AddLayer(p.F_CrtYd);v=fp.GetLayerBoundingBox(ls)
    return[p.ToMM(v.GetX()),p.ToMM(v.GetY()),p.ToMM(v.GetRight()),p.ToMM(v.GetBottom())]
def hit(a,b):return a[0]<b[2]+.1 and a[2]+.1>b[0] and a[1]<b[3]+.1 and a[3]+.1>b[1]
occupied=[];placed={}
def place(r,x,y):
    fp=fps[r];fp.SetPosition(pt(x,y));b=bb(fp);occupied.append((r,b));placed[r]={'xMm':x,'yMm':y,'courtyardMm':b}
fixed={'U1001':(7,9),'U501':(17,9),'U1101':(30,9),'L1101':(36,9),
       'U1301':(46,11),'U1701':(18,27),'U1702':(30,27),'U1703':(43,27),'J501':(6,28)}
if args.open_fanout:
    fixed.update({'L1101':(34.4,9),'C1102':(31,5),'C1103':(27.2,5),
                  'C1104':(28.5,12.5),'C1105':(32.3,13),
                  'C501':(22.5,5),'C502':(23,8),'C503':(23,11.5)})
for i,r in enumerate(endpoints):fixed[r]=(7+13*i,2)
for r,q in fixed.items():
    if r in fps:place(r,*q)
if args.open_fanout:occupied.append(('RESERVED_BQ_FANOUT',[12.5,4.5,21.5,13.5]))
def target(r):
    g=int(re.sub(r'\D','',r))//100
    owner={5:'U501',10:'U1001',11:'U1101',13:'U1301',16:'U501',17:'U1702',19:'U501'}.get(g,'U501')
    return fixed[owner]
remaining=[r for r in fps if r not in placed]
remaining.sort(key=lambda r:-(bb(fps[r])[2]-bb(fps[r])[0])*(bb(fps[r])[3]-bb(fps[r])[1]))
for r in remaining:
    fp=fps[r];b=bb(fp);tx,ty=target(r)
    points=[(x/2,y/2) for x in range(2,115) for y in range(2,75)]
    points.sort(key=lambda q:(q[0]-tx)**2+(q[1]-ty)**2)
    for x,y in points:
        c=[b[0]+x,b[1]+y,b[2]+x,b[3]+y]
        if c[0]<.4 or c[1]<.4 or c[2]>57.6 or c[3]>37.6:continue
        if any(hit(c,z) for _,z in occupied):continue
        place(r,x,y);break
    else:raise RuntimeError('Prototype cannot place '+r)
text=p.PCB_TEXT(board);text.SetText('POWER + CHARGER + TELEMETRY PROTOTYPE ONLY / NOT PRODUCT RELEASE');text.SetPosition(pt(29,-2));text.SetTextSize(pt(.6,.6));text.SetLayer(p.Dwgs_User);board.Add(text)
path=OUT/('SmartVio-power-prototype-open-fanout.kicad_pcb' if args.open_fanout else 'SmartVio-power-prototype-unrouted.kicad_pcb')
configure(p,board,path)
p.SaveBoard(str(path),board)
if not args.open_fanout:assert p.ExportSpecctraDSN(board,str(OUT/'routing/power-prototype.dsn'))
result={'status':'UNROUTED_CORRECTED_POWER_NETLIST_PROTOTYPE_ONLY','components':len(selected),'footprints':len(fps),'outlineMm':[58,38],
 'sourcePowerSHA256':hashlib.sha256((ROOT/'outputs/SmartVio-V26-Engineering/audit/power/corrected-components.json').read_bytes()).hexdigest(),
 'interfaces':endpoints,'placement':placed,'mainArchitectureChanged':False,
 'collisions':[{'refs':[r,s]} for (r,a),(s,b) in itertools.combinations(occupied,2) if r!='RESERVED_BQ_FANOUT' and s!='RESERVED_BQ_FANOUT' and hit(a,b)],
 'hold':['Inductor MPN not selected','No switch-node or high-current loop validation','Thermal design not validated','Endpoint pinout is an explicit test-harness proposal','No production fabrication approval']}
(OUT/'verification'/('power-open-fanout-placement.json' if args.open_fanout else 'power-prototype.json')).write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ('placement','interfaces')},indent=2))
