"""Copy only selected actual current-revision native variants into the parent's final filenames."""
import hashlib
import json
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
selected={'main':'SmartVio-main-v26-final-input','usb':'SmartVio-usb-v26-final',
 'audio':'SmartVio-audio-v26-closed','cover':'SmartVio-cover-v26-closed','sensor':'SmartVio-sensor-v26-final-input'}
records=[]
for kind,name in selected.items():
    src=OUT/(name+'.kicad_pcb');dst=OUT/('SmartVio-'+kind+'-v26-final.kicad_pcb')
    for ext in ['.kicad_pcb','.kicad_pro','.kicad_dru']:
        original=src.with_suffix(ext);target=dst.with_suffix(ext)
        if original.exists():
            if original!=target:shutil.copyfile(original,target)
        elif ext=='.kicad_dru':target.write_text('(version 1)\n')
        else:raise RuntimeError('Missing native companion: '+str(original))
    pro=dst.with_suffix('.kicad_pro');data=json.loads(pro.read_text());data['meta']['filename']=pro.name
    pro.write_text(json.dumps(data,indent=2)+'\n')
    assert src.read_bytes()==dst.read_bytes()
    records.append({'kind':kind,'selectedInput':str(src.resolve()),'finalBoard':str(dst.resolve()),
      'boardSHA256':hashlib.sha256(dst.read_bytes()).hexdigest(),'productionApproved':False})
(OUT/'verification/final-selected-files.json').write_text(json.dumps(records,indent=2))
print(json.dumps(records,indent=2))
