"""Main-board-only native AST helpers and immutable net/geometry signatures."""
import hashlib
import json
from pathlib import Path
import sys
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work';DEST=OUT/'main-remediation'
sys.path.insert(0,str(ROOT/'work/v26/parser-tools'))
import sexpdata as sx
S=sx.Symbol
def key(n):return str(n[0]) if isinstance(n,list) and n else ''
def kids(n,k):return [v for v in n if key(v)==k]
def child(n,k):return next((v for v in n if key(v)==k),None)
def read(path):return sx.loads(Path(path).read_text(encoding='utf-8'))
def write(path,tree):
    path=Path(path).resolve();assert path.is_relative_to(DEST.resolve()) or path.is_relative_to(WORK.resolve())
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(sx.dumps(tree)+'\n',encoding='utf-8')
    assert read(path)==tree
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ref(fp):return next(q[2] for q in kids(fp,'property') if q[1]=='Reference')
def uuid(n):return child(n,'uuid')[1]
def objects(tree):
    result={}
    for obj in tree:
        if key(obj) in ['segment','arc','via','zone']:result[uuid(obj)]=obj
        if key(obj)=='footprint':
            for pad in kids(obj,'pad'):result[uuid(pad)]=pad
    return result
def signature(obj):
    fields=['net','at','start','mid','end','width','size','drill','layer','layers']
    return {k:child(obj,k)[1:] for k in fields if child(obj,k)}
def audit(before,after):
    a=objects(before);b=objects(after)
    return [{'uuid':u,'before':signature(n),'after':signature(b[u]) if u in b else None}
            for u,n in a.items() if u not in b or signature(n)!=signature(b[u])]

