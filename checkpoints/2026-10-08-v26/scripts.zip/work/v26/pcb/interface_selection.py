"""Real jack/control boards with manufacturer lands and source physical pins."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for key,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[key]=str(WORK/folder)
import pcbnew as p
from process_rules import configure
source=OUT.parent/'electrical/native-components.json'
parts={c['ref']:c for c in json.loads(source.read_text(encoding='utf-8-sig'))}
lib=OUT.parent/'audit/selection/SmartVio_V26_Selection.pretty'
mapping=json.loads((OUT/'footprint-map.json').read_text())
provenance={d['name']:d for d in json.loads((lib.parent/'footprint-sources.json').read_text())}
selected={'J102':'Jack_Kycon_STX353K7A6N','J201':'Jack_Kycon_STX353K7A6N','J202':'Jack_Kycon_STX353K7A6N','J301':'Jack_Kycon_STX353K7A6N',
          'LS901':'Speaker_PUI_AS01808AO_SC18_Spring_REFERENCE'}
for r in ('SW810','SW811','SW812','SW813','SW814'):selected[r]='Switch_Alps_SKQGABE010'
for r in ('RV810','RV811','RV812'):selected[r]='Pot_Alps_RK10J11R0A0L'
for r in ('D850','D851','D852'):selected[r]='LED_Kingbright_APT1608VRCXF_A_5MAV'
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
positions={}
for i,r in enumerate(('RV810','RV811','RV812')):positions[r]=(15+20*i,10,0)
for i,r in enumerate(('D850','D851','D852')):positions[r]=(15+20*i,23,0)
for i,r in enumerate(('SW810','SW811','SW812','SW813','SW814')):positions[r]=(10+13*i,35,0)
positions.update({'LS901':(132,25,0),'H_COVER_1_R':(80,16,0),'H_COVER_2_R':(90,25,0),'H_COVER_3_R':(80,34,0),
                  'H_AUDIO_1_R':(18.3,7,90),'H_AUDIO_2_R':(36.6,7,90)})
summary=[]
for kind in ('audio','cover'):
    candidates=[OUT/('SmartVio-'+kind+'-delivery-HOLD.kicad_pcb'),OUT/('SmartVio-'+kind+'-tentative.kicad_pcb')]
    src=next(path for path in candidates if path.exists())
    dst=OUT/('SmartVio-'+kind+'-v26-selection.kicad_pcb');b=p.LoadBoard(str(src))
    oldtracks=list(b.GetTracks())
    for t in oldtracks:b.Remove(t)
    changes=[]
    for old in list(b.GetFootprints()):
        ref=old.GetReference()
        if ref not in selected:continue
        name=selected[ref];f=p.FootprintLoad(str(lib),name);f.SetFPID(p.LIB_ID('SmartVio_V26_Selection',name))
        f.SetReference(ref);f.SetValue(parts[ref]['value']);f.SetField('MPN',parts[ref].get('mpn') or '');f.GetField('MPN').SetVisible(False)
        f.Reference().SetVisible(False);f.Value().SetVisible(False);position=p.VECTOR2I(old.GetPosition());f.SetPosition(position);b.Add(f)
        if old.IsFlipped():f.Flip(position,False)
        f.SetOrientation(old.GetOrientation())
        desired={pin['number']:pin for pin in parts[ref]['pins']}
        physical={d.GetNumber() for d in f.Pads() if d.GetNumber()}
        assert physical==set(desired),(ref,physical,set(desired))
        for d in f.Pads():
            if not d.GetNumber():continue
            pin=desired[d.GetNumber()];d.SetNet(b.FindNet(pin['net']) if pin['net'] else b.FindNet(0));d.SetPinFunction(pin['name'])
        mapping[ref].update({'id':'SmartVio_V26_Selection:'+name,'pinAliases':{},'missingPhysicalPads':[],
                             'board':kind,'manufacturerLandPatternApproved':ref!='LS901','physicalFitApproved':False,
                             'review':'SELECTION_SOURCE_ACTUAL_PADS_AND_CUTOUTS_APPLIED; FULL_ASSEMBLY_HOLD',
                             'geometryChangeApplied':True,'release':'HOLD','sourceEvidence':provenance[name]['evidence']})
        changes.append({'ref':ref,'oldFootprint':str(old.GetFPID().GetUniStringLibId()),'newFootprint':'SmartVio_V26_Selection:'+name,
                        'physicalPinNetMap':{d.GetNumber():d.GetNetname() or None for d in f.Pads() if d.GetNumber()},
                        'footprintSourceSHA256':hashlib.sha256((lib/(name+'.kicad_mod')).read_bytes()).hexdigest()})
        b.Remove(old)
    for f in b.GetFootprints():
        if f.GetReference() in positions:
            x,y,angle=positions[f.GetReference()];f.SetPosition(pt(x,y));f.SetOrientationDegrees(angle)
    width,height=(73.4,14) if kind=='audio' else (148,49)
    for layer in (p.F_Cu,p.B_Cu):
        z=p.ZONE(b);z.SetLayer(layer);z.SetNet(b.FindNet('GND'));z.SetPadConnection(p.ZONE_CONNECTION_FULL)
        z.SetLocalClearance(p.FromMM(.15));z.SetMinThickness(p.FromMM(.15));poly=z.Outline();poly.NewOutline()
        for x,y in [(.35,.35),(width-.35,.35),(width-.35,height-.35),(.35,height-.35)]:poly.Append(p.FromMM(x),p.FromMM(y))
        b.Add(z)
    configure(p,b,dst,src.with_suffix('.kicad_pro'))
    b.GetDesignSettings().m_NetSettings.GetDefaultNetclass().SetTrackWidth(p.FromMM(.2))
    b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(dst),b)
    drc=OUT/'verification'/('v26-'+kind+'-selection-drc.json')
    subprocess.run([str(ROOT/'work/v24/tools/kicad/bin/kicad-cli.exe'),'pcb','drc','--format','json','-o',str(drc),str(dst)],check=True)
    d=json.loads(drc.read_text())
    q={'kind':kind,'board':str(dst),'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),
       'sourceComponentsOnBoard':sum(f.GetReference() in parts for f in b.GetFootprints()),'changes':changes,
       'errors':sum(x['severity']=='error' for x in d['violations']),'warnings':sum(x['severity']=='warning' for x in d['violations']),
       'unconnected':len(d['unconnected_items']),'ignoredChecks':d['ignored_checks'],'productionApproved':False,
       'externalInterfaceFunctionsPreserved':True,'candidateHarnessContract':'proposed-harness.json',
       'mechanical':{'zZero':'Existing violin BACK mounting plane; module control front faces out',
                     'boardFrontZMm':-10.1 if kind=='audio' else None,
                     'audioJackHeightMm':14.9 if kind=='audio' else None,
                     'audioNominalMouthZMm':4.8 if kind=='audio' else None,
                     'audioPlatedSlotTailToMainFrontNominalGapMm':2.4 if kind=='audio' else None,
                     'fullAssemblyApproval':False}}
    summary.append(q)
(OUT/'footprint-map.json').write_text(json.dumps(mapping,indent=2))
(OUT/'verification/v26-selection-native-boards.json').write_text(json.dumps(summary,indent=2))
table=OUT/'fp-lib-table';txt=table.read_text();idx=txt.rfind(')')
if 'name "SmartVio_V26_Selection"' not in txt:
    txt=txt[:idx]+' (lib (name "SmartVio_V26_Selection") (type "KiCad") (uri "${KIPRJMOD}/../audit/selection/SmartVio_V26_Selection.pretty") (options "") (descr "Verified selection land; application and assembly HOLD"))\n'+txt[idx:];table.write_text(txt)
print(json.dumps([{k:q[k] for k in ('kind','board','errors','warnings','unconnected','sourceSHA256')} for q in summary],indent=2))
