"""Close the central TPD2S300 ground with a physical F-In1 laser via."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
from specctra import loads, dumps, child

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/pcb-work'
for key, folder in [('KICAD_CONFIG_HOME', 'config'), ('KICAD_DOCUMENTS_HOME', 'documents'), ('DOCUMENTS_HOME', 'documents')]:
    os.environ[key] = str(WORK / folder)
import pcbnew as p
from process_rules import configure

src = OUT / 'SmartVio-usb-manufacturer-land-HOLD.kicad_pcb'
dst = OUT / 'SmartVio-usb-v26-HDI-ground.kicad_pcb'
b = p.LoadBoard(str(src))
b.SetCopperLayerCount(4)
b.GetDesignSettings().SetBoardThickness(p.FromMM(1))
fps = {f.GetReference(): f for f in b.GetFootprints()}
ball = next(d for d in fps['U1401'].Pads() if d.GetNumber() == 'B2')
assert ball.GetNetname() == 'GND'
v = p.PCB_VIA(b)
v.SetViaType(p.VIATYPE_MICROVIA)
v.SetLayerPair(p.F_Cu, p.In1_Cu)
v.SetPosition(ball.GetPosition())
v.SetWidth(p.FromMM(.25))
v.SetDrill(p.FromMM(.1))
v.SetNet(ball.GetNet())
b.Add(v)
z = p.ZONE(b)
z.SetLayer(p.In1_Cu)
z.SetNet(b.FindNet('GND'))
z.SetPadConnection(p.ZONE_CONNECTION_FULL)
z.SetLocalClearance(p.FromMM(.15))
z.SetMinThickness(p.FromMM(.15))
poly = z.Outline()
poly.NewOutline()
for x, y in [(.475, .475), (23.525, .475), (23.525, 21.525), (.475, 21.525)]:
    poly.Append(p.FromMM(x), p.FromMM(y))
b.Add(z)
configure(p, b, dst, src.with_suffix('.kicad_pro'))
ds = b.GetDesignSettings()
ds.m_MicroViasMinSize = p.FromMM(.25)
ds.m_MicroViasMinDrill = p.FromMM(.1)
ds.m_HasStackup = True
pro = dst.with_suffix('.kicad_pro')
settings = json.loads(pro.read_text())
settings['board']['design_settings']['rules'].update({
    'min_microvia_diameter': .25, 'min_microvia_drill': .1})
settings['board']['design_settings']['rule_severities'] = {'microvia_drill_out_of_range': 'error'}
pro.write_text(json.dumps(settings, indent=2))
dst.with_suffix('.kicad_dru').write_text('''(version 1)
(rule "Filled laser microvia annulus"
  (condition "A.Type == 'Via' && A.Via_Type == 'Micro'")
  (constraint annular_width (min 0.075mm)))
(rule "Contained filled laser hole to foreign copper"
  (condition "(A.Type == 'Via' && A.Via_Type == 'Micro') || (B.Type == 'Via' && B.Via_Type == 'Micro')")
  (constraint hole_clearance (min 0.200mm)))
''')
b.BuildConnectivity()
p.ZONE_FILLER(b).Fill(b.Zones())
p.SaveBoard(str(dst), b)

# Native stackup is not exposed fully by the SWIG wrapper; author its schema,
# then reload through pcbnew before any connectivity or manufacturing check.
tree = loads(dst.read_text())
setup = child(tree, 'setup')
setup[:] = [q for q in setup if not isinstance(q, list) or q[0] != 'stackup']
stack = ['stackup']
for name, thickness, kind in [('F.Cu', .035, 'copper'), ('dielectric 1', .08, 'prepreg'),
                              ('In1.Cu', .035, 'copper'), ('dielectric 2', .70, 'core'),
                              ('In2.Cu', .035, 'copper'), ('dielectric 3', .08, 'prepreg'),
                              ('B.Cu', .035, 'copper')]:
    layer = ['layer', name, ['type', kind], ['thickness', str(thickness)]]
    if kind != 'copper':
        layer += [['material', 'FR4'], ['epsilon_r', '4.2'], ['loss_tangent', '0.02']]
    stack.append(layer)
stack += [['copper_finish', 'ENIG'], ['dielectric_constraints', 'yes']]
setup.append(stack)
for q in tree:
    if isinstance(q, list) and q[0] == 'via' and 'micro' in q:
        q += [['filling', 'yes'], ['capping', 'yes'], ['tenting', 'front', 'back']]
dst.write_text(dumps(tree) + '\n')
b = p.LoadBoard(str(dst))
b.BuildConnectivity()
p.ZONE_FILLER(b).Fill(b.Zones())
p.SaveBoard(str(dst), b)
drc = OUT / 'verification/usb-v26-HDI-ground-drc.json'
cli = ROOT / 'work/v24/tools/kicad/bin/kicad-cli.exe'
run = subprocess.run([str(cli), 'pcb', 'drc', '--format', 'json', '-o', str(drc), str(dst)],
                     capture_output=True, text=True)
report = json.loads(drc.read_text())
record = {
    'sourceSHA256': hashlib.sha256((OUT.parent / 'electrical/native-components.json').read_bytes()).hexdigest(),
    'input': str(src), 'board': str(dst), 'boardSHA256': hashlib.sha256(dst.read_bytes()).hexdigest(),
    'microvia': {'ref': 'U1401', 'pin': 'B2', 'net': 'GND', 'xyMm': [p.ToMM(ball.GetPosition().x), p.ToMM(ball.GetPosition().y)],
                 'diameterMm': .25, 'drillMm': .1, 'layers': ['F.Cu', 'In1.Cu'],
                 'filledAndCapped': True, 'outerDielectricMm': .08, 'laserAspectRatio': .8},
    'process': '4-layer 1.0mm 1+2+1 HDI; copper-filled and capped F-In1 laser via',
    'processReference': 'https://jlcpcb.com/help/article/hdi-pcb-capabilities-faq',
    'scopedLaserRules': {'annularMinMm': .075, 'holeToForeignCopperMinMm': .2,
                        'copperToCopperMinMmUnchanged': .15,
                        'mechanicalThroughHoleRulesUnchanged': True,
                        'justification': 'Filled/capped laser hole lies within its copper land; .075 annulus is the published HDI minimum. Hole-to-copper .200 is an explicit engineering laser-process assumption, not a waived violation; actual .235 and copper-to-copper .160.'},
    'marketProcessAssumptionNotPurchaseApproval': True,
    'stackupCopperThicknessesMm': [.035] * 4, 'stackupDielectricThicknessesMm': [.08, .70, .08],
    'violations': report['violations'], 'unconnected': report['unconnected_items'],
    'ignoredChecks': report.get('ignored_checks', []), 'productionApproved': False,
    'camGate': 'DEFERRED_UNTIL_FL1501_LAND_PIN_ECO_AND_FINAL_PARITY',
    'cliExitCode': run.returncode, 'cliOutput': run.stdout + run.stderr}
(OUT / 'verification/usb-v26-HDI-ground.json').write_text(json.dumps(record, indent=2))
print(json.dumps({k: v for k, v in record.items() if k not in ('violations', 'unconnected')}, indent=2))
print('Native violations:', len(report['violations']), 'unconnected:', len(report['unconnected_items']))
