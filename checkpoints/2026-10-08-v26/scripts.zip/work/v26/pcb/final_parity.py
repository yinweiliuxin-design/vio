"""Compare saved PCB pads with current JSON and native schematic export."""
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:
    os.environ[name]=str(WORK/folder)
import pcbnew as p
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
sourcepath=ROOT/'outputs/SmartVio-V26-Engineering/electrical/native-components.json'
source={c['ref']:c for c in json.loads(sourcepath.read_text(encoding='utf-8-sig'))}
mapping=json.loads((OUT/'footprint-map.json').read_text())
state=json.loads((WORK/'delivery-final-state.json').read_text())
harnesspath=OUT/'proposed-harness.json'
harness={ref:pair['pins'] for pair in json.loads(harnesspath.read_text()) for ref in pair['pair']}
def schematic(path):
    root=ET.parse(path).getroot()
    refs={c.attrib['ref'] for c in root.findall('./components/comp')}
    pins={}
    for net in root.findall('./nets/net'):
        name=net.attrib['name']
        if name.startswith('unconnected-'):continue
        for node in net.findall('node'):
            ref=node.attrib['ref'];number=node.attrib['pin']
            number=mapping.get(ref,{}).get('pinAliases',{}).get(number,number)
            pins[(ref,number)]=name
    return refs,pins
currentexport=OUT/'verification/SmartVio-current-export.net'
schrefs,schpins=schematic(currentexport)
sourcepins={}
for ref,c in source.items():
    for pin in c['pins']:
        if pin['net']:
            number=mapping.get(ref,{}).get('pinAliases',{}).get(pin['number'],pin['number'])
            sourcepins[(ref,number)]=pin['net']
sourceexportdiff=[{'ref':k[0],'pin':k[1],'source':sourcepins.get(k),'schematic':schpins.get(k)}
                  for k in sorted(set(sourcepins)|set(schpins)) if sourcepins.get(k)!=schpins.get(k)]
report={'sourcePath':str(sourcepath.resolve()),'sourceSHA256':sha(sourcepath),
        'routeBasisSourceSHA256':state['routeBasisSourceSHA256'],'routeContractsUnmodified':True,
        'currentSchematicExportPath':str(currentexport.resolve()),'currentSchematicExportSHA256':sha(currentexport),
        'sourceComponents':len(source),'currentSchematicRefs':len(schrefs),
        'sourceExportPinNetDifferences':sourceexportdiff,'sourceExportReferenceDifferences':sorted(set(source)^schrefs),
        'boards':[],'productionApproved':False}
for item in state['boards']:
    path=OUT/item['board'];b=p.LoadBoard(str(path.resolve()))
    fps={f.GetReference():f for f in b.GetFootprints()}
    if item['kind']=='power':
        exp=OUT/'verification/PowerPrototype-export-final.net';refs,pins=schematic(exp)
    else:
        exp=currentexport;refs,pins=schrefs,schpins
    selected=set(fps)&refs;actual={};fpiddiff=[];valuediff=[]
    for ref,f in fps.items():
        expected=mapping.get(ref,{}).get('id');fid=str(f.GetFPID().GetUniStringLibId())
        if expected and fid!=expected:fpiddiff.append({'ref':ref,'map':expected,'board':fid})
        if ref in source and f.GetValue()!=source[ref]['value']:
            valuediff.append({'ref':ref,'source':source[ref]['value'],'board':f.GetValue()})
        for pad in f.Pads():
            if pad.GetNumber():actual.setdefault((ref,pad.GetNumber()),set()).add(pad.GetNetname() or None)
    differences=[]
    for key,net in pins.items():
        if key[0] in selected and actual.get(key)!={net}:
            differences.append({'ref':key[0],'pin':key[1],'schematic':net,'board':sorted(actual.get(key,set()),key=str)})
    for key,nets in actual.items():
        if key[0] in selected and nets!={None} and nets!={pins.get(key)} and not any(d['ref']==key[0] and d['pin']==key[1] for d in differences):
            differences.append({'ref':key[0],'pin':key[1],'schematic':pins.get(key),'board':sorted(nets,key=str)})
    harnessdiff=[{'ref':ref,'pin':number,'expected':net,'actual':sorted(actual.get((ref,number),set()),key=str)}
                 for ref in set(fps)&set(harness) for number,net in harness[ref].items() if actual.get((ref,number))!={net}]
    report['boards'].append({'kind':item['kind'],'boardPath':str(path.resolve()),'boardSHA256':sha(path),
        'schematicExportPath':str(exp.resolve()),'schematicExportSHA256':sha(exp),'sourceRefsCompared':len(selected),
        'connectedSchematicPinsCompared':sum(k[0] in selected for k in pins),'pinNetDifferences':differences,
        'footprintIdDifferences':fpiddiff,'valueDifferences':valuediff,
        'candidateHarnessDifferences':harnessdiff,'candidateHarnessContractPath':str(harnesspath.resolve()),
        'candidateHarnessContractSHA256':sha(harnesspath),'candidateHarnessRefsNotInOriginalCapture':sorted(set(fps)-refs),
        'note':'Body-only missing pads remain failures. Extra candidate harnesses are not in original capture; their net mapping is separate.'})
path=OUT/'verification/current-native-parity.json'
path.write_text(json.dumps(report,indent=2))
print(json.dumps({'sourceSHA256':report['sourceSHA256'],'sourceExportDifferences':len(sourceexportdiff),
                  'boards':[{'kind':q['kind'],'pinNetDifferences':len(q['pinNetDifferences']),'footprintIdDifferences':len(q['footprintIdDifferences'])} for q in report['boards']]},indent=2))
