"""Create a fresh routing candidate without changing placement, nets or manufacturer lands."""
import argparse
import copy
import shutil
from main_ast import *

ap = argparse.ArgumentParser()
ap.add_argument('board', type=Path)
ap.add_argument('--name', required=True)
a = ap.parse_args()
assert a.board.resolve().is_relative_to(DEST.resolve())
before = read(a.board)
removed = [q for q in before if key(q) in ['segment', 'arc', 'via']]
after = [copy.deepcopy(q) for q in before if key(q) not in ['segment', 'arc', 'via']]
for zone in kids(after, 'zone'):
    zone[:] = [q for q in zone if key(q) != 'filled_polygon']
expected = copy.deepcopy(before)
expected[:] = [q for q in expected if key(q) not in ['segment', 'arc', 'via']]
for zone in kids(expected, 'zone'):
    zone[:] = [q for q in zone if key(q) != 'filled_polygon']
assert expected == after
dst = DEST / (a.name + '.kicad_pcb')
assert not dst.exists(), 'Preserve prior routing evidence'
write(dst, after)
for ext in ['.kicad_pro', '.kicad_dru']:
    shutil.copyfile(a.board.with_suffix(ext), dst.with_suffix(ext))
record = {'sourceSHA256': sha(OUT.parent / 'electrical/native-components.json'),
          'inputBoardSHA256': sha(a.board), 'boardSHA256': sha(dst),
          'onlySeedCopperAndCachedFillRemoved': True,
          'removedCopperItems': len(removed), 'placementAndLandsPreserved': True,
          'productionApproved': False}
dst.with_suffix('.restart.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record, indent=2))
