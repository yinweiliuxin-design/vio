"""Create schematic-compatible footprint map and independently compare exported nets."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
mapping=json.loads((OUT/'final-292/footprint-review.json').read_text())
result={}
for r,m in mapping.items():
    result[r]={'id':m['footprint'],'sourceId':m.get('source'),'source':m.get('source'),
               'review':m['review'],'manufacturerLandPatternApproved':False,'physicalFitApproved':False,
               'placement':'CANDIDATE_'+m['board'].upper(),'padSetMatches':not m.get('missingPhysicalPads'),
               'missingPads':m.get('missingPhysicalPads',[]),'extraPads':m.get('extraPhysicalPads',[]),
               'pinAliases':m.get('pinAliases',{}),'heightMaxMm':m.get('heightMaxMm'),
               'release':'HOLD','note':'Reviewed geometry is not a manufacturing signoff; see footprint-review.json.'}
if 'R691' not in result:
    result['R691']={'id':'SmartVioV25:R_0603_1608Metric','review':'RESERVED_FOR_PENDING_DUAL_I2S_NET_ADDITION',
                    'manufacturerLandPatternApproved':False,'physicalFitApproved':False,'pinAliases':{},'release':'HOLD'}
result['Q1201']['review']='PMV30UN2R_PIN123_PACKAGE_CONFIRMED_EXISTING_GENERIC_SOT23_GEOMETRY_RETAINED'
result['Q1201']['geometryChangeApplied']=False
result['J401']['id']='SmartVioV25:GCT_USB4120_Official_A6'
result['J401']['review']='OFFICIAL_A6_PHYSICAL_LAND_CORRECTION_APPLIED_EXPLICITLY; SEE_USB_LAND_UPDATE'
result['J401']['geometryChangeApplied']=True
result['J401']['priorIdRetainedInOldBoards']='SmartVioV25:GCT_USB4120_03_C_DRAWING_A6'
for ref in ('K1201','K1202','K1203','K1204','K1205','K1206','K1207'):
    result[ref]['review']='OFFICIAL_PAD_CENTERS_SIZES_MATCH; STOCK_ROUNDRECT_CORNERS_RETAINED_PENDING_REVIEW'
    result[ref]['officialAlternative']='SmartVio_Audio_Official:Panasonic_SSOP4_PhotoMOS_Official'
    result[ref]['geometryChangeApplied']=False
for ref in ('D1201','D1202','D1203','D1204','D1205','D1206','D1207'):
    result[ref]['review']='TI_DPY_X1SON_PIN12_SOURCE_CORRECTED; OLD_LAND_MISMATCH_HOLD'
    result[ref]['officialAlternative']='Controls_Protection_Official:TI_DPY0002A_1x0.6mm_P0.7mm_NSMD'
    result[ref]['geometryChangeApplied']=False
    result[ref]['note']='DPY is X1SON, not X2SON. Pin 1 signal, pin 2 local ground. Retained copper pads 0.4x0.65 differ from official proposal 0.3x0.5 at +/-0.35. Do not shrink silently in routed board; next exact ECO is recorded in verification/controls-land-eco.json.'
for r in ('JP1','JP2','JP3'):
    result[r]={'id':'SmartVioV25:PROTO_'+r,'review':'EXPLICIT_TEST_ENDPOINT_NOT_CATALOG_CONNECTOR',
               'manufacturerLandPatternApproved':False,'physicalFitApproved':False,'pinAliases':{},'release':'HOLD'}
(OUT/'footprint-map.json').write_text(json.dumps(result,indent=2))
placement_check=json.loads((OUT/'verification/placement-check.json').read_text())
(OUT/'verification/unplaced.json').write_text(json.dumps(placement_check['unplaced'],indent=2))
contract=OUT/'verification/power-prototype-final-contract.json'
export=OUT/'verification/PowerPrototype-export-final.net'
if contract.exists() and export.exists():
    rec=json.loads(contract.read_text());actual=rec['pins'];sch={};diff=[]
    root=ET.parse(export).getroot()
    for net in root.findall('./nets/net'):
        name=net.attrib['name']
        if name.startswith('unconnected-'):continue
        for node in net.findall('node'):
            ref=node.attrib['ref'];pin=node.attrib['pin'];pin=mapping.get(ref,{}).get('pinAliases',{}).get(pin,pin)
            sch[(ref,pin)]=name
    for ref,pads in actual.items():
        for pin,name in pads.items():
            if name and sch.get((ref,pin))!=name:diff.append({'ref':ref,'pin':pin,'board':name,'schematic':sch.get((ref,pin))})
    for (ref,pin),name in sch.items():
        if actual.get(ref,{}).get(pin)!=name and not any(d['ref']==ref and d['pin']==pin for d in diff):diff.append({'ref':ref,'pin':pin,'board':actual.get(ref,{}).get(pin),'schematic':name})
    summary={'board':rec['board'],'boardSHA256':rec['boardSHA256'],'schematicExportSHA256':hashlib.sha256(export.read_bytes()).hexdigest(),
             'pcbRefs':len(actual),'schematicRefs':len(root.findall('./components/comp')),'connectedSchematicPins':len(sch),
             'differences':diff,'sourcePinDifferences':rec['sourcePinDifferences'],
             'comparison':'Native schematic-export connected pin/net graph against native PCB pad graph; EP aliases explicit; netless mechanical pads ignored.'}
    (OUT/'verification/power-prototype-schematic-parity.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
print('Footprint map ready:',OUT/'footprint-map.json')
