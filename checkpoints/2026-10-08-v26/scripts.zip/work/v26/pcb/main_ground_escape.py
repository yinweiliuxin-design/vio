"""Short main-board ground-pad escapes to already filled reference copper, followed by external native DRC."""
import argparse
from collections import deque
import math
import os
import shutil
import uuid as uid
import numpy as np
from PIL import Image,ImageDraw
from main_ast import *
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);ap.add_argument('--name',required=True);a=ap.parse_args()
b=p.LoadBoard(str(a.board.resolve()));tree=read(a.board);original=read(a.board);L=list(b.GetEnabledLayers().CuStack())
SCALE=20;W=1441;H=781;WIDTH=.2;VIA=.35;DRILL=.15;CLEAR=.15;MARGIN=.04
xy=lambda q:(p.ToMM(q.x),p.ToMM(q.y))
point=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
pads={str(d.m_Uuid.AsString()):d for f in b.GetFootprints() for d in f.Pads()}
drc=json.loads((OUT/'verification'/(a.board.stem+'-strict-drc.json')).read_text())
targetids={i['uuid'] for q in drc['unconnected_items'] for i in q['items'] if i['uuid'] in pads and pads[i['uuid']].GetNetname()=='GND'}
zones=[z for z in b.Zones() if z.GetNetname()=='GND' and not z.GetIsRuleArea()]

def mask(extra,all_pads=False):
    ims=[Image.new('1',(W,H),0) for _ in L];draws=[ImageDraw.Draw(im) for im in ims]
    def circle(draw,x,y,r):draw.ellipse(((x-r)*SCALE,(y-r)*SCALE,(x+r)*SCALE,(y+r)*SCALE),fill=1)
    for draw in draws:draw.rectangle((0,0,W-1,H-1),outline=1,width=math.ceil((.25+extra)*SCALE))
    for t in b.GetTracks():
        if t.GetNetname()=='GND':continue
        x,y=xy(t.GetStart());xx,yy=xy(t.GetEnd());via=isinstance(t,p.PCB_VIA)
        r=p.ToMM(t.GetWidth(p.F_Cu) if via else t.GetWidth())/2+extra
        for layer,draw in zip(L,draws):
            if not via and t.GetLayer()!=layer:continue
            draw.line((x*SCALE,y*SCALE,xx*SCALE,yy*SCALE),fill=1,width=math.ceil(2*r*SCALE));circle(draw,x,y,r);circle(draw,xx,yy,r)
    for pad in pads.values():
        if not all_pads and pad.GetNetname()=='GND':continue
        x,y=xy(pad.GetPosition());ww=p.ToMM(pad.GetSize().x)/2+extra;hh=p.ToMM(pad.GetSize().y)/2+extra;angle=math.radians(pad.GetOrientationDegrees())
        corners=[((x+u*math.cos(angle)+v*math.sin(angle))*SCALE,(y-u*math.sin(angle)+v*math.cos(angle))*SCALE) for u,v in [(-ww,-hh),(ww,-hh),(ww,hh),(-ww,hh)]]
        for layer,draw in zip(L,draws):
            if pad.IsOnLayer(layer):draw.polygon(corners,fill=1)
    for owner in [b,*b.GetFootprints()]:
        for z in owner.Zones():
            if not z.GetIsRuleArea():continue
            for layer,draw in zip(L,draws):
                if not z.GetLayerSet().Contains(layer):continue
                if not (z.GetDoNotAllowTracks() or z.GetDoNotAllowVias()):continue
                for i in range(z.Outline().OutlineCount()):
                    poly=z.Outline().Outline(i);coords=[tuple(v*SCALE for v in xy(poly.CPoint(j))) for j in range(poly.PointCount())]
                    draw.polygon(coords,fill=1);draw.line(coords+[coords[0]],fill=1,width=math.ceil(extra*2*SCALE))
    return np.stack([np.asarray(im,dtype=bool) for im in ims])
blocked=mask(CLEAR+WIDTH/2+MARGIN)
viablocked=np.any(mask(CLEAR+VIA/2+MARGIN),axis=0)
# Conventional drilled via stays off every SMD copper pad, including same-net pads.
viablocked |= np.any(mask(VIA/2+.025,True),axis=0)
hole_image=Image.new('1',(W,H),0);hd=ImageDraw.Draw(hole_image)
for t in b.GetTracks():
    if isinstance(t,p.PCB_VIA):
        x,y=xy(t.GetPosition());r=p.ToMM(t.GetDrill())/2+DRILL/2+.25+MARGIN
        hd.ellipse(((x-r)*SCALE,(y-r)*SCALE,(x+r)*SCALE,(y+r)*SCALE),fill=1)
for pad in pads.values():
    if pad.GetDrillSize().x:
        x,y=xy(pad.GetPosition());r=p.ToMM(pad.GetDrillSize().x)/2+DRILL/2+.25+MARGIN
        hd.ellipse(((x-r)*SCALE,(y-r)*SCALE,(x+r)*SCALE,(y+r)*SCALE),fill=1)
viablocked |= np.asarray(hole_image,dtype=bool)
records=[];fails=[];added=[]
for ident in sorted(targetids):
    pad=pads[ident];layer=next(l for l in L if pad.IsOnLayer(l));li=L.index(layer);x,y=xy(pad.GetPosition());start=(round(x*SCALE),round(y*SCALE))
    if blocked[li,start[1],start[0]]:fails.append({'uuid':ident,'reason':'conservative trace clearance mask obstructs pin escape'});continue
    queue=deque([start]);prev={start:None};goal=None
    while queue:
        q=queue.popleft();xx,yy=q
        if not viablocked[yy,xx] and any(z.HitTestFilledArea(l,point(xx/SCALE,yy/SCALE)) for z in zones for l in L[1:-1] if z.IsOnLayer(l)):
            goal=q;break
        for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
            n=(xx+dx,yy+dy)
            if n in prev or not(0<=n[0]<W and 0<=n[1]<H):continue
            if math.dist(start,n)>3*SCALE or blocked[li,n[1],n[0]]:continue
            if dx and dy and (blocked[li,yy,n[0]] or blocked[li,n[1],xx]):continue
            prev[n]=q;queue.append(n)
    if goal is None:fails.append({'uuid':ident,'reason':'no off-pad reference-plane via site within3mm'});continue
    route=[goal]
    while prev[route[-1]] is not None:route.append(prev[route[-1]])
    route.reverse();corners=[route[0]]
    for i in range(1,len(route)-1):
        u,v,w=route[i-1:i+2]
        if (v[0]-u[0],v[1]-u[1])!=(w[0]-v[0],w[1]-v[1]):corners.append(v)
    corners.append(route[-1]);points=[(x,y)]+[(u/SCALE,v/SCALE) for u,v in corners];created=[]
    for u,v in zip(points,points[1:]):
        if u==v:continue
        q=[S('segment'),[S('start'),*u],[S('end'),*v],[S('width'),WIDTH],[S('layer'),p.LayerName(layer)],[S('net'),'GND'],[S('uuid'),str(uid.uuid4())]]
        added.append(q);created.append(uuid(q))
    gx,gy=goal[0]/SCALE,goal[1]/SCALE
    q=[S('via'),[S('at'),gx,gy],[S('size'),VIA],[S('drill'),DRILL],[S('layers'),'F.Cu','B.Cu'],[S('net'),'GND'],[S('uuid'),str(uid.uuid4())]]
    added.append(q);created.append(uuid(q));records.append({'padUUID':ident,'ref':pad.GetParentFootprint().GetReference(),'pin':pad.GetNumber(),'viaXY':[gx,gy],'addedUUIDs':created})
    for yy in range(max(0,goal[1]-9),min(H,goal[1]+10)):
        for xx in range(max(0,goal[0]-9),min(W,goal[0]+10)):
            if math.dist((xx,yy),goal)<(.25+DRILL+MARGIN)*SCALE:viablocked[yy,xx]=True
tree.extend(added);assert not audit(original,tree);dst=DEST/(a.name+'.kicad_pcb');write(dst,tree)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(a.board.with_suffix(ext),dst.with_suffix(ext))
dst.with_suffix('.ground-escape.json').write_text(json.dumps({'inputSHA256':sha(a.board),'outputSHA256':sha(dst),'sourceSHA256':sha(OUT.parent/'electrical/native-components.json'),'traceWidthMm':WIDTH,'viaDiameterMm':VIA,'drillMm':DRILL,'addedEscapes':records,'failedEscapes':fails,'originalNetGeometryPreserved':True,'nativeDRCRequired':True,'productionApproved':False},indent=2))
print(json.dumps({'groundEscapes':len(records),'failed':len(fails),'output':str(dst)}))
