"""Refresh all footprint-map entries from actual current native inventories and compare net assignments."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work';PACK=OUT.parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
sourcepath=PACK/'electrical/native-components.json';source={c['ref']:c for c in json.loads(sourcepath.read_text(encoding='utf-8-sig'))}
expected_sha=json.loads((PACK/'audit/system-v26/native-revision.json').read_text())['sha256']
assert sha(sourcepath)==expected_sha
oldpath=OUT/'footprint-map.json';old=json.loads(oldpath.read_text())
archive=OUT/'verification/footprint-map-before-final-refresh.json'
if not archive.exists():shutil.copyfile(oldpath,archive)
reviews=json.loads((OUT/'footprint-review.json').read_text())
selection={q['libraryId']:q for q in json.loads((PACK/'audit/selection/footprint-sources.json').read_text())}
passives=json.loads((PACK/'audit/passive-closure/footprint-index.json').read_text())['source']
early={q['ref']:q for q in json.loads((PACK/'audit/passive-closure/land-handoff.json').read_text())['entries']}
eco={q['ref']:q for q in json.loads((OUT/'verification/v26-eco-manufacturer-lands.json').read_text())}
inventories=[json.loads((OUT/'verification'/('final-inventory-'+kind+'.json')).read_text()) for kind in ['main','usb','audio','cover','sensor']]
actual={f['ref']:(board,f) for board in inventories for f in board['footprints']}
assert len(actual)==sum(len(b['footprints']) for b in inventories),'Reference duplicated across boards'
harness={ref:record['pins'] for record in json.loads((OUT/'proposed-harness.json').read_text()) for ref in record['pair']}
mapping={};differences=[];package_updates=[];geometry_sources=[]
for ref in sorted(set(source)|set(actual)):
    c=source.get(ref);prior=old.get(ref,{})
    if ref not in actual:
        assert ref=='RT1921',('Current source component has no physical board assignment',ref)
        mapping[ref]={'id':None,'mpn':c.get('mpn'),'value':c['value'],'package':c.get('package'),
          'board':'external-battery-surface','placement':'EXTERNAL_INSULATED_THERMISTOR_HARNESS',
          'physicalPads':[],'expectedPinNumbers':[p['number'] for p in c['pins']],'padSetMatches':None,
          'missingPads':[],'extraPads':[],'pinAliases':{},'landSource':None,'source':c['pins'][0].get('evidence'),
          'sourceSHA256':expected_sha,'captureFootprintField':None,'captureFieldResolution':'INTENTIONALLY_EXTERNAL_NO_PCB_FOOTPRINT',
          'review':'External Semitec bead is bonded to battery, connected through real J1921 pads; adhesive/insulation/thermal qualification HOLD',
          'productionApproved':False,'physicalFitApproved':False,'release':'HOLD'}
        continue
    board,f=actual[ref];pads=f['pads'];numbers={p['number'] for p in pads if p['number']}
    assert f['libraryFileExists'],('Unresolvable Footprint field',ref,f['id'])
    aliases={};expected={};pinroles={}
    if c:
        for pin in c['pins']:
            n=pin['number'];mapped=pin.get('footprintPad') or n
            if mapped not in numbers and prior.get('pinAliases',{}).get(n) in numbers:mapped=prior['pinAliases'][n]
            if mapped!=n:aliases[n]=mapped
            expected[mapped]=pin['net'] or None;pinroles[mapped]=pin.get('nativeName',pin['name'])
    else:expected=harness[ref]
    missing=sorted(set(expected)-numbers);extra=sorted(numbers-set(expected))
    nets={n:{p['net'] for p in pads if p['number']==n} for n in numbers}
    for n in sorted(set(expected)|numbers):
        if nets.get(n,set())!={expected.get(n)}:
            differences.append({'ref':ref,'pin':n,'expected':expected.get(n),'actual':sorted(nets.get(n,set()),key=str)})
    evidence=None;height=None;scope='LIBRARY_CANDIDATE_NOT_MANUFACTURER_LAND_SIGNOFF'
    if f['id'] in selection:
        spec=selection[f['id']];evidence=spec['evidence'];height=spec.get('nominalEnvelopeMm',[None,None,None])[2]
        scope='OFFICIAL_SOURCE_LAND_OR_REFERENCE_GEOMETRY_REVIEWED_NOT_APPLICATION_APPROVED'
    elif c and c.get('mpn') in passives:
        spec=passives[c['mpn']];evidence=spec['evidence'];height=spec['body_lwh_max_mm'][2]
        scope='MANUFACTURER_PASSIVE_LAND_REVIEWED_APPLICATION_AND_EFFECTIVE_CAPACITANCE_HOLD'
    elif ref in early:
        spec=early[ref];evidence=spec.get('evidence',spec.get('land_evidence'));height=spec['body_lwh_max_mm'][2];scope='MANUFACTURER_LAND_HANDOFF_OR_UNSELECTED_CANDIDATE_APPLICATION_HOLD'
    elif ref in eco:
        evidence=eco[ref];height=eco[ref]['heightMaxMm'];scope='OFFICIAL_TI_PACKAGE_LAND_REVIEWED'
    elif c and c.get('footprintProposal') and ref.startswith('D120'):
        evidence=c['footprintProposal']['evidence'];height=.45;scope='OFFICIAL_TI_DPY0002A_NUMERIC_LAND_CHECK_REQUIRED'
    elif reviews.get(ref,{}).get('footprint')==f['id']:
        evidence=reviews[ref].get('source');height=reviews[ref].get('heightMaxMm');scope=reviews[ref].get('review',scope)
    if height is None:height=prior.get('heightMaxMm')
    if ref=='J501':
        assert c['mpn']=='S3B-PH-SM4-TB(LF)(SN)'
        evidence=c['evidence'];height=5.5;scope='JST_OFFICIAL_DRAWING_DERIVED_LAND_REVIEWED_ENGINEERING_NOT_ASSEMBLY_RELEASE'
    fabricated=('WirePads' in f['id'] or ref in harness)
    if fabricated:
        evidence={'type':'FABRICATED_PCB_FEATURE','libraryFile':f['libraryFile'],'fileSHA256':f['libraryFileSHA256'],
                  'definition':'Actual copper solder endpoints; no paste apertures, not a purchased socket or body-only proxy'}
        height=None;scope='REAL_FABRICATED_COPPER_SOLDER_PADS_HARNESS_ASSEMBLY_HOLD'
    entry={'id':f['id'],'mpn':c.get('mpn') if c else None,'manufacturer':c.get('manufacturer') if c else None,
      'value':c['value'] if c else f['value'],'package':c.get('package') if c else 'fabricated candidate internal harness pads',
      'source':evidence,'sourceId':f['id'],'landSource':{'libraryFile':f['libraryFile'],'libraryFileSHA256':f['libraryFileSHA256'],'evidence':evidence},
      'sourceSHA256':expected_sha,'board':board['kind'],'boardPath':board['boardPath'],'boardSHA256':board['boardSHA256'],
      'placement':'CANDIDATE_'+board['kind'].upper(),'xyMm':f['xyMm'],'side':f['side'],'orientationDegrees':f['orientationDegrees'],
      'heightMaxMm':height,'heightQualification':'Manufacturer maximum where cited; selection nominal is not a guaranteed maximum' if ref in ['J501','J102','J201','J202','J301'] else 'Source dimension or retained candidate budget; assembly HOLD',
      'courtyardBBoxMm':f['courtyardBBoxMm'],'physicalPadNumbers':sorted(numbers),'physicalPads':pads,
      'expectedPhysicalPadNumbers':sorted(expected),'padSetMatches':not missing and not extra,
      'missingPads':missing,'extraPads':extra,'missingPhysicalPads':missing,'extraPhysicalPads':extra,
      'pinAliases':aliases,'pinRoles':pinroles,'captureFootprintField':f['id'],
      'captureFieldResolution':'LIBRARY_FILE_EXISTS_AND_NATIVE_BOARD_PARSE_VALID',
      'review':scope,'fabricatedPcbFeature':fabricated,'manufacturerLandPatternApproved':False,
      'physicalFitApproved':False,'applicationApproved':False,'productionApproved':False,'release':'HOLD',
      'note':'Actual saved native pad inventory. Land evidence is not manufacturing, assembly, return-path, EMC or circuit approval.'}
    mapping[ref]=entry
    if c and c.get('footprint')!=f['id']:package_updates.append({'ref':ref,'previousCaptureFootprint':c.get('footprint'),'actualFootprint':f['id']})
    if missing or extra:geometry_sources.append({'ref':ref,'missing':missing,'extra':extra})
oldpath.write_text(json.dumps(mapping,indent=2)+'\n')
currentexport=PACK/'verification/native-netlist.xml';xml=ET.parse(currentexport).getroot()
export_footprints={e.attrib['ref']:e.findtext('footprint','') for e in xml.findall('./components/comp')}
capture_updates=[{'ref':ref,'actualExportFootprint':export_footprints.get(ref),
                  'expectedCurrentFootprint':mapping[ref].get('id') or ''}
                 for ref in source if export_footprints.get(ref)!=(mapping[ref].get('id') or '')]
exportrefs={e.attrib['ref'] for e in xml.findall('./components/comp')};exportpins={}
for net in xml.findall('./nets/net'):
    if net.attrib['name'].startswith('unconnected-'):continue
    for node in net.findall('node'):
        ref=node.attrib['ref'];number=node.attrib['pin'];number=mapping.get(ref,{}).get('pinAliases',{}).get(number,number)
        exportpins[(ref,number)]=net.attrib['name']
sourcepins={(ref,mapping[ref].get('pinAliases',{}).get(pin['number'],pin['number'])):pin['net'] for ref,c in source.items() for pin in c['pins'] if pin['net']}
xml_differences=[{'ref':key[0],'pin':key[1],'source':sourcepins.get(key),'xml':exportpins.get(key)} for key in sorted(set(sourcepins)|set(exportpins)) if sourcepins.get(key)!=exportpins.get(key)]
reports=[]
for b in inventories:
    selected={f['ref'] for f in b['footprints']}&set(source)
    value_dif=[{'ref':f['ref'],'source':source[f['ref']]['value'],'board':f['value']} for f in b['footprints'] if f['ref'] in source and source[f['ref']]['value']!=f['value']]
    mpn_dif=[{'ref':f['ref'],'source':source[f['ref']].get('mpn') or None,'board':f['mpnField'] or None} for f in b['footprints'] if f['ref'] in source and (source[f['ref']].get('mpn') or None)!=(f['mpnField'] or None)]
    function_dif=[{'ref':f['ref'],'pad':p['number'],'expected':mapping[f['ref']]['pinRoles'][p['number']],'actual':p['pinFunction']} for f in b['footprints'] if f['ref'] in source for p in f['pads'] if p['number'] in mapping[f['ref']]['pinRoles'] and p['pinFunction']!=mapping[f['ref']]['pinRoles'][p['number']]]
    selecteddiff=[q for q in differences if q['ref'] in selected]
    harnessdiff=[q for q in differences if q['ref'] in {f['ref'] for f in b['footprints']}-selected]
    reports.append({'kind':b['kind'],'boardPath':b['boardPath'],'boardSHA256':b['boardSHA256'],'sourceRefsCompared':len(selected),
      'pinNetDifferences':selecteddiff,'candidateHarnessDifferences':harnessdiff,'valueDifferences':value_dif,
      'mpnDifferences':mpn_dif,'pinFunctionDifferences':function_dif,'padSetDifferences':[q for q in geometry_sources if q['ref'] in selected],
      'footprintIdDifferences':[q for q in capture_updates if q['ref'] in selected],
      'footprintFilesResolvable':all(f['libraryFileExists'] for f in b['footprints']),
      'nativeSchematicParityCheck':'Actual exported native schematic Footprint fields compared to saved PCB IDs; native ERC is independently reported in electrical-check-v26.json'})
parity={'sourcePath':str(sourcepath.resolve()),'sourceSHA256':sha(sourcepath),'sourceComponents':len(source),'sourcePins':sum(len(c['pins']) for c in source.values()),
 'currentNativeExportPath':str(currentexport.resolve()),'currentNativeExportSHA256':sha(currentexport),
 'sourceExportPinNetDifferences':xml_differences,'sourceExportReferenceDifferences':sorted(set(source)^exportrefs),
 'actualPCBSourceRefs':sorted(set(actual)&set(source)),'externalSourceRefs':sorted(set(source)-set(actual)),
 'allCurrentMapEntries':len(mapping),'captureFootprintMetadataUpdatesRequired':capture_updates,
 'historicalSourceFootprintFieldsSupersededByMap':package_updates,'boards':reports,'productionApproved':False}
(OUT/'verification/current-native-parity.json').write_text(json.dumps(parity,indent=2)+'\n')
(OUT/'verification/footprint-map-refresh.json').write_text(json.dumps({'sourceSHA256':expected_sha,'entries':len(mapping),'sourceRefs':len(source),
 'obsoleteRefsRemoved':sorted(set(old)-set(mapping)),'allBoardLibraryFilesExist':all(q['footprintFilesResolvable'] for q in reports),
 'padSetDifferences':geometry_sources,'captureUpdatesRequired':capture_updates,'historicalMapPath':str(archive.resolve()),'productionApproved':False},indent=2))
print(json.dumps({'mappingEntries':len(mapping),'sourceXMLDifferences':len(xml_differences),'sourceXMLReferenceDifferences':len(set(source)^exportrefs),
 'boards':[{k:q[k] if not isinstance(q[k],list) else len(q[k]) for k in ['kind','pinNetDifferences','candidateHarnessDifferences','valueDifferences','mpnDifferences','pinFunctionDifferences','padSetDifferences']} for q in reports]},indent=2))
