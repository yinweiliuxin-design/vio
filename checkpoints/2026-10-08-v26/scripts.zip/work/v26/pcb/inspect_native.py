import argparse
import json
import os
from pathlib import Path
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'documents')
os.environ['DOCUMENTS_HOME']=str(WORK/'documents')
import pcbnew as p
parser=argparse.ArgumentParser();parser.add_argument('board',type=Path);args=parser.parse_args()
b=p.LoadBoard(str(args.board.resolve()))
fpdata=[]
for f in b.GetFootprints():
    ls=p.LSET();ls.AddLayer(p.B_CrtYd if f.IsFlipped() else p.F_CrtYd)
    box=f.GetLayerBoundingBox(ls)
    pads=[]
    for d in f.Pads():
        if not d.GetNumber():continue
        pads.append({'number':d.GetNumber(),'net':d.GetNetname(),'x':p.ToMM(d.GetPosition().x),'y':p.ToMM(d.GetPosition().y),
                     'w':p.ToMM(d.GetSize().x),'h':p.ToMM(d.GetSize().y),'angle':d.GetOrientationDegrees(),
                     'shape':str(d.GetShape()),'drill':p.ToMM(d.GetDrillSize().x)})
    fpdata.append({'ref':f.GetReference(),'value':f.GetValue(),'side':'B' if f.IsFlipped() else 'F',
                   'x':p.ToMM(f.GetPosition().x),'y':p.ToMM(f.GetPosition().y),
                   'courtyard':[p.ToMM(v) for v in (box.GetX(),box.GetY(),box.GetRight(),box.GetBottom())], 'pads':pads})
tracks=[]
for t in b.GetTracks():
    tracks.append({'kind':'via' if isinstance(t,p.PCB_VIA) else 'track','net':t.GetNetname(),'layer':b.GetLayerName(t.GetLayer()),
                   'width':p.ToMM(t.GetWidth(p.F_Cu) if isinstance(t,p.PCB_VIA) else t.GetWidth()),'start':[p.ToMM(t.GetStart().x),p.ToMM(t.GetStart().y)],
                   'end':[p.ToMM(t.GetEnd().x),p.ToMM(t.GetEnd().y)]})
bb=b.GetBoardEdgesBoundingBox()
record={'file':str(args.board),'width':p.ToMM(bb.GetWidth()),'height':p.ToMM(bb.GetHeight()),'footprints':fpdata,'tracks':tracks}
path=OUT/'verification'/(args.board.stem+'-native.json')
path.write_text(json.dumps(record,indent=2))
print(json.dumps({'file':str(path),'footprints':len(fpdata),'tracksAndVias':len(tracks)}))
