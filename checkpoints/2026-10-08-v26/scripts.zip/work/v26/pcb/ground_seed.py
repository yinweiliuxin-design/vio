"""Remove copper colliding with new ECO bodies; seed checked physical GND plane taps."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V26-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('--board',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
assert a.output.resolve().is_relative_to(OUT.resolve())
b=p.LoadBoard(str(a.board.resolve()));fps={f.GetReference():f for f in b.GetFootprints()}
mergefile=OUT/'verification'/('merge-'+a.board.stem+'.json')
if not mergefile.exists():mergefile=OUT/'verification/main-current-source-merge.json'
merge=json.loads(mergefile.read_text())
ripped=[];held=[];added=[]
for item in merge['added']:
    f=fps[item['ref']];ls=p.LSET();ls.AddLayer(p.B_CrtYd);box=f.GetLayerBoundingBox(ls);box.Inflate(p.FromMM(.2))
    for t in list(b.GetTracks()):
        if not isinstance(t,p.PCB_VIA) and t.GetLayer()!=p.B_Cu:continue
        if box.Intersects(t.GetBoundingBox()):
            ripped.append({'uuid':t.m_Uuid.AsString(),'net':t.GetNetname(),'newPart':item['ref']})
            held.append(t);b.Remove(t)
xy=lambda q:(p.ToMM(q.x),p.ToMM(q.y))
def distance_segment(q,a,z):
    dx=z[0]-a[0];dy=z[1]-a[1];den=dx*dx+dy*dy
    u=max(0,min(1,((q[0]-a[0])*dx+(q[1]-a[1])*dy)/den)) if den else 0
    return math.hypot(q[0]-a[0]-u*dx,q[1]-a[1]-u*dy)
def distance_pad(q,pad):
    x,y=xy(pad.GetPosition());r=math.radians(pad.GetOrientationDegrees());dx=q[0]-x;dy=q[1]-y
    xx=dx*math.cos(r)-dy*math.sin(r);yy=dx*math.sin(r)+dy*math.cos(r)
    return math.hypot(max(abs(xx)-p.ToMM(pad.GetSize().x)/2,0),max(abs(yy)-p.ToMM(pad.GetSize().y)/2,0))
allpads=[d for f in fps.values() for d in f.Pads()]
def legal(q):
    if not(.6<q[0]<71.4 and .6<q[1]<38.4):return False
    for d in allpads:
        if d.GetNetname()=='GND':continue
        if distance_pad(q,d)<.461:return False
    for t in b.GetTracks():
        if isinstance(t,p.PCB_VIA) and math.dist(q,xy(t.GetPosition()))<.65:return False
        if t.GetNetname()=='GND':continue
        width=p.ToMM(t.GetWidth(p.F_Cu) if isinstance(t,p.PCB_VIA) else t.GetWidth())
        if distance_segment(q,xy(t.GetStart()),xy(t.GetEnd()))<.461+width/2:return False
    return True
for f in fps.values():
    for d in f.Pads():
        if d.GetNetname()!='GND' or d.GetAttribute()!=p.PAD_ATTRIB_SMD:continue
        q=xy(d.GetPosition())
        if not legal(q):continue
        v=p.PCB_VIA(b);v.SetPosition(d.GetPosition());v.SetWidth(p.FromMM(.6));v.SetDrill(p.FromMM(.3))
        v.SetLayerPair(p.F_Cu,p.B_Cu);v.SetViaType(p.VIATYPE_THROUGH);v.SetNetCode(b.FindNet('GND').GetNetCode());b.Add(v)
        added.append({'ref':f.GetReference(),'pad':d.GetNumber(),'xyMm':q,'diameterMm':.6,'drillMm':.3,'process':'Filled and plated over GND via-in-pad; no open solder-wicking hole'})
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(a.output),b)
shutil.copyfile(a.board.with_suffix('.kicad_pro'),a.output.with_suffix('.kicad_pro'))
record={'board':str(a.output),'rippedForNewBodyCopperCollisions':ripped,'newGroundTaps':added,
        'sourceSHA256':hashlib.sha256((OUT.parent/'electrical/native-components.json').read_bytes()).hexdigest(),
        'productionApproved':False,'nativeDRCRequired':True,'criticalStrategy':'Direct checked GND via-in-pad to real existing In1/In2 pours; filled/capped fabrication explicitly required'}
(OUT/'verification'/('ground-'+a.output.stem+'.json')).write_text(json.dumps(record,indent=2))
print(json.dumps({'groundTaps':len(added),'rippedCopperForECOBodies':len(ripped),'tracksAndVias':len(list(b.GetTracks()))}))
