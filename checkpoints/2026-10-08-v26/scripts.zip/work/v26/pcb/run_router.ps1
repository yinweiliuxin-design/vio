param(
    [Parameter(Mandatory=$true)][string]$Dsn,
    [Parameter(Mandatory=$true)][string]$Ses,
    [int]$Passes=5,
    [int]$FanoutPasses=8,
    [string]$Timeout='00:10:00',
    [switch]$StrictSignalRules
)
$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$sesTarget=[IO.Path]::GetFullPath($Ses)
$workspace=[IO.Path]::GetFullPath((Join-Path $taskRoot '../../..'))
$outRoot=Join-Path $workspace 'outputs/SmartVio-V26-Engineering/pcb-work'
if(-not ($sesTarget.StartsWith($taskRoot+[IO.Path]::DirectorySeparatorChar) -or $sesTarget.StartsWith($outRoot+[IO.Path]::DirectorySeparatorChar))){throw 'SES output is outside worker ownership roots'}
$java=Join-Path $taskRoot 'java25/jdk-25.0.4.1+1-jre/bin/java.exe'
$jar=Join-Path $taskRoot 'freerouting-2.4.1.jar'
Push-Location $taskRoot
try {
    $extra=@("--router.job_timeout=$Timeout")
    if($StrictSignalRules){$extra+=@('--router.automatic_neckdown=false','--router.neck_width_um=150','--router.strict_drc=true')}
    & $java '-Djava.awt.headless=true' "-Duser.home=$taskRoot/router-home" -jar $jar --gui.enabled=false --api_server.enabled=false --mcp_server.enabled=false "--router.fanout.max_passes=$FanoutPasses" "--user_data_path=$taskRoot/router-data" @extra -da -l en -de ([IO.Path]::GetFullPath($Dsn)) -do $sesTarget -mp $Passes -mt 1
    if($LASTEXITCODE -ne 0){throw "Freerouting failed: $LASTEXITCODE"}
    if(-not (Test-Path -LiteralPath $sesTarget)){throw 'Freerouting did not produce a session'}
} finally {Pop-Location}
