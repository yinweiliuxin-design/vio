"""Read-only placement feasibility for the proposed 2A connector; no source or selected-board edits."""
import numpy as np
from main_ast import *
native=json.loads((OUT/'verification/SmartVio-main-v26-routed-4layers-native.json').read_text())
proposal=OUT.parent/'audit/selection/battery-revision/footprints/SmartVio_Battery_Revision.pretty/JST_PH_S3B_PH_SM4_TB_OfficialLand_3P.kicad_mod'
fp=read(proposal);courts=[q for q in kids(fp,'fp_line') if child(q,'layer')[1]==S('F.CrtYd')]
points=[child(q,k)[1:] for q in courts for k in ['start','end']];x=[v[0] for v in points];y=[v[1] for v in points]
size=[max(x)-min(x)+.05,max(y)-min(y)+.05];results={}
for side in ['F','B']:
    candidates=[];ymax=24.25 if side=='F' else 38.6
    for angle in [0,90]:
        w,h=size if angle==0 else size[::-1]
        for xx in np.arange(.4+w/2,71.6-w/2+.001,.25):
            for yy in np.arange(.4+h/2,ymax-h/2+.001,.25):
                box=[xx-w/2,yy-h/2,xx+w/2,yy+h/2];hits=[];score=0
                for f in native['footprints']:
                    if f['ref']=='J501' or f['side']!=side:continue
                    q=f['courtyard']
                    if box[0]<q[2]+.05 and box[2]>q[0]-.05 and box[1]<q[3]+.05 and box[3]>q[1]-.05:
                        hits.append(f['ref']);score+=100 if f['ref'].startswith(('J','H_','U801','U901')) else 15 if f['ref'].startswith(('U','L')) else 1
                # A horizontal mating connector must sit beside an edge lane, not inside IC routing.
                edge=min(box[0],72-box[2],box[1],39-box[3]);score+=edge
                candidates.append({'side':side,'angle':angle,'xyMm':[round(float(xx),4),round(float(yy),4)],'bboxMm':box,'collidingRefs':hits,'score':score})
    candidates.sort(key=lambda q:q['score']);results[side]=[]
    for q in candidates:
        if not any(np.linalg.norm(np.array(q['xyMm'])-p['xyMm'])<3 for p in results[side]):results[side].append(q)
        if len(results[side])>=3:break
report={'sourceSHA256':sha(OUT.parent/'electrical/native-components.json'),'reviewBoardPath':native['file'],'proposalPath':str(proposal),'proposalSHA256':sha(proposal),
 'manufacturerCourtyardSizeMm':size,'options':results,'noFootprintOrSourceChangeApplied':True,
 'decision':'Not drop-in at existing J501. Local relocation required; B edge placement may reduce CAD displacement but must stay outside battery body projection and requires revised stack/mating/strain-relief approval. F options displace more power/analog parts. No pad shrink.',
 'productionApproved':False}
(DEST/'J501-2A-fit-options.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
