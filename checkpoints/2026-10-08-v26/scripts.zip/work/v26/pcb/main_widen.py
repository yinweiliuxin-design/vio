"""Repair fanout widths in a separate main candidate without relaxing native rules."""
import argparse
import copy
import shutil
from main_ast import *
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);ap.add_argument('--name',required=True);a=ap.parse_args()
tree=read(a.board);before=copy.deepcopy(tree);changed=[]
for q in kids(tree,'segment'):
    width=child(q,'width')
    if width[1]<.15:
        changed.append({'uuid':uuid(q),'net':child(q,'net')[1],'oldWidth':width[1],'newWidth':.15})
        width[1]=.15
dst=DEST/(a.name+'.kicad_pcb');write(dst,tree)
diff=audit(before,tree)
assert len(diff)==len(changed) and all(set(d['before'])==set(d['after']) and all(d['before'][k]==d['after'][k] for k in d['before'] if k!='width') for d in diff)
for ext in ['.kicad_pro','.kicad_dru']:shutil.copyfile(a.board.with_suffix(ext),dst.with_suffix(ext))
report={'inputSHA256':sha(a.board),'outputSHA256':sha(dst),'changes':changed,'onlyTrackWidthChanged':True,'nativeDRCRequired':True}
dst.with_suffix('.width-repair.json').write_text(json.dumps(report,indent=2));print(json.dumps({'changed':len(changed),'output':str(dst)}))
