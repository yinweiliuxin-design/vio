"""Atomic, topology-preserving engineering battery and connector revision."""
import copy
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
path = ROOT / 'electrical/native-components.json'
revision = ROOT / 'audit/selection/battery-revision'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before_hash = sha(path)
assert before_hash == '587358f65402f79e200a5991e694b35c95370abecb3aabd0c1c0513aa372917f'
parts = json.loads(path.read_text(encoding='utf-8'))
before = copy.deepcopy(parts)
by = {c['ref']: c for c in parts}
proposal = json.loads((revision / 'proposal.json').read_text())
assert proposal['preferred_pack']['mpn'] == '56457201020'
assert proposal['preferred_pack']['maximum_continuous_discharge_a'] == 2
topology = lambda rows: {(c['ref'],p['number']):(p['net'],p.get('footprintPad') or p['number']) for c in rows for p in c['pins']}
for replacement in json.loads((revision / 'corrected-components.proposal.json').read_text()):
    r = replacement['ref']
    assert r in ['J501','K1201','K1202']
    assert by[r]['mpn'] == ('532610371' if r == 'J501' else 'AQY221R2VY')
    replacement['selectionStatus'] = 'ADOPTED_ENGINEERING_REVISION_NOT_PRODUCTION_RELEASE'
    replacement['reviewRevision'] = 'V26-BATTERY-2A'
    replacement['previousMPN'] = by[r]['mpn']
    if 'sheet' in by[r]:
        replacement['sheet'] = by[r]['sheet']
    parts[parts.index(by[r])] = replacement
    by[r] = replacement
patch = json.loads((ROOT / 'audit/pin-closure-v26/correction-patch.json').read_text())
for operation in patch['metadata_only_changes']:
    r = operation['ref']
    assert r in ['R403','R404','R601']
    c = by[r]
    assert c['mpn'] == operation['guard']['mpn']
    assert c['value'] == operation['guard']['value']
    assert c['pins'] == operation['guard']['pins']
    c.update(operation['set_fields'])
    c['selectionStatus'] = 'EXACT_CATALOG_MPN_ENGINEERING_SELECTION_APPLICATION_HOLD'
    c['selectionEvidence'] = operation['evidence']
assert topology(before) == topology(parts)
archive = ROOT / 'audit/system-v26/native-before-battery-2A.json'
assert not archive.exists(), 'Do not overwrite the source checkpoint'
archive.write_bytes(path.read_bytes())
path.write_text(json.dumps(parts, ensure_ascii=False, indent=2), encoding='utf-8')
after_hash = sha(path)
record = {'applied':True, 'revision':'V26-BATTERY-2A', 'sourceBeforeSHA256':before_hash,
          'sourceAfterSHA256':after_hash, 'changedRefs':['J501','K1201','K1202','R403','R404','R601'],
          'pinNetDifferences':[], 'battery':proposal['preferred_pack'],
          'connector':proposal['connector_and_harness'], 'productionApproved':False,
          'normalChargeAuthorized':False, 'physicalTests':0,
          'scope':'Engineering source selection, not complete electrical/protection/stack approval. The physical board must separately match this revision.',
          'boardSyncRequired':True,
          'remaining':['Pack R/T and sensor return proof', 'Charge current/termination/time matching',
                       'Real system current and transients', '2A connector height and mating clearance',
                       'Full under-board battery separation and stack', 'Headphone short-current and surge coordination']}
(ROOT/'audit/system-v26/battery-revision-merge.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'audit/system-v26/native-revision.json').write_text(json.dumps({'parts':len(parts),'pins':sum(len(c['pins']) for c in parts),'sha256':after_hash},indent=2))
assembly={'sourceSHA256':after_hash,'productionApproved':False,'engineeringSelection':True,
          'items':[{'ref':'BATT1','mpn':'56457201020','manufacturer':'VARTA','qty':1},
                   {'ref':'J501','mpn':'S3B-PH-SM4-TB(LF)(SN)','manufacturer':'JST','qty':1,'includedInPCBBOM':True},
                   {'ref':'H-BAT-HOUSING','mpn':'PHR-3','manufacturer':'JST','qty':1},
                   {'ref':'H-BAT-CONTACT','mpn':'SPH-002T-P0.5S','manufacturer':'JST','qty':3}],
          'wireAssignment':proposal['connector_and_harness']['pin_map'],
          'note':'VARTA pack has bare leads. JST housing/contact crimp is an internal controlled assembly, not a factory-fitted VARTA plug. Do not order both old and new pack BOMs.'}
(ROOT/'manufacturing-v26/power-pack-BOM-V26.json').write_text(json.dumps(assembly,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'sourceBeforeSHA256':before_hash,'sourceAfterSHA256':after_hash,'changedRefs':record['changedRefs']}))
