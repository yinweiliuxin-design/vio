$ErrorActionPreference = 'Stop'
$root = '.'
Set-Location -LiteralPath $root
$out = Join-Path $root 'outputs/SmartVio-V26-Engineering/audit/vcap-review-v26'
$evidence = Join-Path $out 'evidence'
New-Item -ItemType Directory -Force -Path $evidence | Out-Null
$items = @(
    @{id='DS12110-Rev11'; url='https://www.st.com/resource/en/datasheet/stm32h743vi.pdf'; local='outputs/SmartVio-V26-Engineering/audit/power-closure-v26/sources/STM32H743.pdf'; name='DS12110-Rev11.pdf'; pages=@(106,209,210,211)},
    @{id='AN4938'; url='https://www.st.com/resource/en/application_note/an4938-getting-started-with-stm32h74xig-and-stm32h75xig-mcu-hardware-development-stmicroelectronics.pdf'; name='AN4938.pdf'; pages=@(12,14,36)},
    @{id='MB1246-BOM'; url='https://www.st.com/resource/en/bill_of_materials/mb1246_bom.zip'; name='mb1246_bom.zip'},
    @{id='MB1246-H743-E02'; url='https://www.st.com/resource/en/schematic_pack/mb1246-h743-e02_schematic.pdf'; name='mb1246-h743-e02_schematic.pdf'; pages=@(4)},
    @{id='TDK-C2012X7R1E225K125AB'; url='https://product.tdk.cn/system/files/dam/doc/product/capacitor/ceramic/mlcc/charasheet/c2012x7r1e225k125ab.pdf'; local='outputs/SmartVio-V26-Engineering/audit/power-closure-v26/sources/C2012X7R1E225K125AB.pdf'; name='C2012X7R1E225K125AB.pdf'; pages=@(1)},
    @{id='TDK-specification'; url='https://product.tdk.cn/system/files/dam/doc/product/capacitor/ceramic/mlcc/specification/mlccspec_commercial_general_midvoltage_en.pdf'; local='outputs/SmartVio-V26-Engineering/audit/power-closure-v26/sources/TDK-spec-current.pdf'; name='TDK-specification.pdf'},
    @{id='YAGEO-CC0805KKX7R7BB225'; url='https://www.yageogroup.com/download/specsheet/CC0805KKX7R7BB225'; local='outputs/SmartVio-V26-Engineering/audit/pin-closure-v26/source-evidence/CC0805KKX7R7BB225.pdf'; name='CC0805KKX7R7BB225.pdf'; pages=@(1)}
)
$records = foreach ($item in $items) {
    $dest = Join-Path $evidence $item.name
    try {
        if ($item.local -and (Test-Path -LiteralPath $item.local)) {
            Copy-Item -LiteralPath $item.local -Destination $dest
            $mode = 'LOCAL_PRIMARY_DOCUMENT_COPY_LIVE_WEB_CORROBORATED_WHERE_REVIEWED'
        } else {
            Invoke-WebRequest -Uri $item.url -OutFile $dest -UseBasicParsing -TimeoutSec 25
            $mode = 'LIVE_DOWNLOAD'
        }
        @{id=$item.id; url=$item.url; file=('evidence/'+$item.name); sha256=(Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLower(); bytes=(Get-Item -LiteralPath $dest).Length; pages=$item.pages; status='SAVED'; mode=$mode}
    } catch {
        @{id=$item.id; url=$item.url; status='ACCESS_FAILED_NOT_EVIDENCE'; error=$_.Exception.Message}
    }
}
$native = Join-Path $root 'outputs/SmartVio-V26-Engineering/electrical/native-components.json'
$nativeHash = (Get-FileHash -LiteralPath $native -Algorithm SHA256).Hash.ToLower()
@{date_utc=[DateTime]::UtcNow.ToString('o'); source_path=$native; source_sha256=$nativeHash; expected_source_sha256='0e910987449bffa901d04ab268c706915137b6e57687c6ca12c37101dc3c9430'; sources=@($records)} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $out 'source-manifest.json') -Encoding UTF8
$bom = Join-Path $evidence 'mb1246_bom.zip'
if (Test-Path -LiteralPath $bom) { Expand-Archive -LiteralPath $bom -DestinationPath (Join-Path $evidence 'mb1246-bom') -Force }
$records | ConvertTo-Json -Depth 8
Get-ChildItem -LiteralPath $evidence -Recurse -File | Select-Object FullName,Length
