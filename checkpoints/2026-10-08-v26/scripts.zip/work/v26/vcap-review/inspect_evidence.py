from pathlib import Path
import hashlib
import json
import re
import subprocess
from pypdf import PdfReader
from openpyxl import load_workbook

ROOT = Path('.')
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/audit/vcap-review-v26'
EVIDENCE = OUT / 'evidence'
rows = []
for file in sorted((EVIDENCE / 'mb1246-bom').glob('*H743*.xlsx')):
    workbook = load_workbook(file, read_only=True, data_only=True)
    for sheet in workbook:
        for number, row in enumerate(sheet.iter_rows(values_only=True), 1):
            values = [str(value) if value is not None else '' for value in row]
            if number <= 6 or any(re.search(r'(?<![A-Z0-9])C(?:18|22|30)(?![0-9])', value) for value in values):
                rows.append({'file': file.name, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest(), 'sheet': sheet.title, 'row': number, 'values': values})
    workbook.close()
(OUT / 'official-bom-extract.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')
print(json.dumps(rows, indent=2))
documents = {'DS12110-Rev11.pdf': [106,209,210,211], 'AN4938.pdf': [12,14,36], 'mb1246-h743-e02_schematic.pdf': [4], 'C2012X7R1E225K125AB.pdf': [1], 'CC0805KKX7R7BB225.pdf': [1,4], 'TDK-specification.pdf': None}
for name, pages in documents.items():
    doc = PdfReader(EVIDENCE / name)
    pages = pages or [number + 1 for number, page in enumerate(doc.pages) if re.search(r'aging|Temperature characteristics|measuring conditions', page.extract_text(), re.I)]
    text = '\n'.join(f'PDF PAGE {page}\n{doc.pages[page-1].extract_text()}' for page in pages)
    (EVIDENCE / (name + '.txt')).write_text(text, encoding='utf-8')
    if name in ('mb1246-h743-e02_schematic.pdf', 'C2012X7R1E225K125AB.pdf'):
        poppler = '<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
        subprocess.run([poppler, '-f', str(pages[0]), '-l', str(pages[0]), '-singlefile', '-scale-to', '2300', '-png', str(EVIDENCE / name), str(EVIDENCE / name)], check=True)
    if name == 'C2012X7R1E225K125AB.pdf':
        print(text)
