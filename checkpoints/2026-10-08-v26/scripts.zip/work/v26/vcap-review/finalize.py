from pathlib import Path
from urllib.request import urlopen, Request
import hashlib
import json
import math
from pypdf import PdfReader

ROOT = Path('.')
OUT = ROOT / 'outputs/SmartVio-V26-Engineering/audit/vcap-review-v26'
manifest_path = OUT / 'source-manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
sources = [('YAGEO-CC0603KRX5R6BB225', 'https://www.yageogroup.com/download/specsheet/CC0603KRX5R6BB225', 'CC0603KRX5R6BB225.pdf'), ('YAGEO-X5R', 'https://www.yageogroup.com/content/datasheet/asset/file/UPY-GPHC_X5R_4V-TO-50V', 'YAGEO-X5R.pdf')]
for name, url, filename in sources:
    record = {'id': name, 'url': url, 'file': 'evidence/' + filename}
    try:
        data = urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=20).read()
        assert data.startswith(b'%PDF'), 'Not a PDF'
        file = OUT / 'evidence' / filename
        file.write_bytes(data)
        pdf = PdfReader(file)
        pages = [1,4] if name.endswith('225') else [i+1 for i,p in enumerate(pdf.pages) if 'temperature' in p.extract_text().lower() and ('15%' in p.extract_text() or '15 %' in p.extract_text())]
        text = '\n'.join(f'PDF PAGE {i}\n{pdf.pages[i-1].extract_text()}' for i in pages)
        (file.parent / (filename + '.txt')).write_text(text, encoding='utf-8')
        record.update(status='SAVED', sha256=hashlib.sha256(data).hexdigest(), bytes=len(data), pages=pages)
    except Exception as exc:
        record.update(status='ACCESS_FAILED_NOT_EVIDENCE', error=str(exc))
    manifest['sources'].append(record)
manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
native = ROOT / 'outputs/SmartVio-V26-Engineering/electrical/native-components.json'
current_hash = hashlib.sha256(native.read_bytes()).hexdigest()
assert current_hash == manifest['expected_source_sha256'], 'Parent source changed; review rebase required'
proposal = json.loads((OUT / 'guarded-proposal.json').read_text(encoding='utf-8'))
assert proposal['decision'] == 'HOLD' and not proposal['auto_apply']
assert len(proposal['exact_models_compared']) == 3
calculations = {'st_window_uF':[2.2*.8,2.2*1.2], 'broad_screen_uF':[2.2*.9*.85*.99*.9*.9*.98,2.2*1.1*1.15*1.03], 'restricted_screen_uF':2.2*.9*.99*.97*.97*.95, 'noninitial_factors_required':[1.76/(2.2*.9),2.64/(2.2*1.1)], 'DF_1kHz_illustration_ohm':[.05/(2*math.pi*1000*2.2e-6),.10/(2*math.pi*1000*2.2e-6)]}
(OUT / 'calculations.json').write_text(json.dumps(calculations, indent=2), encoding='utf-8')
verification = {'source_sha256_matches':True, 'guarded_proposal_json_valid':True, 'models_compared':3, 'saved_primary_documents':sum(x['status']=='SAVED' for x in manifest['sources']), 'blocked_source_downloads':[x for x in manifest['sources'] if x['status']!='SAVED'], 'hardware_tests':0, 'decision':'HOLD'}
(OUT / 'verification.json').write_text(json.dumps(verification, indent=2), encoding='utf-8')
hashes = {str(file.relative_to(OUT)).replace('\\','/'):hashlib.sha256(file.read_bytes()).hexdigest() for file in OUT.rglob('*') if file.is_file() and file.name!='artifact-hashes.json'}
(OUT / 'artifact-hashes.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
print(json.dumps(verification, indent=2))
print(json.dumps(calculations, indent=2))
