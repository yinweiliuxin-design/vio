"""Remove reliance on charger TS bias and capture an independently biased NTC."""
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'audit/system-v26'
source = ROOT / 'electrical/native-components.json'
old = json.loads(source.read_text(encoding='utf-8'))
by = {c['ref']: copy.deepcopy(c) for c in old}
changes = []
assert not set(['U1922','R1923','R1924','C1922','RT1921','J1921','C1904']) & set(by)
def add(ref, kind, value, mpn, package, pp, proof=None):
    c = {'ref':ref,'type':kind,'value':value,'mpn':mpn,'package':package,'sheet':'A33',
         'release':'ENGINEERING_REVIEW_NOT_MANUFACTURING_RELEASE','procurementApproved':False,
         'pins':[{'number':str(n),'name':name,'net':net,'electricalType':typ,'footprintPad':str(n)}
                 for n,name,net,typ in pp]}
    if proof:
        for p in c['pins']: p.update({'evidence':proof,'pinAuditStatus':'VERIFIED_OFFICIAL'})
    by[ref]=c
    changes.append({'ref':ref,'action':'add','mpn':mpn})
    return c

for ref,num in [('U1921','3'),('R1921','1')]:
    p=next(p for p in by[ref]['pins'] if p['number']==num)
    assert p['net']=='PACK_NTC'
    p['net']='CELL_NTC_SENSE'
    changes.append({'ref':ref,'pin':num,'before':'PACK_NTC','after':'CELL_NTC_SENSE'})
by['R1921'].update({'value':'169k 1%','mpn':'RC0603FR-07169KL'})
by['U1921']['note']='Independent CELL_NTC_SENSE uses a USB-fed LM4040 2.5V reference and separate battery-bonded thermistor; never uses the charger TS bias. Both outputs clamp charge gate.'
by['U501']['note']='Original PACK_NTC is unchanged and unloaded by external window. Native BQ TS operates with the selected pack NTC. Independent battery-bonded RT1921 adds a narrower inhibit; CHG low during TS fault is not charge-current evidence.'
add('U1922','IC','2.5V independent NTC excitation reference','LM4040A25IDBZR','DBZ SOT23-3',
    [(1,'CATHODE','TEMP_REF2V5','passive'),(2,'ANODE','GND','passive'),(3,'STAR_TIE_ANODE','GND','passive')],
    {'url':'https://www.ti.com/lit/ds/symlink/lm4040.pdf','section':'Table5-1 DBZ:1K2A3star; tie3toanode;6.7 A25I voltage tolerance/current'})
for ref,value,mpn,a,b in [('R1923','8.2k 1%','RC0603FR-078K2L','USB_5V_SAFE','TEMP_REF2V5'),
                         ('R1924','30.1k 1%','RC0603FR-0730K1L','TEMP_REF2V5','CELL_NTC_SENSE')]:
    add(ref,'R',value,mpn,'0603;1%;0.1W',[(1,'1',a,'passive'),(2,'2',b,'passive')])
for ref,a in [('C1922','TEMP_REF2V5'),('C1904','V3D')]:
    c=add(ref,'C','100nF X7R 16V','CC0603KRX7R7BB104','0603',[(1,'1',a,'passive'),(2,'2','GND','passive')])
    if ref=='C1904':c['sheet']='A32'
add('RT1921','NTC','independent battery surface thermistor 10k 1%,B3435 1%',
    '103AT-2','leaded thermistor; battery-bonded insulated harness, not populated on main PCB',
    [(1,'NTC_A','CELL_NTC_SENSE','passive'),(2,'NTC_B','GND','passive')],
    {'url':'https://www.semitec-global.com/products/thermistor_at/','section':'103AT-2:10k 1%;B3435 1%; mount and thermal coupling must be qualified'})
by['RT1921']['boardAssignment']='external-battery-surface'
add('J1921','J','RT1921 harness solder endpoint','', 'fabricated PCB feature,2pads1.5mm pitch',
    [(1,'NTC_SENSE','CELL_NTC_SENSE','passive'),(2,'RETURN','GND','passive')])
by['J1921']['fabricatedFeature']=True

def write(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
write(source,list(by.values()))
write(OUT/'ntc-independent-corrected-components.json',[by[r] for r in ['U1921','R1921','U501','U1922','R1923','R1924','C1922','RT1921','J1921','C1904']])
write(OUT/'ntc-independent-authorized-net-deltas.json',changes)
write(OUT/'native-revision.json',{'parts':len(by),'pins':sum(len(c['pins']) for c in by.values()),
                                'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})

def temp(r,r25,beta):return 1/(1/298.15+math.log(r/r25)/beta)-273.15
categories={'hotTripC':[],'coldTripC':[],'hotReleaseC':[],'coldReleaseC':[]}
# Resistor envelope includes 1% initial and a deliberately allocated 0.5% drift.
for vz,rtop,rc,rb,ia,ib,r25,beta in itertools.product(
        [2.5*.99,2.5*1.01],[30100*.985,30100*1.015],[169000*.985,169000*1.015],
        [100000*.985,100000*1.015],[-25e-9,25e-9],[-15e-9,15e-9],
        [9900,10100],[3435*.99,3435*1.01]):
    for cat,thresholds in [('hotTripC',[.387,.400]),('hotReleaseC',[.396,.404])]:
        for v in thresholds:
            vb=(v/rc-ib)/(1/rc+1/rb)
            intc=(vz-v)/rtop-ia-(v-vb)/rc
            categories[cat].append(temp(v/intc,r25,beta))
    for cat,thresholds in [('coldTripC',[.396,.404]),('coldReleaseC',[.387,.400])]:
        for vb in thresholds:
            v=vb*(1+rc/rb)+ib*rc
            intc=(vz-v)/rtop-ia-(v-vb)/rc
            categories[cat].append(temp(v/intc,r25,beta))
bounds={k:{'min':min(v),'max':max(v),'cornerCount':len(v)} for k,v in categories.items()}
assert bounds['hotTripC']['max']<45 and bounds['coldTripC']['min']>0
shunt_min=(4.1-2.525)/(8200*1.015)-2.525/(30100*.985)
assert shunt_min>80e-6
calc={'revision':'V26_NTC_INDEPENDENT','status':'DESIGN_CORNER_CALCULATION_NOT_TEMPERATURE_SWEEP',
      'bounds':bounds,'refEnvelopeV':[2.475,2.525],'resistorEnvelope':.015,
      'minimumReferenceShuntAUnderUSB4V1':shunt_min,'referenceMinimumRequiredA':80e-6,
      'maxReferenceFeedA':(5.84-2.475)/(8200*.985),
      'referenceFeedResistorMaxPowerW':(5.84-2.475)**2/(8200*.985),
      'referenceMaxPowerW':2.525*(5.84-2.475)/(8200*.985),
      'thermistorMaxSelfHeatW':2.525**2/(4*30100*.985),
      'biasIndependentOfCE':True,'chargerPACK_NTCAdditionalLoadOhm':None,
      'faults':{'openNTC':'Cold inhibit','shortNTC':'Hot inhibit','referenceOpen':'Hot inhibit',
                'referenceShort':'Hot inhibit','USBAbsent':'Hot inhibit; no charging requested',
                'Q1601DrainSourceShort':'Not single-fault protected by TPS3700; native BQ TS remains'},
      'limitations':['Beta model not supplier full R/T table; additional conservative temperature guard required.',
                     'Thermal contact and sensor response are not yet measured.',
                     'No single-fault safety certification or physical sample test is claimed.']}
write(OUT/'ntc-independent-calculations.json',calc)
historical=json.loads((OUT/'ntc-window-calculations.json').read_text(encoding='utf-8'))
historical.update({'status':'REJECTED_SHARED_BQ_BIAS_ASSUMPTION_NOT_CURRENT_DESIGN',
                   'supersededBy':'ntc-independent-calculations.json'})
write(OUT/'ntc-window-calculations.json',historical)
print(json.dumps({'parts':len(by),'pins':sum(len(c['pins']) for c in by.values()),'calculation':calc},ensure_ascii=False))
