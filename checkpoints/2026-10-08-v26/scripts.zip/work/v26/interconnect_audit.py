"""Resolve every fabricated board-to-board endpoint against actual saved pads."""
import hashlib
import html
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
PCB = ROOT / 'pcb-work'
OUT = ROOT / 'manufacturing-v26'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
parts = {}
board_hashes = {}
for kind in ['main', 'usb', 'audio', 'cover', 'sensor']:
    inventory = read(PCB / f'verification/final-inventory-{kind}.json')
    board_hashes[kind] = inventory['boardSHA256']
    for part in inventory['footprints']:
        assert part['ref'] not in parts
        parts[part['ref']] = {'board': kind, **part}

def endpoint(ref, number):
    part = parts[ref]
    pad = next(p for p in part['pads'] if p['number'] == str(number))
    return {'ref': ref, 'pin': str(number), 'board': part['board'], 'net': pad['net'],
            'xyMm': pad['xyMm'], 'side': part['side'], 'padMm': pad['sizeMm'], 'drillMm': pad['drillMm']}

rows = []
for pair in read(PCB / 'proposed-harness.json'):
    start, end = pair['pair']
    for number, net in pair['pins'].items():
        a, b = endpoint(start, number), endpoint(end, number)
        assert a['net'] == b['net'] == net
        group = start.removesuffix('_M')
        category = ('USB_DATA_PAIR' if net in ['USB_DP_MCU', 'USB_DM_MCU'] else
                    'BTL_SPEAKER_PAIR' if net in ['SPK_P', 'SPK_N'] else
                    'POWER' if net in ['V3D', 'USB_5V_SAFE', 'VBUS_RAW'] else
                    'GROUND' if net == 'GND' else 'AUDIO' if '_PORT' in net else 'CONTROL')
        rows.append({'wireID': f'{group}-{number}', 'group': group, 'net': net, 'from': a, 'to': b,
                     'class': category, 'nominalCutLengthMm': None, 'stripLengthMm': None,
                     'wireMPN': None, 'cutAndTerminationApproved': False,
                     'requirement': {'USB_DATA_PAIR': 'D+/D- as one controlled twisted pair with GND return; no independent arbitrary loose wires; cable/strip lengths need SI review.',
                                     'BTL_SPEAKER_PAIR': 'Twist SPK_P with SPK_N; neither is ground. Do not add a parallel second harness from J901.',
                                     'POWER': 'Select conductor current/voltage and insulation from branch maximum; keep unprotected VBUS separate from analog.',
                                     'GROUND': 'Required return conductor, not optional shielding. Audio return must not carry speaker load.',
                                     'AUDIO': 'Keep away from BTL/switching/RF; shielding/return and termination remain assembly design inputs.',
                                     'CONTROL': 'Verify logic rail and default state; insulate and strain-relieve each solder endpoint.'}[category]})
for pin, net in [('1', 'V3D'), ('2', 'GND'), ('3', 'TEMP_SCL'), ('4', 'TEMP_SDA')]:
    a, b = endpoint('J1801', pin), endpoint('J1802', pin)
    assert a['net'] == b['net'] == net
    rows.append({'wireID': 'H-TEMP-' + pin, 'group': 'H-TEMP', 'net': net, 'from': a, 'to': b,
                 'class': 'SENSOR', 'nominalCutLengthMm': None, 'stripLengthMm': None, 'wireMPN': None,
                 'cutAndTerminationApproved': False, 'requirement': 'Existing separate sensor board; TMP117 is board temperature, not cell NTC.'})

assert len(rows) == len({r['wireID'] for r in rows}) == 37
speaker = {'defaultPath': 'H_COVER_2_M pins6/5 -> H_COVER_2_R pins6/5 -> cover PCB copper -> LS901 spring-contact pads',
           'J901Disposition': 'No second speaker cable fitted. J901 remains an insulated internal test/alternate terminal.',
           'springSoldering': 'Do not solder directly to transducer spring contacts; use the designed contact/preload fixture.',
           'polarity': {'6': 'SPK_P', '5': 'SPK_N'}, 'fixtureAndAcousticsApproved': False}
result = {'sourceSha256': hashlib.sha256((ROOT / 'electrical/native-components.json').read_bytes()).hexdigest(),
          'boardHashes': board_hashes, 'wires': rows, 'endpointChecks': len(rows) * 2,
          'endpointNetDifferences': [], 'speakerAssemblyPath': speaker,
          'externalConnections': [
              {'id': 'PICKUP', 'to': endpoint('J101', 1), 'return': endpoint('J101', 2),
               'instruction': 'Retain original bridge pickup, shield and existing wire hole; do not add microphone input.'},
              {'id': 'CELL_SURFACE_NTC', 'to': endpoint('J1921', 1), 'return': endpoint('J1921', 2),
               'instruction': 'Separate insulated103AT-2, never parallel with PACK_NTC; no soldering to battery foil.'}],
          'manufacturingRelease': False,
          'scope': 'Actual endpoint/net continuity definition. Cable material, lengths, stripping, strain relief and complete stack are not frozen.'}
(OUT / 'interboard-wire-by-wire.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
esc = html.escape
body = '<h1>V26 板间逐线连接审核</h1><p>工程连接定义，尚非可直接生产的线束加工单。37根板间导线、74个端点已与原生PCB对账。</p>'
body += '<p>喇叭默认通过 H_COVER_2 的6脚正、5脚负连接面板触点；J901不再另接第二条喇叭线。两个喇叭端均不是地。</p>'
body += '<div class="scroll"><table><tr><th>线号</th><th>网络</th><th>起点（板/位号/脚）</th><th>终点（板/位号/脚）</th><th>加工状态</th></tr>'
for row in rows:
    label = lambda e: f"{e['board']} / {e['ref']}.{e['pin']}"
    body += '<tr>' + ''.join('<td>' + esc(str(v)) + '</td>' for v in [row['wireID'], row['net'], label(row['from']), label(row['to']), '线材型号、切长、剥线及应力释放待布置冻结']) + '</tr>'
body += '</table></div><p>拾音器：J101.1信号，J101.2屏蔽地。独立电池表面NTC：J1921.1/2；不得与电池包NTC并接。</p>'
(OUT / 'interboard-wire-by-wire.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>V26板间逐线连接</title><style>body{font:14px/1.6 Arial,"Microsoft YaHei";margin:24px;color:#25352f}h1{font-size:23px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd6d1;padding:8px;text-align:left}.scroll{overflow:auto}th{background:#edf4f0}</style>' + body + '</html>', encoding='utf-8')
print(json.dumps({'wires': len(rows), 'endpointChecks': len(rows) * 2, 'netDifferences': 0, 'productionApproved': False}))
