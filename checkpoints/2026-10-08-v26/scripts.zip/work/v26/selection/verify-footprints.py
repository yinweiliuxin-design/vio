import hashlib
import json
from pathlib import Path
import pcbnew

ROOT = Path(__file__).resolve().parent
WS = ROOT.parents[2]
OUT = WS / 'V26/audit/selection'
LIB = OUT / 'SmartVio_V26_Selection.pretty'
sources = json.loads((OUT / 'footprint-sources.json').read_text())
checks = []
for source in sources:
    fp = pcbnew.FootprintLoad(str(LIB), source['name'])
    assert fp is not None, source['name']
    pads = list(fp.Pads())
    actual = []
    for p in pads:
        pos, size, drill = p.GetPosition(), p.GetSize(), p.GetDrillSize()
        actual.append(dict(number=p.GetNumber(), x=round(pcbnew.ToMM(pos.x),6), y=round(pcbnew.ToMM(pos.y),6), w=round(pcbnew.ToMM(size.x),6), h=round(pcbnew.ToMM(size.y),6), drill=[round(pcbnew.ToMM(drill.x),6),round(pcbnew.ToMM(drill.y),6)]))
    expected = source['pads']
    assert len(actual) == len(expected), source['name']
    for want in expected:
        match = next((p for p in actual if p['number']==want['number'] and all(abs(p[k]-want[k])<1e-6 for k in ('x','y','w','h'))),None)
        assert match, (source['name'],want,actual)
        assert match['drill'] == want.get('drill',[0,0])
    copper_gaps=[]
    for i,a in enumerate(actual):
        for b in actual[i+1:]:
            dx=max(0,abs(a['x']-b['x'])-(a['w']+b['w'])/2)
            dy=max(0,abs(a['y']-b['y'])-(a['h']+b['h'])/2)
            copper_gaps.append((dx*dx+dy*dy)**0.5)
    edge_count=sum(1 for d in fp.GraphicalItems() if d.GetLayer()==pcbnew.Edge_Cuts)
    checks.append(dict(name=source['name'],parsed=True,padCount=len(actual),pads=actual,edgeCutsPrimitiveCount=edge_count,localMinCopperGapMm=round(min(copper_gaps),4) if copper_gaps else None,sourceHashMatches=hashlib.sha256(Path(source['file']).read_bytes()).hexdigest()==source['sha256']))
base = Path(json.loads((OUT/'authorized-net-deltas.json').read_text())['baselineFile'])
declared=json.loads((OUT/'authorized-net-deltas.json').read_text())['baselineSha256']
report=dict(schema='SmartVio.local-footprint-verification.v1',kicadVersion=pcbnew.Version(),checks=checks,baselineSourceUnchanged=hashlib.sha256(base.read_bytes()).hexdigest()==declared,scope='Real KiCad parser, pad/drill coordinate match and local pad gaps only; source drawings were visually inspected separately',fullBoardErcRun=False,fullBoardDrcRun=False,physicalMeasurements=0,thermalMeasurements=0,assembledCadFitValidated=False,productionApproval=False)
(OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['baselineSourceUnchanged'], 'Parent baseline changed while preparing patch: rebase with full preconditions'
print(json.dumps(dict(footprintsParsed=len(checks),baselineUnchanged=report['baselineSourceUnchanged'],kicadVersion=report['kicadVersion'],productionApproval=False)))
