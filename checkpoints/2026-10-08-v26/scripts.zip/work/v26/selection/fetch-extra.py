import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'sources.json').read_text(encoding='utf-8-sig'))
items = [
    ('molex-mate', '532610371_sd.pdf', 'https://www.molex.com/content/dam/molex/molex-dot-com/products/automated/en-us/salesdrawingpdf/532/53261/532610371_sd.pdf?inline%5C='),
    ('alps-switch-part', 'SKQGABE010.html', 'https://tech.alpsalpine.com/e/products/detail/SKQGABE010/'),
    ('alps-pot-part', 'RK10J11R0A0L.html', 'https://tech.alpsalpine.com/e/products/detail/RK10J11R0A0L/'),
    ('alps-pot-taper', 'taper.gif', 'https://tech.alpsalpine.com/assets/products/detail-additional/2021-2022/RV/r1.gif'),
    ('semitec-ntc', 'P12-13-AT-Thermistor.pdf', 'https://www.semitec-global.com/uploads/2022/01/P12-13-AT-Thermistor.pdf'),
    ('kycon-catalog', 'STX-353K7A.pdf', 'https://www.kycon.com/Catalog_PDF/STX-353K7A.pdf'),
    ('kicad-molex', 'Molex_PicoBlade_53261-0371_1x03-1MP_P1.25mm_Horizontal.kicad_mod', 'https://raw.githubusercontent.com/KiCad/kicad-footprints/master/Connector_Molex.pretty/Molex_PicoBlade_53261-0371_1x03-1MP_P1.25mm_Horizontal.kicad_mod'),
    ('molex-family', '532610271_sd.pdf', 'https://www.molex.com/pdm_docs/sd/532610271_sd.pdf'),
]
for sid, name, url in items:
    record = dict(id=sid, url=url)
    try:
        previous = next((r for r in manifest if r['id'] == sid and r.get('status') == 'downloaded'), None)
        if previous:
            print(sid, 'cached')
            continue
        with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=30) as response:
            payload = response.read()
        if name.endswith('.pdf') and not payload.startswith(b'%PDF-'):
            raise ValueError('Response is not PDF; source not accepted')
        path = root / 'sources' / name
        path.write_bytes(payload)
        record.update(file=str(path), sha256=hashlib.sha256(payload).hexdigest(), bytes=len(payload), status='downloaded', retrieved_utc=datetime.now(timezone.utc).isoformat())
    except Exception as exc:
        record.update(status='download_failed', error=str(exc))
    manifest = [r for r in manifest if r['id'] != sid] + [record]
    print(sid, record['status'])
(root / 'sources.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
