import sys
from pathlib import Path
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parents[1] / 'v25/audio/pythonlibs'))
import fitz

out = root / 'evidence'
out.mkdir(exist_ok=True)
for path in (root / 'sources').glob('*.pdf'):
    try:
        doc = fitz.open(path)
        (out / (path.stem + '.txt')).write_text('\n'.join(f'\n=== PDF PAGE {i+1} ===\n{p.get_text()}' for i,p in enumerate(doc)), encoding='utf-8')
        for i, page in enumerate(doc):
            page.get_pixmap(matrix=fitz.Matrix(2,2)).save(out / f'{path.stem}-p{i+1}.png')
        if path.stem == 'STX-353K7A-6N-KTTR':
            p = doc[0]
            p.get_pixmap(matrix=fitz.Matrix(5,5), clip=fitz.Rect(p.rect.width*0.27,p.rect.height*0.30,p.rect.width*0.52,p.rect.height*0.70)).save(out / 'jack-land-detail.png')
            p.get_pixmap(matrix=fitz.Matrix(6,6), clip=fitz.Rect(p.rect.width*0.27,p.rect.height*0.74,p.rect.width*0.62,p.rect.height*0.89)).save(out / 'jack-contact-detail.png')
        if path.stem == 'SKQG':
            p = doc[0]
            p.get_pixmap(matrix=fitz.Matrix(5,5), clip=fitz.Rect(p.rect.width*0.39,p.rect.height*0.71,p.rect.width*0.70,p.rect.height*0.92)).save(out / 'switch-land-detail.png')
        if path.stem == 'RK10J':
            p = doc[1]
            p.get_pixmap(matrix=fitz.Matrix(5,5), clip=fitz.Rect(p.rect.width*0.40,p.rect.height*0.70,p.rect.width*0.71,p.rect.height*0.91)).save(out / 'pot-land-detail.png')
            p.get_pixmap(matrix=fitz.Matrix(10,10), clip=fitz.Rect(p.rect.width*0.45,p.rect.height*0.71,p.rect.width*0.68,p.rect.height*0.85)).save(out / 'pot-dimension-detail.png')
        print(path.name, len(doc), 'pages')
    except Exception as exc:
        print(path.name, 'HOLD', str(exc))
