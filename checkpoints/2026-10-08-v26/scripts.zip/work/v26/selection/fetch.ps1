$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$dir = Join-Path $root 'sources'
New-Item -ItemType Directory -Path $dir -Force | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$items = @(
  @{id='kycon-jack';file='STX-353K7A-6N-KTTR.pdf';url='https://www.kycon.com/Pub_Eng_Draw/STX-353K7A-6N-KTTR.pdf'},
  @{id='smk-jack-catalog';file='JK-35_E_250523.pdf';url='https://www.smkusa.com/system/files/import/JK-35_E_250523.pdf'},
  @{id='alps-switch';file='SKQG.pdf';url='https://tech.alpsalpine.com/cms.media/product_catalog_ta_02_skqg_en_d003713f01.pdf'},
  @{id='alps-pot';file='RK10J.pdf';url='https://tech.alpsalpine.com/cms.media/product_catalog_rv_03_rk10j_en_780020d1ea.pdf'},
  @{id='cyan-led';file='APT1608VRCXF-A-5MAV.pdf';url='https://www.kingbrightusa.com/images/catalog/SPEC/APT1608VRCXF-A-5MAV.pdf'},
  @{id='pui-speaker';file='AS01808AO-SC18-WP-R.pdf';url='https://api.puiaudio.com/filename/AS01808AO-SC18-WP-R.pdf'},
  @{id='globtek-pack';file='BL0750F5030481S1PCTC.pdf';url='https://www.globtek.com/pdf/manual-datasheets/BL0750F5030481S1PCTC.pdf'},
  @{id='molex-mate';file='532610371_sd.pdf';url='https://www.molex.com/content/dam/molex/molex-dot-com/products/automated/en-us/salesdrawingpdf/532/53261/532610371_sd.pdf?inline%5C='},
  @{id='ltc-pb';file='2954fb.pdf';url='https://www.analog.com/media/en/technical-documentation/data-sheets/2954fb.pdf'},
  @{id='pullup-resistor';file='RC0603FR-0710KL.pdf';url='https://www.yageogroup.com/component-documentation/download/specsheet/RC0603FR-0710KL'},
  @{id='smk-jack-jp';file='JK-35_JP.pdf';url='https://www.smk.co.jp/system/files/import/JK-35_E_250523.pdf'}
)
$records = foreach ($item in $items) {
  $path = Join-Path $dir $item.file
  try {
    if (-not (Test-Path -LiteralPath $path)) {
      Invoke-WebRequest -UseBasicParsing -Uri $item.url -OutFile $path -TimeoutSec 35
    }
    [ordered]@{id=$item.id;file=$path;url=$item.url;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();bytes=(Get-Item -LiteralPath $path).Length;status='downloaded';retrieved_utc=[DateTime]::UtcNow.ToString('o')}
    Write-Host "OK $($item.id)"
  } catch {
    [ordered]@{id=$item.id;url=$item.url;status='download_failed';error=$_.Exception.Message}
    Write-Host "HOLD $($item.id)"
  }
}
$records | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $root 'sources.json') -Encoding UTF8
