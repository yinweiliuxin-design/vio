import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WS = ROOT.parents[2]
OUT = WS / 'V26/audit/selection'
LIB = OUT / 'SmartVio_V26_Selection.pretty'
OUT.mkdir(parents=True, exist_ok=True)
LIB.mkdir(exist_ok=True)
BASE = WS / 'outputs/SmartVio-V25-Engineering/electrical/native-components.json'
raw = BASE.read_bytes()
baseline = json.loads(raw.decode('utf-8-sig'))
byref = {c['ref']: c for c in baseline}
sources = json.loads((ROOT / 'sources.json').read_text(encoding='utf-8-sig'))
S = {s['id']: s for s in sources}
records, operations, land_records, pin_records = [], [], [], []


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')


def ev(sid, pages, section):
    s = S[sid]
    return dict(sourceId=sid, url=s['url'], sha256=s.get('sha256'), sourceFile=s.get('file'), pdfPages=pages, section=section)


def pin(number, name, net, evidence):
    p = dict(number=str(number), name=name, net=net, footprintPad=str(number), electricalType='passive', pinAuditStatus='VERIFIED_OFFICIAL_FUNCTION', evidence=evidence)
    if net is None:
        p.update(intentionalNoConnect=True, noConnectReason='Unused physical contact retained as an actual land; do not omit copper.')
    return p


def replace(ref, mpn, manufacturer, package, pins, footprint, evidence, note, holds):
    c = copy.deepcopy(byref[ref])
    for key in ('footprintAudit', 'auditFindingIds', 'detectionSwitch', 'pinAuditStatus', 'candidateManufacturer', 'bomEvidence'):
        c.pop(key, None)
    c.update(mpn=mpn, manufacturer=manufacturer, value=mpn, package=package, pins=pins, footprint=footprint, source=evidence['sourceId'], note=note, selectionStatus='ENGINEERING_SELECTED', release='HOLD', productionApproval=False, selectionRevision='V26', evidence=evidence, physicalSamplesTested=0, integrationHolds=holds, verificationScope='Official sources and local footprint parsing only; full-board ERC/DRC, assembled fit, thermal and physical tests not performed.')
    c['footprintAudit'] = dict(status='ENGINEERING_SOURCE_MAPPED_NOT_PRODUCTION_RELEASED', allowPcbLayout=footprint is not None, allowManufacturingExport=False, evidence=evidence)
    records.append(c)
    operations.append(dict(op='replace_component', ref=ref, precondition=copy.deepcopy(byref[ref]), replacement=c, pinNetBefore=byref[ref]['pins'], pinNetAfter=pins, applyAtomically=True))
    for p in pins:
        pin_records.append(dict(ref=ref, mpn=mpn, **p))
    return c


def line(a, b, layer='F.Fab', width=0.1):
    return f'(fp_line (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (stroke (width {width}) (type default)) (layer "{layer}"))'


def rect(x1, y1, x2, y2, layer='F.Fab', width=0.1):
    return '\n'.join(line(a,b,layer,width) for a,b in [((x1,y1),(x2,y1)),((x2,y1),(x2,y2)),((x2,y2),(x1,y2)),((x1,y2),(x1,y1))])


def arc(a, mid, b):
    return f'(fp_arc (start {a[0]} {a[1]}) (mid {mid[0]} {mid[1]}) (end {b[0]} {b[1]}) (stroke (width 0.05) (type default)) (layer "Edge.Cuts"))'


def keepout(x1,y1,x2,y2):
    return f'(zone (net 0) (net_name "") (layer "F.Cu") (hatch edge 0.5) (connect_pads (clearance 0)) (min_thickness 0.1) (keepout (tracks not_allowed) (vias not_allowed) (pads not_allowed) (copperpour not_allowed) (footprints allowed)) (polygon (pts (xy {x1} {y1}) (xy {x2} {y1}) (xy {x2} {y2}) (xy {x1} {y2}))))'


def pad(number, x, y, w, h, drill=None, paste=True):
    if drill:
        return f'(pad "{number}" thru_hole oval (at {x} {y}) (size {w} {h}) (drill oval {drill[0]} {drill[1]}) (layers "*.Cu" "*.Mask"))'
    layers = '"F.Cu" "F.Mask"' + (' "F.Paste"' if paste else '')
    return f'(pad "{number}" smd rect (at {x} {y}) (size {w} {h}) (layers {layers}))'


def footprint(name, content, pads, evidence, comments, envelope, attr='smd'):
    text = f'(footprint "{name}" (version 20240108) (generator "smartvio_selection") (layer "F.Cu")\n(descr "V26 source-derived engineering footprint; see footprint-sources.json; no production approval")\n(attr {attr})\n(solder_mask_margin 0.05)\n(fp_text reference "REF**" (at 0 -10) (layer "F.SilkS") (effects (font (size 0.8 0.8) (thickness 0.12))))\n(fp_text value "{name}" (at 0 12) (layer "F.Fab") (effects (font (size 0.6 0.6) (thickness 0.1))))\n{content}\n)\n'
    path = LIB / (name + '.kicad_mod')
    path.write_text(text, encoding='ascii')
    land_records.append(dict(name=name, libraryId='SmartVio_V26_Selection:'+name, file=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), evidence=evidence, pads=pads, notes=comments, nominalEnvelopeMm=envelope, engineeringMaskExpansionMm=0.05, productionApproval=False))
    return 'SmartVio_V26_Selection:' + name


# Kycon explicitly calls its PCB layout top view; retain this orientation.
ej = ev('kycon-jack',[1],'Recommended PCB Layout (Top View), schematic and plug-in schematic, rev A1 2016-08-17')
jpads = [dict(number='1',x=0,y=4.05,w=1.9,h=1.0,drill=[1.5,0.6]),dict(number='2',x=2.75,y=-4.35,w=1.0,h=1.9,drill=[0.6,1.5]),dict(number='3',x=-2.75,y=-4.35,w=1.0,h=1.9,drill=[0.6,1.5]),dict(number='4',x=-3.07,y=4.05,w=1.0,h=1.9,drill=[0.6,1.5]),dict(number='5',x=2.05,y=4.05,w=1.0,h=1.9,drill=[0.6,1.5]),dict(number='6',x=3.35,y=4.05,w=1.0,h=1.9,drill=[0.6,1.5])]
cuts = [line((-4.3,-3.05),(4.1,-3.05),'Edge.Cuts',0.05),arc((4.1,-3.05),(4.6,-2.55),(4.1,-2.05)),line((4.1,-2.05),(4.1,1.75),'Edge.Cuts',0.05),arc((4.1,1.75),(4.6,2.25),(4.1,2.75)),line((4.1,2.75),(-4.3,2.75),'Edge.Cuts',0.05),arc((-4.3,2.75),(-4.8,2.25),(-4.3,1.75)),line((-4.3,1.75),(-4.3,-2.05),'Edge.Cuts',0.05),arc((-4.3,-2.05),(-4.8,-2.55),(-4.3,-3.05))]
jfp = footprint('Jack_Kycon_STX353K7A6N', '\n'.join([pad(p['number'],p['x'],p['y'],p['w'],p['h'],p['drill']) for p in jpads]+cuts+[rect(-4.3,-4.85,4.1,4.55),rect(-5.3,-5.8,5.1,5.5,'F.CrtYd',0.05)]), jpads, ej, ['Six plated 0.6 x 1.5 mm slots, lands 1.0 x 1.9 mm; pad1 rotated 90 degrees', 'Board cutout 8.4 x 5.8 mm with four radius-0.5 outward semicircles is mandatory; contour must be propagated into board CAM', 'Land-to-cutout nominal minimum 0.35 mm; require a parent reviewed local edge-clearance rule and fabricator acceptance, not default 0.5mm override without review', 'Finished slot tolerance +/-0.05mm and registration allowance are engineering fabrication requirements, not vendor guaranteed tolerances'], [7.65,9.4,14.9], 'through_hole')
for ref in ('J102','J201','J202','J301'):
    old={p['number']:p for p in byref[ref]['pins']}
    hp=ref=='J301'
    pins=[pin(1,'SLEEVE','GND',ej),pin(2,'RING2_TRS_SLEEVE','GND',ej),pin(3,'RING1',old['3']['net'],ej),pin(4,'TIP',old['2']['net'],ej),pin(5,'DET_NO_A','HP_DETECT_RAW' if hp else None,ej),pin(6,'DET_NO_B','GND' if hp else None,ej)]
    c=replace(ref,'STX-353K7A-6N-KTTR','Kycon','Vertical 3.5mm four-pole THT, six slotted plated contacts, mandatory PCB cutout',pins,jfp,ej,'Four-pole jack used for three-pole TRS with sleeve and extra ring2 both grounded; no MIC function. DA/6/8 ambiguity removed by changing actual manufacturer.', ['TRS/TS plug continuity and isolated switch sample qualification', 'Cutout manufacturing and complete mechanical stack fit', 'Existing lineout TS ring-short protection remains parent audio-system issue'])
    c['detectionSwitch']=dict(contactPair=['5','6'],type='isolated_normally_open_make_contact',unplugged='open',fullyInserted='closed',plannedGpioWithExistingPullup=dict(unplugged=1,inserted=0),sampleValidationRequired=True)

es=ev('alps-switch',[1],'SKQGABE010 row, Drawing No.1, circuit diagram and land dimensions')
spads=[dict(number=str(i),x=x,y=y,w=1.8,h=1.1) for i,x,y in [(1,-3.1,-1.85),(2,3.1,-1.85),(3,-3.1,1.85),(4,3.1,1.85)]]
sfp=footprint('Switch_Alps_SKQGABE010', '\n'.join([pad(p['number'],p['x'],p['y'],p['w'],p['h']) for p in spads]+[rect(-2.6,-2.6,2.6,2.6),rect(-4.25,-2.85,4.25,2.85,'F.CrtYd',0.05),keepout(-4,-1.3,-1,1.3),keepout(1,-1.3,4,1.3)]),spads,es,['1-2 internally common; 3-4 internally common; switch joins groups only when pressed', 'Manufacturer prohibits copper tracks under two hatched regions; keepouts also conservatively prohibit vias/pours', 'Left/right permutation within common pair is electrically equivalent; top component numbering follows Drawing No.1'],[5.2,5.2,1.5])
for ref in ('SW810','SW811','SW812','SW813','SW814'):
    key=byref[ref]['pins'][0]['net']
    replace(ref,'SKQGABE010','Alps Alpine','5.2 x 5.2 mm, height 1.5 +0.15/-0 mm, SMT four-terminal NO tactile', [pin(1,'A1',key,es),pin(2,'A2',key,es),pin(3,'B1','GND',es),pin(4,'B2','GND',es)],sfp,es,'1.57N; 0.25mm travel; 1M operations; >=10uA 1V DC to <=50mA 12V DC. Do not omit duplicated electrical terminals.', ['Cap/preload/stop qualification and mechanical debounce', 'SW813 minimum-current guarantee closed by proposed R826, not assumed from typical internal PB pull-up'] if ref=='SW813' else ['Cap/preload/stop qualification and firmware debounce'])

ep=ev('alps-pot',[1,2],'RK10J11R0A0L product row and Drawing No.3 mounting-side land/circuit')
# Coordinates preserve the labelled mounting-pattern orientation, origin at knob centre.
# Dimension leaders: 1.8 = upper lug centre to knob centre; 8.3 = knob centre to lower-pad top.
ppads=[dict(number='1',x=-4,y=9,w=1.2,h=1.4),dict(number='2',x=-2,y=9,w=1.2,h=1.4),dict(number='',localMechanicalId='DUMMY1',x=0,y=9,w=1.2,h=1.4),dict(number='',localMechanicalId='DUMMY2',x=2,y=9,w=1.2,h=1.4),dict(number='3',x=4,y=9,w=1.2,h=1.4),dict(number='',localMechanicalId='LUG1',x=-6.1,y=-1.8,w=2.2,h=1.4),dict(number='',localMechanicalId='LUG2',x=6.1,y=-1.8,w=2.2,h=1.4)]
pcontent=[pad(p['number'],p['x'],p['y'],p['w'],p['h']) for p in ppads]
for y in (-3.0,5.4):
    pcontent.append(rect(-1.1,y-0.5,1.1,y+0.5,'Edge.Cuts',0.05))
pcontent += [rect(-7.1,-7.1,7.1,9.7),rect(-7.45,-7.45,7.45,9.95,'F.CrtYd',0.05)]
pfp=footprint('Pot_Alps_RK10J11R0A0L', '\n'.join(pcontent),ppads,ep,['Electrical 1,2,3 plus four manufacturer-unnumbered isolated mechanical solder lands; no fabricated electrical numbers', 'Top lug inner-edge gap 10; each width 2.2; x centres +/-6.1. Top lug centre y=-1.8', 'Retention openings width 2.2, height 1; upper opening bottom y=-2.5, lower opening top y=4.9; inner-edge spacing 7.4. Centres y=-3.0,+5.4', 'Bottom pad top y=8.3, height 1.4; centre y=9.0. Do not misread 8.3 as top-to-bottom pad pitch', 'Rectangular apertures require controlled micro-routing/laser/punch corner relief; exact sharp rectangles are source geometry, not an ordinary 0.5mm-radius router claim', 'F.Cu pattern retains manufacturer mounting-pattern orientation; terminal-1 marking/rotation must be preserved in assembly documentation'],[14.2,16.8,2.5])
for ref in ('RV810','RV811','RV812'):
    replace(ref,'RK10J11R0A0L','Alps Alpine','SMT 10k linear 1B +/-30%, diameter14 +/-0.2 mm wheel, thickness1.0 mm wheel', [pin(p['number'],p['name'],p['net'],ep) for p in byref[ref]['pins']],pfp,ep,'20V DC compatible single element; existing 3.3V divider retained. Increasing rotation towards terminal3 decreases ADC reading with existing 1=V3D,3=GND.', ['Rectangular retention aperture process/assembled wheel clearance', 'ADC dynamic settling and endpoint/direction calibration', '10k operating cycles; -10..60C operating range limits selected control environment'])

el=ev('cyan-led',[1,2,3],'Exact APT1608VRCXF/A-5MAV identity, pin diagram, recommended solder pattern, electrical and reflow limits')
lpads=[dict(number='1',x=-0.825,y=0,w=0.8,h=0.8),dict(number='2',x=0.825,y=0,w=0.8,h=0.8)]
lfp=footprint('LED_Kingbright_APT1608VRCXF_A_5MAV','\n'.join([pad(p['number'],p['x'],p['y'],p['w'],p['h']) for p in lpads]+[rect(-0.8,-0.4,0.8,0.4),line((-0.65,-0.3),(-0.65,0.3)),rect(-1.48,-0.65,1.48,0.65,'F.CrtYd',0.05)]),lpads,el,['Manufacturer 1=K,2=A; original logical anode/cathode pin numbers must be exchanged', 'Pad0.8 x0.8, inner gap0.85 gives pitch1.65mm; cyan identity verified, not a green-only substitute', 'MSL3, ESD sensitive; dry handling and manufacturer reflow envelope required'],[1.6,0.8,0.75])
for i,ref in enumerate(('D850','D851','D852'),1):
    replace(ref,'APT1608VRCXF/A-5MAV','Kingbright','Cyan 1.6 x0.8 x0.75 +/-0.1 mm SMD', [pin(1,'K','GND',el),pin(2,'A',f'LED_ZONE_{i}_A',el)],lfp,el,'Keep existing R850..852=1k. Vf2.8typ/3.2max at5mA; existing 3.3V circuit cannot guarantee 5mA brightness bin. No resistor decrease authorized in this patch.', ['Brightness at actual low current, cold voltage margin, optical diffuser and sunlight visibility untested'])

ea=ev('pui-speaker',[1,2,3,4,5],'Electrical/acoustic ratings, reliability test, Dimensions and contact point pattern (Reference)')
apads=[dict(number='1',x=5.25,y=7.75,w=2.5,h=2.5),dict(number='2',x=5.25,y=-7.75,w=2.5,h=2.5)]
afp=footprint('Speaker_PUI_AS01808AO_SC18_Spring_REFERENCE','\n'.join([pad(p['number'],p['x'],p['y'],p['w'],p['h'],paste=False) for p in apads]+[rect(-6.5,-9,6.5,9),rect(-6.9,-9.4,6.9,9.4,'F.CrtYd',0.05)]),apads,ea,['Reference spring-contact pattern, NOT a manufacturer solder land recommendation: no F.Paste', '2.5x2.5 lands, inner gap13 across long axis, centre-to-inner-edge offset4 across short axis. Rotate pattern90 degrees and mirror underside to PCB top view; positive remains lower contact, local pad1=SPK_P', 'Local pad IDs1/2 are project-defined; manufacturer supplies unnumbered +/- spring contacts', 'Specify ENIG flat contact lands, controlled 2.8+/-0.2mm working spring height, housing restraint/gasket. Pressure/finish durability untested'],[13.15,18.15,3.0])
replace('LS901','AS01808AO-SC18-WP-R','PUI Audio','18x13x2.5mm spring-contact speaker; working height2.8+/-0.2mm; 8ohm +/-15%', [pin(1,'+','SPK_P',ea),pin(2,'-','SPK_N',ea)],afp,ea,'Practice monitor, not full-spectrum violin speaker. Manufacturer rating1W and1.2Wmax do not permit unrestricted low-frequency drive. MAX98357 BTL: neither terminal to GND.', ['Reference spring pattern orientation/pressure and physical polarity check', 'Speaker-only HPF>=850Hz slope>=12dB/oct, conservative <=1.0Vrms drive contract and DC/fault shutdown need parent firmware integration', 'Acoustic sealed-back volume, thermal/excursion and contact durability qualification'])

# Adding the manufacturer recommended PB pull-up guarantees the selected switch minimum current.
assert 'R826' not in byref, 'R826 occupied: renumber proposal rather than overwrite'
er=ev('pullup-resistor',[1],'RC0603FR-0710KL exact product sheet; 10k +/-1%,0.1W')
r=copy.deepcopy(byref['R823'])
r.update(ref='R826',value='10k',mpn='RC0603FR-0710KL',manufacturer='YAGEO',source='pullup-resistor',note='NEW proposed pull-up SYS to PWR_PB, per LTC2954 p14 Figure9. Do not connect to KEY_PWR or switched V3D.',pins=[pin(1,'1','SYS',er),pin(2,'2','PWR_PB',er)],selectionRevision='V26',selectionStatus='ENGINEERING_SELECTED',productionApproval=False,physicalSamplesTested=0,evidence=er,footprint='Resistor_SMD:R_0603_1608Metric',footprintAudit={'status':'REUSE_PARENT_VERIFIED_0603_PATTERN_REQUIRED','allowManufacturingExport':False})
records.append(r)
operations.append(dict(op='add_component',ref='R826',precondition={'referenceAbsent':True},replacement=r,applyAtomically=True,applicationEvidence=ev('ltc-pb',[3,7,14],'PB input limits and Figure9 external 10k pull-up to VIN')))
pin_records += [dict(ref='R826',mpn=r['mpn'],**p) for p in r['pins']]

dump('corrected-components.json',records)
dump('authorized-net-deltas.json',dict(schema='SmartVio.authorized-component-deltas.v1',baselineFile=str(BASE),baselineSha256=hashlib.sha256(raw).hexdigest(),scope='Owned selected refs only; no global file written',applyPolicy='Verify each full precondition; never bulk replace unrelated components. Update jack detection firmware before enabling speaker/headphone decisions.',operations=operations,firmwareDeltas=[{'function':'HP presence','oldInsertedLevel':1,'newInsertedLevel':0,'source':'Kycon normally-open 5/6, existing pull-up preserved'},{'function':'speaker branch','hpfHz':850,'minimumSlopeDbPerOctave':12,'targetMaxOutputVrms':1.0,'scope':'LS901 only; analog headphones/send/return/lineout boundaries preserved','status':'PROPOSAL_REQUIRES_INTEGRATION_AND_MEASUREMENT'}],globalApplied=False,productionApproval=False))
dump('footprint-sources.json',land_records)
dump('pin-records.json',pin_records)
dump('source-manifest.json',sources)

status=json.loads((OUT/'selection-status.json').read_text())
status.update(stage='PATCH_AND_FOOTPRINTS_PUBLISHED',correctedComponents='V26/audit/selection/corrected-components.json',authorizedNetDeltas='V26/audit/selection/authorized-net-deltas.json',footprintLibrary='V26/audit/selection/SmartVio_V26_Selection.pretty',batteryNtcHandoff='V26/audit/selection/battery-ntc-handoff.json',note='J501 header patch follows separately if official library and manufacturer land correspondence are established; do not infer approval from failed PDF download. Speaker is a source reference pressure contact, not a solder-mounted certified footprint.')
status['selections'][-1]['status']='ENGINEERING_SELECTED_LAYOUT_REFERENCE_CHARGE_HOLD'
status['selections'][-1]['independentSensorMpn']='SEMITEC 103AT-2; externally biased separate sensor, not internal pack NTC'
dump('selection-status.json',status)

ntc=json.loads((OUT/'battery-ntc-handoff.json').read_text())
ntc['selected_independent_sensor']['source_sha256']=S['semitec-ntc']['sha256']
ntc['finished_pack']['source_sha256']=S['globtek-pack']['sha256']
dump('battery-ntc-handoff.json',ntc)
print(f'Published {len(records)} component records, {len(pin_records)} electrical pins, {len(land_records)} source-derived footprints; global native unchanged.')
