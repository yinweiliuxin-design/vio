$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$source=Join-Path $PSScriptRoot 'firmware/vendor'
$target=Join-Path $root 'outputs/SmartVio-V26-Engineering/firmware/vendor'
New-Item -ItemType Directory -Force $target | Out-Null
foreach($name in @('st','cmsis','cmsis-dsp-1.16.2')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination $target -Recurse -Force
}
$hal='stm32h7xx-hal-driver-1.11.4'
New-Item -ItemType Directory -Force (Join-Path $target "$hal/Src") | Out-Null
Copy-Item -LiteralPath (Join-Path $source "$hal/Inc") -Destination (Join-Path $target $hal) -Recurse -Force
Copy-Item -LiteralPath (Join-Path $source "$hal/LICENSE.md") -Destination (Join-Path $target $hal) -Force
foreach($suffix in @('hal','hal_rcc','hal_rcc_ex','hal_gpio','hal_dma','hal_dma_ex','hal_sai','hal_sai_ex','hal_cortex','hal_pwr','hal_pwr_ex','hal_flash','hal_flash_ex','hal_iwdg','hal_adc','hal_adc_ex')) {
    Copy-Item -LiteralPath (Join-Path $source "$hal/Src/stm32h7xx_$suffix.c") -Destination (Join-Path $target "$hal/Src") -Force
}
$files=@(Get-ChildItem -LiteralPath $target -Recurse -File)
$rows=@($files | ForEach-Object {
    $relative=$_.FullName.Substring($target.Length+1)
    $original=Join-Path $source $relative
    $hash=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
    if($hash -ne (Get-FileHash -LiteralPath $original -Algorithm SHA256).Hash){throw "Vendor mismatch: $relative"}
    [ordered]@{path=$relative.Replace('\','/');bytes=$_.Length;sha256=$hash}
})
[ordered]@{scope='Licensed minimal build subset, not toolchains or ESP-IDF';files=$rows;identicalToReviewedBuildInputs=$true} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $target '../verification/vendor-handoff.json') -Encoding utf8
Write-Output "Verified vendor files: $($rows.Count)"
