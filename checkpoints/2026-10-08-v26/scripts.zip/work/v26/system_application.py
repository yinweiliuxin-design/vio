"""Application-level review with explicit limits, not a blanket pin approval."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'audit/system-v26'
parts = json.loads((ROOT / 'electrical/native-components.json').read_text(encoding='utf-8'))
by = {c['ref']: c for c in parts}
source_hash = hashlib.sha256((ROOT / 'electrical/native-components.json').read_bytes()).hexdigest()


def p(ref, number):
    return next(pin for pin in by[ref]['pins'] if pin['number'] == str(number))


profiles = [
    {'refs': ['U101', 'U201'], 'domain': 'V3A', 'default': 'Performance supply off; unused U101 channel is a VMID follower, not floating.', 'signal': 'Pickup buffer, SEND buffer, stereo line/return buffers; pickup shield to GND.', 'fault': 'Mute port SSRs on reset, clock/telemetry failure; do not loop RETURN back to SEND.', 'open': ['Output short coordination and audio transient/feedback tests; external voltage misuse is not inherently covered by ESD TVS.']},
    {'refs': ['U301'], 'domain': 'V3A', 'default': 'EN pull-down; HPVDD/HPVSS capacitors required; gains strapped -6dB.', 'signal': 'Stereo ground-referenced TRS headphone only. NO XLR/48V/MIC.', 'fault': 'Internal short/thermal protection plus output SSR isolation; external mono/half-insert can short ring.', 'open': ['K1201/2 are now AQY221R6VY 1A at25C. This is not a current limiter; IC short-current, hot derating, external DC and ESD coordination remain open.']},
    {'refs': ['U401', 'U1401', 'U1501'], 'domain': 'V3D / USB_5V_SAFE as individual nets', 'default': 'USB data disabled until reference/rail ready; CC resistors on safe side.', 'signal': 'USB FS, CC OVP; CMC physical winding corrected to 1-4 and 2-3.', 'fault': 'CC/USB FLT_N goes to MCU. eFuse safe-voltage zero does not prove unplug.', 'open': ['System ESD clamp peak vs MCU 3.3V PHY absolute maximum and powered-off sequencing require transient coordination; do not test destructive faults on user phones/PCs.']},
    {'refs': ['U501', 'Q1601'], 'domain': 'USB_5V_SAFE / SYS / PACK_PLUS', 'default': 'CE high by R503; CHARGE_GATE low by R1602; EN00 restricted source state.', 'signal': 'BQ TS dedicated PACK_NTC; ISET monitoring isolated; TMR/ITERM intentional NC defaults.', 'fault': 'Independent temperature comparator overrides MCU charge allow; pack protection remains separate.', 'open': ['VARTA NTC B3380 is documented; beta tolerance/full R-T/reference temperature/return are incomplete. BQ nominal 0..50C alone cannot establish pack0..45C compatibility.', 'Charge voltage/current/termination/time must include full tolerance; normal charging firmware remains disabled until its authorization and cell-temperature evidence are implemented.']},
    {'refs': ['U601'], 'domain': 'V3A + V3LOAD', 'default': 'Digital and analog off behind U1901; I2C disconnected by U1902; unused channels excluded by mixer config.', 'signal': 'Two I2S RX data lanes, ADC clock at 24.576MHz; four inputs frozen by verified register/readback contract.', 'fault': 'NACK/readback mismatch/clock or DMA errors must mute and disable test grant.', 'open': ['Real analog level, channel mapping, SNR and DMA timing not measured.']},
    {'refs': ['U701'], 'domain': 'V3A + V3LOAD', 'default': 'XSMT held low; SCK grounded for 3-wire PLL; FMT/DEMP grounded, FLT high on switched supply.', 'signal': '48kHz / 64-bit stereo frame; play data separately from speaker data.', 'fault': 'Mute before clocks or rail change; keep MCU signal outputs analog/low when DAC unpowered.', 'open': ['PLL lock, output DC and click/pop remain physical tests.']},
    {'refs': ['U801'], 'domain': 'V3D / MCU_VDDA', 'default': 'HSI8 low-power housekeeping, outputs preloaded safe before mode switch; PC13 pin7 bus enable, not PE8.', 'signal': 'SAI1 RX x2 / SAI2 TX x2; I2C, USART3, ADC wheels, fault inputs, SWD.', 'fault': 'Persistent fault journal and watchdog; invalid readings/expired grant stay muted and charging disabled.', 'open': ['DMA WCET/races, power-source budget and exact silicon revision must be measured; target compile is not on-device execution.']},
    {'refs': ['U901'], 'domain': 'V3LOAD', 'default': 'EN pull-down, UART/I2S back-power prevention; RF startup only after source qualification.', 'signal': 'ESP Classic A2DP SOURCE to external speakers; BLE GATT for control; not all speakers guarantee useful performance latency.', 'fault': 'Pairing timeout/disconnect revoke wireless stream; local wired audio must survive wireless loss.', 'open': ['Actual pairing/reconnect/audio latency/RF coexistence untested; module approval is not whole-product certification.']},
    {'refs': ['U902', 'LS901'], 'domain': 'SYS', 'default': 'SD low and I2S clocks off; BTL outputs float, neither speaker wire grounded.', 'signal': 'Speaker-only 850Hz high-pass proposal and constrained RMS level; keep headphones/line full-bandwidth.', 'fault': 'Mute on DMA/supply/temp fault; clamp does not prove transducer thermal safety.', 'open': ['Speaker spring compression, 1cm3 acoustic cavity, installed power/feedback/temperature test and battery current budget remain unresolved.']},
    {'refs': ['U1001', 'U1101', 'U1301', 'D1301', 'D1302'], 'domain': 'VBUS_RAW / USB_5V_SAFE / SYS / V3D', 'default': 'LTC and USB diode OR wake housekeeping; performance domain defaults off.', 'signal': 'Buck-boost, eFuse, pushbutton power controller and independent USB wake.', 'fault': 'Input OVP/short latch and firmware reset journal; USB present keeps housekeeping on after user OFF.', 'open': ['USB100 cold-start current must be bounded in hardware testing; diode low-temp Vf and all regulator corner assumptions must be reviewed.']},
    {'refs': ['U1701', 'U1702', 'U1703', 'U1801'], 'domain': 'V3D', 'default': 'Monitor mux defaults disconnected; I2C timeouts disable grant.', 'signal': 'USB/battery/SYS/charge-current diagnostics and TMP117 board thermal telemetry.', 'fault': 'NACK, stale conversion, saturation and impossible readings fail closed.', 'open': ['TMP117 board temperature is NOT cell temperature; ADS current channel estimates charge current, not discharge current.']},
    {'refs': ['U1901', 'U1902'], 'domain': 'V3D -> V3LOAD -> V3A', 'default': 'PE2 off and PC13 off by hardware pull-downs; unused switch channels 8..13 grounded.', 'signal': 'Load ramp first, isolated I2C next; reverse order off while ports muted.', 'fault': 'No electrical pin can feed unpowered ADC/DAC/ESP; QOD discharge before re-enable.', 'open': ['CT timing is typical; effective reservoir, ramp/thermal and discharge measured criteria remain pending.']},
    {'refs': ['U1921', 'U1922', 'RT1921'], 'domain': 'SYS comparator + USB-biased 2.5V reference', 'default': 'Open/short/reference missing inhibit CE. Does not depend on BQ TS being active with CE high.', 'signal': 'Independent insulated battery-surface 103AT-2; no user external port and no new MCU status pin.', 'fault': 'OUTA/OUTB wired open-drain to CHARGE_GATE; MCU cannot override temperature inhibit.', 'open': ['R/T beta approximation, surface thermal lag, reference/comparator single faults and Q1601 D-S short not covered by blanket safety claim.']},
    {'refs': ['J102', 'J201', 'J202', 'J301'], 'domain': 'Ground-referenced 3.5mm user audio', 'default': 'Kycon physical1/2ground;3ring,4tip; unused detector5/6NC except headphone.', 'signal': 'TRS: TipL/mono, RingR (SEND grounded), SleeveGND; NO phantom power. J301 detector5sense6GND, inserted LOW.', 'fault': 'Mute before insertion transitions; debounce and half-insert may not equal valid headphone presence.', 'open': ['Four-pole body wired for TRS requires genuine plug/contact qualification; patch removes drawing ambiguity but is not a contact test.']},
]
covered = {ref: profile for profile in profiles for ref in profile['refs']}
records = []
for c in parts:
    profile = covered.get(c['ref'])
    for pin in c['pins']:
        records.append({'ref': c['ref'], 'pin': pin['number'], 'manufacturerName': pin.get('nativeName', pin['name']),
                        'net': pin['net'], 'mpn': c.get('mpn'), 'identityEvidence': pin.get('evidence', c.get('evidence', c.get('bomEvidence'))),
                        'supply': profile['domain'] if profile else 'PASSIVE_OR_INTERFACE: see individual source/selection review',
                        'default': profile['default'] if profile else pin.get('noConnectReason', 'No independent application signoff in this ledger; individual review required.'),
                        'signal': profile['signal'] if profile else pin['name'],
                        'fault': profile['fault'] if profile else 'See parent net application and individual stress/footprint review.',
                        'openItems': profile['open'] if profile else [],
                        'applicationFullyClosed': False, 'physicalTested': False})
(OUT / 'application-profiles.json').write_text(json.dumps({'sourceSha256': source_hash, 'profiles': profiles, 'pins': records,
    'meaning': 'Explicit design review and remaining application limits; NOT a mass conversion of 287 pending pins into PASS.'}, ensure_ascii=False, indent=2), encoding='utf-8')

v = 3.45
load_current = 0.65
pack_min, efficiency = 3.0, 0.70
required = v * load_current / (pack_min * efficiency)
pack_limit = 2.0
speaker_w = 1.0**2 / 8.0
speaker_efficiency = .70
speaker_a = speaker_w / (pack_min * speaker_efficiency)
budget = {'sourceSha256': source_hash,
    'USB100_housekeeping': {'allocatedV3DCurrentA': 0.060, 'V3DMaxV': v, 'efficiencyAssumption': 0.70, 'inputMinV': 4.35,
        'otherInputAllocationA': 0.005, 'calculatedInputA': v * 0.060 / (0.70 * 4.35) + 0.005,
        'guaranteedByMeasurements': False, 'note': 'Budget target, not H743 maximum consumption. Performance rail off during this state.'},
    'performance': {'allocatedRailCurrentA': load_current, 'requiredPackA': required, 'selectedPack': '56457201020',
        'selectedPackContinuousMaxA': pack_limit, 'staticBudgetWithinRating': required + speaker_a + .01 <= pack_limit,
        'speakerPowerW':speaker_w, 'speakerEfficiencyAssumption':speaker_efficiency,
        'speakerPackA':speaker_a, 'extraCurrentReserveA':.01,
        'combinedAllocatedPackA':required+speaker_a+.01, 'transientAndThermalApproved':False,
        'remainingV3DCurrentAIfSpeakerUsesZeroCurrent': pack_min * efficiency * pack_limit / v,
        'note': 'Both loads use3.0V/70% efficiency in this allocation; efficiency and reserve are not guaranteed operating maxima. New2A pack and JST replace0.7A/1A parts together. PCM trip is not operating permission. No function silently removed.'},
    'NTC': json.loads((OUT / 'ntc-independent-calculations.json').read_text(encoding='utf-8')),
    'mechanical': {'coverMm': [148,49], 'oldCavityMm': [78,47,22], 'cupCandidateMm': [76,43,18], 'mainCandidateMm': [72,39,1],
        'packMaxMm': [52,34.5,5.4], 'oldBatteryStripWidthMm': 29.2, 'packFitsOldStrip': False,
        'proposedPlacement':'Insulated under-mainboard cradle, separate from connector edge and speaker chamber; full assembly interference not yet closed',
        'internalBatteryHeaderHeightNominalMm':5.5,
        'simultaneousStackApproved': False, 'outwardMaxMm': 5, 'wholeMaxMm': 25, 'screwLengthMaxMm': 6,
        'factoryGeometryExcludedFromCurrentWaitingDependencies': True},
    'physicalTests': 0, 'fullFunctionProductionRelease': False}
corner_path = ROOT / 'audit/power-closure-v26/same-corner-pack-budget.json'
if corner_path.exists():
    corners = json.loads(corner_path.read_text(encoding='utf-8'))
    assert corners['source_sha256'] == source_hash
    budget['performance']['sameCornerSensitivity'] = corners
    budget['performance']['sameCornerEvidencePath'] = corner_path.relative_to(ROOT).as_posix()
    budget['performance']['loaded3V70pct6p8ohmAllocatedA'] = next(
        row['total_A'] for row in corners['rows'] if row['case'] == 'same_corner3V70pct6p8ohm')
    budget['performance']['note'] += ' Other bias/efficiency/speaker resistance scenarios are recalculated at the same corner; a2.5V SYS sensitivity is not permission to discharge the pack below3V.'
(OUT / 'power-and-stack-budget.json').write_text(json.dumps(budget, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'parts': len(parts), 'pins': len(records), 'profileCoveredParts': len(covered), 'packRequiredA': required, 'packApprovedForFullLoad': False}, ensure_ascii=False))
