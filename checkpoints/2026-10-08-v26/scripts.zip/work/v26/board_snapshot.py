"""Independently rerun KiCad DRC and plot the selected, unapproved native boards."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'verification/pcb-final-v26'
OUT.mkdir(exist_ok=True)
PLOTS = ROOT / 'drawings/pcb-native-v26'
PLOTS.mkdir(exist_ok=True)
source_hash = hashlib.sha256((ROOT / 'electrical/native-components.json').read_bytes()).hexdigest()
checks = []
commands = []


def cli(*args, drc=False):
    result = subprocess.run([sys.executable, '-X', 'utf8', str(BASE / 'work/v24/kicad_cli.py'), *map(str, args)],
                            capture_output=True, text=True, encoding='utf-8', errors='replace')
    commands.append({'args': list(map(str, args)), 'exitCode': result.returncode,
                     'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode not in ([0, 5] if drc else [0]):
        raise RuntimeError(result.stdout + result.stderr)


for name in ['main', 'usb', 'audio', 'cover', 'sensor']:
    board = ROOT / f'pcb-work/SmartVio-{name}-v26-final.kicad_pcb'
    before = hashlib.sha256(board.read_bytes()).hexdigest()
    report = OUT / (name + '-strict-drc.json')
    cli('pcb', 'drc', '--format', 'json', '--output', report, '--severity-all', '--refill-zones', '--exit-code-violations', board, drc=True)
    evidence = json.loads(report.read_text(encoding='utf-8-sig'))
    project = json.loads(board.with_suffix('.kicad_pro').read_text(encoding='utf-8-sig'))
    severities = project.get('board', {}).get('design_settings', {}).get('rule_severities', {})
    ignored = sorted(k for k, v in severities.items() if v == 'ignore')
    checks.append({'board': name, 'sourceSha256': source_hash, 'boardSha256': before,
                   'boardPath': board.relative_to(ROOT).as_posix(),
                   'errors': sum(v['severity'] == 'error' for v in evidence.get('violations', [])),
                   'warnings': sum(v['severity'] == 'warning' for v in evidence.get('violations', [])),
                   'unconnected': len(evidence.get('unconnected_items', [])),
                   'reportedIgnoredChecks': evidence.get('ignored_checks', []),
                   'projectIgnoredCategories': ignored,
                   'projectExclusionCount': len(project.get('board', {}).get('design_settings', {}).get('drc_exclusions', [])),
                   'drcPath': report.relative_to(ROOT).as_posix(), 'manufactureRelease': False})
    for face, layers in [('front', 'F.Cu,F.SilkS,Edge.Cuts'), ('back', 'B.Cu,B.SilkS,Edge.Cuts')]:
        cli('pcb', 'export', 'svg', '--layers', layers, '--mode-single', '--fit-page-to-board',
            '--exclude-drawing-sheet', '--check-zones', '--output', PLOTS / (name + '-' + face + '.svg'), board)
    if hashlib.sha256(board.read_bytes()).hexdigest() != before:
        raise RuntimeError('Board changed during verification: ' + name)
result = {'sourceSha256': source_hash, 'tool': 'KiCad CLI native DRC and SVG export', 'boards': checks,
          'allNativeRulesEnabled': all(not x['reportedIgnoredChecks'] and not x['projectIgnoredCategories'] and not x['projectExclusionCount'] for x in checks),
          'physicalTests': 0, 'manufactureRelease': False}
(OUT / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
(OUT / 'commands.json').write_text(json.dumps(commands, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
