"""Promote only local board fixes with preserved nets and zero strict DRC."""
import hashlib
import json
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering/pcb-work'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
results = []
for kind in ['usb', 'audio']:
    source = ROOT / f'SmartVio-{kind}-v26-final.kicad_pcb'
    candidate = ROOT / f'SmartVio-{kind}-v26-parent-local.kicad_pcb'
    evidence = json.loads((ROOT / f'verification/parent-{kind}-local-eco.json').read_text())
    drc = json.loads((ROOT / f'verification/parent-{kind}-local-drc.json').read_text())
    assert sha(source) == evidence['sourceBoardSha256']
    assert drc['source'] == candidate.name
    assert not drc['violations'] and not drc['unconnected_items'] and not drc['ignored_checks']
    assert evidence['allNetsAndPadsPreserved']
    backup = ROOT / 'verification/pre-parent-local' / source.name
    backup.parent.mkdir(exist_ok=True)
    assert not backup.exists(), 'Do not overwrite the pre-repair audit copy'
    shutil.copy2(source, backup)
    shutil.copy2(candidate, source)
    results.append({'board': kind, 'beforeSHA256': sha(backup), 'afterSHA256': sha(source),
                    'candidateDRC': drc, 'changeEvidence': evidence,
                    'productionApproved': False})
(ROOT / 'verification/parent-local-promotion.json').write_text(json.dumps(results, indent=2))
print(json.dumps([{'board': r['board'], 'afterSHA256': r['afterSHA256']} for r in results]))
