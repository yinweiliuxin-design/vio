"""Merge owned selection ECOs with exact per-component guards."""
import copy
import hashlib
import json
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
selection = ROOT / 'audit/selection'
shutil.copytree(BASE / 'V26/audit/selection', selection, dirs_exist_ok=True)
source = ROOT / 'electrical/native-components.json'
parts = json.loads(source.read_text(encoding='utf-8'))
by = {c['ref']: c for c in parts}
delta = json.loads((selection / 'authorized-net-deltas.json').read_text(encoding='utf-8'))
battery = json.loads((selection / 'battery-interface-proposal.json').read_text(encoding='utf-8'))
ops = delta['operations'] + [battery['operation']]
log = {'beforeSha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'operations': [],
       'scope': 'Selected owned components only; unrelated MCU and independent NTC ECO preserved',
       'physicalTests': 0, 'manufactureRelease': False}
for op in ops:
    ref = op['ref']
    replacement = copy.deepcopy(op['replacement'])
    if op['op'] == 'add_component':
        if ref in by and by[ref] == replacement:
            continue
        assert ref not in by, f'{ref} already exists: explicit rebase required'
        replacement['sheet'] = 'A11'
        parts.append(replacement)
        by[ref] = replacement
    else:
        existing = by[ref]
        if existing == replacement:
            continue
        assert existing == op['precondition'], f'{ref} precondition changed: scoped rebase required'
        parts[parts.index(existing)] = replacement
        by[ref] = replacement
    log['operations'].append({'op': op['op'], 'ref': ref, 'mpn': replacement['mpn'],
                              'pins': [{'number': p['number'], 'net': p['net']} for p in replacement['pins']]})
assert next(p for p in by['U801']['pins'] if p['number'] == '7')['nativeName'] == 'PC13'
assert next(p for p in by['U1921']['pins'] if p['number'] == '3')['net'] == 'CELL_NTC_SENSE'
source.write_text(json.dumps(parts, ensure_ascii=False, indent=2), encoding='utf-8')
log['afterSha256'] = hashlib.sha256(source.read_bytes()).hexdigest()
log['parts'] = len(parts)
log['pins'] = sum(len(c['pins']) for c in parts)
(ROOT / 'audit/system-v26/selection-merge-log.json').write_text(json.dumps(log, ensure_ascii=False, indent=2), encoding='utf-8')
(ROOT / 'audit/system-v26/native-revision.json').write_text(json.dumps({'parts': log['parts'], 'pins': log['pins'], 'sha256': log['afterSha256']}, indent=2), encoding='utf-8')
print(json.dumps(log, ensure_ascii=False))
