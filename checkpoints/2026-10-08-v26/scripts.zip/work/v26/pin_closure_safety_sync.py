"""Attach independently verified target safety remediation without closing hardware application pins."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
OUT = ROOT / 'audit/pin-closure-v26'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source_hash = sha(ROOT/'electrical/native-components.json')
completion_path = ROOT/'firmware/verification/f01-f02-completion.json'
completion = json.loads(completion_path.read_text(encoding='utf-8-sig'))
parent_path = ROOT/'verification/parent-host-rerun-v26.json'
parent = json.loads(parent_path.read_text(encoding='utf-8-sig'))
assert source_hash == completion['nativeSourceSha256'] == parent['sourceSha256']
assert parent['allNineHostProgramsPass'] and parent['currentTargetAndSafetyInputHashesPass']
path = OUT/'findings.json'
findings = json.loads(path.read_text(encoding='utf-8-sig'))
backup = OUT/'findings-before-target-safety-sync.json'
if not backup.exists():
    backup.write_bytes(path.read_bytes())
for entry in findings:
    if entry['id'] not in ['F01','F02']:
        continue
    entry['status'] = 'SOFTWARE_REMEDIATION_INTEGRATED_VERIFIED_PHYSICAL_TIMING_PENDING'
    entry['statement'] = completion[entry['id']]
    entry['parent_followup'] = 'Actual target source reviewed and nine current host programs independently rerun. Physical tests remain0. Baseline pin application counts not automatically closed.'
    entry['closure_evidence_needed'] = ['Physical INT/insert timing, startup boundaries and instrumented output power-down']
    entry['current_source_sha256'] = source_hash
    entry['current_firmware_main_sha256'] = completion['mainSourceSha256']
    entry['completion_evidence'] = {'relativePath':completion_path.relative_to(ROOT).as_posix(), 'sha256':sha(completion_path)}
    entry['independent_parent_rerun'] = {'relativePath':parent_path.relative_to(ROOT).as_posix(), 'sha256':sha(parent_path)}
    entry['hardware_tests'] = 0
path.write_text(json.dumps(findings,indent=2),encoding='utf-8')
status_path = OUT/'status.json'
status = json.loads(status_path.read_text(encoding='utf-8-sig'))
assert status['source_sha256'] == source_hash
counts = status['status_counts'].copy()
status['firmware_findings_disposition'] = 'F01/F02 current target software remediation integrated, reviewed and independently rerun; physical timing pending. No baseline application pin is automatically closed.'
status['firmware_safety_completion'] = {'relativePath':completion_path.relative_to(ROOT).as_posix(), 'sha256':sha(completion_path)}
status['independent_host_rerun'] = {'relativePath':parent_path.relative_to(ROOT).as_posix(), 'sha256':sha(parent_path)}
assert status['status_counts'] == counts
status_path.write_text(json.dumps(status,indent=2),encoding='utf-8')
record = {'sourceSHA256':source_hash,'findingsSHA256':sha(path), 'F01F02SoftwareReviewVerified':True,
          'physicalTimingTests':0,'original287PinCountsUnchanged':True,'statusSHA256':sha(status_path),'productionApproved':False}
(OUT/'firmware-safety-closure.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
