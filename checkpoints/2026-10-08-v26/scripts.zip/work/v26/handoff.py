"""Prepare an explicit engineering handoff, never a false manufacturing release."""
import csv
import hashlib
import html
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
MAN = ROOT / 'manufacturing-v26'
MAN.mkdir(exist_ok=True)
parts = json.loads((ROOT / 'electrical/native-components.json').read_text(encoding='utf-8'))
by = {c['ref']: c for c in parts}
source_hash = hashlib.sha256((ROOT / 'electrical/native-components.json').read_bytes()).hexdigest()
old_pins = json.loads((BASE / 'outputs/SmartVio-V25-Engineering/audit/all-pins.json').read_text(encoding='utf-8'))
pending_categories = {'REQUIRES_REVIEW', 'PASSIVE_APPLICATION_AND_MPN_REVIEW_PENDING', 'HOLD_PHYSICAL_PAD_OR_FUNCTION'}
old_pending = [p for p in old_pins if p['reviewStatus'] in pending_categories]
assert len(old_pending) == 287
selection_refs = {o['ref'] for o in json.loads((ROOT / 'audit/system-v26/selection-merge-log.json').read_text(encoding='utf-8'))['operations']}
field_refs = {r['ref'] for e in json.loads((ROOT / 'audit/system-v26/field-merge-log.json').read_text(encoding='utf-8')) for r in e['applied']}
tracking = []
review_path = ROOT / 'audit/pin-closure-v26/pin-review.json'
review = json.loads(review_path.read_text(encoding='utf-8')) if review_path.exists() else {}
current_review = review.get('source_sha256') == source_hash
review_rows = {(r['baseline']['ref'],str(r['baseline']['pin'])):r for r in review.get('rows',[])} if current_review else {}
for old in old_pending:
    c = by[old['ref']]
    tracking.append({'legacyRef': old['ref'], 'legacyPin': old['pin'], 'legacyNet': old['net'], 'legacyStatus': old['reviewStatus'],
        'currentMpn': c.get('mpn'), 'currentPinMap': [{'pin': p['number'], 'net': p['net']} for p in c['pins']],
        'action': 'EXACT_COMPONENT_AND_PIN_REPLACEMENT_MERGED' if c['ref'] in selection_refs else 'MPN_LAND_REVIEW_MERGED' if c['ref'] in field_refs else 'COPPER_ENDPOINT_REVIEW' if c.get('fabricatedFeature') else 'APPLICATION_ITEM_REMAINS_OPEN',
        'fullyElectricallyApproved': False, 'hardwareTested': False,
        'warning': 'A reviewed MPN or renamed pin is not application signoff; see detailed calculations, same-version PCB and fault review.'})
    application = review_rows.get((old['ref'],str(old['pin'])))
    if application:
        tracking[-1].update({'localApplicationStatus':application['status'],
            'localDesignReviewClosed':application['design_review_closed'],
            'pendingLimits':application['pending_limits'], 'closedScope':application['closed_scope'],
            'applicationReviewRelativePath':'audit/pin-closure-v26/pin-review.json'})
(ROOT / 'verification/legacy-287-tracking.json').write_text(json.dumps({'baselinePending': 287, 'records': tracking, 'all287FullyClosed': False,
    'sourceSha256': source_hash, 'sameSourceApplicationReviewIntegrated':current_review,
    'localDesignReviewClosed':sum(bool(r.get('localDesignReviewClosed')) for r in tracking),
    'physicalTests': 0}, ensure_ascii=False, indent=2), encoding='utf-8')

bom_rows = []
for c in parts:
    is_feature = c['ref'] in {'J101','J801','J901','J902','J1801','J1802','J1921'}
    bom_rows.append({'Ref': c['ref'], 'Value': c['value'], 'MPN': c.get('mpn') or '', 'Manufacturer': c.get('manufacturer') or '',
        'Package': c.get('package') or '', 'Qty': 1, 'Population': 'FABRICATED_COPPER_FEATURE' if is_feature else 'ENGINEERING_CANDIDATE',
        'ProcurementApproved': False, 'Release': 'NOT_RELEASED', 'SourceSHA256': source_hash})
with (MAN / 'BOM-V26-ENGINEERING-NOT-RELEASED.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=bom_rows[0].keys())
    writer.writeheader()
    writer.writerows(bom_rows)

harness = [
    {'ID': 'H-PACK', 'from': 'VARTA56457201020 finished protected pack, factory bare AWG24 leads', 'to': 'J501 JST S3B-PH-SM4-TB(LF)(SN)', 'cut': 'Manufacturer45..55mm leads; no arbitrary cutting before complete route/strain-relief drawing', 'strip': 'For SPH-002T-P0.5S crimp, approved application tool/strip setting not yet frozen. Do not open pack or rework cell tabs.', 'map': 'PHR-3 pin1 red PACK_PLUS;pin2 black GND;pin3 white PACK_NTC', 'process': 'Controlled harness crimp, not a factory-fitted pack connector. Verify pin1 drawing, isolated continuity/polarity and crimp pull strength; use guarded insulated tooling and never bridge live pack leads.'},
    {'ID': 'H-NTC', 'from': 'RT1921 Semitec103AT-2', 'to': 'J1921 main', 'cut': '80mm candidate each wire; final routing/cut length NOT FROZEN', 'strip': '2.0mm candidate for PCB pad; retain insulated strain relief, no exposed cell contact', 'map': '1 CELL_NTC_SENSE;2 GND. Nonpolar sensor; do NOT parallel PACK_NTC.', 'process': 'Insulated external cell-surface thermal bond only. No pouch piercing, opening or soldering to cell.'},
    {'ID': 'H-PICKUP', 'from': 'Existing bridge pickup and existing wire hole', 'to': 'J101 main', 'cut': 'Reuse existing wire; no fixed new cut length without physical route', 'strip': 'Preserve braid and dielectric; verify under magnification', 'map': '1 PZ_RAW;2 shield GND', 'process': 'Route away from switching inductor, BTL and RF. Strain relief before board pads; do not load bridge mechanically.'},
    {'ID': 'H-SPK', 'from': 'H_COVER_2_M pins6/5', 'to': 'H_COVER_2_R pins6/5 then cover copper to LS901', 'cut': 'Route within cover harness as twisted pair; cut length NOT FROZEN', 'strip': 'Only PCB solder endpoints; stripping NOT FROZEN', 'map': '6 SPK_P;5 SPK_N; neither is GND', 'process': 'No second parallel cable from J901; J901 remains internal alternate/test pads. Spring-contact preload fixture and acoustic chamber remain unqualified. Do not solder directly to speaker springs.'},
    {'ID': 'H-TEMP', 'from': 'J1801 main', 'to': 'J1802 sensor', 'cut': '100mm candidate; NOT FROZEN', 'strip': '2.0mm candidate, each end', 'map': '1 V3D;2 GND;3 TEMP_SCL;4 TEMP_SDA', 'process': 'Match 1-to-1; avoid swapping power. TMP117 is board temperature, not RT1921 or cell NTC.'},
]
(MAN / 'harness-process-DRAFT.json').write_text(json.dumps({'sourceSha256': source_hash, 'items': harness, 'allCutLengthsFrozen': False,
    'interboardDefinition': 'interboard-wire-by-wire.json',
    'weldPathsProductionApproved': False, 'reason': 'Actual endpoints documented; cable material, cutting, stripping, strain relief and full assembly remain unfrozen.'}, ensure_ascii=False, indent=2), encoding='utf-8')

steps = [
    ('01', '版本与投板门禁', '核对电路源、原生PCB、Gerber/钻孔/焊膏/坐标/BOM的同一版哈希。主板未连接或封装不符时不得投完整一体机。旧V25制造文件仅作历史证据，不是本版工厂文件。'),
    ('02', '电子厂DFM签署', '逐板确认叠层、外/内铜厚、钻孔/微孔工艺、盲孔填孔盖铜、阻抗、槽孔、拼板和AOI/X-ray能力。USB中心地焊球的HDI工艺不能当成普通通孔工艺。不得替工厂签署。'),
    ('03', '焊接与装配', '先核对封装、极性、pin1和未使用脚。各器件按其原厂MSL/回流/手焊限制建过程卡；不可把按键、调节轮、塑料插座、电池和扬声器统一放入同一回流流程。电池/NTC/喇叭固定件后装。'),
    ('04', '无电首检', '不接电池、不接USB手机/电脑。显微镜/AOI检查桥连、缺件、极性、HDI地焊球；检测每个电源对地、每个端口触点/检测开关及板间线束连续性。记录真实阻值，不假设电容充电引起的低阻一定正常。'),
    ('05', '安全首次上电', '先用限流夹具、假电池/可源可吸电池模拟器和隔离测试USB源；不要把台式电源直接与真电池并联。充电CE、音频/RF默认禁止，保留急停与温度监测。限制输入状态从USB100开始，测冷启动峰值和稳定电流后再升级功率许可。'),
    ('06', '烧录与自检', 'STM32通过J801 SWD，J902仅目标电压参考，不向失电V3LOAD反灌。ESP按bootloader/分区表/app镜像及flasher_args.json地址烧录；使用有界ROM烧录会话，不得将STM32一直拉在复位导致V3LOAD失电。夹具须有VTREF掉电联锁；核对目标型号、镜像哈希、日志及默认禁充/静音。'),
    ('07', '充电专用夹具', '使用电阻箱验证PACK_NTC和独立RT1921开短路、冷热禁充。读取TMP117不能替代电池表面温度。先假电池验证输入限流、CE时序、终止/再充和USB断插，真实电池全充流程未批准前不得接真电池试充。'),
    ('08', '音频逐路', '示波器先测48kHz FS、3.072MHz BCLK、24.576MHz ADC参考时钟及64-bit帧，再测双ADC通道映射。输出先假负载和低幅1kHz测试音，核对耳机直流、半插静音、LINE/SEND/RETURN串音及增益。BTL负端不得接示波器地。'),
    ('09', '无线与热', '明确A2DP SOURCE到外置音箱，BLE为控制。配对/断连/重连、干扰、音频延时、低电量和边充边用分别记录实测。逐点记录IC、电感、壳体、电池温升，不能将计算热功耗当温升测试。'),
    ('10', '结构与螺丝', '上盖四角螺丝、下壳只卡扣；长度不超过6mm是上限，不是所有点都选6mm。螺钉直径/头型/导孔与胶合板拔出、滑牙及循环拆装验证后冻结扭矩。目前没有获批的扭矩值，不以估算数值冒充生产规格。'),
    ('11', '首件检验与异常', '记录板号/序列号、料批、程序哈希、仪器和校准、操作人、测量值、照片、故障和返修复测。任何电源/热/音频异常立即静音禁充断电，写故障日志，不自动反复重启。'),
]
(MAN / 'factory-sequence-DRAFT.json').write_text(json.dumps({'revision': 'V26', 'sourceSha256': source_hash,
    'steps': [{'id': i, 'name': n, 'instruction': s} for i,n,s in steps], 'factorySigned': False, 'fullSampleRelease': False}, ensure_ascii=False, indent=2), encoding='utf-8')
text = 'SmartVio V26 工程审核交付说明\n不是完整一体机样机生产放行包\n\n'
text += '已按用户要求，不将琴厂几何测量、供应商寄样作为本轮等待项；这不等于真实装配/容量/保护验证已经完成。\n\n'
text += '\n\n'.join(f'{i}. {n}\n{s}' for i,n,s in steps)
text += '\n\n源哈希: ' + source_hash + '\n'
(MAN / 'FACTORY-PROCEDURE-DRAFT.txt').write_text(text, encoding='utf-8-sig')
print(json.dumps({'sourceSha256': source_hash, 'bomRows': len(bom_rows), 'legacyPendingTracked': len(tracking), 'factorySteps': len(steps), 'productionRelease': False}, ensure_ascii=False))
