"""Check current native capture and topology with explicit negative controls."""
import copy
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V26-Engineering'
V = ROOT / 'verification'
records = []


def cli(*args):
    cmd = [sys.executable, '-X', 'utf8', str(BASE / 'work/v24/kicad_cli.py'), *map(str, args)]
    result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    records.append({'command': cmd, 'exitCode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)


def checks(parts):
    by = {c['ref']: c for c in parts}

    def pin(ref, number):
        return next(p for p in by[ref]['pins'] if p['number'] == str(number))

    def net(ref, number):
        return pin(ref, number)['net']

    return {
        'charge_current_monitor_connected': net('U501', 16) == net('R501', 1) == net('U1702', 12),
        'charger_thermal_pad_ground': net('U501', 17) == 'GND',
        'charge_gate_active_low': net('Q1601', 3) == net('U501', 4) == 'CHARGE_DISABLE',
        'charge_gate_reset_pulldown': net('Q1601', 1) == net('R1602', 1) and net('R1602', 2) == 'GND',
        'pack_ntc_bq_backup': net('U501', 1) == net('J501', 3) == 'PACK_NTC',
        'bq_safety_timer_not_disabled': net('U501', 14) is None,
        'independent_ntc_not_shared_with_bq_ts': net('U1921', 3) == net('J1921', 1) == net('RT1921', 1) == 'CELL_NTC_SENSE',
        'ntc_reference_usb_powered': net('R1923', 1) == 'USB_5V_SAFE' and net('R1923', 2) == net('U1922', 1) == 'TEMP_REF2V5',
        'ntc_reference_anode_and_star_ground': net('U1922', 2) == net('U1922', 3) == 'GND',
        'ntc_hot_and_cold_override_mcu': net('U1921', 1) == net('U1921', 6) == net('Q1601', 1) == 'CHARGE_GATE',
        'ntc_cold_divider_current_revision': by['R1921']['mpn'] == 'RC0603FR-07158KL',
        'usb_wake_or_separate_ltc_output': net('U1301', 6) == net('D1301', 1) == 'PWR_LTC_EN' and net('D1301', 3) == net('D1302', 3) == net('U1101', 14) == 'SYS_ENABLE',
        'performance_gate_hardware_default_off': net('U1901', 3) == net('R1911', 1) == net('U801', 1) == 'AUDIO_PWR_EN' and net('R1911', 2) == 'GND',
        'audio_bus_pc13_not_pe8': pin('U801', 7)['nativeName'] == 'PC13' and net('U801', 7) == net('R1913', 1) == 'AUDIO_BUS_EN' and net('U801', 38) == 'CC_FAULT_N',
        'audio_bus_switch_not_load_domain_powered': net('U1902', 14) == 'V3D',
        'audio_i2c_isolated': net('U1902', 3) == net('U601', 23) == 'I2C_AUDIO_SDA' and net('U1902', 6) == net('U601', 24) == 'I2C_AUDIO_SCL',
        'audio_switch_unused_channels_grounded': all(net('U1902', i) == 'GND' for i in range(8, 14)),
        'adc_dac_rf_share_switched_digital_domain': all(net(r, p) == 'V3LOAD' for r, p in [('U601', 13), ('U601', 14), ('U701', 11), ('U701', 20), ('U901', 3), ('J902', 1)]),
        'filtered_analog_domain_from_load': net('FB1101', 1) == 'V3LOAD' and net('FB1101', 2) == 'V3A',
        'adc_lane2_damping': net('U601', 21) == net('R691', 1) == 'ADC_DATA2_SRC' and net('R691', 2) == net('U801', 2) == 'ADC_DATA2',
        'dac_three_wire_clock': net('U701', 12) == 'GND',
        'radio_enable_default_off': net('R901', 1) == net('C901', 1) == net('U901', 8) == 'RF_CHIP_EN' and net('R901', 2) == 'GND',
        'radio_enable_cap_is_resistor_isolated': net('R907', 1) == net('U801', 33) == 'RF_ENABLE' and net('R907', 2) == 'RF_CHIP_EN',
        'usb_reference_independent_of_mcu_rail': net('U1501', 8) == 'USB_VREF' and net('U1501', 6) == 'USB_OVP_MODE',
        'headphone_charge_pump_reservoir_larger_nominal': by['C304']['value'].startswith('2.2uF'),
        'unused_opamp_feedback_not_floating': net('U101', 12) == 'VMID' and net('U101', 13) == net('U101', 14) == 'UNUSED_BUF',
    }


parts = json.loads((ROOT / 'electrical/native-components.json').read_text(encoding='utf-8'))
baseline = checks(parts)
negative = []
for ref, number, bad, expected in [
    ('U501', '17', 'PACK_PLUS', 'charger_thermal_pad_ground'),
    ('U501', '14', 'GND', 'bq_safety_timer_not_disabled'),
    ('U1921', '3', 'PACK_NTC', 'independent_ntc_not_shared_with_bq_ts'),
    ('R1923', '1', 'CHARGE_GATE', 'ntc_reference_usb_powered'),
    ('U1921', '6', 'NTC_UNCONNECTED', 'ntc_hot_and_cold_override_mcu'),
    ('U1301', '6', 'SYS_ENABLE', 'usb_wake_or_separate_ltc_output'),
    ('R1911', '2', 'V3D', 'performance_gate_hardware_default_off'),
    ('U1902', '14', 'V3LOAD', 'audio_bus_switch_not_load_domain_powered'),
    ('U601', '23', 'I2C_SDA', 'audio_i2c_isolated'),
    ('U1902', '10', None, 'audio_switch_unused_channels_grounded'),
    ('U901', '3', 'V3D', 'adc_dac_rf_share_switched_digital_domain'),
    ('FB1101', '1', 'V3D', 'filtered_analog_domain_from_load'),
    ('U801', '2', 'ADC_DATA', 'adc_lane2_damping'),
    ('U1501', '8', 'V3D', 'usb_reference_independent_of_mcu_rail'),
]:
    changed = copy.deepcopy(parts)
    part = next(c for c in changed if c['ref'] == ref)
    next(p for p in part['pins'] if p['number'] == number)['net'] = bad
    negative.append({'ref': ref, 'pin': number, 'injectedNet': bad, 'expectedCheck': expected, 'detected': not checks(changed)[expected]})
changed = copy.deepcopy(parts)
next(p for c in changed if c['ref'] == 'U801' for p in c['pins'] if p['number'] == '7')['nativeName'] = 'PE8'
negative.append({'ref': 'U801', 'pin': '7', 'injectedIdentity': 'PE8', 'expectedCheck': 'audio_bus_pc13_not_pe8', 'detected': not checks(changed)['audio_bus_pc13_not_pe8']})

cli('sch', 'erc', '--format', 'json', '-o', V / 'erc.json', ROOT / 'eda/SmartVio.kicad_sch')
cli('sch', 'export', 'netlist', '--format', 'kicadxml', '-o', V / 'native-netlist.xml', ROOT / 'eda/SmartVio.kicad_sch')
cli('sch', 'export', 'svg', '-o', str(ROOT / 'drawings') + '/', ROOT / 'eda/SmartVio.kicad_sch')
cli('sch', 'export', 'pdf', '-o', ROOT / 'drawings/SmartVio-V26-Schematic-REVIEW.pdf', ROOT / 'eda/SmartVio.kicad_sch')
expected, actual = {}, {}
for c in parts:
    for p in c['pins']:
        if p['net']:
            expected.setdefault(p['net'], set()).add((c['ref'], p['number']))
for n in ET.parse(V / 'native-netlist.xml').findall('.//nets/net'):
    name = n.get('name')
    if not name.startswith('unconnected-'):
        actual[name] = {(v.get('ref'), v.get('pin')) for v in n.findall('node') if not v.get('ref').startswith('#')}
diff = [{'net': n, 'missing': sorted(expected.get(n, set()) - actual.get(n, set())), 'extra': sorted(actual.get(n, set()) - expected.get(n, set()))}
        for n in sorted(set(expected) | set(actual)) if expected.get(n, set()) != actual.get(n, set())]
erc = json.loads((V / 'erc.json').read_text(encoding='utf-8'))
violations = [v for s in erc['sheets'] for v in s['violations']]
mapping = json.loads((ROOT / 'electrical/footprint-map.json').read_text(encoding='utf-8'))
exported_parts = {c.get('ref'): c for c in ET.parse(V / 'native-netlist.xml').findall('./components/comp')}
footprint_diff = []
for c in parts:
    expected_footprint = mapping[c['ref']].get('id') or ''
    actual_footprint = exported_parts[c['ref']].findtext('footprint', '')
    if actual_footprint != expected_footprint:
        footprint_diff.append({'ref': c['ref'], 'expected': expected_footprint, 'actual': actual_footprint})
summary = {'revision': 'V26', 'components': len(parts), 'pins': sum(len(c['pins']) for c in parts), 'nets': len(expected),
           'sourceSha256': hashlib.sha256((ROOT / 'electrical/native-components.json').read_bytes()).hexdigest(),
           'ercViolations': len(violations), 'netlistDifferences': diff, 'logicalTopologyChecks': baseline,
           'footprintFieldDifferences': footprint_diff, 'footprintFieldsChecked': len(parts),
           'negativeControls': negative, 'pass': not violations and not diff and not footprint_diff and all(baseline.values()) and all(n['detected'] for n in negative),
           'scope': 'Native capture transfer and named logical topology ONLY. Not device application approval, analog simulation, PCB routing approval or physical test.',
           'physicalTests': 0, 'manufactureRelease': False}
(V / 'electrical-check-v26.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
(V / 'export-log-v26.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2))
if not summary['pass']:
    raise SystemExit(1)
