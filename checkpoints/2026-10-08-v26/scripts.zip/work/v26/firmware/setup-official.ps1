$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$out=Join-Path $root 'outputs/SmartVio-V26-Engineering/firmware/verification'
$vendor=Join-Path $PSScriptRoot 'vendor'
$downloads=Join-Path $PSScriptRoot 'downloads'
New-Item -ItemType Directory -Force $vendor,$downloads,(Join-Path $PSScriptRoot 'build'),(Join-Path $PSScriptRoot 'tmp') | Out-Null
Start-Transcript -Path (Join-Path $out 'official-setup.log')
try {
    foreach($item in @(
        @{name='esp-idf-v5.4.3.zip';url='https://github.com/espressif/esp-idf/releases/download/v5.4.3/esp-idf-v5.4.3.zip';folder='esp-idf-v5.4.3'},
        @{name='stm32h7xx-hal-driver-v1.11.4.zip';url='https://codeload.github.com/STMicroelectronics/stm32h7xx-hal-driver/zip/refs/tags/v1.11.4';folder='stm32h7xx-hal-driver-1.11.4'}
    )) {
        $archive=Join-Path $downloads $item.name
        if(!(Test-Path (Join-Path $vendor $item.folder))){
            & curl.exe -L --fail --retry 3 --connect-timeout 30 $item.url -o $archive
            if($LASTEXITCODE -ne 0){throw "Download failed: $($item.url)"}
            & tar.exe -xf $archive -C $vendor
            if($LASTEXITCODE -ne 0){throw "Extraction failed: $archive"}
        }
    }
    $old=Join-Path $root 'work/v25/firmware'
    foreach($folder in @('st','cmsis')) {
        if(!(Test-Path (Join-Path $vendor $folder))){Copy-Item -LiteralPath (Join-Path $old ('vendor/'+$folder)) -Destination $vendor -Recurse}
    }
    Copy-Item -LiteralPath (Join-Path $old 'downloads/STM32H743VITx.xml') -Destination $downloads
    Copy-Item -LiteralPath (Join-Path $old 'generate-i2c-test-header.ps1') -Destination $PSScriptRoot
    $env:IDF_PATH=Join-Path $vendor 'esp-idf-v5.4.3'
    $env:IDF_TOOLS_PATH=Join-Path $PSScriptRoot 'esp-tools'
    $env:PIP_CACHE_DIR=Join-Path $PSScriptRoot 'pip-cache'
    $env:TEMP=Join-Path $PSScriptRoot 'tmp';$env:TMP=$env:TEMP
    $python='<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
    & $python (Join-Path $env:IDF_PATH 'tools/idf_tools.py') install --targets=esp32
    if($LASTEXITCODE -ne 0){throw 'Official ESP tool installation failed'}
    & $python (Join-Path $env:IDF_PATH 'tools/idf_tools.py') install-python-env
    if($LASTEXITCODE -ne 0){throw 'Official ESP Python environment setup failed'}
    [ordered]@{status='OFFICIAL_DEPENDENCIES_INSTALLED';idfPath=$env:IDF_PATH;idfToolsPath=$env:IDF_TOOLS_PATH;archives=@(Get-ChildItem $downloads -Filter '*.zip' | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash);toolDownloadChecks='idf_tools.py checks the pinned official tools.json checksums';hardwareTests=0} | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $out 'official-setup.json') -Encoding utf8
} catch {
    @{status='SETUP_FAILED';error=$_.Exception.Message;hardwareTests=0} | ConvertTo-Json | Set-Content (Join-Path $out 'official-setup.json') -Encoding utf8
    throw
} finally {Stop-Transcript}
