$ErrorActionPreference='Stop'
$dest=Join-Path $PSScriptRoot 'vendor/cmsis-dsp-1.16.2'
$files=@('LICENSE','Include/arm_math_types.h','Include/arm_math_memory.h','Include/dsp/filtering_functions.h','Include/dsp/none.h','Include/dsp/utils.h','Include/dsp/support_functions.h','Include/dsp/fast_math_functions.h','Include/dsp/basic_math_functions.h','Source/FilteringFunctions/arm_biquad_cascade_df1_f32.c','Source/FilteringFunctions/arm_biquad_cascade_df1_init_f32.c')
foreach($file in $files){
    $path=Join-Path $dest $file
    New-Item -ItemType Directory -Force (Split-Path $path)|Out-Null
    & curl.exe --silent --show-error --fail --location --max-time 45 --retry 2 ('https://raw.githubusercontent.com/ARM-software/CMSIS-DSP/v1.16.2/'+$file) --output $path
    if($LASTEXITCODE -ne 0){throw "Official CMSIS-DSP download failed: $file"}
}
@{upstream='https://github.com/ARM-software/CMSIS-DSP';version='v1.16.2';subset=$files;files=@($files|ForEach-Object {Get-FileHash (Join-Path $dest $_)|Select-Object Path,Hash})}|ConvertTo-Json -Depth 5|Set-Content (Join-Path $dest 'provenance.json') -Encoding utf8
