"""Append exact native copper through an AST, preserving all original net names."""
import argparse
import hashlib
import json
import shutil
import sys
import uuid
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BASE / 'work/v26/parser-tools'))
import sexpdata as sx

ROOT = BASE / 'outputs/SmartVio-V26-Engineering/pcb-work'
parser = argparse.ArgumentParser()
parser.add_argument('kind', choices=['usb', 'audio'])
args = parser.parse_args()
src = ROOT / f'SmartVio-{args.kind}-v26-final.kicad_pcb'
dst = ROOT / f'SmartVio-{args.kind}-v26-parent-local.kicad_pcb'
original = sx.loads(src.read_text(encoding='utf-8'))
tree = sx.loads(src.read_text(encoding='utf-8'))
paths = ([('VBUS_RAW', [(12, 11.6246), (12, 11.45), (12.2, 11.25), (12.3522, 11.25), (12.3522, 11.2724)])]
         if args.kind == 'usb' else [('HP_L_PORT', [(23.6, 12.25), (23.6, 13.05), (58.45, 13.05), (58.45, 12.25)])])
layer = 'B.Cu'
removed = []
if args.kind == 'audio':
    for entry in list(tree[1:]):
        if isinstance(entry, list) and any(isinstance(v, list) and str(v[0]) == 'uuid' and v[1] == '661ea6f3-140b-4f02-ba04-19a65005ff8f' for v in entry[1:]):
            removed.append(entry)
            tree.remove(entry)
    assert len(removed) == 1, 'Expected exact obsolete HP_L horizontal route'
added = []
for net, pts in paths:
    for start, end in zip(pts, pts[1:]):
        added.append([sx.Symbol('segment'), [sx.Symbol('start'), *start], [sx.Symbol('end'), *end],
                      [sx.Symbol('width'), 0.2], [sx.Symbol('layer'), layer], [sx.Symbol('net'), net],
                      [sx.Symbol('uuid'), str(uuid.uuid4())]])
tree.extend(added)
serialized = sx.dumps(tree)
parsed = sx.loads(serialized)
assert parsed[:-len(added)] == [e for e in original if e not in removed], 'Unrelated native AST changed'
dst.write_text(serialized + '\n', encoding='utf-8')
for ext in ['.kicad_pro', '.kicad_dru']:
    if src.with_suffix(ext).exists():
        shutil.copy2(src.with_suffix(ext), dst.with_suffix(ext))
(ROOT / 'verification' / f'parent-{args.kind}-local-eco.json').write_text(json.dumps({
    'sourceBoardSha256': hashlib.sha256(src.read_bytes()).hexdigest(), 'candidate': str(dst),
    'paths': paths, 'traceWidthMm': 0.2, 'layer': layer, 'strictDRCRequired': True,
    'unmodifiedNativeASTPreserved': True, 'allNetsAndPadsPreserved': True,
    'explicitlyReplacedCopper': [sx.dumps(e) for e in removed],
    'parser': 'sexpdata1.0.2; original native expressions preserved', 'manufactureRelease': False}, indent=2), encoding='utf-8')
print(dst)
