import hashlib
import json
import os
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V25-Engineering'
os.environ['KICAD_CONFIG_HOME'] = str(WORK / 'kicad-config')
os.environ['KICAD_DOCUMENTS_HOME'] = str(WORK / 'documents')
import pcbnew as pcb

REFS = ['L1101', 'FB1101', 'FL1501', 'L1501', 'L1502', 'Y801',
        'C303', 'C304', 'C807', 'C808', 'C812', 'C813',
        'C501', 'C502', 'C503', 'C1001', 'C1002', 'C1003',
        'C1101', 'C1102', 'C1103', 'C1104', 'C1105', 'C1106', 'C1107',
        'C1501', 'C1502', 'C403', 'C301', 'C302', 'C305']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

inputs = {}
data = {}
for rel in ['reference/v25-circuits.json', 'electrical/native-components.json',
            'pcb-work/footprint-map.json', 'pcb-work/placement.json']:
    path = OUT / rel
    obj = json.loads(path.read_text(encoding='utf-8-sig'))
    inputs[rel] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    if rel.endswith('v25-circuits.json'):
        data['circuits'] = {c['ref']: dict(c, sheet=s['id']) for s in obj
                            for c in s['components'] if c['ref'] in REFS}
    elif rel.endswith('native-components.json'):
        data['native_components'] = {c['ref']: c for c in obj if c['ref'] in REFS}
    else:
        data[Path(rel).stem] = {r: obj.get(r) for r in REFS}

data['library_footprints'] = {}
for name in ['Inductor_4x4_TENTATIVE', 'CMC_2012_TENTATIVE_PINOUT',
             'L_0603_1608Metric', 'C_0603_1608Metric', 'C_0805_2012Metric',
             'Crystal_SMD_3225-4Pin_3.2x2.5mm']:
    path = OUT / 'pcb-work/SmartVioV25.pretty' / (name + '.kicad_mod')
    inputs[str(path.relative_to(OUT))] = {'sha256': digest(path)}
    f = pcb.FootprintLoad(str(path.parent), name)
    data['library_footprints'][name] = {'pads': [
        {'number': p.GetNumber(),
         'xy_mm': [pcb.ToMM(p.GetPosition().x), pcb.ToMM(p.GetPosition().y)],
         'size_mm': [pcb.ToMM(p.GetSize().x), pcb.ToMM(p.GetSize().y)]}
        for p in f.Pads()]}

data['boards'] = {}
for name in ['SmartVio-main-tentative', 'SmartVio-audio-tentative',
             'SmartVio-usb-tentative', 'SmartVio-power-prototype-final-repaired']:
    path = OUT / 'pcb-work' / (name + '.kicad_pcb')
    before = digest(path)
    board = pcb.LoadBoard(str(path))
    data['boards'][name] = {}
    for f in board.GetFootprints():
        if f.GetReference() not in REFS:
            continue
        data['boards'][name][f.GetReference()] = {
            'footprint_id': str(f.GetFPID().GetLibItemName()),
            'value': f.GetValue(), 'angle_deg': f.GetOrientationDegrees(),
            'side': 'B' if f.IsFlipped() else 'F',
            'pads': [{'number': p.GetNumber(), 'net': p.GetNetname(),
                      'xy_mm': [pcb.ToMM(p.GetPosition().x), pcb.ToMM(p.GetPosition().y)],
                      'size_mm': [pcb.ToMM(p.GetSize().x), pcb.ToMM(p.GetSize().y)]}
                     for p in f.Pads()]}
    assert digest(path) == before
    inputs[str(path.relative_to(OUT))] = {'sha256': before, 'read_only_verified': True}

data['inputs'] = inputs
data['scope_refs'] = REFS
(WORK / 'input-snapshot.json').write_text(json.dumps(data, indent=2, ensure_ascii=True), encoding='utf-8')
for r in REFS:
    c = data['native_components'].get(r, {})
    boards = {k: v[r]['footprint_id'] for k, v in data['boards'].items() if r in v}
    print(json.dumps({'ref': r, 'value': c.get('value'), 'nets': [p.get('net') for p in c.get('pins', [])], 'boards': boards}))
