import copy
import hashlib
import json
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

from pypdf import PdfReader

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V25-Engineering'
AUDIT = OUT / 'audit/critical-passives'
SNAP = json.loads((WORK / 'input-snapshot.json').read_text(encoding='utf-8'))
NOW = datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clean(text):
    return re.sub(r'\s+', '', ''.join(c for c in unicodedata.normalize('NFKC', text)
                                    if unicodedata.category(c) != 'Cf')).upper()


sources = {}
attempts = []
for path in sorted(WORK.glob('manifest-*.json')):
    for record in json.loads(path.read_text(encoding='utf-8')):
        attempts.append(dict(record, manifest=str(path.relative_to(ROOT))))
        if record['download_status'] == 'SUCCESS' and record.get('pdf'):
            p = WORK / record['path']
            assert sha(p) == record['sha256'], record['id']
            sources[record['id']] = dict(record, local_path=str(p.relative_to(ROOT)))

tpd_path = OUT / 'audit/audio/sources/TPD2S703_Q1.pdf'
sources['TPD2S703_Q1'] = {
    'id': 'TPD2S703_Q1', 'url': 'https://www.ti.com/lit/ds/symlink/tpd2s703-q1.pdf',
    'local_path': str(tpd_path.relative_to(ROOT)), 'sha256': sha(tpd_path),
    'pages': len(PdfReader(tpd_path).pages), 'download_status': 'REUSED_OFFICIAL_LOCAL_PDF',
    'retrieved_utc': None, 'pdf': True,
}
sources['ACM2012H_WEB'] = {
    'id': 'ACM2012H_WEB',
    'url': 'https://product.tdk.com/system/files/dam/doc/product/emc/emc/cmf_cmc/catalog/cmf_automotive_signal_acm2012h-t06_en.pdf',
    'local_path': None, 'sha256': None, 'pages': 5, 'document_revision': '20260507',
    'download_status': 'OFFICIAL_PDF_WEB_TEXT_READ_LOCAL_HTTP403',
    'retrieved_date': '2026-10-08',
    'limitations': 'Official PDF text inspected through web; no locally hashed PDF or visually approved numbered land/circuit drawing. Not mounting-approved.',
}


def evidence(source_id, pages, section):
    s = sources[source_id]
    return {'source_id': source_id, 'manufacturer_url': s['url'], 'pdf_pages': pages,
            'section': section, 'sha256': s.get('sha256'), 'local_path': s.get('local_path')}


catalog = {}
cap_rows = [
    ('CC0805KKX7R7BB105', 1, 10, 16, 'X7R', '0805', 125),
    ('CC0805KKX7R7BB225', 2.2, 10, 16, 'X7R', '0805', 125),
    ('CC0603KRX7R6BB225', 2.2, 10, 10, 'X7R', '0603', 125),
    ('CC0805KKX7R6BB475', 4.7, 10, 10, 'X7R', '0805', 125),
    ('CC0805KKX5R6BB106', 10, 10, 10, 'X5R', '0805', 85),
    ('CC0805MKX5R6BB226', 22, 20, 10, 'X5R', '0805', 85),
    ('CC0603KRX7R7BB105', 1, 10, 16, 'X7R', '0603', 125),
    ('CC0603KRX7R9BB104', 0.1, 10, 50, 'X7R', '0603', 125),
    ('CC0603KRX7R6BB104', 0.1, 10, 10, 'X7R', '0603', 125),
    ('CC0603JRNPO9BN472', 0.0047, 5, 50, 'C0G', '0603', 125),
    ('CC0603JRNPO9BN300', 0.000030, 5, 50, 'C0G', '0603', 125),
]
for mpn, uf, tol, volts, dielectric, case, temp_max in cap_rows:
    pages = json.loads((WORK / 'text' / (mpn + '.json')).read_text(encoding='utf-8'))
    txt = clean(''.join(p['text'] for p in pages))
    assert clean(mpn) in txt, mpn
    assert f'{volts}VDC' in txt and dielectric in txt and case in txt, mpn
    small = case == '0603'
    readable = ''.join(c for c in ''.join(p['text'] for p in pages) if unicodedata.category(c) != 'Cf')
    dimension_table = {axis: (float(nom), float(tol))
                       for axis, nom, tol in re.findall(r'([LWTB])\s+([\d.]+)mm\s*\+/-([\d.]+)mm', readable)}
    assert set(dimension_table) == set('LWTB'), mpn
    dims = [dimension_table[a][0] for a in 'LWT']
    tolerance = [dimension_table[a][1] for a in 'LWT']
    packaging = re.search(r'Packaging\s+T&R,([^\n]+)', readable)
    catalog[mpn] = {
        'manufacturer': 'YAGEO', 'mpn': mpn, 'kind': 'MLCC',
        'identity_status': 'EXACT_MPN_IN_OFFICIAL_PART_SPECIFICATION',
        'package': {'case_eia': case, 'case_metric': '1608' if small else '2012',
                    'body_lwh_nominal_mm': dims, 'body_lwh_tolerance_mm': tolerance,
                    'height_max_mm': round(sum(dimension_table['T']), 6),
                    'height_basis': 'T nominal plus published positive tolerance; component-only, not assembled stack height',
                    'termination_length_nominal_mm': dimension_table['B'][0],
                    'termination_length_tolerance_mm': dimension_table['B'][1]},
        'ratings': {'capacitance_nominal_uF': uf, 'tolerance_percent': tol,
                    'rated_voltage_dc_V': volts, 'dielectric': dielectric,
                    'temperature_range_C': [-55, temp_max]},
        'dc_bias': {'status': 'UNKNOWN_FOR_EXACT_MPN_AND_OPERATING_ENVELOPE',
                    'ceff_min_uF': None, 'ceff_max_uF': None,
                    'bias_curve': None, 'combined_temperature_tolerance_aging_bound': None,
                    'notes': 'No exact-MPN bias/aging/ESR curves in the downloaded one-page part sheet; do not assume a retention factor, even for C0G.'},
        'esr_max_ohm': None,
        'purchasing': {'exact_order_code_documented': True, 'rohs_in_part_sheet': True,
                       'termination': 'Tin', 'reel_quantity': 4000 if small else 3000,
                       'packaging_description_from_pdf': packaging.group(1).strip() if packaging else None,
                       'lifecycle_verified': False, 'authorized_supplier_quote': None,
                       'stock_verified': False, 'procurement_approved': False},
        'evidence': [evidence(mpn, [1], 'Exact part header, dimensions, specifications and packaging')],
    }

catalog['XGL4020-152MEC'] = {
    'manufacturer': 'Coilcraft', 'mpn': 'XGL4020-152MEC', 'kind': 'SHIELDED_POWER_INDUCTOR',
    'identity_status': 'EXACT_VALUE_ROW_PLUS_MANUFACTURER_ORDERING_CODES',
    'package': {'body_lwh_nominal_mm': [4.0, 4.0, None],
                'body_lw_tolerance_mm': [0.3, 0.3], 'body_lw_max_mm': [4.3, 4.3],
                'height_max_mm': 2.1, 'height_basis': 'Official drawing, E tin-silver termination',
                'recommended_pad_size_mm': [0.98, 3.4],
                'recommended_pad_inner_gap_mm': 2.37,
                'recommended_pad_centers_x_mm': [-1.675, 1.675]},
    'ratings': {'inductance_nominal_uH': 1.5, 'tolerance_percent': 20,
                'test_frequency_MHz': 1, 'test_voltage_Vrms': 0.1,
                'dcr_typ_ohm': 0.013, 'dcr_max_ohm': 0.0143, 'srf_typ_MHz': 45,
                'isat_A_by_inductance_drop_percent_at_25C': {'10': 3.2, '20': 5.3, '30': 7.5},
                'irms_A_by_temperature_rise_C_from_25C': {'20': 8.0, '40': 11.1},
                'irms_is_absolute_maximum_rating': False, 'operating_voltage_V': 80},
    'dc_bias': {'status': 'L_VS_I_TYPICAL_CURVE_AND_DROP_POINTS_ONLY',
                'application_leff_min_uH': None, 'application_peak_current_A': None,
                'hot_isat_guarantee_A': None},
    'purchasing': {'exact_order_code_documented': True, 'rohs_in_part_sheet': True,
                   'termination': 'E tin-silver 96.5/3.5 over copper', 'packaging': 'C 7-inch machine-ready reel',
                   'reel_quantity': 1000, 'lifecycle_verified': False, 'stock_verified': False,
                   'authorized_supplier_quote': None, 'procurement_approved': False},
    'evidence': [evidence('XGL4020', [1, 3], '1.5uH row, ordering codes, physical and land drawing')],
}
catalog['742792625'] = {
    'manufacturer': 'Wurth Elektronik', 'mpn': '742792625', 'kind': 'FERRITE_BEAD',
    'identity_status': 'EXACT_MPN_IN_OFFICIAL_DRAWING',
    'package': {'case_eia': '0603', 'case_metric': '1608',
                'body_lwh_nominal_mm': [1.6, 0.8, 0.8], 'body_lwh_tolerance_mm': [0.2, 0.2, 0.2],
                'height_max_mm': 1.0, 'recommended_pad_size_mm': [0.7, 0.7],
                'recommended_land_overall_span_mm': 2.6,
                'recommended_pad_centers_x_mm': [-0.95, 0.95]},
    'ratings': {'impedance_at_100MHz_ohm': 120, 'impedance_tolerance_percent': 25,
                'dcr_max_ohm_at_20C': 0.05, 'rated_current_A_at_20K_rise': 1.5,
                'rated_current_A_at_40K_rise': 2.0, 'temperature_range_C': [-55, 125]},
    'dc_bias': {'status': 'LOADED_IMPEDANCE_NOT_QUALIFIED', 'impedance_at_0_5A_100MHz_ohm': None},
    'purchasing': {'exact_order_code_documented': True, 'rohs_in_part_sheet': True,
                   'reel_quantity': 4000, 'msl': 1, 'lifecycle_verified': False,
                   'stock_verified': False, 'authorized_supplier_quote': None, 'procurement_approved': False},
    'evidence': [evidence('WE_742792625', [1, 2, 3], 'Rev002.010 exact part, electrical table, high-current recommended land, thermal derating and packaging')],
}
catalog['ACM2012H-900-2P-T06'] = {
    'manufacturer': 'TDK', 'mpn': 'ACM2012H-900-2P-T06', 'kind': 'COMMON_MODE_CHOKE',
    'identity_status': 'EXACT_MPN_IN_OFFICIAL_CATALOG_WEB_TEXT',
    'package': {'case_metric': '2012', 'body_lwh_nominal_mm': [2.0, 1.2, 1.2],
                'body_lwh_tolerance_mm': [0.2, 0.2, 0.1], 'height_max_mm': 1.3,
                'recommended_pad_size_mm': [0.75, 0.4],
                'recommended_horizontal_inner_gap_mm': 1.1,
                'recommended_pad_centers_abs_mm': [0.925, 0.4],
                'numbered_pad_topology_status': 'HOLD_VISUAL_DELIVERY_DRAWING_NOT_LOCALLY_VERIFIED'},
    'ratings': {'common_mode_impedance_100MHz_typ_ohm': 90,
                'common_mode_impedance_100MHz_min_ohm': 65,
                'dcr_max_per_line_ohm': 0.3, 'rated_current_A': 0.3,
                'rated_voltage_dc_V': 50, 'insulation_resistance_min_Mohm': 10,
                'temperature_range_C_including_self_heating': [-40, 125]},
    'dc_bias': {'status': 'APPLICATION_SIGNAL_INTEGRITY_AND_CURRENT_NOT_QUALIFIED',
                'application_loaded_impedance_ohm': None},
    'purchasing': {'exact_order_code_documented': True, 'reel_quantity': 2000,
                   'delivery_specification_required_by_manufacturer': True,
                   'rohs_in_part_sheet': None, 'lifecycle_verified': False,
                   'stock_verified': False, 'authorized_supplier_quote': None, 'procurement_approved': False},
    'evidence': [evidence('ACM2012H_WEB', [1, 3], 'Rev20260507 exact part table, dimensional text and packaging')],
}
catalog['0603HP-10NXGRW'] = {
    'manufacturer': 'Coilcraft', 'mpn': '0603HP-10NXGRW', 'kind': 'CERAMIC_RF_INDUCTOR',
    'identity_status': 'EXACT_VALUE_ROW_AND_ORDERING_CODES_CONFIRMED_ON_MANUFACTURER_PRODUCT_PAGE',
    'package': {'case_eia': '0603', 'case_metric': '1608',
                'body_length_max_mm': 1.75, 'body_width_range_mm': [0.86, 1.09],
                'height_max_mm': 0.94, 'height_basis': 'Before optional solder application',
                'optional_solder_height_addition_max_mm': 0.152,
                'height_max_with_optional_solder_mm': 1.092,
                'recommended_pad_size_mm_along_across_body': [0.69, 1.02],
                'recommended_inner_gap_mm_along_body': 0.71,
                'recommended_pad_centers_x_mm_after_90deg_rotation': [-0.7, 0.7]},
    'ratings': {'inductance_nominal_nH': 10, 'tolerance_percent': 2,
                'test_frequency_MHz': 250, 'dcr_max_ohm': 0.048, 'srf_typ_GHz': 4.3,
                'irms_A_at_15C_rise': 1.4, 'irms_is_absolute_maximum_rating': False,
                'temperature_range_C_with_irms': [-40, 125],
                'temperature_coefficient_inductance_ppm_per_C': [25, 125]},
    'dc_bias': {'status': 'RF_APPLICATION_NOT_QUALIFIED', 'application_impedance_or_effective_L': None},
    'purchasing': {'exact_order_code_documented': True, 'rohs_in_part_sheet': True,
                   'termination': 'R matte tin over nickel over silver platinum-glass frit',
                   'packaging': 'W 7-inch reel', 'reel_quantity': 2000, 'msl': 1,
                   'lifecycle_verified': False, 'stock_verified': False,
                   'authorized_supplier_quote': None, 'procurement_approved': False},
    'evidence': [evidence('0603HP', [1, 2], 'Doc537 rev08/08/22 dimensions, 10nH row, tolerance/termination/packaging codes'),
                 {'manufacturer_url': 'https://www.coilcraft.com/en-us/products/rf/ceramic-core-chip-inductors/0603-%281608%29/0603hp/0603hp-10n/',
                  'section': 'Manufacturer explicitly lists 0603HP-10NXGRW and G/R/W options',
                  'sha256': None, 'local_path': None, 'access_method': 'OFFICIAL_WEB_READ_2026-10-08'}],
}
catalog['ABM8-24.576MHZ-B2-T'] = {
    'manufacturer': 'Abracon', 'mpn': 'ABM8-24.576MHZ-B2-T', 'kind': 'PASSIVE_CRYSTAL',
    'identity_status': 'CONFIGURATION_FROM_MANUFACTURER_ORDERING_TABLE_EXACT_SKU_FACTORY_CONFIRMATION_HOLD',
    'package': {'body_lwh_nominal_mm': [3.2, 2.5, None], 'body_lw_tolerance_mm': [0.2, 0.2],
                'height_max_mm': 0.8, 'recommended_pad_size_mm': [1.3, 1.05],
                'recommended_pad_centers_abs_mm': [1.15, 0.875],
                'pin_functions': {'1': 'XTAL', '2': 'GND', '3': 'XTAL', '4': 'GND'},
                'pin_location_top_view': {'1': 'bottom-left', '2': 'bottom-right', '3': 'top-right', '4': 'top-left'}},
    'ratings': {'frequency_MHz': 24.576, 'mode': 'Fundamental', 'load_capacitance_pF': 18,
                'frequency_tolerance_ppm_at_25C': 20, 'frequency_stability_ppm': 50,
                'temperature_range_C': [-20, 70], 'esr_max_ohm_for_20_to_29_999MHz': 50,
                'shunt_capacitance_max_pF': 3, 'drive_typ_uW': 10, 'drive_max_uW': 100,
                'aging_first_year_ppm': 2},
    'dc_bias': {'status': 'NOT_MLCC_EFFECTIVE_C; OSCILLATOR_LOAD_AND_DRIVE_UNQUALIFIED',
                'measured_load_pF': None, 'measured_drive_uW': None},
    'purchasing': {'exact_order_code_documented': 'CONFIGURATION_DECODED_FACTORY_SKU_CONFIRMATION_REQUIRED',
                   'ordering_decode': '24.576MHZ frequency; default CL18pF and 0.8mm max height; B -20..70C; 2 +/-20ppm tolerance; default +/-50ppm stability; T 1000/reel',
                   'exact_sku_factory_confirmation': None, 'reel_quantity': 1000,
                   'rohs_in_part_sheet': True, 'lifecycle_verified': False, 'stock_verified': False,
                   'authorized_supplier_quote': None, 'procurement_approved': False},
    'evidence': [evidence('ABM8_current', [1, 2], 'Rev07-29-20 ordering table, ESR band, CL, physical top view and land pattern')],
}

assign = {
    'L1101': 'XGL4020-152MEC', 'FB1101': '742792625', 'FL1501': 'ACM2012H-900-2P-T06',
    'L1501': '0603HP-10NXGRW', 'L1502': '0603HP-10NXGRW', 'Y801': 'ABM8-24.576MHZ-B2-T',
    'C301': 'CC0805KKX7R7BB105', 'C302': 'CC0805KKX7R7BB105', 'C303': 'CC0805KKX7R7BB105',
    'C304': 'CC0805KKX7R7BB225', 'C305': 'CC0805KKX7R7BB225',
    'C807': 'CC0603KRX7R6BB225', 'C808': 'CC0603KRX7R6BB225',
    'C812': 'CC0603JRNPO9BN300', 'C813': 'CC0603JRNPO9BN300',
    'C501': 'CC0805KKX7R6BB475', 'C502': 'CC0805KKX5R6BB106', 'C503': 'CC0805KKX5R6BB106',
    'C1001': 'CC0603JRNPO9BN472', 'C1002': 'CC0603KRX7R9BB104', 'C1003': 'CC0603KRX7R7BB105',
    'C1101': 'CC0603KRX7R6BB104', 'C1102': 'CC0805KKX5R6BB106', 'C1103': 'CC0603KRX7R6BB104',
    'C1104': 'CC0805MKX5R6BB226', 'C1105': 'CC0805MKX5R6BB226', 'C1106': 'CC0805MKX5R6BB226',
    'C1107': 'CC0603KRX7R6BB104', 'C1501': 'CC0805KKX7R7BB225',
    'C1502': 'CC0603KRX7R7BB105', 'C403': 'CC0603KRX7R6BB104',
}
assert set(assign) == set(SNAP['scope_refs'])

requirements = {
    'CP': {'refs': ['C303', 'C304'], 'status': 'HOLD',
           'criterion': 'C304 effective minimum >= C303 effective maximum at their different operating biases, temperature, tolerance and aging; low-ESR ceramic X5R or better.',
           'measured_or_guaranteed_ceff_min_uF': None, 'measured_or_guaranteed_ceff_max_uF': None,
           'nominal_values_uF': {'C303': 1, 'C304': 2.2},
           'notes': '2.2uF vs 1uF nominal alone is not proof; flying-cap ripple/ESR, HPVSS ripple and THD not tested.',
           'evidence': evidence('TPA6132A2', [15], '8.2.1.2.2 Charge Pump Flying Capacitor and HPVSS Capacitor')},
    'VCAP': {'refs': ['C807', 'C808'], 'status': 'HOLD',
             'criterion': 'Each VCAP capacitor 2.2uF typical, +/-20% tolerated, ESR <100mohm with internal regulator enabled.',
             'acceptance_capacitance_range_uF_derived_from_2_2_plus_minus_20_percent': [1.76, 2.64],
             'esr_required_max_exclusive_ohm': 0.1, 'measured_esr_ohm': None,
             'notes': 'Cap nominal +/-10% is not total bias/temperature/aging bound. Published dissipation factor is not an ESR guarantee at regulator operating frequency. Confirm silicon revision and regulator mode; no bypass-mode value changes here.',
             'evidence': evidence('STM32H743', [106, 211], 'DS12110 Rev11 Table15 revY and Table114 revV')},
    'CHARGER_IN': {'refs': ['C501'], 'status': 'HOLD', 'local_effective_min_required_uF': 1,
                   'criterion': 'Native effective >=1uF; TI IN bypass recommendation 1..10uF. Qualify USB_5V_SAFE maximum DC/transient and local input/inrush.',
                   'evidence': evidence('BQ24074', [8, 35], 'Pin Functions and 10.2.2.5 IN/OUT/BAT Capacitors')},
    'CHARGER_OUT': {'refs': ['C502'], 'status': 'HOLD', 'local_effective_min_required_uF': 4.7,
                    'criterion': 'Native effective >=4.7uF; TI OUT bypass recommendation 4.7..47uF; real pulsed load and battery-to-USB transition not measured.',
                    'evidence': evidence('BQ24074', [8, 35], 'OUT bypass and real operational evaluation')},
    'CHARGER_BAT': {'refs': ['C503'], 'status': 'HOLD', 'local_effective_min_required_uF': 4.7,
                    'criterion': 'Native effective >=4.7uF; TI BAT bypass recommendation 4.7..47uF; use PACK_PLUS maximum envelope and qualify stability.',
                    'evidence': evidence('BQ24074', [8, 35], 'BAT bypass and real operational evaluation')},
    'BUCK_INPUT': {'refs': ['C1102', 'C1103'], 'status': 'HOLD',
                   'local_input_min_required_uF': 4.7, 'local_input_typical_uF': 10,
                   'criterion': 'TPS63070 input 4.7uF minimum/10uF nominal; bulk + close HF bypass. Determine retained C and layout at SYS worst case, including short supply dips.',
                   'notes': 'Do not silently count remote C502 into local VIN capacitance without impedance/layout review.',
                   'evidence': evidence('TPS63070', [4, 19], '7.3 Recommended Operating Conditions; 9.2.2.3.1 Input Capacitor')},
    'BUCK_OUTPUT': {'refs': ['C1104', 'C1105'], 'status': 'HOLD',
                    'vout_effective_C_range_uF_for_nominal_1_5uH_from_table': [15, 470],
                    'vout_C_typical_uF': 47, 'direct_bulk_nominal_sum_uF': 44,
                    'direct_bulk_effective_sum_uF': None,
                    'criterion': 'Cout,eff(uF) >=10*Leff(uH) and operating table range; for 1.5uH Table3 nominal 47/68/100uF combinations. Validate 2x22uF=44uF nominal combination, loop stability, RHPZ, startup, ripple and load steps at worst-case SYS/load.',
                    'notes': '47uF is typical/recommended nominal, NOT a universal 47uF effective minimum. C1106 is after FB1101 on V3A and is not an unconditional direct VOUT capacitor. General text mentions -80% bias variation whereas Table3 assumes -50%; neither is an exact-MPN retention guarantee.',
                    'evidence': evidence('TPS63070', [4, 17, 18, 19], '7.3, Table3, 9.2.2.2 and 9.2.2.3.2')},
    'BUCK_AUX': {'refs': ['C1101'], 'status': 'HOLD',
                 'criterion': 'VAUX 100nF nominal; qualify bias, transient rating and local loop/placement.',
                 'evidence': evidence('TPS63070', [4, 17], 'VAUX recommended capacitance and BOM')},
    'ANALOG_FILTER': {'refs': ['FB1101', 'C1106', 'C1107'], 'status': 'HOLD',
                      'criterion': 'Verify loaded bead impedance, DCR loss, LC resonance/damping, V3A ripple and actual analog load; do not count V3A bulk as direct V3D COUT.',
                      'actual_loaded_impedance_or_transient': None},
    'USB_VPWR': {'refs': ['C1501'], 'status': 'HOLD_DESIGN_REQUIREMENT_DISCREPANCY',
                 'native_effective_range_uF': [1, 10], 'native_nominal_uF': 2.2,
                 'manufacturer_recommended_nominal_uF': 10,
                 'criterion': 'TPD2S703-Q1 section10.1 recommends 10uF close to VPWR; current 2.2uF is not that nominal recommendation. Qualify effective C and short-to-bus/ESD/UVLO transients or obtain documented design acceptance; this proposal does NOT change 2.2uF.',
                 'evidence': evidence('TPD2S703_Q1', [21], '10.1 VPWR Path')},
    'USB_VREF': {'refs': ['C1502'], 'status': 'HOLD', 'native_effective_range_uF': [0.3, 3],
                 'criterion': 'TPD2S703-Q1 section10.2 requires local 1uF VREF bypass; qualify exact retained C over dedicated USB_VREF envelope, regulator stability, enable timing and ESD clamps. No connection to V3D proposed.',
                 'evidence': evidence('TPD2S703_Q1', [8, 20, 21], 'VREF fast charge test conditions, enable timing, 10.2 VREF Pin')},
    'USB_FILTER': {'refs': ['FL1501', 'L1501', 'L1502'], 'status': 'HOLD',
                   'criterion': 'TPD2S703-Q1 recommends 90ohm@100MHz common choke plus 10nH series inductors. Exact land/pin mapping, same-order-code pair matching, USB2 eye/S-parameters and ESD/short-to-bus system tests remain open.',
                   'nominal_L_pair_mismatch_percent_bound_from_independent_2_percent_tolerances': 4,
                   'pair_matching_guaranteed_by_same_mpn': False,
                   'notes': '4% is difference relative to 10nH nominal, not measured matching. Same lot/MPN does not guarantee selected-pair matching.',
                   'evidence': evidence('TPD2S703_Q1', [14, 19], 'ESD/STB setups and 9.2.2.1 Common choke and Inductor')},
    'HSE': {'refs': ['Y801', 'C812', 'C813'], 'status': 'HOLD',
            'criterion': 'Confirm CL18pF via C1*C2/(C1+C2)+Cstray, oscillator startup/negative resistance, crystal drive <=100uW, temperature/frequency budget and clock configuration.',
            'series_load_nominal_pF_from_two_30pF': 15,
            'stray_pF_needed_to_reach_18pF_if_nominal_caps': 3,
            'measured_stray_pF': None, 'measured_startup_or_drive': None,
            'notes': '3pF is required stray under nominal algebra, NOT a verified parasitic. B-temperature -20..70C is not system temperature approval.',
            'evidence': evidence('ABM8_current', [1, 2], 'CL18, drive and selected options')},
    'USB_POWER_CAPS': {'refs': ['C1001', 'C1002', 'C1003', 'C403'], 'status': 'HOLD',
                       'criterion': 'Qualify exact bias, rail transient/pulse voltage, total USB input charge/inrush, efuse dVdt timing at 4.7nF and local ESD bypass. Voltage rating or manufacturer endurance percentage is NOT a guaranteed system transient limit.',
                       'measured_rail_transient_V': None, 'measured_inrush': None},
    'AUDIO_OTHER': {'refs': ['C301', 'C302', 'C305'], 'status': 'HOLD',
                    'criterion': 'Qualify retained C, audio high-pass cutoff, channel matching, ceramic distortion and HPVDD bypass/ripple at actual audio/bias envelope.',
                    'evidence': evidence('TPA6132A2', [15], '8.2.1.2.1 Input Coupling Capacitors')},
}

hard_no_fit = {'L1101', 'FB1101', 'FL1501'}
per_ref = []
for ref in SNAP['scope_refs']:
    current = SNAP['native_components'][ref]
    candidate = copy.deepcopy(catalog[assign[ref]])
    instances = {b: d[ref] for b, d in SNAP['boards'].items() if ref in d}
    fp_ids = sorted(set(x['footprint_id'] for x in instances.values()))
    assert len(fp_ids) == 1, ref
    fp = fp_ids[0]
    place = SNAP['placement'][ref]
    conditions = [k for k, v in requirements.items() if ref in v['refs']]
    height_ok = candidate['package']['height_max_mm'] <= place['heightMaxMm']
    mounting = {
        'actual_footprint': fp, 'actual_board_instances': instances,
        'actual_library_pads': SNAP['library_footprints'][fp]['pads'],
        'placement_height_limit_mm': place['heightMaxMm'],
        'component_max_height_within_placement_limit': height_ok,
        'assembly_solder_standoff_clearance_verified': False,
        'manufacturer_exact_land_geometry_match': False,
        'pin_net_map_released': False, 'assembly_approved': False,
    }
    holds = ['Authorized supplier quote, lifecycle, exact delivered ordering code and traceability not approved.',
             'No physical sample, assembly process or assembled height/clearance approval.']
    if candidate['kind'] == 'MLCC':
        mounting['package_class_match_to_actual_pcb'] = candidate['package']['case_eia'] in fp
        assert mounting['package_class_match_to_actual_pcb'], ref
        value_match = re.match(r'([\d.]+)(uF|nF|pF)', current['value'])
        assert value_match, ref
        expected_uf = float(value_match.group(1)) * {'uF': 1, 'nF': 0.001, 'pF': 0.000001}[value_match.group(2)]
        assert abs(expected_uf - candidate['ratings']['capacitance_nominal_uF']) < 1e-9, ref
        required_voltage = re.search(r'([\d.]+)V', current['value'])
        assert not required_voltage or candidate['ratings']['rated_voltage_dc_V'] >= float(required_voltage.group(1)), ref
        assert 'X7R' not in current['value'] or candidate['ratings']['dielectric'] == 'X7R', ref
        mounting['land_status'] = 'GENERIC_METRIC_CASE_MATCH_ONLY_MANUFACTURER_LAND_REVIEW_HOLD'
        holds.append('Exact manufacturer land pattern/reflow acceptance not contained in one-page part sheet; generic-case compatibility is not exact-land approval.')
        holds.append('Exact-MPN DC-bias, combined tolerance/temperature/aging, ESR and application transient evidence incomplete; Ceff remains null.')
        if candidate['ratings']['dielectric'] == 'X5R':
            holds.append('X5R part operating range ends at +85C; component hot temperature/system envelope not accepted.')
    elif ref == 'L1101':
        mounting['land_status'] = 'NOT_A_DROP_IN'
        holds += ['4.0+/-0.3mm body can reach 4.3x4.3mm, outside strict <=4x4 envelope; Hmax2.1mm exceeds 2.0mm placement limit.',
                  'Current pads1.5x3.4mm at x=+/-1.55 differ from official0.98x3.4mm at +/-1.675.',
                  'Isat5.3A applies at20% L drop and25C only; >=5A drop criterion and hot derating remain unaccepted.',
                  'Actual minimum input, maximum load, peak current and 20% saturation margin, Leff and thermal loss need verification; Irms is not Isat.']
    elif ref == 'FB1101':
        mounting['land_status'] = 'NOT_A_DROP_IN'
        holds += ['Hmax1.0mm exceeds 0.95mm placement limit.',
                  'Official high-current land0.7x0.7mm at +/-0.95 differs from current0.875x0.95mm at +/-0.7875.',
                  '120ohm is zero-bias nominal impedance, not a guaranteed loaded impedance at0.5A.']
    elif ref == 'FL1501':
        mounting['land_status'] = 'NOT_A_DROP_IN_PINOUT_AND_HEIGHT_HOLD'
        holds += ['Hmax1.3mm exceeds current1.0mm placement limit.',
                  'Current numbered placeholder pairs1-2/3-4 have not been matched to manufacturer numbered physical terminals/windings. Do not set MPN and reuse placeholder blindly.',
                  'Land0.75x0.4mm centers abs0.925,0.4 differs from current0.6x0.5mm centers abs0.8,0.4; official delivery drawing and numbered circuit require visual approval.',
                  '90ohm is typical; manufacturer minimum is65ohm. USB2 signal integrity and ESD/STB behavior not verified.']
    elif ref in ['L1501', 'L1502']:
        mounting['land_status'] = 'CASE_FAMILY_ONLY_NOT_EXACT_LAND'
        holds += ['Cmax0.94mm before optional solder fits0.95mm component-only limit with0.01mm margin; optional solder adds0.152mm, giving1.092mm. Delivered termination and assembled clearance not verified.',
                  'Official recommended land (rotated to horizontal body) differs from generic L0603 land; do not auto-release footprint.',
                  'Two independent +/-2% inductors are not a guaranteed matched pair; verify differential impedance/matching, USB eye and ESD/STB.']
    elif ref == 'Y801':
        mounting['land_status'] = 'LOGICAL_TERMINALS_MATCH_GEOMETRY_DEVIATION_HOLD'
        mounting['manufacturer_logical_pin_functions_match'] = True
        holds += ['Current pads1.4x1.2mm at abs1.1,0.85 differ from recommended1.3x1.05mm at abs1.15,0.875; backside assembly view/orientation and land acceptance remain HOLD.',
                  'Ordering-table configuration is documented; exact factory SKU/availability confirmation not obtained. No dealer part-number decoding used.',
                  'CL18pF, -20..70C temperature option, frequency/drive and startup margins require oscillator qualification; 30pF+30pF is not a verified18pF load.']
    metadata_mismatch = '0603' in current.get('package', '') and '0805' in fp
    native_map = {str(p['number']): p.get('net') for p in current['pins']}
    net_mismatches = {b: {str(p['number']): p.get('net') for p in x['pads']}
                      for b, x in instances.items()
                      if {str(p['number']): p.get('net') for p in x['pads']} != native_map}
    mounting['actual_pcb_numbered_nets_equal_native'] = not net_mismatches
    mounting['actual_pcb_numbered_net_mismatches'] = net_mismatches
    if net_mismatches:
        holds.append('HOLD_NET_MISMATCH: actual PCB pad/net map differs from current native JSON; MPN-only assignment cannot repair this. For C1502 native pad1=USB_VREF but USB PCB pad1=V3D; do not assemble against this stale net map.')
        mounting['land_status'] = 'HOLD_NET_MISMATCH_AND_GENERIC_LAND'
    if metadata_mismatch:
        holds.append('Native package description says0603 but actual PCB uses0805; report metadata conflict only, no file/value/net change made.')
    proposed = None if ref in hard_no_fit else candidate['mpn']
    item = {
        'ref': ref, 'status': 'HOLD', 'release': 'HOLD',
        'current': {'mpn': current.get('mpn'), 'value': current['value'],
                    'package_description': current.get('package'), 'pins': current['pins']},
        'preserved_design_value': current['value'], 'preserved_pin_net_map': current['pins'],
        'proposed_mpn': proposed, 'proposal_only_no_native_edit': True,
        'value_change': False, 'network_change': False, 'footprint_change': False,
        'candidate': candidate,
        'candidate_disposition': 'DOCUMENTED_EVALUATION_ONLY_NOT_CURRENT_ENVELOPE_ELIGIBLE' if ref in hard_no_fit else 'PARAMETER_MATCHED_CONDITIONAL_CANDIDATE_NOT_APPROVED',
        'eligible_for_mpn_only_integration_without_further_review': False,
        'fully_matched_and_approved_candidates': [], 'mounting': mounting,
        'native_package_description_conflicts_with_actual_pcb': metadata_mismatch,
        'requirement_ids': conditions, 'hold_reasons': holds,
        'effective_capacitance_verdict': 'UNKNOWN_HOLD' if ref.startswith('C') else 'NOT_APPLICABLE',
        'application_transient_verdict': 'NOT_MEASURED_HOLD',
        'procurement_approved': False,
    }
    if ref in ['C301', 'C302', 'C303', 'C304', 'C305', 'C1502']:
        item['candidate_voltage_rating_note'] = 'Candidate16V rating meets/exceeds current10V requirement; schematic/design value string is preserved, not changed to16V.'
    per_ref.append(item)

proposal = {
    'schema': 'smartvio-v25-critical-passives-proposal/1.0', 'generated_utc': NOW,
    'status': 'EVIDENCE_BACKED_CANDIDATES_ONLY_ALL_RELEASE_HOLD', 'procurement_approved': False,
    'scope_refs': SNAP['scope_refs'], 'scope_count': len(per_ref),
    'integration_policy': 'Parent may use this as a review overlay only. Never auto-change network, nominal value, footprint, symbol pin numbering or procurement status. proposed_mpn is a conditional documented candidate, not production approval. Three hard installation failures have proposed_mpn=null.',
    'native_patch': None, 'pcb_patch': None,
    'components': per_ref, 'application_requirements': requirements,
    'omitted_or_not_promoted': [
        {'mpn': 'XGL4015-152MEC', 'ref': 'L1101',
         'reason': 'Official electrical row retrieved:1.5uH, Isat2.7/4.3/6.3A at10/20/30% drop;20% drop Isat<5A. Physical dimensions image not successfully retrieved/verified in closeout. Not promoted as fully installation-matched candidate.',
         'evidence': evidence('XGL4015', [1], 'Doc1660 rev02/19/26 electrical row')},
        {'mpn': 'DLW21SN900SQ2L', 'ref': 'FL1501',
         'reason': 'Official exact physical/numbered mounting evidence not obtained locally; no dealer-derived substitute approval.'},
        {'mpn': 'ACM2012-900-2P-T002', 'ref': 'FL1501',
         'reason': 'Not promoted: official status search indicated NRND; delivery PDF/numbered mounting verification incomplete. Prefer resolving an active suitable-height exact part; not a blanket substitute.'},
        {'mpn': 'BLM18PG121SN1D', 'ref': 'FB1101',
         'reason': 'Exact suffix/delivery datasheet and installation evidence not verified; excluded despite family nominal search result.'},
        {'mpn': '74438335015', 'ref': 'L1101',
         'reason': 'Guessed original URL returned404; no original exact-part evidence, excluded.'},
        {'mpn': '742792641', 'ref': 'FB1101',
         'reason': 'Retrieved manufacturer sheet is not the requested120ohm@100MHz value; excluded, not an alternative.'},
        {'source_id': 'TPD2S300',
         'reason': 'Trial reference excluded: actual U1501 is TPD2S703QDGSRQ1. TPD2S300 capacitor recommendations are NOT used.'},
    ],
    'source_catalog': list(sources.values()),
}

checks = []


def check(cid, condition, detail):
    checks.append({'id': cid, 'result': 'PASS' if condition else 'FAIL', 'detail': detail})


input_checks = []
for rel, baseline in SNAP['inputs'].items():
    path = OUT / rel
    final_hash = sha(path)
    row = {'path': str(path.relative_to(ROOT)), 'before_sha256': baseline['sha256'],
           'after_sha256': final_hash, 'unchanged': final_hash == baseline['sha256']}
    input_checks.append(row)
check('INPUT_SNAPSHOT_HASHES', all(x['unchanged'] for x in input_checks),
      'Whole-file hashes may drift during authorized parallel audits. Record before/after exactly; separately compare every scoped passive JSON record. This subtask writes only its audit/work directories.')
live_native = {c['ref']: c for c in json.loads((OUT / 'electrical/native-components.json').read_text(encoding='utf-8-sig'))
               if c['ref'] in SNAP['scope_refs']}
live_circuits = {c['ref']: dict(c, sheet=s['id'])
                 for s in json.loads((OUT / 'reference/v25-circuits.json').read_text(encoding='utf-8-sig'))
                 for c in s['components'] if c['ref'] in SNAP['scope_refs']}
scope_input_unchanged = live_native == SNAP['native_components'] and live_circuits == SNAP['circuits']
check('SCOPED_JSON_RECORDS_UNCHANGED', scope_input_unchanged,
      'All31 audited native and circuit records compared structurally to current files, despite unrelated whole-file drift.')
physical_inputs_unchanged = all(x['unchanged'] for x in input_checks if '/pcb-work/' in x['path'].replace('\\', '/'))
check('PCB_AND_FOOTPRINT_HASHES', physical_inputs_unchanged,
      'Six actual footprint libraries and four loaded PCB files are hash-identical to snapshot.')
assert scope_input_unchanged and physical_inputs_unchanged, 'Scoped inputs changed during audit; refresh before handing off.'
check('SCOPE', len(per_ref) == 31 and set(assign) == set(SNAP['scope_refs']),
      'All requested refs plus C301/C302/C305, HSE load capacitors and USB VREF C1502 covered.')
check('NO_RELEASE', all(x['procurement_approved'] is False and x['status'] == 'HOLD' for x in per_ref),
      'No production/procurement/assembly approval.')
check('DESIGN_VALUES_AND_NETS', all(x['preserved_design_value'] == x['current']['value'] and
                                   x['preserved_pin_net_map'] == x['current']['pins'] and
                                   not x['network_change'] and not x['value_change'] for x in per_ref),
      'Proposal preserves exact native value strings and numbered pin/net maps; no update applied.')
check('NO_FAKE_CEFF', all(c['dc_bias']['ceff_min_uF'] is None and c['dc_bias']['ceff_max_uF'] is None
                        for c in catalog.values() if c['kind'] == 'MLCC'),
      'Retained effective C deliberately null. Thresholds and nominal calculations are clearly labeled, not measurements.')
check('NO_HARD_NOFIT_MPN_PATCH', all(x['proposed_mpn'] is None for x in per_ref if x['ref'] in hard_no_fit),
      'L1101/FB1101/FL1501 no-fit data remain evaluated only; no MPN-only integration proposed.')
check('CAP_PACKAGE_CLASS', all(x['mounting'].get('package_class_match_to_actual_pcb') for x in per_ref
                             if x['candidate']['kind'] == 'MLCC'),
      'Every cap candidate case class matches actual loaded PCB footprint, not stale JSON descriptions.')
pin_net_results = []
for item in per_ref:
    native_map = {str(p['number']): p.get('net') for p in item['current']['pins']}
    for board, instance in item['mounting']['actual_board_instances'].items():
        pcb_map = {str(p['number']): p.get('net') for p in instance['pads']}
        pin_net_results.append({'ref': item['ref'], 'board': board,
                                'native_map': native_map, 'pcb_map': pcb_map,
                                'same': pcb_map == native_map})
check('NUMBERED_PCB_NETS', all(x['same'] for x in pin_net_results),
      'Actual PCB pad numbers/nets compared to native map. C1502 mismatch is a real integration HOLD, not an artifact-generation error. Equality on other refs does NOT certify manufacturer package mapping.')

ref_verification = []
for item in per_ref:
    c = item['candidate']
    ref_verification.append({
        'ref': item['ref'], 'mpn_examined': c['mpn'], 'status': 'HOLD',
        'identity_and_data_evidence_status': c['identity_status'],
        'body_package_height': c['package'], 'nominal_ratings': c['ratings'],
        'actual_mounting_verdict': item['mounting']['land_status'],
        'actual_pcb_numbered_nets_equal_native': item['mounting']['actual_pcb_numbered_nets_equal_native'],
        'actual_pcb_numbered_net_mismatches': item['mounting']['actual_pcb_numbered_net_mismatches'],
        'component_height_fits_declared_placement_limit': item['mounting']['component_max_height_within_placement_limit'],
        'dc_bias': c['dc_bias'], 'effective_C_status': item['effective_capacitance_verdict'],
        'application_requirement_ids': item['requirement_ids'], 'uncompleted': item['hold_reasons'],
        'procurement_attributes': c['purchasing'], 'procurement_approved': False,
        'manufacturer_evidence': c['evidence'],
    })

verification = {
    'schema': 'smartvio-v25-critical-passives-verification/1.0', 'generated_utc': NOW,
    'audit_completion': 'COMPLETED_FOR_ACQUIRED_EVIDENCE_WITH_EXPLICIT_OPEN_ITEMS',
    'design_release': 'HOLD', 'procurement_approved': False,
    'summary': {'refs': len(per_ref), 'unique_documented_candidate_mpns': len(catalog),
                'conditional_mpn_proposals': sum(x['proposed_mpn'] is not None for x in per_ref),
                'hard_installation_no_fit_refs': sorted(hard_no_fit),
                'fully_approved_refs': 0, 'effective_C_fully_qualified_refs': 0,
                'actual_pcb_vs_native_net_mismatch_refs': sorted(set(x['ref'] for x in pin_net_results if not x['same'])),
                'json_0603_vs_actual_0805_conflicts': [x['ref'] for x in per_ref if x['native_package_description_conflicts_with_actual_pcb']]},
    'checks': checks, 'read_only_input_hash_checks': input_checks,
    'actual_pcb_numbered_net_comparisons': pin_net_results,
    'components': ref_verification, 'application_requirements': requirements,
    'release_blockers': [
        'L1101: no strict <=4x4x2mm, >=5A at accepted drop/temperature, exact-land-qualified selection. XGL4020 is electrical evidence only and oversized.',
        'FB1101: documented742792625 height1.0mm > current0.95mm; different recommended high-current land; loaded impedance unknown.',
        'FL1501: documented TDK height1.3mm >1.0mm; tentative numbered pin/winding map and land not approved. Manufacturer delivery drawing required.',
        'L1501/L1502: exact 10nH MPN identified, but no guaranteed pair matching, accepted exact land, assembled-height approval, USB eye or ESD/STB system test.',
        'Y801: ordering-table candidate only; factory exact-SKU confirmation, generic-vs-official land/backside assembly acceptance, CL/drive/startup and temperature budget outstanding.',
        'All MLCC: exact rated capacitance/voltage/package available, exact-MPN DC-bias/aging/temperature/ESR bounds and manufacturer land/reflow acceptance missing.',
        'C303/C304 effective minimum-vs-maximum inequality and low ESR not proven; VCAP1/2 capacitance window and ESR<100mohm not proven.',
        'C501/C502/C503 retained local minima and real pulsed-load/USB inrush unverified.',
        'C1102 VIN retained input C and C1104/C1105 direct Cout effective sum, Leff ratio, nominal44uF vs recommended47uF combination, loop/RHPZ/ripple/load transient unverified; C1106 after bead cannot be counted blindly.',
        'C1501 current2.2uF does not match TPD2S703-Q1 VPWR10uF recommendation. Keep design value, require documented acceptance or separate authorized redesign; C1502 retained VREF C and timing/clamp behavior unknown.',
        'C1502 native pad1=USB_VREF but SmartVio-usb-tentative PCB pad1=V3D; stale net mapping prevents integration/assembly release. MPN-only proposal does not change or repair this network.',
        'C1102/C1104/C1105/C1106/C1501 JSON package0603 vs actualPCB0805 metadata conflict requires parent reconciliation; this audit makes no source edits.',
        'No authorized quote, exact delivered suffix, lifecycle/stock confirmation, traceability, sample qualification or procurement approval.',
    ],
    'evidence_method': 'Live JSON plus pcbnew read-only footprint/board extraction; original manufacturer PDFs downloaded and hashed; physical/electrical selected pages rendered and inspected. TDK official PDF web text only, local403, visual mounting verification withheld. Never infer from dealer SKUs.',
    'visual_reviewed_pages': {
        'XGL4020': [3], '0603HP': [1], 'ABM8_current': [2], 'WE_742792625': [1],
        'CC0805KKX7R7BB105': [1], 'CC0805KKX7R7BB225': [1], 'CC0603KRX7R6BB225': [1],
        'TPS63070': [4], 'STM32H743': [211], 'TPD2S703_Q1': [21],
    },
    'test_limitations': ['No oscilloscope, C/V/ESR, temperature, physical assembly, USB eye or ESD/STB measurements.',
                         'No network/ERC/DRC redesign or routing approval performed.',
                         'Source PDF endurance/hipot is not a system transient guarantee; no fabricated transient acceptance.'],
    'source_catalog': list(sources.values()),
    'download_failures_not_used_as_verified_evidence': [x for x in attempts if x['download_status'] != 'SUCCESS'],
    'changed_files_scope': ['outputs/SmartVio-V25-Engineering/audit/critical-passives/proposal.json',
                            'outputs/SmartVio-V25-Engineering/audit/critical-passives/verification.json',
                            'work/v25/critical-passives/*'],
    'native_or_pcb_files_modified_by_this_subtask': [],
}
verification['created_or_modified_files'] = sorted(
    [str(p.relative_to(ROOT)).replace('\\', '/') for p in WORK.rglob('*') if p.is_file()] +
    ['outputs/SmartVio-V25-Engineering/audit/critical-passives/proposal.json',
     'outputs/SmartVio-V25-Engineering/audit/critical-passives/verification.json'])
verification['visual_reviewed_pages']['WE_742792625'] = [1, 2]

assert all(x['result'] == 'PASS' for x in checks
           if x['id'] not in ['INPUT_SNAPSHOT_HASHES', 'NUMBERED_PCB_NETS']), checks
AUDIT.mkdir(parents=True, exist_ok=True)
for name, obj in [('proposal.json', proposal), ('verification.json', verification)]:
    path = AUDIT / name
    path.write_text(json.dumps(obj, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
    assert json.loads(path.read_text(encoding='utf-8')) == obj
print(json.dumps({'outputs': [str(AUDIT / 'proposal.json'), str(AUDIT / 'verification.json')],
                  'summary': verification['summary'], 'checks': checks}, indent=2))
