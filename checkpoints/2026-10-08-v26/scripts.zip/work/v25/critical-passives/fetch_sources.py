import argparse
import concurrent.futures
import hashlib
import json
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from pypdf import PdfReader

WORK = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('index', type=Path)
parser.add_argument('--workers', type=int, default=6)
parser.add_argument('--timeout', type=int, default=30)
args = parser.parse_args()
sources = json.loads(args.index.read_text(encoding='utf-8'))
(WORK / 'sources').mkdir(parents=True, exist_ok=True)
(WORK / 'text').mkdir(parents=True, exist_ok=True)

def fetch(s):
    result = dict(s, retrieved_utc=datetime.now(timezone.utc).isoformat())
    try:
        req = urllib.request.Request(s['url'], headers={'User-Agent': 'Mozilla/5.0', 'Accept': '*/*'})
        with urllib.request.urlopen(req, timeout=args.timeout) as response:
            body = response.read()
            result.update(final_url=response.url, http_status=response.status,
                          content_type=response.headers.get('Content-Type'))
        ext = '.pdf' if body.startswith(b'%PDF') else '.html'
        path = WORK / 'sources' / (s['id'] + ext)
        path.write_bytes(body)
        result.update(path=str(path.relative_to(WORK)), bytes=len(body),
                      sha256=hashlib.sha256(body).hexdigest(), pdf=ext == '.pdf')
        if ext == '.pdf':
            reader = PdfReader(path)
            pages = [{'page': i + 1, 'text': p.extract_text() or ''}
                     for i, p in enumerate(reader.pages)]
            (WORK / 'text' / (s['id'] + '.json')).write_text(json.dumps(pages, indent=2), encoding='utf-8')
            result['pages'] = len(pages)
        result['download_status'] = 'SUCCESS'
    except Exception as exc:
        result.update(download_status='FAILED', error=str(exc))
    print(json.dumps({'id': s['id'], 'status': result['download_status'],
                      'pdf': result.get('pdf'), 'bytes': result.get('bytes'),
                      'error': result.get('error')}), flush=True)
    return result

with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
    records = list(pool.map(fetch, sources))
(WORK / ('manifest-' + args.index.stem + '.json')).write_text(json.dumps(records, indent=2), encoding='utf-8')
