from pathlib import Path
import pypdfium2 as pdfium

WORK = Path(__file__).resolve().parent
(WORK / 'rendered').mkdir(exist_ok=True)
PAGES = {'XGL4015': [1], 'XGL4020': [2], '0603HP': [0, 1],
         'ABM8_current': [0, 1], 'WE_742792625': [0, 1],
         'CC0805KKX7R7BB105': [0], 'CC0805KKX7R7BB225': [0],
         'CC0603KRX7R6BB225': [0], 'TPS63070': [3, 16, 18],
         'BQ24074': [7, 34], 'STM32H743': [105, 210], 'TPA6132A2': [14],
         'TPD2S703_Q1': [18, 20]}
for name, pages in PAGES.items():
    path = WORK / 'sources' / (name + '.pdf')
    if name == 'TPD2S703_Q1':
        path = WORK.parents[2] / 'outputs/SmartVio-V25-Engineering/audit/audio/sources/TPD2S703_Q1.pdf'
    doc = pdfium.PdfDocument(path)
    for number in pages:
        img = doc[number].render(scale=1.5).to_pil()
        target = WORK / 'rendered' / f'{name}-p{number+1}.png'
        img.save(target)
    print(name, [p + 1 for p in pages])
