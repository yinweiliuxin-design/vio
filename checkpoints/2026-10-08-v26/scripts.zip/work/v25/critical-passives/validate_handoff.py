import hashlib
import json
import re
import unicodedata
from html.parser import HTMLParser
from pathlib import Path

from pypdf import PdfReader

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
AUDIT = ROOT / 'outputs/SmartVio-V25-Engineering/audit/critical-passives'
proposal = json.loads((AUDIT / 'proposal.json').read_text(encoding='utf-8'))
verification = json.loads((AUDIT / 'verification.json').read_text(encoding='utf-8'))
assert len(proposal['components']) == len({c['ref'] for c in proposal['components']}) == 31
assert verification['summary']['refs'] == 31
assert verification['summary']['fully_approved_refs'] == 0
assert proposal['native_patch'] is None and proposal['pcb_patch'] is None
assert not proposal['procurement_approved'] and not verification['procurement_approved']
assert all(not c['procurement_approved'] and not c['eligible_for_mpn_only_integration_without_further_review']
           and c['status'] == 'HOLD' for c in proposal['components'])
assert all(c['fully_matched_and_approved_candidates'] == [] for c in proposal['components'])


def clean(text):
    return re.sub(r'\s+', '', ''.join(c for c in unicodedata.normalize('NFKC', text)
                                    if unicodedata.category(c) != 'Cf')).upper()


parts = {c['candidate']['mpn']: c['candidate'] for c in proposal['components']}
assert len(parts) == 16
validated_sources = set()
for part in parts.values():
    assert part['package']['height_max_mm'] > 0
    assert not part['purchasing']['procurement_approved']
    for e in part['evidence']:
        if not e.get('local_path'):
            continue
        path = ROOT / e['local_path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == e['sha256'], path
        validated_sources.add(str(path))
    if part['kind'] == 'MLCC':
        assert part['dc_bias']['ceff_min_uF'] is None and part['dc_bias']['ceff_max_uF'] is None
        assert part['esr_max_ohm'] is None
        e = part['evidence'][0]
        text = ''.join(p.extract_text() or '' for p in PdfReader(ROOT / e['local_path']).pages)
        assert part['mpn'] in clean(text)
        dims = re.findall(r'([LWT])\s+([\d.]+)mm\s*\+/-([\d.]+)mm',
                          ''.join(c for c in text if unicodedata.category(c) != 'Cf'))
        parsed = {axis: (float(nom), float(tol)) for axis, nom, tol in dims}
        assert len(parsed) == 3, (part['mpn'], parsed)
        actual_dims = [parsed[a][0] for a in 'LWT']
        actual_tol = [parsed[a][1] for a in 'LWT']
        assert actual_dims == part['package']['body_lwh_nominal_mm']
        assert actual_tol == part['package']['body_lwh_tolerance_mm']
        assert abs(sum(parsed['T']) - part['package']['height_max_mm']) < 1e-9

by_ref = {c['ref']: c for c in proposal['components']}
for ref in ['L1101', 'FB1101', 'FL1501']:
    assert by_ref[ref]['proposed_mpn'] is None
    assert not by_ref[ref]['mounting']['component_max_height_within_placement_limit']
assert by_ref['L1501']['proposed_mpn'] == by_ref['L1502']['proposed_mpn'] == '0603HP-10NXGRW'
assert by_ref['C1502']['mounting']['actual_pcb_numbered_net_mismatches'] == {
    'SmartVio-usb-tentative': {'1': 'V3D', '2': 'GND'}}
assert {p['number']: p.get('net') for p in by_ref['C1502']['preserved_pin_net_map']} == {
    '1': 'USB_VREF', '2': 'GND'}
assert set(verification['summary']['json_0603_vs_actual_0805_conflicts']) == {
    'C1102', 'C1104', 'C1105', 'C1106', 'C1501'}
assert proposal['application_requirements']['BUCK_OUTPUT']['direct_bulk_effective_sum_uF'] is None
assert proposal['application_requirements']['HSE']['measured_stray_pF'] is None
assert proposal['application_requirements']['USB_VPWR']['manufacturer_recommended_nominal_uF'] == 10
for name in verification['created_or_modified_files']:
    assert name.startswith('work/v25/critical-passives/') or name.startswith(
        'outputs/SmartVio-V25-Engineering/audit/critical-passives/'), name
assert verification['native_or_pcb_files_modified_by_this_subtask'] == []
assert proposal['snapshot_board_scope']['current_routed_final_verdict'] == 'NOT_EVALUATED_BY_THIS_SUBTASK'
assert by_ref['C1502']['mounting']['net_mismatch_not_a_current_final_finding']
assert not verification['parent_followup']['scoped_native_records_currently_unchanged']
assert verification['parent_followup']['only_five_authorized_package_fields_changed']
assert verification['parent_followup']['source_sha256'] == 'c3cf838f184bc2a50f5ec8f46a998342dc6cf1402db8976f6b50a1c9844f19c6'
manifest = json.loads((AUDIT / 'source-manifest.json').read_text(encoding='utf-8'))
assert manifest['copied_original_pdf_count'] == 23
for record in manifest['files']:
    assert hashlib.sha256((AUDIT / record['package_relative_path']).read_bytes()).hexdigest() == record['sha256']


class ReportLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.links.extend(v for k, v in attrs if k == 'href')


report_links = ReportLinks()
report_links.feed((AUDIT / 'report.html').read_text(encoding='utf-8'))
for href in report_links.links:
    if not href.startswith(('https://', 'http://')):
        assert (AUDIT / href).is_file(), href
print(json.dumps({'artifact_validation': 'PASS', 'refs': 31, 'candidate_mpns': 16,
                  'local_candidate_pdf_hashes_checked': len(validated_sources),
                  'exact_mlcc_dimensions_cross_checked_from_pdf': 11,
                  'remaining_release_status': 'HOLD',
                  'portable_original_pdfs_checked': manifest['copied_original_pdf_count'],
                  'report_relative_links': 'PASS',
                  'parent_five_package_deltas': 'VERIFIED_AUTHORIZED_DELTA_NOT_UNCHANGED',
                  'known_net_mismatch': 'HISTORICAL SmartVio-usb-tentative C1502 only; final-292 NOT evaluated'}, indent=2))
