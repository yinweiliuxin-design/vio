import hashlib
import html
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V25-Engineering'
AUDIT = OUT / 'audit/critical-passives'
PDFS = AUDIT / 'sources'
proposal = json.loads((AUDIT / 'proposal.json').read_text(encoding='utf-8'))
verification = json.loads((AUDIT / 'verification.json').read_text(encoding='utf-8'))
snapshot = json.loads((WORK / 'input-snapshot.json').read_text(encoding='utf-8'))
NOW = datetime.now(timezone.utc).isoformat()
FIXED_REFS = {'C1102', 'C1104', 'C1105', 'C1106', 'C1501'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path):
    return str(path.relative_to(ROOT)).replace('\\', '/')


live_native_path = OUT / 'electrical/native-components.json'
live_native = {c['ref']: c for c in json.loads(live_native_path.read_text(encoding='utf-8-sig'))
               if c['ref'] in snapshot['scope_refs']}
native_diffs = []
for ref in snapshot['scope_refs']:
    before = snapshot['native_components'][ref]
    after = live_native[ref]
    changed = {key: {'before': before.get(key), 'after': after.get(key)}
               for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)}
    if changed:
        native_diffs.append({'ref': ref, 'fields': changed})
assert {x['ref'] for x in native_diffs} == FIXED_REFS, native_diffs
assert all(set(x['fields']) == {'package'} for x in native_diffs), native_diffs
assert all(x['fields']['package']['after'] ==
           '0805/2012 actual candidate PCB class; exact MPN, height and effective capacitance HOLD'
           for x in native_diffs)
assert sha(live_native_path).startswith('c3cf838f') and sha(live_native_path).endswith('4f19c6')
initial_hash_checks = {x['path'].replace('\\', '/'): x for x in verification['read_only_input_hash_checks']}
closeout_hashes = []
for rel, info in snapshot['inputs'].items():
    path = OUT / rel
    key = relative(path)
    initial = initial_hash_checks[key]
    closeout_hashes.append({'path': key, 'snapshot_before_sha256': info['sha256'],
                            'original_audit_after_sha256': initial['after_sha256'],
                            'closeout_sha256': sha(path),
                            'original_before_after_record_preserved': True,
                            'attribution': 'AUTHORIZED_PARENT_PACKAGE_METADATA_FOLLOWUP' if path == live_native_path else
                            'UNCHANGED_FROM_SNAPSHOT' if sha(path) == info['sha256'] else
                            'PARALLEL_PARENT_INPUT_CHANGE_NOT_ATTRIBUTED_TO_THIS_SUBTASK'})
followup = {
    'schema': 'smartvio-v25-critical-passives-parent-followup/1.0', 'observed_utc': NOW,
    'authorization': 'Direct parent/user closeout instruction: only five package descriptions corrected, no overlay MPN merge, no network/value/pad changes.',
    'source_path': relative(live_native_path), 'source_sha256': sha(live_native_path),
    'parent_reported_sha256_prefix': 'c3cf838f', 'parent_reported_sha256_suffix': '4f19c6',
    'scoped_native_records_currently_unchanged': False,
    'changed_fields': native_diffs,
    'only_five_authorized_package_fields_changed': True,
    'scoped_native_mpn_values_pin_net_maps_release_other_fields_unchanged': True,
    'overlay_mpns_merged_by_this_subtask': False,
    'original_snapshot_and_original_before_after_hash_records_preserved': True,
    'input_hash_observations': closeout_hashes,
}


scope = {
    'classification': 'HISTORICAL_INPUT_SNAPSHOT_NOT_CURRENT_ROUTED_FINAL',
    'boards_loaded': list(snapshot['boards']),
    'not_inspected': ['final-292 new routed boards'],
    'current_routed_final_verdict': 'NOT_EVALUATED_BY_THIS_SUBTASK',
    'C1502': {
        'observed_board': 'SmartVio-usb-tentative',
        'observed_pcb_pad1_net': 'V3D', 'snapshot_native_pad1_net': 'USB_VREF',
        'result': 'HISTORICAL_SNAPSHOT_MISMATCH_ONLY',
        'not_a_finding_against_current_routed_final': True,
        'parent_update': 'Parent reports PCB worker is correcting MODE1 in final-292 new boards. No independent final-292 verification is claimed here.',
    },
    'package_metadata_conflicts': {
        'refs': ['C1102', 'C1104', 'C1105', 'C1106', 'C1501'],
        'classification': 'HISTORICAL_SNAPSHOT_NATIVE_0603_VS_PCB_0805',
        'parent_update': 'Parent corrected exactly five package descriptions only. Verified current native SHA256 c3cf838f184bc2a50f5ec8f46a998342dc6cf1402db8976f6b50a1c9844f19c6. No scoped MPN/value/net/release changes. Exact MPN, height and Ceff remain HOLD.',
        'resolution': 'RESOLVED_BY_AUTHORIZED_PARENT_PACKAGE_DESCRIPTION_ONLY',
    },
}
proposal['snapshot_board_scope'] = scope
verification['snapshot_board_scope'] = scope
verification['summary']['pcb_net_mismatch_scope'] = 'HISTORICAL_SMARTVIO_USB_TENTATIVE_ONLY_NOT_FINAL_292'
verification['summary']['package_metadata_conflict_scope'] = 'HISTORICAL_SNAPSHOT_PARENT_RECONCILIATION'
verification['summary']['package_metadata_conflict_resolution'] = 'RESOLVED_BY_PARENT_PACKAGE_DESCRIPTION_ONLY'

historical_net_note = ('HISTORICAL_SNAPSHOT_ONLY: C1502 pad1 on SmartVio-usb-tentative was V3D, '
                       'while snapshot native JSON was USB_VREF. This is not a finding against '
                       'current routed final/final-292. Parent reports MODE1 correction in new boards; '
                       'this subtask did not inspect those boards and makes no current-final verdict.')
metadata_note = ('HISTORICAL_SNAPSHOT_RESOLVED: native package description said0603 while loaded '
                 'PCB footprint was0805. Parent corrected exactly five package descriptions to '
                 '0805/2012; source hash and field-only diffs recorded in parent-followup.json. '
                 'No MPN/pad/value/net/release changes; exact MPN, height and Ceff remain HOLD.')

for component in proposal['components']:
    component['mounting']['observation_scope'] = 'HISTORICAL_INPUT_SNAPSHOT_NOT_CURRENT_ROUTED_FINAL'
    if component['native_package_description_conflicts_with_actual_pcb']:
        component['native_package_conflict_scope'] = 'HISTORICAL_SNAPSHOT_RESOLVED_BY_PARENT_PACKAGE_ONLY'
        component['parent_followup_package_description'] = live_native[component['ref']]['package']
        component['hold_reasons'] = [metadata_note if 'Native package description says0603' in reason else reason
                                     for reason in component['hold_reasons']]
    if component['ref'] == 'C1502':
        component['mounting']['land_status'] = 'HISTORICAL_NET_MISMATCH_ONLY_GENERIC_LAND_HOLD'
        component['mounting']['net_mismatch_not_a_current_final_finding'] = True
        component['hold_reasons'] = [historical_net_note if 'HOLD_NET_MISMATCH:' in reason else reason
                                     for reason in component['hold_reasons']]
    history = [reason for reason in component['hold_reasons'] if reason in [metadata_note, historical_net_note]]
    component['historical_observations'] = sorted(set(component.get('historical_observations', [])) | set(history))
    component['hold_reasons'] = [reason for reason in component['hold_reasons'] if reason not in history]

for component in verification['components']:
    component['board_observation_scope'] = 'HISTORICAL_INPUT_SNAPSHOT_NOT_CURRENT_ROUTED_FINAL'
    component['uncompleted'] = [historical_net_note if 'HOLD_NET_MISMATCH:' in reason else
                              metadata_note if 'Native package description says0603' in reason else reason
                              for reason in component['uncompleted']]
    if component['ref'] == 'C1502':
        component['actual_mounting_verdict'] = 'HISTORICAL_NET_MISMATCH_ONLY_GENERIC_LAND_HOLD'
        component['net_mismatch_not_a_current_final_finding'] = True
    history = [reason for reason in component['uncompleted'] if reason in [metadata_note, historical_net_note]]
    component['historical_observations'] = sorted(set(component.get('historical_observations', [])) | set(history))
    component['uncompleted'] = [reason for reason in component['uncompleted'] if reason not in history]

verification.setdefault('original_release_blockers_before_parent_closeout', verification['release_blockers'])
verification['release_blockers'] = [
    historical_net_note if reason.startswith('C1502 native pad1=') else
    metadata_note if reason.startswith('C1102/C1104/C1105/C1106/C1501 JSON package0603') else reason
    for reason in verification['release_blockers']]
verification['historical_findings_not_current_final_blockers'] = [historical_net_note, metadata_note]
verification['release_blockers'] = [reason for reason in verification['release_blockers']
                                  if reason not in [historical_net_note, metadata_note]]
for row in verification['actual_pcb_numbered_net_comparisons']:
    row['observation_scope'] = 'HISTORICAL_INPUT_SNAPSHOT_NOT_CURRENT_ROUTED_FINAL'
for check in verification['checks']:
    check['scope'] = 'AUDIT_ARTIFACT_OR_HISTORICAL_INPUT_SNAPSHOT'
    if check['id'] == 'NUMBERED_PCB_NETS':
        check['scope'] = 'HISTORICAL_BOARDS_ONLY_NOT_CURRENT_ROUTED_FINAL'
        check['detail'] = historical_net_note
    if check['id'] in ['SCOPED_JSON_RECORDS_UNCHANGED', 'SCOPED_JSON_RECORDS_UNCHANGED_AT_INITIAL_AUDIT']:
        check.setdefault('original_id', check['id'])
        check['id'] = 'SCOPED_JSON_RECORDS_UNCHANGED_AT_INITIAL_AUDIT'
        check['scope'] = 'INITIAL_AUDIT_TIME_ONLY_NOT_CURRENT_CLOSEOUT'
        if 'Historical PASS only.' not in check['detail']:
            check['detail'] += ' Historical PASS only. At current closeout five package fields differ via authorized parent correction; see parent-followup.json.'
verification['checks'] = [c for c in verification['checks'] if c['id'] != 'CURRENT_SCOPED_PARENT_FOLLOWUP']
verification['checks'].append({'id': 'CURRENT_SCOPED_PARENT_FOLLOWUP', 'result': 'PASS_AUTHORIZED_DELTA',
                               'scoped_records_unchanged': False,
                               'scope': 'CURRENT_CLOSEOUT_NATIVE_JSON',
                               'detail': 'Exactly five authorized package-only diffs; current native source matches reported c3cf838f...4f19c6. No scoped MPN/value/pin-net/release changes.'})
proposal['parent_followup'] = followup
verification['parent_followup'] = followup
verification['closeout_input_hash_observations'] = closeout_hashes

source_by_id = {s['id']: s for s in proposal['source_catalog']}
acquired = {p.stem: p for p in (WORK / 'sources').glob('*.pdf')}
tpd = source_by_id['TPD2S703_Q1']
acquired['TPD2S703_Q1'] = ROOT / tpd.get('original_cache_path', tpd['local_path'])
PDFS.mkdir(parents=True, exist_ok=True)
copies = {}
manifest_records = []
for source_id, original in sorted(acquired.items()):
    assert original.is_file() and original.read_bytes().startswith(b'%PDF'), original
    assert source_id in source_by_id, source_id
    record = source_by_id[source_id]
    expected = record['sha256']
    assert sha(original) == expected, source_id
    target = PDFS / (source_id + '.pdf')
    assert target.resolve().parent == PDFS.resolve()
    if target.exists():
        assert sha(target) == expected, target
    else:
        shutil.copy2(original, target)
    assert sha(target) == expected
    copies[source_id] = target
    manifest_records.append({
        'source_id': source_id, 'manufacturer_url': record['url'],
        'package_relative_path': 'sources/' + target.name,
        'engineering_root_relative_path': str(target.relative_to(OUT)).replace('\\', '/'),
        'workspace_relative_path': relative(target), 'sha256': expected,
        'bytes': target.stat().st_size,
        'original_cache_path': relative(original),
        'use': 'EXCLUDED_TRIAL_REFERENCE_NOT_CANDIDATE_EVIDENCE' if source_id in ['TPD2S300', 'WE_742792641'] else
               'EVALUATED_NOT_PROMOTED' if source_id == 'XGL4015' else 'CITED_ORIGINAL_MANUFACTURER_EVIDENCE',
    })


def attach_portable_paths(value):
    if isinstance(value, dict):
        source_id = value.get('source_id', value.get('id'))
        if source_id in copies and value.get('local_path'):
            value.setdefault('original_cache_path', value['local_path'])
            value['local_path'] = relative(copies[source_id])
            value['local_path_base'] = 'WORKSPACE_ROOT'
            value['package_relative_path'] = 'sources/' + copies[source_id].name
            value['package_relative_path_base'] = 'THIS_AUDIT_DIRECTORY'
            value['engineering_root_relative_path'] = str(copies[source_id].relative_to(OUT)).replace('\\', '/')
        for child in value.values():
            attach_portable_paths(child)
    elif isinstance(value, list):
        for child in value:
            attach_portable_paths(child)


attach_portable_paths(proposal)
attach_portable_paths(verification)
url_only = [s for s in proposal['source_catalog'] if not s.get('local_path')]
manifest = {
    'schema': 'smartvio-v25-critical-passives-evidence-package/1.0',
    'generated_utc': NOW, 'download_or_new_search_during_closeout': False,
    'path_base': 'Directory containing report.html/proposal.json/verification.json',
    'copied_original_pdf_count': len(manifest_records), 'files': manifest_records,
    'url_only_evidence': url_only,
    'url_only_note': 'TDK original PDF was read through web; local HTTP403 prevented PDF capture. Use the retained manufacturer URL. No PDF fabricated and numbered mounting remains HOLD.',
    'snapshot_board_scope': scope,
    'regeneration_order': ['build_handoff.py (only for a deliberate audit regeneration)',
                           'package_evidence.py', 'validate_handoff.py'],
}


def esc(value):
    return html.escape(str(value))


def link(url, label):
    return '<a href="' + html.escape(url, quote=True) + '">' + esc(label) + '</a>'


rows = []
for component in proposal['components']:
    part = component['candidate']
    package = part['package']
    dims = package.get('body_lwh_nominal_mm')
    if dims:
        size = ' x '.join('drawing' if d is None else str(d) for d in dims)
        tolerance = package.get('body_lwh_tolerance_mm', package.get('body_lw_tolerance_mm'))
        if tolerance:
            size += '; +/- ' + '/'.join(str(t) for t in tolerance)
    else:
        size = 'Lmax ' + str(package.get('body_length_max_mm')) + '; W ' + str(package.get('body_width_range_mm'))
    size += '; Hmax ' + str(package['height_max_mm']) + ' mm'
    refs = []
    for e in part['evidence']:
        if e.get('package_relative_path'):
            refs.append(link(e['package_relative_path'], e['source_id'] + ' PDF'))
        elif e.get('manufacturer_url'):
            refs.append(link(e['manufacturer_url'], 'manufacturer URL'))
    ceff = 'UNKNOWN / HOLD' if part['kind'] == 'MLCC' else 'not MLCC Ceff'
    mounting = component['mounting']['land_status']
    if component['ref'] == 'C1502':
        mounting = 'old SmartVio-usb-tentative mismatch only; final-292 NOT evaluated'
    rows.append('<tr><td>' + esc(component['ref']) + '</td><td>' + esc(part['mpn']) +
                '<br>' + esc('overlay candidate' if component['proposed_mpn'] else 'evaluated only; no proposed_mpn') +
                '</td><td>' + esc(size) + '</td><td>' + esc(mounting) +
                '</td><td>' + esc(ceff) + '</td><td>' + '<br>'.join(refs) + '</td></tr>')

source_rows = ['<tr><td>' + esc(s['source_id']) + '</td><td>' +
               link(s['package_relative_path'], 'PDF') + '</td><td>' +
               link(s['manufacturer_url'], 'manufacturer') + '</td><td>' + esc(s['use']) +
               '</td><td><code>' + esc(s['sha256']) + '</code></td></tr>' for s in manifest_records]
for s in url_only:
    source_rows.append('<tr><td>' + esc(s['id']) + '</td><td>URL only; local HTTP403</td><td>' +
                       link(s['url'], 'manufacturer') + '</td><td>mounting verification HOLD</td><td>not captured</td></tr>')
blockers = ''.join('<li>' + esc(text) + '</li>' for text in verification['release_blockers'])
report = '''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SmartVio V25 Critical Passives Audit</title>
<style>body{font:14px/1.55 system-ui,Arial,sans-serif;color:#202124;background:#fff;margin:24px auto;padding:0 20px;max-width:1500px}h1{font-size:24px}h2{font-size:18px;margin-top:28px}a{color:#175ca3}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #c7cdd3;padding:8px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#edf0f2}code{font-size:11px}.notice{border-left:4px solid #b54522;padding:8px 12px;background:#fff3ec}.scroll{overflow:auto}li{margin-bottom:7px}</style>
</head><body><h1>SmartVio V25 关键无源候选审核</h1>
<p>31 个位号，16 个候选 MPN，28 个候选叠加字段。所有 eligible 自动替换与采购批准均为 false。未修改 native、PCB、焊盘、网络或标称设计数值。</p>
<p>交付文件：''' + link('proposal.json', 'proposal.json') + ' | ' + link('verification.json', 'verification.json') + ' | ' + link('source-manifest.json', 'source-manifest.json') + ' | ' + link('parent-followup.json', 'parent-followup.json') + '''</p>
<div class="notice"><strong>历史板范围限定</strong><p>C1502 的 V3D / USB_VREF 差异只来自 input-snapshot 中的旧 SmartVio-usb-tentative；不是 current routed final 或 final-292 的错误结论。父代理说明 PCBworker 正在 final-292 新板修正 MODE1，本子任务未检查新板。</p><p>五处 native 0603 / 实际 0805 差异也是历史快照观察，已由父代理授权纠正 package 描述。当前源哈希 c3cf838f184bc2a50f5ec8f46a998342dc6cf1402db8976f6b50a1c9844f19c6；逐字段差异见 parent-followup.json。原始快照与 before/after 哈希保留，不把历史 scoped-unchanged PASS 当作当前不变结论。MPN overlay 未合并；无 pads / nominal value / nets / release 更改。</p></div>
<h2>候选与安装判定</h2><p>下表尺寸单位为 mm；完整公差、额定参数、安装差异与逐位未完成项见 proposal / verification。component Hmax 不等于已批准的装配高度。有效 C 未验证时保持 null，不采用假设保留率。</p>
<div class="scroll"><table><thead><tr><th>位号</th><th>精准 MPN / 层级</th><th>原厂尺寸 / 高度</th><th>快照安装判定</th><th>有效 C</th><th>原厂证据</th></tr></thead><tbody>''' + ''.join(rows) + '''</tbody></table></div>
<h2>未完成项 / 不可放行条件</h2><p>安装观察仅对列入快照的历史板有效；新板是否关闭安装条件由其最终审核决定。元件参数、有效 C、ESR、瞬态及采购条件仍独立保留 HOLD。</p><ul>''' + blockers + '''</ul>
<h2>原厂证据索引</h2><p>所有已取得的原厂 PDF 均为原始字节复制；不需要工作目录即可从本报告相对链接打开。被排除的试查 PDF 明确标注，不能用作候选批准证据。TDK 未取得本地 PDF，保留原厂可访问 URL，未虚构附件。</p>
<div class="scroll"><table><thead><tr><th>Source ID</th><th>随包 PDF</th><th>原厂 URL</th><th>用途</th><th>SHA256</th></tr></thead><tbody>''' + ''.join(source_rows) + '''</tbody></table></div>
<p>交付整理时间 UTC：''' + esc(NOW) + '''。未新增器件搜索；未形成采购、装配或 current routed final 批准。</p></body></html>
'''

manifest_path = AUDIT / 'source-manifest.json'
report_path = AUDIT / 'report.html'
(AUDIT / 'parent-followup.json').write_text(json.dumps(followup, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
manifest_path.write_text(json.dumps(manifest, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
report_path.write_text(report, encoding='utf-8')
for obj in [proposal, verification]:
    obj['evidence_package'] = {'manifest': 'source-manifest.json', 'report': 'report.html',
                               'copied_original_pdf_count': len(manifest_records),
                               'portable_relative_path_base': 'THIS_AUDIT_DIRECTORY',
                               'no_new_search_during_closeout': True, 'packaged_utc': NOW}
verification['created_or_modified_files'] = sorted(set(verification['created_or_modified_files']) |
    {relative(p) for base in [WORK, AUDIT] for p in base.rglob('*') if p.is_file()})
verification['evidence_package_validation'] = {'copied_pdf_hashes': 'PASS',
                                              'copied_pdf_count': len(manifest_records),
                                              'historical_C1502_scope': 'NOT_A_CURRENT_FINAL_FINDING'}
for name, obj in [('proposal.json', proposal), ('verification.json', verification)]:
    (AUDIT / name).write_text(json.dumps(obj, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'report': relative(report_path), 'manifest': relative(manifest_path),
                  'copied_original_pdfs': len(manifest_records),
                  'current_routed_final': 'NOT_EVALUATED', 'procurement_approved': False}, indent=2))
