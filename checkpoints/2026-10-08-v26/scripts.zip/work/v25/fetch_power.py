import hashlib
import json
import subprocess
import urllib.request
from pathlib import Path
from pypdf import PdfReader

root=Path(__file__).resolve().parent/'power'
root.mkdir(parents=True,exist_ok=True)
poppler=Path('<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftotext.exe')
urls={n:'https://www.ti.com/lit/ds/symlink/'+n+'.pdf' for n in ['bq24074','tps25947','tps63070','ads1115','tmux1511','opa4330','tmp117']}
urls['ltc2954']='https://www.analog.com/media/en/technical-documentation/data-sheets/2954fb.pdf'
urls['pmv30un2']='https://assets.nexperia.com/documents/data-sheet/PMV30UN2.pdf'
records=[]
for name,url in urls.items():
    dest=root/(name+'.pdf')
    try:
        if not dest.exists():
            with urllib.request.urlopen(url,timeout=50) as response:data=response.read()
            assert data.startswith(b'%PDF'),url
            dest.write_bytes(data)
        reader=PdfReader(str(dest))
        dest.with_suffix('.txt').write_text('\n'.join(f'\n=== PAGE {i+1} ===\n'+p.extract_text(extraction_mode='layout') for i,p in enumerate(reader.pages)),encoding='utf-8')
        with dest.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
        records.append(dict(id=name,url=url,sha256=digest,file=str(dest),retrieved='2026-10-04',success=True))
        print(name,'OK',flush=True)
    except Exception as e:
        records.append(dict(id=name,url=url,success=False,error=str(e)))
        print(name,str(e),flush=True)
(root/'sources.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
