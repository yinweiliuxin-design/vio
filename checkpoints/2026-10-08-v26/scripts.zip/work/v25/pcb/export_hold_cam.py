"""Export review-only CAM after native geometry/connectivity gate, never release."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2];OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser()
ap.add_argument('--board',type=Path,required=True);ap.add_argument('--drc',type=Path,required=True)
ap.add_argument('--output-dir',type=Path,required=True)
a=ap.parse_args();assert a.output_dir.resolve().is_relative_to(OUT.resolve())
a.output_dir.mkdir(parents=True,exist_ok=True)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
drc=json.loads(a.drc.read_text());assert not drc['violations'] and not drc['unconnected_items'],'CAM gate requires zero native violations and unconnected items'
assert drc['source']==a.board.name
b=p.LoadBoard(str(a.board.resolve()));before=sha(a.board)
cli=ROOT/'work/v24/tools/kicad/bin/kicad-cli.exe'
def run(*args):
    q=subprocess.run([str(cli),*map(str,args)],capture_output=True,text=True)
    assert q.returncode==0,q.stdout+q.stderr
    print(q.stdout,flush=True)
layers=['F.Cu']+(['In1.Cu','In2.Cu'] if b.GetCopperLayerCount()==4 else [])+['B.Cu','F.Paste','B.Paste','F.Mask','B.Mask','F.Silkscreen','B.Silkscreen','Edge.Cuts']
run('pcb','export','gerbers','--layers',','.join(layers),'--exclude-refdes','--exclude-value','--check-zones','--output',a.output_dir,a.board)
run('pcb','export','drill','--output',a.output_dir,'--excellon-units','mm','--excellon-separate-th','--generate-map','--map-format','gerberx2','--generate-report','--report-path',a.output_dir/'drill-report.txt',a.board)
pos=a.output_dir/'positions-native-all.csv'
run('pcb','export','pos','--format','csv','--units','mm','--side','both','--output',pos,a.board)
rows=list(csv.DictReader(pos.open(newline='',encoding='utf-8-sig')))
manual={f.GetReference() for f in b.GetFootprints() if f.GetReference().startswith(('JP','J1802'))}
assembly=[r for r in rows if r['Ref'] not in manual]
with (a.output_dir/'positions-assembly-candidates.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(assembly)
power='power' in a.board.name
specific=('Power board is a charger/power/telemetry prototype, NOT the complete SmartVio product.\n'
    'Generic L1101 footprint has no approved MPN; XGL4020-152MEC4 remains a proposal with different dimensional budget.\n'
    'Validate current/temperature, copper weight, switching/feedback/return loops, thermal EP via, stencil and pack harness.\n'
    'JP1/JP2/JP3 are manual test-wire terminals, not pick-and-place components; native-all pos retains them for inspection.\n') if power else (
    'Separate temperature sensor board only, NOT the complete SmartVio product.\n'
    'Sensor accuracy, thermal coupling, cable/connector termination and final assembly remain HOLD.\n'
    'J1802 is a manual solder endpoint, not a selected catalog connector or placement component.\n')
(a.output_dir/'HOLD.txt').write_text('ENGINEERING REVIEW EXPORT ONLY. productionApproved=false.\n'
    'Do not order production or claim product release. Native DRC/parity do not approve the circuit or assembly.\n'
    +specific+
    'B.Paste may be empty when no bottom SMD parts exist. No electrical, mechanical or production approval.\n')
jobfiles=list(a.output_dir.glob('*.gbrjob'))
assert len(jobfiles)==1
job=json.loads(jobfiles[0].read_text())
gerbers=[a.output_dir/f['Path'] for f in job['FilesAttributes']]
assert len(gerbers)==len(layers), 'Gerber job must include all layers'
for f in gerbers:
    text=f.read_text();assert '%FSL' in text and '%MOMM*%' in text and 'M02*' in text
assert len(list(a.output_dir.glob('*_Paste.g?*')))==2
assert list(a.output_dir.glob('*.drl'))
assert sha(a.board)==before,'CAM export mutated the native board'
files=[{'path':str(f.resolve()),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(a.output_dir.glob('*')) if f.is_file() and f.name!='CAM-manifest.json']
record={'productionApproved':False,'status':'ENGINEERING_HOLD_REVIEW_EXPORT',
    'boardPath':str(a.board.resolve()),'boardSHA256':before,'nativeDRCPath':str(a.drc.resolve()),'nativeDRCSHA256':sha(a.drc),
    'layers':layers,'nativePositionRows':len(rows),'assemblyCandidatePositionRows':len(assembly),'manualTerminalRefs':sorted(manual),
    'gerberLayerFilesValidated':len(gerbers),'ignoredChecks':drc['ignored_checks'],
    'vias':sum(isinstance(t,p.PCB_VIA) for t in b.GetTracks()),'CAM':files,
    'blockingApproval':specific}
(a.output_dir/'CAM-manifest.json').write_text(json.dumps(record,indent=2))
print(json.dumps({'files':len(files),'positionRows':len(rows),'assemblyRows':len(assembly),'productionApproved':False}))
