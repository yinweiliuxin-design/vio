"""Apply source values without moving copper, add real ground pours, emit pin parity."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import xml.etree.ElementTree as ET
from process_rules import configure

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'documents')
os.environ['DOCUMENTS_HOME']=str(WORK/'documents')
import pcbnew as p

ap=argparse.ArgumentParser()
ap.add_argument('--board',type=Path,required=True)
ap.add_argument('--output',type=Path,required=True)
ap.add_argument('--components',type=Path,default=ROOT/'outputs/SmartVio-V25-Engineering/electrical/native-components.json')
ap.add_argument('--prototype',action='store_true')
ap.add_argument('--fill',action='store_true')
args=ap.parse_args()
assert args.output.resolve().is_relative_to(OUT.resolve())
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
parts=json.loads(args.components.read_text(encoding='utf-8-sig'))
source={c['ref']:c for c in parts}
mapping=json.loads((OUT/'footprint-review.json').read_text())
if args.prototype:
    capture=json.loads((OUT/'power-prototype-components.json').read_text())
    selected={c['ref']:source.get(c['ref'],c) for c in capture}
else:
    selected=source
b=p.LoadBoard(str(args.board.resolve()))
def copper():
    return sorted((f.GetReference(),d.GetNumber(),d.GetNetname(),d.GetPosition().x,d.GetPosition().y,f.GetLayer()) for f in b.GetFootprints() for d in f.Pads())
before=copper();differences=[];actual={};values=[]
for f in b.GetFootprints():
    r=f.GetReference()
    actual[r]={}
    for d in f.Pads():
        if d.GetNumber():actual[r][d.GetNumber()]=d.GetNetname() or None
    if r not in selected:continue
    c=selected[r]
    f.SetValue(c['value'])
    f.SetField('MPN',c.get('mpn','') or '')
    f.GetField('MPN').SetVisible(False)
    f.Value().SetVisible(False)
    values.append({'ref':r,'value':c['value'],'mpn':c.get('mpn')})
    aliases=mapping.get(r,{}).get('pinAliases',{})
    for pin in c['pins']:
        n=aliases.get(pin['number'],pin['number'])
        want=pin['net'] or None
        if n not in actual[r]:
            differences.append({'ref':r,'pin':n,'expected':want,'actual':'MISSING_PAD'})
        elif actual[r][n]!=want:
            differences.append({'ref':r,'pin':n,'expected':want,'actual':actual[r][n]})
    expected={aliases.get(pin['number'],pin['number']) for pin in c['pins']}
    for n,net in actual[r].items():
        if n not in expected and net:differences.append({'ref':r,'pin':n,'expected':'ABSENT_PIN','actual':net})
assert before==copper(),'Value-only update altered pad/net/placement geometry'
configure(p,b,args.output,args.board.with_suffix('.kicad_pro'))
if args.fill:
    assert all(z.GetIsRuleArea() for z in b.Zones()),'Refusing duplicate copper pours'
    edge=b.GetBoardEdgesBoundingBox()
    # Internal copper is not a continuous reference plane until return-path review.
    for layer in ((p.In1_Cu,p.In2_Cu) if b.GetCopperLayerCount()==4 else (p.F_Cu,p.B_Cu)):
        z=p.ZONE(b);z.SetLayer(layer);z.SetNetCode(b.FindNet('GND').GetNetCode())
        z.SetLocalClearance(p.FromMM(.2));z.SetMinThickness(p.FromMM(.15))
        z.SetPadConnection(p.ZONE_CONNECTION_FULL)
        z.SetIslandRemovalMode(p.ISLAND_REMOVAL_MODE_ALWAYS)
        poly=z.Outline();poly.NewOutline()
        x0=p.ToMM(edge.GetX())+.5;y0=p.ToMM(edge.GetY())+.5
        x1=p.ToMM(edge.GetRight())-.5;y1=p.ToMM(edge.GetBottom())-.5
        for x,y in ((x0,y0),(x1,y0),(x1,y1),(x0,y1)):poly.Append(p.FromMM(x),p.FromMM(y))
        b.Add(z)
    b.BuildConnectivity()
    filler=p.ZONE_FILLER(b);filler.Fill(b.Zones())
if not args.prototype and 'main' in args.board.name and not any(z.GetIsRuleArea() for z in b.Zones()):
    z=p.ZONE(b);z.SetLayer(p.F_Cu);z.SetIsRuleArea(True)
    z.SetDoNotAllowFootprints(True);z.SetDoNotAllowPads(False)
    z.SetDoNotAllowTracks(False);z.SetDoNotAllowVias(False);z.SetDoNotAllowZoneFills(False)
    poly=z.Outline();poly.NewOutline()
    for x,y in ((0,24.5),(72,24.5),(72,39),(0,39)):poly.Append(p.FromMM(x),p.FromMM(y))
    b.Add(z)
p.SaveBoard(str(args.output),b)
record={'status':'ENGINEERING_HOLD_NOT_FOR_FABRICATION','source':str(args.components),'sourceSHA256':sha(args.components),
        'inputBoardSHA256':sha(args.board),'board':str(args.output),'boardSHA256':sha(args.output),
        'footprints':len(actual),'tracksAndVias':len(list(b.GetTracks())),'zones':len(list(b.Zones())),
        'copperUnchangedByValueUpdate':True,'sourcePinDifferences':differences,'values':values,'pins':actual,
        'extraHarnessRefs':sorted(set(actual)-set(selected)),'missingSourceRefs':sorted(set(selected)-set(actual)) if args.prototype else [],
        'criticalPowerAudioEmiReview':'NOT_APPROVED','fabrication':'HOLD','drc':'RUN_NATIVE_CLI_AFTER_THIS_STEP'}
if args.prototype:record['components']=[selected[r] for r in sorted(selected)]
path=OUT/'verification'/('power-prototype-final-contract.json' if args.prototype else args.output.stem+'-contract.json')
path.write_text(json.dumps(record,indent=2))
print(json.dumps({k:v for k,v in record.items() if k not in ('values','pins','components')},indent=2))
