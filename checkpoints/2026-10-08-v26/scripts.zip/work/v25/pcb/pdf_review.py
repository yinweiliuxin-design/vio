from pathlib import Path
import json
import subprocess
from pypdf import PdfReader

root = Path(__file__).resolve().parent
out = root / 'pdf-review'
out.mkdir(exist_ok=True)
index = {}
for path in (root / 'sources').glob('*.pdf'):
    doc = PdfReader(path)
    texts = [page.extract_text() for page in doc.pages]
    (out / (path.stem + '.txt')).write_text('\n'.join(f'\nPAGE {i+1}\n{text}' for i,text in enumerate(texts)), encoding='utf-8')
    selected = [i for i,t in enumerate(texts) if any(s in t.upper() for s in ('LAND PATTERN','EXAMPLE BOARD LAYOUT','RECOMMENDED PCB','RECOMMENDED P.C.B.','PACKAGE INFORMATION'))]
    if len(doc.pages) <= 3:
        selected = list(range(len(doc.pages)))
    index[path.stem] = {'pages':len(doc.pages),'reviewPages':[i+1 for i in selected]}
    for i in selected:
        subprocess.run(['pdftoppm','-f',str(i+1),'-l',str(i+1),'-scale-to','1600','-png','-singlefile',str(path),str(out / f'{path.stem}-{i+1}')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
print(json.dumps(index,indent=2))
