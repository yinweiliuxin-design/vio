"""Move a local power-controller signal corner away from its neighbouring lead."""
import json
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2];OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
src=OUT/'SmartVio-power-prototype-v2-bridged.kicad_pcb';dst=OUT/'SmartVio-power-prototype-clear.kicad_pcb'
b=p.LoadBoard(str(src));drc=json.loads((OUT/'verification/power-v2-bridged-drc.json').read_text())
assert len(drc['violations'])==1 and drc['violations'][0]['type']=='clearance'
uid=drc['violations'][0]['items'][0]['uuid']
tracks=list(b.GetTracks());target=next(t for t in tracks if t.m_Uuid.AsString()==uid)
assert target.GetNetname()=='PWR_KILL'
points={(q.x,q.y) for q in (target.GetStart(),target.GetEnd())}
changes=[]
for t in tracks:
    if t.GetNetname()!='PWR_KILL':continue
    for endpoint in ('Start','End'):
        q=getattr(t,'Get'+endpoint)()
        if (q.x,q.y) not in points:continue
        old=[q.x,q.y]
        z=p.VECTOR2I(q.x,q.y-p.FromMM(.02));getattr(t,'Set'+endpoint)(z)
        changes.append({'uuid':t.m_Uuid.AsString(),'endpoint':endpoint,'oldNm':old,'newNm':[z.x,z.y]})
p.SaveBoard(str(dst),b);shutil.copyfile(src.with_suffix('.kicad_pro'),dst.with_suffix('.kicad_pro'))
(OUT/'verification/power-clearance-nudge.json').write_text(json.dumps({'changes':changes,'padsMoved':False,'rulesChanged':False,'drc':'REQUIRED'},indent=2))
print(json.dumps(changes))
