"""Physical switch-loop placement and short power-pad escapes before routing."""
import json
import os
from pathlib import Path
import shutil
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
pt=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
source=OUT/'SmartVio-power-prototype-charger-seeded.kicad_pcb'
target=OUT/'SmartVio-power-prototype-critical-v2-seeded.kicad_pcb'
b=p.LoadBoard(str(source))
fps={f.GetReference():f for f in b.GetFootprints()}
fps['L1101'].SetOrientationDegrees(-90)
added=[]
def track(net,points,width):
    for a,z in zip(points,points[1:]):
        t=p.PCB_TRACK(b);t.SetStart(pt(*a));t.SetEnd(pt(*z));t.SetWidth(p.FromMM(width));t.SetLayer(p.F_Cu);t.SetNetCode(b.FindNet(net).GetNetCode());b.Add(t)
        added.append({'net':net,'start':a,'end':z,'widthMm':width,'layer':'F.Cu'})
def via(net,x,y):
    v=p.PCB_VIA(b);v.SetPosition(pt(x,y));v.SetWidth(p.FromMM(.6));v.SetDrill(p.FromMM(.3));v.SetViaType(p.VIATYPE_THROUGH);v.SetLayerPair(p.F_Cu,p.B_Cu);v.SetNetCode(b.FindNet(net).GetNetCode());b.Add(v)
    added.append({'net':net,'via':[x,y],'diameterMm':.6,'drillMm':.3})
# Short 0.25 mm pad necks open into 0.6 mm switch copper, on one surface.
for net,y,endY in [('BUCK_L1',8.5,7.45),('BUCK_L2',9.5,10.55)]:
    track(net,[(30.775,y),(31.95,y)],.25)
    track(net,[(31.95,y),(32.55,endY),(34.4,endY)],.6)
track('BUCK_FB',[(29.275,10.4),(29.275,11.5),(27.325,11.5),(27.325,9)],.15)
track('USB_5V_SAFE',[(7.25,9),(7.25,10.7),(8.1,11.55),(8.1,11.9)],.2)
via('USB_5V_SAFE',8.1,11.9)
track('V3D',[(20.1,27),(21.6,27)],.15)
via('V3D',21.6,27)
track('SYS',[(44.8625,10.025),(44.8625,9.2)],.2)
via('SYS',44.8625,9.2)
p.SaveBoard(str(target),b)
shutil.copyfile(source.with_suffix('.kicad_pro'),target.with_suffix('.kicad_pro'))
(OUT/'verification/power-critical-v2-seed.json').write_text(json.dumps({'board':str(target),'inductorRotationDeg':-90,'added':added,
    'approval':False,'hold':'Generic inductor land; widths and local loops require current, thermal and EMI review'},indent=2))
print(target)
