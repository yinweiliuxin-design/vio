"""Explicit engineering fabrication capability assumptions, not fab approval."""
import json
from pathlib import Path

RULES={'min_clearance':.15,'min_track_width':.15,'min_via_diameter':.6,
       'min_through_hole_diameter':.3,'min_copper_edge_clearance':.25}
def configure(p,board,path,inherit=None):
    ds=board.GetDesignSettings()
    ds.m_MinClearance=p.FromMM(.15);ds.m_TrackMinWidth=p.FromMM(.15)
    ds.m_ViasMinSize=p.FromMM(.6);ds.m_MinThroughDrill=p.FromMM(.3)
    nc=ds.m_NetSettings.GetDefaultNetclass()
    nc.SetClearance(p.FromMM(.15));nc.SetTrackWidth(p.FromMM(.2));nc.SetViaDiameter(p.FromMM(.6));nc.SetViaDrill(p.FromMM(.3))
    project={'meta':{'filename':Path(path).with_suffix('.kicad_pro').name,'version':1},
             'board':{'design_settings':{'rules':RULES}},
             'net_settings':{'classes':[{'name':'Default','clearance':.15,'track_width':.2,'via_diameter':.6,'via_drill':.3}],
                             'netclass_assignments':{},'netclass_patterns':[]}}
    if inherit and Path(inherit).exists():
        previous=json.loads(Path(inherit).read_text())
        extra=[c for c in previous.get('net_settings',{}).get('classes',[]) if c['name']!='Default']
        project['net_settings']['classes'].extend(extra)
        project['net_settings']['netclass_patterns']=previous.get('net_settings',{}).get('netclass_patterns',[])
    Path(path).with_suffix('.kicad_pro').write_text(json.dumps(project,indent=2))
