"""Machine-readable native-board status; no inferred route or release passes."""
import collections
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:
    os.environ[name]=str(WORK/folder)
import pcbnew as p

sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
sourcefile=ROOT/'outputs/SmartVio-V25-Engineering/electrical/native-components.json'
source={c['ref']:c for c in json.loads(sourcefile.read_text(encoding='utf-8-sig'))}
review=json.loads((OUT/'final-292/footprint-review.json').read_text())
config=json.loads((WORK/'delivery-final-state.json').read_text())
nativeparityfile=OUT/'verification/current-native-parity.json'
nativeparity=json.loads(nativeparityfile.read_text())
assert nativeparity['sourceSHA256']==sha(sourcefile),'Final source changed after native parity'
nativeboards={q['kind']:q for q in nativeparity['boards']}
boards=[]
for item in config['boards']:
    path=OUT/item['board']
    b=p.LoadBoard(str(path.resolve()))
    fps=list(b.GetFootprints());tracks=list(b.GetTracks());zones=list(b.Zones())
    parity=[];actualrefs={f.GetReference() for f in fps}
    parts=source
    if item['kind']=='power':
        capture=json.loads((OUT/'power-prototype-components.json').read_text())
        parts={c['ref']:source.get(c['ref'],c) for c in capture}
    for f in fps:
        r=f.GetReference()
        if r not in parts:continue
        aliases=review.get(r,{}).get('pinAliases',{})
        pads={}
        for d in f.Pads():
            if d.GetNumber():pads.setdefault(d.GetNumber(),set()).add(d.GetNetname() or None)
        for pin in parts[r]['pins']:
            number=aliases.get(pin['number'],pin['number'])
            if pads.get(number)!={pin['net'] or None}:
                parity.append({'ref':r,'pin':number,'expected':pin['net'],'actual':sorted(pads.get(number,[]),key=str)})
    expected=set(parts) if item['kind']=='power' else {r for r,m in review.items() if r in source and m['board']==item['kind']}
    missing=sorted(expected-actualrefs)
    drcpath=OUT/item['drc'] if item.get('drc') else None
    drc=json.loads(drcpath.read_text()) if drcpath and drcpath.exists() else None
    camdir=OUT/item['camDir'] if item.get('camDir') else None
    cam=[{'path':str(f.resolve()),'relativePackPath':f.relative_to(OUT.parent).as_posix(),
          'relativeWorkspacePath':f.relative_to(ROOT).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size}
         for f in sorted(camdir.glob('*')) if f.is_file()] if camdir else []
    assert nativeboards[item['kind']]['boardSHA256']==sha(path),'Board changed since native parity'
    boards.append({**item,'boardPath':str(path.resolve()),'relativePackPath':path.relative_to(OUT.parent).as_posix(),
        'boardSHA256':sha(path),'sourceSHA256':sha(sourcefile),
        'footprints':len(fps),'tracks':sum(not isinstance(t,p.PCB_VIA) for t in tracks),
        'vias':sum(isinstance(t,p.PCB_VIA) for t in tracks),
        'zones':sum(not z.GetIsRuleArea() for z in zones),'ruleAreas':sum(z.GetIsRuleArea() for z in zones),
        'layers':b.GetCopperLayerCount(),'thicknessMm':p.ToMM(b.GetDesignSettings().GetBoardThickness()),
        'drc':({'reportPath':str(drcpath.resolve()),'reportSHA256':sha(drcpath),'version':drc['kicad_version'],
                'errors':sum(v['severity']=='error' for v in drc['violations']),
                'warnings':sum(v['severity']=='warning' for v in drc['violations']),
                'violationsByType':dict(collections.Counter(v['type'] for v in drc['violations'])),
                'ignoredChecks':drc['ignored_checks']} if drc else {'status':'NOT_RUN'}),
        'unconnected':len(drc['unconnected_items']) if drc else None,
        'unconnectedDetails':drc['unconnected_items'] if drc else [],
        'parity':{'method':'native physical pad numbers versus latest source with explicit EP aliases',
                  'differences':len(parity),'details':parity,'missingSourceRefsWithinBoard':missing,
                  'extraInterfaceRefs':sorted(actualrefs-set(parts)),
                  'nativeSchematicExportComparison':nativeboards[item['kind']],
                  'electricalApproved':False},
        'CAMExported':bool(cam),'CAMGatePassedForEngineeringReviewOnly':bool(cam),
        'CAM':cam,'productionApproved':False})
record={'generatedUTC':datetime.now(timezone.utc).isoformat(),'status':'ENGINEERING_CANDIDATE_HOLD',
    'sourcePath':str(sourcefile.resolve()),'sourceSHA256':sha(sourcefile),'sourceComponents':len(source),
    'sourcePins':sum(len(c['pins']) for c in source.values()),'sourceNets':len({q['net'] for c in source.values() for q in c['pins'] if q['net']}),
    'route_basis':config['routeBasisSourceSHA256'],
    'routeBasisScope':'Main final-292 bounded DSN only; retained original contracts are not overwritten. All delivered boards compared to actual current source.',
    'currentNativeParityPath':str(nativeparityfile.resolve()),'currentNativeParitySHA256':sha(nativeparityfile),
    'currentSourceVsSchematicPinNetDifferences':nativeparity['sourceExportPinNetDifferences'],
    'currentSourceVsSchematicReferenceDifferences':nativeparity['sourceExportReferenceDifferences'],
    'relativePackPathBase':'outputs/SmartVio-V25-Engineering (engineering package root)',
    'canonicalSummaryRelativePackPath':'pcb-work/verification/final-summary.json',
    'CAMIndexPath':str((OUT/'verification/CAM-index.json').resolve()),
    'CAMIndexRelativePackPath':'pcb-work/verification/CAM-index.json',
    'CAMIndexSHA256':sha(OUT/'verification/CAM-index.json'),
    'productionApproved':False,'boards':boards,'routingJobs':config.get('routingJobs',[]),
    'blockers':config['blockers'],'nextDeliverableStage':config['nextDeliverableStage'],
    'oldVersionsPreserved':True,'drcLimitsRelaxedToHideErrors':False,
    'allRulesPassClaimed':False,'ignoredCheckCategories':boards[0]['drc']['ignoredChecks'],
    'routerProcessesStillRunning':False,'frozenHandoff':True,
    'readmePath':str((OUT/'README-INTEGRATION.txt').resolve()),
    'controlsProtectionExactNextECO':str((OUT/'verification/controls-land-eco.json').resolve())}
encoded=json.dumps(record,indent=2)
(OUT/'final-summary.json').write_text(encoded)
(OUT/'verification/final-summary.json').write_text(encoded)
print(json.dumps({'file':str(OUT/'final-summary.json'),'boards':[{'kind':q['kind'],'unconnected':q['unconnected'],'drc':q['drc'].get('violationsByType'),'parityDifferences':q['parity']['differences']} for q in boards]},indent=2))
