"""Focused MON_BAT_ADC copper repair. Native KiCad DRC remains the acceptance gate."""
import argparse
import heapq
import json
import math
import os
from pathlib import Path
import shutil
import numpy as np
from PIL import Image, ImageDraw

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'documents')
os.environ['DOCUMENTS_HOME']=str(WORK/'documents')
import pcbnew as p

ap=argparse.ArgumentParser();ap.add_argument('--prepare-ntc',action='store_true');ap.add_argument('--prepare-power',action='store_true');args=ap.parse_args()
source=OUT/('SmartVio-power-prototype-unrouted.kicad_pcb' if args.prepare_ntc or args.prepare_power else 'SmartVio-power-prototype-routed-candidate.kicad_pcb')
dest=OUT/('SmartVio-power-prototype-power-seeded.kicad_pcb' if args.prepare_power else 'SmartVio-power-prototype-ntc-seeded.kicad_pcb' if args.prepare_ntc else 'SmartVio-power-prototype-repaired.kicad_pcb')
b=p.LoadBoard(str(source))
LAYERS=[p.F_Cu,p.In1_Cu,p.In2_Cu,p.B_Cu]
S=20; W=1161; H=761
point=lambda x,y:p.VECTOR2I(p.FromMM(x),p.FromMM(y))
xy=lambda q:(p.ToMM(q.x),p.ToMM(q.y))
report={'input':str(source),'output':str(dest),'signalWidthMm':.15,'clearanceMm':.15,'rasterSafetyMm':.01,'repairs':[]}
original_tracks=list(b.GetTracks())
for t in original_tracks:
    if t.GetNetname()=='MON_BAT_ADC':b.Remove(t)
    elif not isinstance(t,p.PCB_VIA) and t.GetWidth()<p.FromMM(.15):t.SetWidth(p.FromMM(.15))

def mask(net,extra):
    images=[Image.new('1',(W,H),0) for _ in LAYERS]
    draws=[ImageDraw.Draw(im) for im in images]
    for d in draws:
        d.rectangle((0,0,W-1,H-1),outline=1,width=math.ceil((.25+extra)*S))
    def circle(d,x,y,r):d.ellipse(((x-r)*S,(y-r)*S,(x+r)*S,(y+r)*S),fill=1)
    for t in b.GetTracks():
        if t.GetNetname()==net:continue
        x,y=xy(t.GetStart());xx,yy=xy(t.GetEnd())
        via=isinstance(t,p.PCB_VIA)
        r=p.ToMM(t.GetWidth(p.F_Cu) if via else t.GetWidth())/2+extra
        for layer,d in zip(LAYERS,draws):
            if not via and t.GetLayer()!=layer:continue
            d.line((x*S,y*S,xx*S,yy*S),fill=1,width=math.ceil(2*r*S))
            circle(d,x,y,r);circle(d,xx,yy,r)
    for f in b.GetFootprints():
        for pad in f.Pads():
            if pad.GetNetname()==net:continue
            x,y=xy(pad.GetPosition());ww=p.ToMM(pad.GetSize().x)/2+extra;hh=p.ToMM(pad.GetSize().y)/2+extra
            a=math.radians(pad.GetOrientationDegrees())
            pts=[((x+u*math.cos(a)+v*math.sin(a))*S,(y-u*math.sin(a)+v*math.cos(a))*S) for u,v in [(-ww,-hh),(ww,-hh),(ww,hh),(-ww,hh)]]
            for layer,d in zip(LAYERS,draws):
                if pad.IsOnLayer(layer):d.polygon(pts,fill=1)
    return np.stack([np.asarray(im,dtype=bool) for im in images])

def findpath(start,goal,net,width,start_layer=0,goal_layer=0):
    blocked=mask(net,.15+width/2+.01)
    via_blocked=np.any(mask(net,.15+.3+.01),axis=0)
    a=(start_layer,round(start[0]*S),round(start[1]*S));z=(goal_layer,round(goal[0]*S),round(goal[1]*S))
    if blocked[a[0],a[2],a[1]] or blocked[z[0],z[2],z[1]]:raise RuntimeError('Pad escape blocked: '+net)
    def heur(s):return math.hypot(s[1]-z[1],s[2]-z[2])+(30 if s[0]!=z[0] else 0)
    queue=[(heur(a),0,a)];cost={a:0};prev={};steps=0
    while queue:
        _,g,s=heapq.heappop(queue)
        if g!=cost[s]:continue
        if s==z:
            path=[s]
            while s in prev:s=prev[s];path.append(s)
            return list(reversed(path))
        layer,x,y=s;steps+=1
        nxt=[]
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
            xx,yy=x+dx,y+dy
            if not(0<=xx<W and 0<=yy<H) or blocked[layer,yy,xx]:continue
            if dx and dy and (blocked[layer,y,xx] or blocked[layer,yy,x]):continue
            nxt.append(((layer,xx,yy),math.hypot(dx,dy)))
        if not via_blocked[y,x]:
            nxt.extend(((l,x,y),45) for l in range(4) if l!=layer)
        for n,c in nxt:
            ng=g+c
            if ng<cost.get(n,float('inf')):
                cost[n]=ng;prev[n]=s;heapq.heappush(queue,(ng+heur(n),ng,n))
        if steps>1800000:raise RuntimeError('Search limit '+net)
    picture=np.where(blocked[0,:,:,None],np.array([160,30,30]),np.array([245,245,245])).astype('uint8')
    picture[via_blocked & ~blocked[0]]=[225,205,160]
    picture[a[2]-2:a[2]+3,a[1]-2:a[1]+3]=[20,20,220]
    Image.fromarray(picture).save(OUT/'verification'/('blocked-'+net+'.png'))
    raise RuntimeError('No safe path '+net+' reachable='+str(len(cost)))

def terminal(ref,num):
    f=next(f for f in b.GetFootprints() if f.GetReference()==ref)
    return next(d for d in f.Pads() if d.GetNumber()==num)

def route(ref1,num1,ref2,num2,goal=None,width=.15,start=None,start_layer=0,goal_layer=0):
    d=terminal(ref1,num1);net=d.GetNetname()
    if goal is None:
        end=terminal(ref2,num2);assert net==end.GetNetname();goal=xy(end.GetPosition())
    start=start or xy(d.GetPosition())
    path=findpath(start,goal,net,width,start_layer,goal_layer)
    simplified=[path[0]]
    for i in range(1,len(path)-1):
        u,v,w=path[i-1],path[i],path[i+1]
        if tuple(v[j]-u[j] for j in range(3))!=tuple(w[j]-v[j] for j in range(3)):simplified.append(v)
    simplified.append(path[-1])
    def track(a,z,layer):
        if a==z:return
        t=p.PCB_TRACK(b);t.SetStart(point(*a));t.SetEnd(point(*z));t.SetWidth(p.FromMM(width));t.SetLayer(layer);t.SetNetCode(d.GetNetCode());b.Add(t)
    track(start,(path[0][1]/S,path[0][2]/S),LAYERS[start_layer])
    for u,v in zip(simplified,simplified[1:]):
        aa=(u[1]/S,u[2]/S);zz=(v[1]/S,v[2]/S)
        if u[0]!=v[0]:
            via=p.PCB_VIA(b);via.SetPosition(point(*aa));via.SetWidth(p.FromMM(.6));via.SetDrill(p.FromMM(.3));via.SetLayerPair(p.F_Cu,p.B_Cu);via.SetViaType(p.VIATYPE_THROUGH);via.SetNetCode(d.GetNetCode());b.Add(via)
        else:track(aa,zz,LAYERS[u[0]])
    track((path[-1][1]/S,path[-1][2]/S),goal,LAYERS[goal_layer])
    record={'net':net,'from':ref1+'.'+num1,'to':ref2+'.'+num2,'waypoints':simplified}
    report['repairs'].append(record);print(json.dumps({k:v for k,v in record.items() if k!='waypoints'}),flush=True)

if args.prepare_power:
    route('U501','2','U501','3',width=.2)
    route('U501','3','C503','1',width=.2)
    route('C503','1','J501','1',width=.3)
    route('C503','1','R1705','1',width=.2)
    route('U501','1','J501','3',width=.2)
elif args.prepare_ntc:
    route('U501','1','J501','3',width=.2)
else:
    route('R1708','2','U1701','5')
    route('R1708','2','C1704','1')
    report['unresolved']=['PACK_NTC requires coordinated BQ24074 fanout rework; failed speculative repairs were not saved.']
p.SaveBoard(str(dest),b)
shutil.copyfile(source.with_suffix('.kicad_pro'),dest.with_suffix('.kicad_pro'))
(OUT/'verification'/('power-seed.json' if args.prepare_power else 'ntc-seed.json' if args.prepare_ntc else 'route-repairs.json')).write_text(json.dumps(report,indent=2))
print('Saved; native DRC required',flush=True)
