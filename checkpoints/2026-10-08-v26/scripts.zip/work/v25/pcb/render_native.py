"""Render directly inspected native pad and track geometry for visual QA."""
import argparse
import json
import math
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
parser=argparse.ArgumentParser();parser.add_argument('geometry',type=Path);args=parser.parse_args()
d=json.loads(args.geometry.read_text())
scale=18; margin=46;head=76;bw=round(d['width']*scale);bh=round(d['height']*scale)
img=Image.new('RGB',(2*bw+3*margin,bh+head+70),'#fafbfc');draw=ImageDraw.Draw(img)
font=lambda n:ImageFont.truetype('C:/Windows/Fonts/arial.ttf',n)
draw.text((margin,12),Path(d['file']).stem,fill='#111820',font=font(24))
draw.text((margin,42),'Native KiCad geometry | Tentative engineering candidate | No fabrication release',fill='#8e2424',font=font(16))
for k,side in enumerate(('F','B')):
    ox=margin+k*(bw+margin);oy=head
    xy=lambda x,y:(ox+x*scale,oy+y*scale)
    draw.rectangle([ox,oy,ox+bw,oy+bh],fill='#eff6f3',outline='#126246',width=2)
    if 'main-' in d['file'] and side=='F':
        draw.rectangle([xy(0,24.5),xy(72,39)],fill='#e0e2e3')
        draw.text(xy(1,36.7),'AUDIO PCB + PIN-TAIL VOLUME / NO TOP COMPONENTS',fill='#555d60',font=font(13))
    for t in d['tracks']:
        if t['layer'] not in ('F.Cu' if side=='F' else 'B.Cu',):continue
        a=xy(*t['start']);b=xy(*t['end']);color='#b84b47' if side=='F' else '#3469a8'
        if t['kind']=='via':
            rr=max(2,t['width']*scale/2);draw.ellipse((a[0]-rr,a[1]-rr,a[0]+rr,a[1]+rr),outline='#405f58',width=2)
        else:draw.line((a,b),fill=color,width=max(1,round(t['width']*scale)))
    for f in d['footprints']:
        if f['side']!=side:continue
        x0,y0,x1,y1=f['courtyard'];draw.rectangle([xy(x0,y0),xy(x1,y1)],outline='#717c79',width=1)
        for p in f['pads']:
            x,y=p['x'],p['y'];w,h=p['w'],p['h'];a=math.radians(p['angle'])
            corners=[xy(x+xx*math.cos(a)+yy*math.sin(a),y-xx*math.sin(a)+yy*math.cos(a)) for xx,yy in [(-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)]]
            draw.polygon(corners,fill='#d19d43')
        label=f['ref'];point=xy((x0+x1)/2,(y0+y1)/2)
        draw.text(point,label,fill='#162126',font=font(10 if label[0] in 'RC' else 12),anchor='mm',stroke_width=0)
    draw.text((ox,oy+bh+12),('TOP / F.Cu' if side=='F' else 'BOTTOM / B.Cu (top-view projection)')+f" | {d['width']:.1f} x {d['height']:.1f} mm",fill='#24332f',font=font(16))
path=OUT/'verification'/(args.geometry.stem.replace('-native','')+'.png')
img.save(path)
print(path)
