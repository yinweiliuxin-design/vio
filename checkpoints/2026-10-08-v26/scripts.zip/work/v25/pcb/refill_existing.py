"""Refill existing zones without changing pads, nets, placements or routing."""
import argparse
import os
from pathlib import Path
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:
    os.environ[name]=str(WORK/folder)
import pcbnew as p
ap=argparse.ArgumentParser();ap.add_argument('board',type=Path);a=ap.parse_args()
assert a.board.resolve().is_relative_to(OUT.resolve())
b=p.LoadBoard(str(a.board.resolve()))
b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones())
p.SaveBoard(str(a.board.resolve()),b)
print('Existing zones refilled:',a.board)
