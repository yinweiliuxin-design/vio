"""Small structured SPECCTRA S-expression reader preserving quoted atom spelling."""
import re

def loads(text):
    stack=[];root=None
    for token in re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^()\s]+',text):
        if token=='(':
            node=[]
            if stack:stack[-1].append(node)
            else:
                if root is not None:raise ValueError('multiple roots')
                root=node
            stack.append(node)
        elif token==')':
            if not stack:raise ValueError('unbalanced close')
            stack.pop()
        else:
            if not stack:raise ValueError('atom outside root')
            stack[-1].append(token)
    if stack:raise ValueError('unclosed list')
    return root

def dumps(node):
    return '('+' '.join(dumps(v) if isinstance(v,list) else v for v in node)+')'

def child(node,name):
    return next(v for v in node if isinstance(v,list) and v and v[0]==name)

def power_class(text,names,width_mm):
    tree=loads(text);network=child(tree,'network')
    classes=[v for v in network if isinstance(v,list) and v and v[0]=='class']
    present={v[1] for v in network if isinstance(v,list) and v and v[0]=='net'}
    chosen=[n for n in names if n in present]
    for cls in classes:
        cls[:]=[v for v in cls if isinstance(v,list) or v not in chosen]
    circuit=child(classes[0],'circuit')
    network.append(['class','kicad_Power',*chosen,circuit,['rule',['width',str(round(width_mm*1000))],['clearance','150']]])
    encoded=dumps(tree)+'\n'
    checked=loads(encoded)
    routed=next(v for v in child(checked,'network') if isinstance(v,list) and v[:2]==['class','kicad_Power'])
    assert child(child(routed,'rule'),'width')[1]==str(round(width_mm*1000))
    return encoded,chosen
