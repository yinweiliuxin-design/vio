"""Explicit USB4120 A6 physical-land correction, without changing pin nets."""
import hashlib
import json
import os
from pathlib import Path
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2];OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
from process_rules import configure
src=OUT/'SmartVio-usb-delivery-HOLD.kicad_pcb';dst=OUT/'SmartVio-usb-manufacturer-land-HOLD.kicad_pcb'
lib=ROOT/'outputs/SmartVio-V25-Engineering/audit/audio/footprints/SmartVio_Audio_Official.pretty'
name='GCT_USB4120_Official_A6'
b=p.LoadBoard(str(src));old=next(f for f in b.GetFootprints() if f.GetReference()=='J401')
padnets={d.GetNumber():d.GetNetname() for d in old.Pads() if d.GetNumber()}
new=p.FootprintLoad(str(lib),name);new.SetFPID(p.LIB_ID('SmartVioV25',name))
p.FootprintSave(str(OUT/'SmartVioV25.pretty'),new)
new.SetReference(old.GetReference());new.SetValue(old.GetValue());new.SetPosition(old.GetPosition());new.SetOrientation(old.GetOrientation())
assert not old.IsFlipped()
for d in new.Pads():
    net=padnets.get(d.GetNumber())
    if net:d.SetNet(b.FindNet(net))
new.Reference().SetVisible(False);new.Value().SetVisible(False)
new.SetField('MPN','USB4120-03-C');new.GetField('MPN').SetVisible(False)
assert {d.GetNumber():d.GetNetname() for d in new.Pads() if d.GetNumber()}==padnets
b.Remove(old);b.Add(new);b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones())
configure(p,b,dst,src.with_suffix('.kicad_pro'));p.SaveBoard(str(dst),b)
record={'oldBoard':str(src),'newBoard':str(dst),'padsNetsUnchanged':True,'boardPositionUnchanged':True,
    'physicalChanges':['Right locating NPTH round0.52 -> oval0.72x0.52mm',
        'Contacts1.10 ->0.87mm long and rows+/-0.870 ->+/-0.865mm',
        'Shield copper rounded rectangles -> official oval pads; centres, copper dimensions and slots unchanged',
        'Official courtyard +/-5.0,+/-2.95mm'],
    'priorBoardPreserved':True,'productionApproved':False,'nativeDRC':'REQUIRED',
    'source':'GCT USB4120 drawing A6 recommended PCB land, audio audit transcription'}
(OUT/'verification/usb-land-update.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
