"""Portable, hash-verified engineering CAM inventory with native drill cross-check."""
import hashlib
import json
from pathlib import Path
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
state=json.loads((WORK/'delivery-final-state.json').read_text())
index={'productionApproved':False,'status':'ENGINEERING_REVIEW_HOLD',
       'relativePackPathBase':'outputs/SmartVio-V25-Engineering (engineering package root)',
       'boards':[],'noCAMBoards':[]}
for item in state['boards']:
    if not item.get('camDir'):
        index['noCAMBoards'].append({'kind':item['kind'],'status':item['status'],'reason':item['blockers']})
        continue
    camdir=OUT/item['camDir'];manifestpath=camdir/'CAM-manifest.json'
    manifest=json.loads(manifestpath.read_text())
    board=OUT/item['board'];drcpath=OUT/item['drc']
    assert manifest['boardSHA256']==sha(board)
    assert manifest['nativeDRCSHA256']==sha(drcpath)
    for rec in manifest['CAM']:
        path=Path(rec['path'])
        assert sha(path)==rec['sha256'] and path.stat().st_size==rec['bytes']
        rec['relativePackPath']=path.relative_to(OUT.parent).as_posix()
        rec['relativeWorkspacePath']=path.relative_to(ROOT).as_posix()
    pth=next(camdir.glob('*-PTH.drl'));npth=next(camdir.glob('*-NPTH.drl'))
    # KiCad exports explicit X/Y lines for every drill hit; no routing slots here.
    hits=lambda f:sum(line.startswith('X') and 'Y' in line for line in f.read_text().splitlines())
    plated=hits(pth);unplated=hits(npth)
    assert plated==manifest['vias'] and unplated==0
    manifest.update({'relativePackPathBase':index['relativePackPathBase'],
        'boardRelativePackPath':board.relative_to(OUT.parent).as_posix(),
        'nativeDRCRelativePackPath':drcpath.relative_to(OUT.parent).as_posix(),
        'drillNativeCrossCheck':{'platedHitCount':plated,'unplatedHitCount':unplated,
             'nativeVias':manifest['vias'],'match':True,'scope':'These boards have no footprint through-holes'}})
    manifestpath.write_text(json.dumps(manifest,indent=2))
    files=[{'path':str(f.resolve()),'relativePackPath':f.relative_to(OUT.parent).as_posix(),
            'relativeWorkspacePath':f.relative_to(ROOT).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)}
           for f in sorted(camdir.glob('*')) if f.is_file()]
    index['boards'].append({'kind':item['kind'],'boardPath':str(board.resolve()),
        'boardRelativePackPath':board.relative_to(OUT.parent).as_posix(),'boardSHA256':sha(board),
        'manifestRelativePackPath':manifestpath.relative_to(OUT.parent).as_posix(),
        'manifestSHA256':sha(manifestpath),'files':files,'drillNativeCrossCheck':manifest['drillNativeCrossCheck'],
        'productionApproved':False,'ignoredChecks':manifest['ignoredChecks']})
(OUT/'verification/CAM-index.json').write_text(json.dumps(index,indent=2))
print(json.dumps({'CAMBoards':[{'kind':b['kind'],'files':len(b['files']),'drill':b['drillNativeCrossCheck']} for b in index['boards']],
                  'noCAMBoards':[b['kind'] for b in index['noCAMBoards']]},indent=2))
