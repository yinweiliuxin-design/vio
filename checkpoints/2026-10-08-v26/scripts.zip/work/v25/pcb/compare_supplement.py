"""Compare new catalog evidence without replacing any routed pad geometry."""
import hashlib
import json
import os
from pathlib import Path
WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[2];OUT=ROOT/'outputs/SmartVio-V25-Engineering/pcb-work'
for name,folder in [('KICAD_CONFIG_HOME','config'),('KICAD_DOCUMENTS_HOME','documents'),('DOCUMENTS_HOME','documents')]:os.environ[name]=str(WORK/folder)
import pcbnew as p
local=OUT/'SmartVioV25.pretty'
official=ROOT/'outputs/SmartVio-V25-Engineering/audit/audio/footprints/SmartVio_Audio_Official.pretty'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def pads(fp):
    return sorted([{'number':d.GetNumber(),'x':p.ToMM(d.GetPosition().x),'y':p.ToMM(d.GetPosition().y),
        'w':p.ToMM(d.GetSize().x),'h':p.ToMM(d.GetSize().y),'shape':int(d.GetShape()),
        'roundRectRadiusMm':p.ToMM(d.GetRoundRectCornerRadius()) if d.GetShape()==p.PAD_SHAPE_ROUNDRECT else 0} for d in fp.Pads()],key=lambda q:q['number'])
stock='Panasonic_APV-AQY_SSOP-4_4.45x2.65mm_P1.27mm';reviewed='Panasonic_SSOP4_PhotoMOS_Official'
a=pads(p.FootprintLoad(str(local),stock));z=pads(p.FootprintLoad(str(official),reviewed))
keys=['number','x','y','w','h']
same=all(all(u[k]==v[k] for k in keys) for u,v in zip(a,z)) and len(a)==len(z)
record={'productionApproved':False,'sourceNativeSHA256':sha(ROOT/'outputs/SmartVio-V25-Engineering/electrical/native-components.json'),
    'Q1201':{'selectedCandidateMPN':'PMV30UN2R','footprint':'SmartVioV25:SOT-23',
        'pins':{'1':'G/SSR_GATE','2':'S/GND','3':'D/SSR_SINK'},
        'existingPads':pads(p.FootprintLoad(str(local),'SOT-23')),
        'geometryChangeApplied':False,'comparedManufacturerFigure':'PMV30UN2.pdf page11 Figure19, 24 April 2014',
        'note':'Existing generic KiCad SOT23 retained. Numbered pins and 1.9mm pair pitch match package; generic extended pads are not an exact Fig19 land transcription. Reflow land, mask and paste approval remains HOLD.',
        'evidence':'https://assets.nexperia.com/documents/data-sheet/PMV30UN2.pdf'},
    'K1201..K1207':{'existingLibrarySHA256':sha(local/(stock+'.kicad_mod')),'officialLibrarySHA256':sha(official/(reviewed+'.kicad_mod')),
        'existingPads':a,'officialPads':z,'padNumbersCentersSizesIdentical':same,'exactCopperGeometryIdentical':a==z,
        'geometryChangeApplied':False,'routedStockFootprintRetained':True,
        'difference':'Official rectangles versus stock roundrect radius 0.175mm; courtyard also differs. No silent footprint replacement.',
        'release':'HOLD_PAD_CORNER_MASK_PASTE_ASSEMBLY_REVIEW'}}
assert same
(OUT/'verification/supplemental-footprint-comparison.json').write_text(json.dumps(record,indent=2))
print(json.dumps({'SSRcentersSizesMatch':same,'SSRexactCopperMatch':a==z,'QgeometryChanged':False,'productionApproved':False}))
