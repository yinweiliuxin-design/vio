import os
from pathlib import Path

WORK = Path(__file__).resolve().parent
os.environ['KICAD_CONFIG_HOME'] = str(WORK / 'config')
os.environ['KICAD_DOCUMENTS_HOME'] = str(WORK / 'documents')
os.environ['DOCUMENTS_HOME'] = str(WORK / 'documents')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
for folder in ('config', 'documents'):
    (WORK / folder).mkdir(exist_ok=True)
import pcbnew as p

print(p.GetBuildVersion())
print('DSN:', p.ExportSpecctraDSN.__doc__)
print('SES:', p.ImportSpecctraSES.__doc__)
print('Footprint:', [n for n in dir(p.FOOTPRINT) if any(s in n for s in ('Courtyard','Bounding','Flip','Property','Attributes'))])
print('Zone:', [n for n in dir(p.ZONE) if any(s in n for s in ('Keepout','RuleArea','Allowed','Disallowed','Outline'))])
