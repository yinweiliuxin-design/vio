"""Native capture of proposed internal solder endpoints, separate from product ports."""
import importlib.util
import json
from pathlib import Path

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V25-Engineering'
OUT=ROOT/'assembly'
OUT.mkdir(exist_ok=True)
links=json.loads((ROOT/'pcb-work/proposed-harness.json').read_text())
mapping=json.loads((ROOT/'pcb-work/footprint-review.json').read_text())
spec=importlib.util.spec_from_file_location('cap_harness',ROOT/'reproduce/capture_library.py')
lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
lib.mapping={r:{'id':m['footprint']} for r,m in mapping.items() if 'footprint' in m}
parts=[];wires=[]
for cable in links:
    a,b=cable['pair']
    for ref in (a,b):
        parts.append({'ref':ref,'type':'J','value':'INTERNAL SOLDER ENDPOINT / NOT DOCK / HOLD',
          'mpn':None,'pins':[{'number':str(n),'name':net,'net':net} for n,net in cable['pins'].items()]})
    for num,net in cable['pins'].items():
        if net.startswith('USB_D') and net.endswith('_MCU'):
            category='USB differential pair; route DM/DP together, qualify impedance/return path and assembled cable'
        elif net in ('SPK_P','SPK_N'):
            category='BTL speaker pair; neither conductor may be grounded'
        elif net in ('VBUS_RAW','USB_5V_SAFE','V3D'):
            category='Power rail; current/temperature and short protection determine final wire gauge'
        elif any(x in net for x in ('HP_','LINE_','RETURN_','SEND_')):
            category='Analog audio; shielding/ground and crosstalk qualification required'
        else:category='Control/reference; independent from high-current speaker switching path'
        wires.append({'fromRef':a,'fromPad':str(num),'toRef':b,'toPad':str(num),'net':net,
          'routingClass':category,'wireMpn':None,'cutLengthMm':None,'stripLengthMm':None,
          'assemblyStatus':'PROPOSAL_NOT_RELEASED','wireGauge':'TBD from current and final harness design'})
project='Interconnect'
(OUT/'Interconnect.kicad_sch').write_text(lib.capture('Interconnect',parts,'V25 INTERNAL INTERCONNECT / HOLD',lib.uid('Interconnect'),project=project),encoding='utf-8')
(OUT/'Interconnect.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "smartvio_interconnect")\n'+''.join(lib.library(c,False) for c in parts)+')',encoding='utf-8')
(OUT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "SmartVio") (type "KiCad") (uri "${KIPRJMOD}/Interconnect.kicad_sym") (options "") (descr "Internal wiring candidate")))',encoding='utf-8')
(OUT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "SmartVioV25") (type "KiCad") (uri "${KIPRJMOD}/../pcb-work/SmartVioV25.pretty") (options "") (descr "Candidate solder endpoints")))',encoding='utf-8')
(OUT/'Interconnect.kicad_pro').write_text(json.dumps({'meta':{'filename':'Interconnect.kicad_pro','version':1},'erc':{'erc_exclusions':[]}},indent=2),encoding='utf-8')
checks=[]
for cable in links:
    pins=cable['pins']
    dm=[int(k) for k,v in pins.items() if v=='USB_DM_MCU']
    dp=[int(k) for k,v in pins.items() if v=='USB_DP_MCU']
    if dm or dp:checks.append({'pair':cable['pair'],'usbAdjacent':bool(dm and dp and abs(dm[0]-dp[0])==1)})
record={'endpointCount':len(parts),'wireCount':len(wires),'proposedPairs':links,'wireSchedule':wires,
        'checks':checks,'allUsbPairsAdjacent':bool(checks) and all(c['usbAdjacent'] for c in checks),
        'manufacturingRelease':False,'interpretation':'Assembly-level proposal, not additional external ports. Length/gauge/strain relief and solder process not frozen.'}
(OUT/'interconnect.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k not in ('proposedPairs','wireSchedule')},ensure_ascii=False))
