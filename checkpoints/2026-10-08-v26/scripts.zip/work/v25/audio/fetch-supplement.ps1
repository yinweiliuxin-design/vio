$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$destination = Join-Path $root 'outputs/SmartVio-V25-Engineering/audit/audio/sources'
$sources = [ordered]@{
  PMV30UN2 = 'https://assets.nexperia.com/documents/data-sheet/PMV30UN2.pdf'
  Nexperia_2N7002 = 'https://assets.nexperia.com/documents/data-sheet/2N7002.pdf'
  GCT_USB4120 = 'https://gct.co/files/drawings/usb4120.pdf'
  PUI_AS01808AO_SC18_WP_R = 'https://puiaudio.com/file/specs-AS01808AO-SC18-WP-R.pdf'
  Lumberg1503_18_current = 'https://downloads.lumberg.com/datenblaetter/en/1503_18.pdf'
}
$records = foreach ($item in $sources.GetEnumerator()) {
  $path = Join-Path $destination ($item.Key + '.pdf')
  try {
    Invoke-WebRequest -UseBasicParsing -Uri $item.Value -OutFile $path -TimeoutSec 45
    [ordered]@{id=$item.Key;url=$item.Value;file=('sources/'+$item.Key+'.pdf');sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();bytes=(Get-Item -LiteralPath $path).Length;retrievedAtUtc=[DateTime]::UtcNow.ToString('o');status='downloaded';publisherOrigin='official_manufacturer'}
  } catch {
    [ordered]@{id=$item.Key;url=$item.Value;status='failed';error=$_.Exception.Message}
  }
}
$records | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 (Join-Path $destination '../supplemental-source-manifest.json')
$records | ConvertTo-Json -Depth 6
