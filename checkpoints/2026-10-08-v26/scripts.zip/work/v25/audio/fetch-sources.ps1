$ErrorActionPreference = 'Stop'
$destination = Join-Path $PSScriptRoot '../../../outputs/SmartVio-V25-Engineering/audit/audio/sources'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
$sources = [ordered]@{
    TLV9064 = 'https://www.ti.com/lit/ds/symlink/tlv9064.pdf'
    TPA6132A2 = 'https://www.ti.com/lit/ds/symlink/tpa6132a2.pdf'
    PCM1864 = 'https://www.ti.com/lit/ds/symlink/pcm1864.pdf'
    PCM5102A = 'https://www.ti.com/lit/ds/symlink/pcm5102a.pdf'
    USBLC6_2 = 'https://www.st.com/resource/en/datasheet/usblc6-2.pdf'
    Lumberg1503_18 = 'https://downloads.lumberg.com/datenblaetter/en/1503_18.pdf'
    TPD2S300 = 'https://www.ti.com/lit/ds/symlink/tpd2s300.pdf'
    TPD2S703_Q1 = 'https://www.ti.com/lit/ds/symlink/tpd2s703-q1.pdf'
    MAX98357A = 'https://www.analog.com/media/en/technical-documentation/data-sheets/max98357a-max98357b.pdf'
}
$records = foreach ($item in $sources.GetEnumerator()) {
    $path = Join-Path $destination ($item.Key + '.pdf')
    try {
        Invoke-WebRequest -Uri $item.Value -OutFile $path -TimeoutSec 45
        [ordered]@{id=$item.Key;url=$item.Value;file=('sources/'+$item.Key+'.pdf');sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower();bytes=(Get-Item -LiteralPath $path).Length;retrievedAtUtc=[DateTime]::UtcNow.ToString('o');status='downloaded'}
    } catch {
        [ordered]@{id=$item.Key;url=$item.Value;status='failed';error=$_.Exception.Message}
    }
}
$records | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 (Join-Path $destination '../source-manifest.json')
$records | ConvertTo-Json -Depth 5
