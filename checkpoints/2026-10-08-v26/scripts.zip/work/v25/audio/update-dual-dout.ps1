$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$out = Join-Path $root 'outputs/SmartVio-V25-Engineering/audit/audio'
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Read-Json([string]$p) { Get-Content -LiteralPath $p -Raw | ConvertFrom-Json }
function Write-Json([string]$p, $v) { [IO.File]::WriteAllText($p, (ConvertTo-Json -InputObject $v -Depth 100) + "`n", $utf8) }
function Field($v, [string]$k, $x) { $v | Add-Member -NotePropertyName $k -NotePropertyValue $x -Force }
function Hash([string]$p) { (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() }
$name = 'pcm1864-dual-dout-contract.json'
$dual = Read-Json (Join-Path $out $name)
foreach($s in $dual.sources) { if ((Hash (Join-Path $out $s.file)) -ne $s.sha256) { throw "Source hash mismatch: $($s.id)" } }

$srcPath = Join-Path $out 'source-manifest.json'
$sources = Read-Json $srcPath
$rm = $dual.sources | Where-Object id -eq 'ST_RM0433'
$info = Get-Item -LiteralPath (Join-Path $out $rm.file)
$sources = @($sources | Where-Object id -ne $rm.id) + @([ordered]@{id=$rm.id;url=$rm.url;file=$rm.file;sha256=$rm.sha256;bytes=$info.Length;retrievedAtUtc=$info.LastWriteTimeUtc.ToString('o');timestampBasis='download file modification time';revision=$rm.revision;status='downloaded';publisherOrigin='official_manufacturer'})
Write-Json $srcPath $sources

$mergePath = Join-Path $out 'integration-contract.json'
$merge = Read-Json $mergePath
$native = Read-Json (Join-Path $root $merge.baseInput.file)
if ($native.ref -contains 'R691') { throw 'R691 collides with baseline' }
if (($native | Where-Object ref -eq 'U801').pins.Where({$_.number -eq '2'}).net) { throw 'MCU pin2 already assigned in baseline' }
$recordsPath = Join-Path $out 'corrected-components.json'
$records = Read-Json $recordsPath
$adc = $records | Where-Object ref -eq 'U601'
$pin = $adc.pins | Where-Object number -eq '21'
if ($pin.net -and $pin.net -ne 'ADC_DATA2_SRC') { throw 'Unexpected U601 pin21 net' }
$pin.net = 'ADC_DATA2_SRC'
$pin.PSObject.Properties.Remove('noConnectReason')
$pin.PSObject.Properties.Remove('intentionalNoConnect')
Field $pin 'configuredFunction' 'DOUT2, normal polarity, p0.0x10[6:4]=101'
Field $pin 'configuredElectricalType' 'output'
Field $pin 'authorizedNetChange' ([ordered]@{oldNet=$null;newNet='ADC_DATA2_SRC';status='AUTHORIZED_UNROUTED';contract=$name})
Field $pin 'functionEvidence' ([ordered]@{sourceId='PCM1864';pdfPages=@(58,98);section='9.3.16.3;Table42 GPIO1_FUNC';sha256=$dual.sources[0].sha256;url=$dual.sources[0].url})
Field $adc 'digitalInterfaceAudit' ([ordered]@{status=$dual.status;contract=$name;dataLanes=2;bitsPerFramePerLane=64;slotWidthBits=32;slotsPerLane=2;activeAnalogChannels=3;fourthChannel='muted';clockSource='24.576MHz SCKI512fs auto';timing='positive analytical residuals; board SI and measurement pending';hardware='UNROUTED'})
Write-Json $recordsPath $records

$delta = [ordered]@{
    schemaVersion='SmartVio.audio.authorized-net-delta.v1';contract=$name;status='LOGICAL_DESIGN_ONLY_UNROUTED'
    ownedPinChanges=@([ordered]@{ref='U601';pin='21';expectedOldNet=$null;newNet='ADC_DATA2_SRC';removeNoConnect=$true;function='GPIO1_DOUT2';footprintPadUnchanged='21'})
    parentPinChanges=@([ordered]@{ref='U801';pin='2';expectedOldNet=$null;newNet='ADC_DATA2';name='PE3_SAI1_SD_B';alternateFunction=6;electricalType='input';removeNoConnect=$true;manufacturerName='PE3';source='STM32H743';pdfPages=@(55,64,94);sha256=$dual.sources[1].sha256})
    addComponentsFile='additional-components.json';addRefs=@('R691');removeRefs=@();newNets=@('ADC_DATA2_SRC','ADC_DATA2')
    atomicMerge='Replace U601 and patch U801.2 plus add R691 together. Clear both NC markers. Recheck R691/PE3 allocation in latest parent state. Never label an unrouted two-pin net physically complete.'
}
Write-Json (Join-Path $out 'authorized-net-deltas.json') $delta

$rows = Import-Csv -LiteralPath (Join-Path $out 'per-pin-audit.csv')
$row = $rows | Where-Object { $_.ref -eq 'U601' -and $_.number -eq '21' }
$row.net='ADC_DATA2_SRC'; $row.ncReason=''; $row.status='VERIFIED_PIN_AUTHORIZED_DOUT2_UNROUTED'; $row.pdfPages='11;58;98'; $row.section='GPIO1 physicalpin21;9.3.16.3/Table42 DOUT2'
$rows | Export-Csv -LiteralPath (Join-Path $out 'per-pin-audit.csv') -NoTypeInformation -Encoding utf8

$newAction = 'Active candidate is dual-DOUT stereo I2S, NOT TDM: 48kHz,64bits/lane,2x32-bit slots/lane,BCLK3.072MHz,SCKI24.576MHz512fs auto. DOUT1 carriespickup/AUX-L; GPIO1pin21 DOUT2 carriesAUX-R/mutedfourth via newR69133R toPE3pin2AF6. Explicit identity mixer and exact registers are in pcm1864-dual-dout-contract.json. Preserve HP_DETECT and DAC/bias mute sequencing. Positive analytical timing residuals are conditional on board/firmware qualification; hardware is UNROUTED.'
$finding = [ordered]@{
    id='AUD-012';severity='P1';refs=@('U601','U801','R691');title='Feature-preserving dual-DOUT I2S corrective design'
    status='SUPPORTED_DESIGN_UNROUTED_INTEGRATION_AND_EVT_HOLD'
    observation='Official9.3.16.3/GPIO1mux and identity mixer support two stereo lanes while retaining3inputs/4channels. PE3 LQFP100pin2 AF6 supports SAI1_SD_B; RM0433 supports A masterRX and synchronousB slaveRX. At3.072MHz the nominal halfcycle is162.760ns; conservative analytical FSsetup residual92.760ns and data setup residuals122.260ns(A)/121.760ns(B), before board/skew/jitter terms. No measured pass claimed.'
    requiredAction='Apply authorized-net-deltas.json atomically with additional-components.json and current U601 record. Replace activeTDM firmware/capture notes with this dual-lane contract; preserve historicalTDM findings but do not program them. Route and qualify R691/lane2, clocks, coefficient readback, DMA alignment and fullboard before release.'
    contract=$name
    evidence=@([ordered]@{sourceId='PCM1864';pdfPages=@(11,19,41,54,58,68,69,95,98,106,125,127,129,130,131);url=$dual.sources[0].url;sha256=$dual.sources[0].sha256},[ordered]@{sourceId='STM32H743';pdfPages=@(55,64,94,194,305,306,307);url=$dual.sources[1].url;sha256=$dual.sources[1].sha256},[ordered]@{sourceId='ST_RM0433';pdfPages=@(2241,2242);section='51.4.4';url=$rm.url;sha256=$rm.sha256})
}
foreach ($p in @((Join-Path $PSScriptRoot 'audit-data.json'), (Join-Path $out 'findings-and-required-changes.json'))) {
    $data=Read-Json $p
    $f=$data.findings | Where-Object id -eq 'AUD-006'
    $f.requiredAction=$newAction; $f.PSObject.Properties.Remove('tdmContract'); Field $f 'digitalInterfaceContract' $name
    $old=$data.findings | Where-Object id -eq 'AUD-011'
    $old.status='SUPERSEDED_ACTIVE_DESIGN_BY_AUD012_HISTORICAL_TDM_HOLD'
    $old.requiredAction='Do not implement the old TDM candidate. Its timing/1024fs problems remain valid historical findings; the authorized dual-DOUT design in AUD-012 replaces it without deleting any input.'
    Field $old 'supersededBy' 'AUD-012'
    $data.findings=@($data.findings | Where-Object id -ne 'AUD-012') + @($finding)
    $change=$data.requiredChanges | Where-Object id -eq 'CHANGE-A07'
    $change.requirements=@($change.requirements | ForEach-Object {if ($_ -match '^PCM1864') {'PCM1864 dual-DOUT I2S:2lanes x2slots x32bits,48kHz,3.072MHzBCLK,24.576MHzSCKI; explicit identity matrix; fourthmute; synchronizedDMA. NoTDM.'}else{$_}})
    $data.requiredChanges=@($data.requiredChanges | Where-Object id -ne 'CHANGE-A08') + @([ordered]@{id='CHANGE-A08';action='add_internal_DOUT2_lane';refs=@('U601','R691','U801');status='AUTHORIZED_UNROUTED';contract=$name;netDeltas='authorized-net-deltas.json';additionalComponents='additional-components.json';removeComponents=@()})
    Write-Json $p $data
}

$merge.mergePolicy='Replace ONLY13 audio-owned refs. Preserve original nets except the explicitly authorized U601.21 NC->ADC_DATA2_SRC delta. Parent atomically patches U801.2 and addsR691 from separate records. No user function removed; rebase by ref if parent inputs changed.'
$merge.PSObject.Properties.Remove('adcTdmContract')
Field $merge 'adcInterfaceContract' $name
Field $merge 'supersededAdcInterfaceContract' 'pcm1864-tdm-contract.json'
Field $merge 'authorizedNetDeltas' 'authorized-net-deltas.json'
Field $merge 'additionalComponents' 'additional-components.json'
Field $merge 'adcClockRelease' 'SUPPORTED512FS_AUTO_CANDIDATE_UNROUTED_SI_FIRMWARE_EVT_HOLD'
Write-Json $mergePath $merge

$oldPath=Join-Path $out 'pcm1864-tdm-contract.json'
$old=Read-Json $oldPath
Field $old 'activeCandidate' $false
Field $old 'supersededBy' $name
Field $old 'historicalStatus' $old.status
$old.status='SUPERSEDED_NOT_FOR_IMPLEMENTATION'
Write-Json $oldPath $old

$opsPath=Join-Path $out 'parent-change-instructions.json'
$ops=Read-Json $opsPath
($ops.operations | Where-Object operation -eq 'replace_records_by_ref').notes='Preserve all pre-existing logical nets except U601.21 now assignedADC_DATA2_SRC by authorized dual-DOUT fix. Integrate matchingR691 and U801.2 targeted patch atomically; do not overwrite non-owned MCU records.'
$ops.operations=@($ops.operations | Where-Object { $_.operation -notin @('replace_pcm1864_candidate_clock_contract','integrate_dual_dout_corrective_design') }) + @([ordered]@{
    operation='integrate_dual_dout_corrective_design';status='AUTHORIZED_LOGICAL_FIX_UNROUTED';contract=$name
    patchFile='authorized-net-deltas.json';addComponentsFile='additional-components.json';addRefs=@('R691');removeRefs=@();targetSheet='A15';createNewSheet=$false
    actions=@('Replace U601 record with pin21 DOUT2 net assigned; clear NC marker','AddR691 pin1=ADC_DATA2_SRC pin2=ADC_DATA2, at U601 source','Patch only U801.2 PE3 AF6 to ADC_DATA2 input; clear NC marker','Retain existing DOUT1 and all analog inputs','Replace active TDM notes/clock contracts with dual64-bit stereo I2S lane contract','Implement and verify explicit identity mixer, auto512fs clocks and synchronizedA/B DMA','Keep PCB routing, exact resistorMPN/footprint, SI, targetfirmware and EVT pending; no production release')
})
$ops.assertionsAfterMerge=@($ops.assertionsAfterMerge | Where-Object {$_ -notmatch 'U601.21|R691|dual-DOUT'}) + @('U601.21 to R691.1 and R691.2 to U801.2 are separate two-pin nets with no NC markers.','Dual-DOUT preserves pickup/AUX-L/AUX-R plus muted fourth; no TDM initializer remains active.','Hardware remains UNROUTED until parent PCB work completes and is verified.')
Write-Json $opsPath $ops

$qaPath=Join-Path $out 'verification/audit-validation-summary.json'
$qa=Read-Json $qaPath
$qa.logicalNetsPreservedForEveryOwnedPin=$false
Field $qa 'originalFunctionalNetsPreserved' $true
Field $qa 'authorizedOwnedPinNetChanges' @('U601.21 NC -> ADC_DATA2_SRC')
Field $qa 'additionalComponentProvisions' @('R691')
$qa.manufacturerPdfsHashed=$sources.Count
$qa.criticalHolds=@($qa.criticalHolds | Where-Object {$_ -ne 'PCM1864 manual1024fs and FSYNC/DOUT timing'}) + @('Dual-DOUT new lane UNROUTED; passiveMPN, SI/timing, synchronizedDMA, mixerreadback andEVT pending')
Field $qa 'pcm1864ActiveInterface' $name
Field $qa 'pcm1864AnalyticalTimingPositiveBeforeBoardTerms' $true
Field $qa 'pcm1864FrameArithmeticVerified' $true
Field $qa 'pcm1864ClockAndTimingRelease' $false
Write-Json $qaPath $qa

$reportPath=Join-Path $out 'AUDIT-REPORT.txt'
$report=[IO.File]::ReadAllText($reportPath)
$report=$report -replace '(?m)^Action: Firmware candidate.*$', ('Action: ' + $newAction)
$report=$report.Replace('Sources: 13 manufacturer PDF files','Sources: 14 manufacturer PDF files')
$report=$report.Replace('13 owned records / 157 pins; all logical nets preserved; 13 official PDFs hashed.','13 owned records / 157 pins; all original functional nets preserved, plus authorized U601.21 NC-to-DOUT2 connection; R691 supplied separately.14 official PDFs hashed.')
$marker="`nActive corrective design (AUD-012):"
if ($report.Contains($marker)) { $report=$report.Substring(0,$report.IndexOf($marker)) }
$report += $marker+"`n"+$finding.observation+"`n"+$newAction+"`n"+'U601.21 ADC_DATA2_SRC -> R69133R -> ADC_DATA2 -> U801.2 PE3AF6. Historical AUD-011/TDM is superseded, not approved. Parent instructions and net deltas are explicit; no parent native/PCB files edited by this worker.'+"`n"
[IO.File]::WriteAllText($reportPath,$report,$utf8)

# Validate the exact scope: one newly assigned owned pin, no alteration of any existing signal net.
$changes=@()
foreach($c in $records){
    $n=$native | Where-Object ref -eq $c.ref
    foreach($p in $c.pins){
        $nnum=if($p.legacyPinNumber){$p.legacyPinNumber}else{$p.number}
        $op=$n.pins | Where-Object number -eq $nnum
        if($op.net -ne $p.net){$changes += "$($c.ref).$($p.number):$($op.net)->$($p.net)"}
        if($null -eq $p.net -and -not $p.noConnectReason){throw "MissingNC reason: $($c.ref).$($p.number)"}
    }
}
if($changes.Count -ne 1 -or $changes[0] -ne 'U601.21:->ADC_DATA2_SRC'){throw "Unexpected net delta: $changes"}
if($records.Count -ne 13){throw 'Ownedrecord count changed'}
if($dual.serial.sampleRateHz*$dual.serial.bitsPerFramePerLane -ne $dual.serial.BCLK_Hz){throw 'I2S clock arithmetic'}
if($dual.serial.sampleRateHz*$dual.serial.SCKI_to_Fs -ne $dual.serial.SCKI_Hz){throw 'SCKI arithmetic'}
$add=Read-Json (Join-Path $out 'additional-components.json')
if($add.Count -ne 1 -or $add[0].ref -ne 'R691'){throw 'Unexpected added components'}
$budget=$dual.analyticalTiming
$half=1e9/$dual.serial.BCLK_Hz/2
$expected=@{BCLKhighLow=$half-1.5e9/$dual.serial.SCKI_Hz;ADC_FSsetup_with20nsSourceAllowance=$half-20-50;MCU_A_dataSetup=$half-40-0.5;MCU_B_dataSetup=$half-40-1;MCU_A_dataHold=$half-10-3.5;MCU_B_dataHold=$half-10-2}
foreach($k in $expected.Keys){if([math]::Abs($expected[$k]-$budget.residualBudgetsBeforeUnmodeledTerms_ns.$k) -gt 0.0001){throw "Timing arithmetic: $k"}}
$validation=[ordered]@{status='LOGICAL_FIX_VALIDATED_UNROUTED';ownedRecords=13;ownedPinRows=157;addedResistor='R691';authorizedOwnedNetChanges=$changes;otherOwnedNetsUnchanged=$true;frameArithmeticVerified=$true;timingArithmeticVerified=$true;allSourceHashesVerified=$true;manufacturerPDFs=$sources.Count;parentNativeEdited=$false;benchTests=0;fullBoardDRC=$false;productionRelease=$false}
Write-Json (Join-Path $out 'verification/dual-dout-validation.json') $validation
$files=@(Get-ChildItem -LiteralPath $out -Recurse -File | Where-Object Name -ne 'artifact-manifest-sha256.json' | Sort-Object FullName | ForEach-Object {[ordered]@{file=$_.FullName.Substring($out.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Hash $_.FullName)}})
Write-Json (Join-Path $out 'artifact-manifest-sha256.json') $files
$validation | ConvertTo-Json -Depth 8
