import json
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(Path(__file__).parent / 'pythonlibs'))
if len(sys.argv) > 1 and sys.argv[1] == 'html':
    text = (Path(__file__).parent / 'panasonic-product.html').read_text(encoding='utf-8-sig')
    for name, version in re.findall(r'"name":"([^"]*)","fileVersions":\[\{"id":(\d+)', text):
        if 'SSOP' in name or 'Datasheet' in name:
            print(name, version)
elif len(sys.argv) > 1 and sys.argv[1] == 'native':
    data = json.loads((root / 'outputs/SmartVio-V25-Engineering/electrical/native-components.json').read_text(encoding='utf-8-sig'))
    for c in data:
        if re.match(r'^(SP|LS|BZ)|^U902$', c['ref']):
            print(json.dumps(c, indent=2))
else:
    import fitz
    name = sys.argv[1]
    path = root / 'outputs/SmartVio-V25-Engineering/audit/audio/sources' / (name + '.pdf')
    reader = fitz.open(path)
    pages = [p.get_text(sort=True) for p in reader]
    (Path(__file__).parent / 'pdf-text' / (name + '.json')).write_text(json.dumps(pages, indent=2), encoding='utf-8')
    selected = list(map(int, sys.argv[2].split(','))) if len(sys.argv) > 2 else range(1, len(pages) + 1)
    for page in selected:
        print(f'PDF PAGE {page}\n{pages[page-1]}')
        reader[page-1].get_pixmap(matrix=fitz.Matrix(2, 2)).save(str(Path(__file__).parent / f'{name}-page-{page}.png'))
