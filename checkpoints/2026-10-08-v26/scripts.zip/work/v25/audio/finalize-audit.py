import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'outputs/SmartVio-V25-Engineering/audit/audio'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
contract=read(OUT/'integration-contract.json')
native=read(ROOT/contract['baseInput']['file'])
byref={c['ref']:c for c in native}
records=read(OUT/'corrected-components.json')
assert len(records)==13
assert {c['ref'] for c in records}==set(contract['ownedRefs'])
for input_kind in ['baseInput','referenceInput']:
    assert sha(ROOT/contract[input_kind]['file'])==contract[input_kind]['sha256']
for c in records:
    old=byref[c['ref']]
    assert c['release']=='HOLD'
    for pin in c['pins']:
        oldnum=pin.get('legacyPinNumber',pin['number'])
        op=next(v for v in old['pins'] if v['number']==oldnum)
        assert pin['net']==op['net'],(c['ref'],pin['number'])
        if pin['net'] is None:assert pin.get('noConnectReason')
        if c['ref'].startswith('J') and pin['number']=='DA':assert pin['footprintPad'] is None
manifest=read(OUT/'source-manifest.json')
for s in manifest:assert sha(OUT/s['file'])==s['sha256']
fps=read(OUT/'footprint-specifications.json')
for s in fps:assert sha(OUT/s['file'])==s['sha256']
base=read(OUT/'verification/footprint-coupon-drc-baseline-0.20mm.json')
cond=read(OUT/'verification/footprint-coupon-drc-conditional-0.15mm.json')
assert len(base['violations'])==16 and all(v['type']=='clearance' for v in base['violations'])
assert not cond['violations'] and not cond['unconnected_items']
summary={
 'status':'AUDIT_DELIVERED_PRODUCTION_HOLD',
 'ownedRecords':13,'pinRows':sum(len(c['pins']) for c in records),'manufacturerPdfsHashed':len(manifest),
 'logicalNetsPreservedForEveryOwnedPin':True,'nativeInputsUnchangedFromContractHashes':True,
 'ncReasonsComplete':True,'footprintLibraryVariantsLoaded':9,'assignedComponentPadSetsVerified':8,
 'footprintAssignmentHolds':['U301 RTE0016B/C selection','J102','J201','J202','J301'],
 'baselineDrc':{'ruleMm':.20,'violations':16,'types':{'clearance':16},'unconnected':len(base['unconnected_items']),
     'report':'verification/footprint-coupon-drc-baseline-0.20mm.json','boardSha256':sha(OUT/'verification/audio-footprint-coupon.kicad_pcb'),
     'meaning':'Official YFF9 pads have 0.17mm gaps and ADI T1633 corner pads ~0.1768mm gaps, incompatible with baseline 0.20mm clearance.'},
 'conditionalDrc':{'localClearanceMm':.15,'localOverrideRefs':['UQA6 (YFF9)','UQA9 (T1633)'],
     'violations':0,'unconnected':0,'report':'verification/footprint-coupon-drc-conditional-0.15mm.json',
     'boardSha256':sha(OUT/'verification/audio-footprint-coupon-CONDITIONAL-0.15mm.kicad_pcb'),
     'meaning':'Separate nonfunctional coupon only, explicit local pad clearance overrides. No alteration to distributed library copper or parent board rules. Does not establish board-house approval or full-board DRC.'},
 'cliEnvironmentNote':'KiCad 10.0.6 emitted denied global AppData/registry settings writes in sandbox, but generated DRC reports. No permission escalation for those writes; configuration/documents paths were directed under work/v25/audio. Baseline and conditional checks returned their corresponding violation exit codes.',
 'earlierArtifacts':'footprint-coupon-drc.json is the first historical run before silkscreen text height correction; superseded by the named baseline and conditional reports. The extensionless verification/svg is a combined SVG export, not a fabrication file.',
 'benchTests':0,'fullBoardDrc':False,'fabricationRelease':False,
 'criticalHolds':['Lumberg official pin6 vs8 conflict','USB fault clamp and VREF rail coordination','Manual fault-latch reset/new authorized session; no physical unplug detector','Actual speaker limit and acoustic qualification','Original pickup envelope','RTE procurement variant','Passive MPNs and effective capacitance','Board fabrication process approval']
}
save('verification/audit-validation-summary.json',summary)
contract['validationSummary']='verification/audit-validation-summary.json'
contract['parentOperations']='parent-change-instructions.json'
contract['manufacturingClearanceCondition']='YFF9 and T1633 require approved local copper clearance <=0.17mm / <=0.1768mm respectively; only the separate 0.15mm coupon passes. Do not lower parent rules automatically.'
save('integration-contract.json',contract)
ops=read(OUT/'parent-change-instructions.json')
ops['operations'].append({'operation':'parent_pcb_process_review','status':'HOLD_BOARD_HOUSE_APPROVAL',
 'refs':['U1401','U902'],'preserveOfficialCopperGeometry':True,
 'minimumMeasuredCopperGapMm':{'U1401':.17,'U902':.1767767},
 'default0V20mmClearanceCompatible':False,
 'conditionalCoupon0V15mmResult':'0 violations, isolated footprints only',
 'parentBoardRuleEditsApplied':False})
save('parent-change-instructions.json',ops)
with (OUT/'AUDIT-REPORT.txt').open('a',encoding='utf-8') as f:
    f.write('\nFinal validation:\n13 owned records / 157 pins; all logical nets preserved; 13 official PDFs hashed.\n')
    f.write('9 footprint variants load in KiCad; 8 component assignments have matching pin/pad sets; U301 variant and four jacks remain blocked.\n')
    f.write('Footprint-only DRC baseline at 0.20mm: 16 clearance violations. Separate coupon with explicit 0.15mm local clearance for YFF9 and T1633 only: 0 violations, 0 unconnected. This is conditional geometry validation, not full-board approval.\n')
    f.write('No passive removal or hardware addition is auto-applied. C304=2.2uF is a proposal with an effective-capacitance condition. Parent operations are in parent-change-instructions.json.\n')
files=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name!='artifact-manifest-sha256.json':
        files.append(dict(file=str(p.relative_to(OUT)).replace('\\','/'),bytes=p.stat().st_size,sha256=sha(p)))
save('artifact-manifest-sha256.json',files)
print(json.dumps(summary,indent=2))
