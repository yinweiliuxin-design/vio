$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$out = Join-Path $root 'outputs/SmartVio-V25-Engineering/audit/audio'
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Read-Json([string]$path) { Get-Content -LiteralPath $path -Raw | ConvertFrom-Json }
function Write-Json([string]$path, $obj) { [IO.File]::WriteAllText($path, (ConvertTo-Json -InputObject $obj -Depth 100) + "`n", $utf8) }
function Set-Field($obj, [string]$name, $value) { $obj | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force }

$contractName = 'pcm1864-tdm-contract.json'
$tdm = Read-Json (Join-Path $out $contractName)
$sourceHash = (Get-FileHash -LiteralPath (Join-Path $out $tdm.source.file) -Algorithm SHA256).Hash.ToLowerInvariant()
if ($sourceHash -ne $tdm.source.sha256) { throw 'PCM1864 source hash changed' }
if ($tdm.frame.sampleRateHz * $tdm.frame.frameBits -ne $tdm.frame.BCLK_Hz) { throw 'Frame arithmetic mismatch' }
if ($tdm.frame.slotWidthBits * $tdm.frame.slotPositionsPerFrame -ne $tdm.frame.frameBits) { throw 'Slot arithmetic mismatch' }

$newAction = 'Firmware candidate page0: input selects0x06=01,0x07=01,0x08=04,0x09=00; keep four-channel processing and mute ADC2R. The frame is256 BCLK at48kHz=12.288MHz, eight32-bit positions, four transmitted24+8-bit words (three live inputs plus muted fourth), then128 BCLK Hi-Z. See pcm1864-tdm-contract.json for exact registers and clock/timing HOLD. This is not a four-slot frame or four64-bit slots.49.152MHz SCKI=1024fs is not an approved auto-detect ratio. Preserve HP_DETECT active high and DAC/bias mute sequencing; playback I2S stays separate.'
$oldAction = 'Firmware candidate on page0: ADC1L select register0x06=0x01, ADC1R 0x07=0x01, ADC2L 0x08=0x04, ADC2R 0x09=0x00 (mute). Read back and validate four TDM slots/clock timing before audio enable. HP_DETECT is active high after the verified break contact opens. Enable headphone only after DAC and bias settle; disable before source shutdown. Validate 49.152MHz ADC SCKI and 12.288MHz BCK, 48kHz TDM separately from 3.072MHz playback I2S.'
$finding = [ordered]@{
    id = 'AUD-011'
    severity = 'BLOCKER'
    refs = @('U601', 'U801')
    title = 'PCM1864 fixed256-bit TDM frame and unresolved1024fs slave timing'
    status = 'HOLD_CLOCK_AND_INTERFACE_TIMING'
    observation = 'Correct frame is256 BCLK,8x32-bit positions with4 transmitted words,3 live inputs and1 muted channel; remainder Hi-Z. The original V23 A15 frame note was correct; preliminary audio audit four-slot wording was wrong.49.152MHz at48kHz is1024fs, absent from automatic ratio table. At12.288MHz half-cycle40.690ns is less than50ns FSYNC setup for a falling-edge transition, and DOUT max40ns leaves0.690ns before MCU setup/skew.'
    requiredAction = 'Use pcm1864-tdm-contract.json. Do not enable audio from nominal clocks alone. Resolve manual clock/status behavior and exact FSYNC/DOUT timing with manufacturer clarification and target measurements. No clock-master change or guessed timing exception is applied.'
    evidence = @([ordered]@{ sourceId = 'PCM1864'; pdfPages = @(16,19,39,41,58,59,95,96,106,107,109,125,126,127,128); section = 'TDM Fig46, Tables8/10, serial/clock registers, slave timing'; url = $tdm.source.url; sha256 = $sourceHash })
    contract = $contractName
}

# Update the authored finding input and its generated counterpart without rebuilding unrelated records.
foreach ($path in @((Join-Path $PSScriptRoot 'audit-data.json'), (Join-Path $out 'findings-and-required-changes.json'))) {
    $data = Read-Json $path
    $aud6 = $data.findings | Where-Object id -eq 'AUD-006'
    $aud6.requiredAction = $newAction
    Set-Field $aud6 'tdmContract' $contractName
    $data.findings = @($data.findings | Where-Object id -ne 'AUD-011') + @($finding)
    $change = $data.proposedChanges | Where-Object id -eq 'CHANGE-A07'
    if (-not $change) { $change = $data.requiredChanges | Where-Object id -eq 'CHANGE-A07' }
    if (-not $change) { throw "Cannot find firmware change in $path" }
    $change.requirements = @($change.requirements | ForEach-Object { if ($_ -match '^PCM1864 select') { 'PCM1864 eight32-bit slot positions in256-BCLK frame,4 transmitted words with fourth muted; exact candidate registers and timing HOLD in pcm1864-tdm-contract.json' } else { $_ } })
    Write-Json $path $data
}

$recordsPath = Join-Path $out 'corrected-components.json'
$records = Read-Json $recordsPath
$adc = $records | Where-Object ref -eq 'U601'
Set-Field $adc 'digitalInterfaceAudit' ([ordered]@{ status = $tdm.status; contract = $contractName; frameBits = 256; slotWidthBits = 32; slotPositions = 8; transmittedWords = 4; activeAnalogChannels = 3; clockRelease = 'HOLD'; interfaceTimingRelease = 'HOLD' })
Write-Json $recordsPath $records

$mergePath = Join-Path $out 'integration-contract.json'
$merge = Read-Json $mergePath
Set-Field $merge 'adcTdmContract' $contractName
Set-Field $merge 'adcClockRelease' 'HOLD_MANUAL1024FS_AND_INTERFACE_TIMING'
Write-Json $mergePath $merge

$opsPath = Join-Path $out 'parent-change-instructions.json'
$ops = Read-Json $opsPath
$ops.operations = @($ops.operations | Where-Object operation -ne 'replace_pcm1864_candidate_clock_contract') + @([ordered]@{
    operation = 'replace_pcm1864_candidate_clock_contract'; refs = @('U601','U801'); contract = $contractName
    status = $tdm.status; hardwareEdits = @(); clockMasterChange = $false
    removeClaims = @('four total TDM slots', '4x64-bit channels', '49.152MHz SCKI auto-detection validated', 'nominal clocks establish interface timing pass')
    addRequirements = @('256-bit frame/8x32-bit positions/4 transmitted words', 'slots4..7 Hi-Z and excluded from audio', 'register and DMA contract with three live channels', 'manual1024fs/status and FSYNC/DOUT timing HOLD')
})
Write-Json $opsPath $ops

$qaPath = Join-Path $out 'verification/audit-validation-summary.json'
$qa = Read-Json $qaPath
Set-Field $qa 'pcm1864FrameArithmeticVerified' $true
Set-Field $qa 'pcm1864ClockAndTimingRelease' $false
$qa.criticalHolds = @($qa.criticalHolds | Where-Object { $_ -ne 'PCM1864 manual1024fs and FSYNC/DOUT timing' }) + @('PCM1864 manual1024fs and FSYNC/DOUT timing')
Write-Json $qaPath $qa

$reportPath = Join-Path $out 'AUDIT-REPORT.txt'
$report = [IO.File]::ReadAllText($reportPath).Replace($oldAction, $newAction)
$marker = "`nPCM1864 clock correction (AUD-011):"
if ($report.Contains($marker)) { $report = $report.Substring(0, $report.IndexOf($marker)) }
$report += $marker + "`n" + $finding.observation + "`nAction: " + $finding.requiredAction + "`nEvidence: PCM1864 SLAS831D pp19,39,41,58-59,95-96,106-109,125-128; SHA256 " + $sourceHash + "`n"
[IO.File]::WriteAllText($reportPath, $report, $utf8)

$native = Read-Json (Join-Path $root $merge.baseInput.file)
foreach ($c in $records) {
    $old = $native | Where-Object ref -eq $c.ref
    foreach ($pin in $c.pins) {
        $oldNum = if ($pin.legacyPinNumber) { $pin.legacyPinNumber } else { $pin.number }
        $oldPin = $old.pins | Where-Object number -eq $oldNum
        if ($oldPin.net -ne $pin.net) { throw "Logical net changed: $($c.ref).$oldNum" }
    }
}
$files = @(Get-ChildItem -LiteralPath $out -Recurse -File | Where-Object Name -ne 'artifact-manifest-sha256.json' | Sort-Object FullName | ForEach-Object {
    [ordered]@{ file = $_.FullName.Substring($out.Length + 1).Replace('\','/'); bytes = $_.Length; sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() }
})
Write-Json (Join-Path $out 'artifact-manifest-sha256.json') $files
[ordered]@{ status = $tdm.status; frameBits = 256; slotPositions = 8; slotWidthBits = 32; BCLK_Hz = 12288000; transmittedWords = 4; liveInputs = 3; logicalNetsUnchanged = $true; records = $records.Count; artifactsHashed = $files.Count } | ConvertTo-Json
