"""Read back generated KiCad files and build an isolated geometry-only DRC coupon."""
import json
import os
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
WORK=Path(__file__).parent
OUT=ROOT/'outputs/SmartVio-V25-Engineering/audit/audio'
os.environ['KICAD_CONFIG_HOME']=str(WORK/'kicad-config')
os.environ['KICAD_DOCUMENTS_HOME']=str(WORK/'kicad-documents')
import pcbnew as p

LIB=OUT/'footprints/SmartVio_Audio_Official.pretty'
QA=OUT/'verification'
QA.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
specs=read(OUT/'footprint-specifications.json')
records=read(OUT/'corrected-components.json')
mm=p.FromMM
pt=lambda x,y:p.VECTOR2I(mm(x),mm(y))
b=p.BOARD()
b.SetCopperLayerCount(2)
results=[]
for i,s in enumerate(specs):
    fp=p.FootprintLoad(str(LIB),s['name'])
    assert fp is not None,s['name']
    numbered={pad.GetNumber():pad for pad in fp.Pads() if pad.GetNumber()}
    assert set(numbered)=={v['number'] for v in s['pads']},s['name']
    for expected in s['pads']:
        pad=numbered[expected['number']]
        xy=pad.GetPosition();size=pad.GetSize()
        observed=[p.ToMM(xy.x),p.ToMM(xy.y),p.ToMM(size.x),p.ToMM(size.y)]
        assert max(abs(a-v) for a,v in zip(observed,[expected['x'],expected['y'],expected['width'],expected['height']]))<1e-5,(s['name'],expected['number'],observed)
    fp.SetFPID(p.LIB_ID('SmartVio_Audio_Official',s['name']))
    fp.SetReference('UQA'+str(i+1));fp.SetValue(s['name'])
    fp.SetPosition(pt(15+25*(i%3),15+25*(i//3)))
    fp.Value().SetVisible(False)
    b.Add(fp)
    for pad in fp.Pads():
        if pad.GetNumber():
            net=p.NETINFO_ITEM(b,fp.GetReference()+'_'+pad.GetNumber());b.Add(net);pad.SetNet(net)
    results.append(dict(footprint=s['id'],load=True,padSetMatches=True,coordinateAndSizeMatch=True,electricalPadCount=len(numbered)))
for a,z in [((5,5),(80,5)),((80,5),(80,80)),((80,80),(5,80)),((5,80),(5,5))]:
    sh=p.PCB_SHAPE();sh.SetShape(p.SHAPE_T_SEGMENT);sh.SetStart(pt(*a));sh.SetEnd(pt(*z));sh.SetWidth(mm(.05));sh.SetLayer(p.Edge_Cuts);b.Add(sh)
p.SaveBoard(str(QA/'audio-footprint-coupon.kicad_pcb'),b)
for fp in b.GetFootprints():
    if fp.GetReference() in ['UQA6','UQA9']:
        fp.SetLocalClearance(mm(.15))
p.SaveBoard(str(QA/'audio-footprint-coupon-CONDITIONAL-0.15mm.kicad_pcb'),b)
lut={s['id']:s for s in specs}
assignments=[]
for c in records:
    fid=c.get('footprint')
    if fid:
        expected={v['number'] for v in c['pins']}
        actual={v['number'] for v in lut[fid]['pads']}
        assert actual==expected,c['ref']
        assignments.append(dict(ref=c['ref'],footprint=fid,padSetMatches=True))
    else:
        assert c['ref']=='U301' or c['ref'].startswith('J'),c['ref']
        assignments.append(dict(ref=c['ref'],footprint=None,padSetMatches=None,status=c['footprintAudit']['status']))
project={
 'board':{'design_settings':{'rules':{'min_clearance':0.15,'min_track_width':0.15,'min_hole_clearance':0.25,'min_copper_edge_clearance':0.25,'min_silk_clearance':0.1}}},
 'meta':{'filename':'audio-footprint-coupon.kicad_pro','version':1}
}
(QA/'audio-footprint-coupon.kicad_pro').write_text(json.dumps(project,indent=2),encoding='utf-8')
(QA/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "SmartVio_Audio_Official") (type "KiCad") (uri "${KIPRJMOD}/../footprints/SmartVio_Audio_Official.pretty") (options "") (descr "Official land transcriptions; circuit manufacturing release HOLD")))\n',encoding='ascii')
(QA/'footprint-load-and-pad-checks.json').write_text(json.dumps(dict(kicad=p.GetBuildVersion(),footprints=results,componentAssignments=assignments,
    validationScope='Isolated footprint loading, numbered copper-pad coordinates/sizes, component pad identities. Independent one-pad nets on a nonfunctional coupon. Not full-board circuit DRC.',
    declaredCouponRules={'globalMinimumCopperClearanceMm':.15,'defaultNetclassCopperClearanceMm':.2,'conditionalLocalCouponClearanceMm':.15,'reason':'YFF9 has 0.17mm adjacent copper gap; ADI T1633 has 0.1768mm corner gap. The 0.20mm baseline must report these, and a separate explicitly conditional 0.15mm test may pass. Actual board-house approval is not implied.'},
    missingFullBoardChecks=['Routing and electrical connectivity','Actual PCB stackup and clearance rules','Footprint against purchased sample','Solder process and stencil review','Jack footprint unresolved','RTE procurement variant unresolved']),indent=2),encoding='utf-8')
print(json.dumps({'loaded':len(results),'componentPadSetsVerified':sum(bool(v['padSetMatches']) for v in assignments),'componentHolds':sum(v['footprint'] is None for v in assignments),'coupon':str(QA/'audio-footprint-coupon.kicad_pcb')},indent=2))
