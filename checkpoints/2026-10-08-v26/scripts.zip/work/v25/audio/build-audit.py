"""Generate audio-owned records and source-transcribed footprints; never edit parent inputs."""
import copy
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).parent
OUT = ROOT / 'outputs/SmartVio-V25-Engineering/audit/audio'
LIB = OUT / 'footprints/SmartVio_Audio_Official.pretty'
LIB.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

data = read(WORK / 'audit-data.json')
native_path = ROOT / 'outputs/SmartVio-V24-NativeEDA/electrical/native-components.json'
circuits_path = ROOT / 'outputs/SmartVio-V24-NativeEDA/reference/v23-circuits.json'
native = read(native_path)
byref = {c['ref']: c for c in native}
sources = read(OUT / 'source-manifest.json')
extras = [
    ('MAX98357A_land_90-0031', 'https://mds.analog.com/api/public/content/90-0031.pdf', '90-0031 Rev C, one-page land pattern'),
    ('Lumberg1503_18_3d', 'https://downloads.lumberg.com/3dpdf/lumberg_1503_18.pdf', 'Official alternate 3D PDF; no revision identified'),
    ('ST_AN4879', 'https://www.st.com/resource/en/application_note/DM00296349-.pdf', 'AN4879 Rev 12, June 2026'),
    ('STM32H743', 'https://www.st.com/resource/en/datasheet/stm32h743vi.pdf', 'DS12110 Rev 11, January 2026')
]
for sid, url, revision in extras:
    p = OUT / 'sources' / (sid + '.pdf')
    sources = [s for s in sources if s['id'] != sid]
    sources.append(dict(id=sid, url=url, file='sources/' + p.name, sha256=sha(p), bytes=p.stat().st_size,
                        retrievedAtUtc=datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat(),
                        timestampBasis='download file modification time', revision=revision, status='downloaded'))
revisions = {'TLV9064': 'SBOS839N, July 2026', 'TPA6132A2': 'SLOS597B, July 2017; appended drawings through July 2025',
             'PCM1864': 'SLAS831D, March 2018', 'PCM5102A': 'SLAS859C, May 2015',
             'USBLC6_2': 'DS4260 Rev 7, December 2021', 'Lumberg1503_18': '07/2025',
             'TPD2S300': 'SLVSDL1, April 2017', 'TPD2S703_Q1': 'SLLSEU8B, May 2020',
             'MAX98357A': '19-6779 Rev 16, February 2026'}
for s in sources:
    p = OUT / s['file']
    assert s['status'] == 'downloaded' and p.read_bytes().startswith(b'%PDF-')
    assert sha(p) == s['sha256']
    s['revision'] = revisions.get(s['id'], s.get('revision'))
    s['publisherOrigin'] = 'official_manufacturer'
save('source-manifest.json', sources)
source = {s['id']: s for s in sources}
def cite(sid, pages, section):
    s = source[sid]
    return dict(sourceId=sid, pdfPages=pages, section=section, url=s['url'], sha256=s['sha256'])

# Names/numbers are independently transcribed from the indicated manufacturer pin tables.
maps = {
 'TLV9064': ('OUT1 IN1- IN1+ V+ IN2+ IN2- OUT2 OUT3 IN3- IN3+ V- IN4+ IN4- OUT4'.split(), 8, '5, Table 5-5 (PW column)'),
 'TPA6132A2': ('INL- INL+ INR+ INR- OUTR G0 G1 HPVSS CPN PGND CPP HPVDD EN VDD SGND OUTL Thermal_Pad'.split(), 3, '5 Pin Functions; package drawings pad 17'),
 'USBLC6_2': ('IO1 GND IO2 IO2 VBUS IO1'.split(), 1, 'Functional diagram (top view)'),
 'PCM1864': ('VINL2/VIN1M VINR2/VIN2M VINL1/VIN1P VINR1/VIN2P MIC_BIAS VREF AGND AVDD XO XI LDO DGND DVDD IOVDD SCKI LRCK BCK DOUT GPIO3/INTC GPIO2/INTB/DMCLK GPIO1/INTA/DMIN MISO/GPIO0/DMIN2 MOSI/SDA MC/SCL MS/AD MD0 VINL4/VIN4M VINR4/VIN3M VINL3/VIN4P VINR3/VIN3P'.split(), 11, '6 Pin Functions: PCM1862/3/4/5'),
 'PCM5102A': ('CPVDD CAPP CPGND CAPM VNEG OUTL OUTR AVDD AGND DEMP FLT SCK BCK DIN LRCK FMT XSMT LDOO DGND DVDD'.split(), 5, '7 Pin Functions, PW20'),
 'MAX98357A': ('DIN GAIN_SLOT GND SD_MODE NC NC VDD VDD OUTP OUTN GND NC NC LRCLK GND BCLK EP'.split(), 15, 'Pin Description, TQFN column'),
 'TPD2S300': ('C_CC1 VBIAS C_CC2 CC1 GND CC2 FLT_N VPWR VM'.split(), 3, '5 Pin Functions, YFF9'),
 'TPD2S703_Q1': ('VD- VD+ GND FLT_N EN_N MODE VPWR VREF D+ D-'.split(), 3, '5 Pin Functions, DGS10')
}
refs_to_source = {'U101':'TLV9064','U201':'TLV9064','U301':'TPA6132A2','U401':'USBLC6_2',
                  'U601':'PCM1864','U701':'PCM5102A','U902':'MAX98357A','U1401':'TPD2S300','U1501':'TPD2S703_Q1'}
power_in = {'U101':['4','11'],'U201':['4','11'],'U301':['10','14','15','17'],
            'U401':['2','5'],'U601':['7','8','12','13','14'],'U701':['1','3','8','9','19','20'],
            'U902':['3','7','8','11','15','EP'],'U1401':['B2','C2'],'U1501':['3','7','8']}
power_out = {'U301':['8','9','11','12'],'U601':['5','6','11'],'U701':['2','4','5','18'],'U1401':['A2']}
output = {'U101':['1','7','8','14'],'U201':['1','7','8','14'],'U301':['5','16'],'U601':['9','18'],
          'U701':['6','7'],'U902':['9','10'],'U1401':['C1'],'U1501':['4']}
bidir = {'U401':['1','3','4','6'],'U601':['16','17','19','20','21','22','23'],
         'U1401':['A1','A3','B1','B3'],'U1501':['1','2','9','10']}
nc_reasons = {
 'U601': {'1':'Unused analog input; must remain open per 9.3.1 p28.', '2':'Unused analog input; must remain open per 9.3.1 p28.',
          '5':'Unused microphone bias output; may be open per 9.3.2.1 p29. Firmware must leave disabled; no microphone added.',
          '9':'No crystal fitted; SCKI supplies clock. XO output deliberately open.',
          '19':'Unused multifunction GPIO; configure inactive output or internal pulls as appropriate.',
          '20':'Unused multifunction GPIO; digital microphone clock function disabled.',
          '21':'Unused multifunction GPIO; digital microphone function disabled.',
          '22':'I2C operation, unused GPIO0/DMIN2; digital microphone function disabled.',
          '27':'Unused analog input; must remain open per 9.3.1 p28.', '28':'Unused analog input; must remain open per 9.3.1 p28.',
          '30':'Unused analog input; must remain open per 9.3.1 p28.'},
 'U902': {p:'Manufacturer NC; copper land retained for assembly, no connected net or test trace.' for p in ['5','6','12','13']}
}

# Geometry is in mm, top/component view, x right, y down. No standard library geometry is assumed.
fps = {}
def add_fp(name, body, pads, sid, pages, drawing, paste_policy='same_as_copper', note=None):
    fps[name] = dict(id='SmartVio_Audio_Official:'+name, name=name, units='mm', view='PCB top/component view; x right; y down',
                    bodyNominalMm=body, pads=pads, provenance=cite(sid,pages,drawing),
                    copperGeometryStatus='VERIFIED_OFFICIAL_LAND_PATTERN_TRANSCRIPTION',
                    pastePolicy=paste_policy, manufacturingRelease='HOLD_BOARD_AND_ASSEMBLY_REVIEW', note=note)
def pad(n,x,y,w,h,shape='roundrect',radius=0.05):
    return dict(number=str(n),x=round(x,6),y=round(y,6),width=w,height=h,shape=shape,cornerRadiusMm=radius if shape=='roundrect' else 0)
def two_row(count,pitch,span,length,width):
    half=count//2
    return [pad(i+1,-span/2,(i-(half-1)/2)*pitch,length,width) for i in range(half)]+[
           pad(half+i+1,span/2,((half-1)/2-i)*pitch,length,width) for i in range(half)]
add_fp('TI_PW0014A_Official', [4.4,5.0],two_row(14,.65,5.8,1.5,.45),'TLV9064',[89,90,91],'PW0014A 4220202/B 12/2023')
add_fp('TI_PW0020A_Official', [4.4,6.5],two_row(20,.65,5.8,1.5,.45),'PCM5102A',[41,42,43],'PW0020A 4220206/A 02/2017')
add_fp('TI_DBT0030A_Official', [4.4,7.8],two_row(30,.5,5.8,1.5,.3),'PCM1864',[142,143,144],'DBT0030A 4220214/B 09/2021; visually read, pages have no extracted text')
add_fp('TI_DGS0010A_Official', [3,3],two_row(10,.5,4.4,1.45,.3),'TPD2S703_Q1',[28,29,30],'DGS0010A 4211984/A 05/2015; no EP')
add_fp('ST_USBLC6_2SC6_SOT23_6L_Official',[1.6,2.9],two_row(6,.95,2.3,1.2,.6),'USBLC6_2',[1,12,13],
       'SOT23-6L Figure19, rotated 90 degrees relative to land-only Figure19 to align numbered functional top view',
       note='Rectangular copper pads from ST Figure19; mask expansion 0.04mm and courtyard are local process choices, not manufacturer-dimensioned.')
for p in fps['ST_USBLC6_2SC6_SOT23_6L_Official']['pads']:
    p['shape']='rect';p['cornerRadiusMm']=0
bga = [pad(row+str(col+1),(col-1)*.4,(ri-1)*.4,.23,.23,'circle') for ri,row in enumerate('ABC') for col in range(3)]
for p in bga:
    p['pasteSizeMm']=[.25,.25];p['pasteShape']='roundrect';p['pasteCornerRadiusMm']=.05
add_fp('TI_YFF0009_Official',[1.36,1.36],bga,'TPD2S300',[3,34,35,36],'YFF0009 4219552/A 05/2016',
       '0.25mm square R0.05 apertures, 0.1mm stencil per official drawing',
       'BGA body min1.33 max1.39mm. 0.4mm pitch escape and mask web need actual board-house approval. A1 top-left in component view.')
def qfn16(span,length,width,ep,label='17',start='left_top'):
    pts=[(-span/2,-.75+i*.5,length,width) for i in range(4)]+[(-.75+i*.5,span/2,width,length) for i in range(4)]+[
        (span/2,.75-i*.5,length,width) for i in range(4)]+[(.75-i*.5,-span/2,width,length) for i in range(4)]
    if start=='bottom_left':
        pts=pts[4:]+pts[:4]
    return [pad(i+1,*xywh) for i,xywh in enumerate(pts)]+[pad(label,0,0,ep,ep)]
for suffix,ep,paste,pg,doc in [('C',1.68,1.55,26,'4219117/B 04/2022'),('B',1.6,1.51,29,'4230836/A 07/2025')]:
    pads=qfn16(2.8,.6,.24,ep)
    pads[-1]['pasteSizeMm']=[paste,paste]
    add_fp('TI_RTE0016'+suffix+'_Official',[3,3],pads,'TPA6132A2',[pg-1,pg,pg+1],'RTE0016'+suffix+' '+doc,
           'EP paste '+str(paste)+'mm square; 0.125mm stencil; no thermal vias included (optional per drawing)',
           'Component assignment HOLD until supplied RTE0016B/C variant identified. Ground EP17; solder it even though electrical floating is also permitted.')
mpads=qfn16(2.85,.8,.3,1.23,'EP','bottom_left')
for p in mpads:
    p['shape']='rect';p['cornerRadiusMm']=0
add_fp('ADI_T1633_4_Official',[3,3],mpads,'MAX98357A_land_90-0031',[1],'90-0031 Rev C, T1633+4; numbering from MAX98357A p15',
       '1:1 paste is a local candidate; vendor land drawing does not specify a stencil; assembly review required',
       'Pin 1 bottom-left in the source top view; not interchangeable with TI RTE orientation. Exposed pad number EP is local CAD representation of unnumbered manufacturer EP; must connect solid GND.')
fps['ADI_T1633_4_Official']['additionalEvidence']=[cite('MAX98357A',[15,35],'TQFN pin orientation and T1633+4 to land-pattern association')]

def fmt(v):
    return f'{v:.6f}'.rstrip('0').rstrip('.') if isinstance(v,float) else str(v)
def make_pad(p,layers,number=None,size=None,shape=None):
    w,h=size or [p['width'],p['height']]
    shape=shape or p['shape']
    s=f'  (pad "{p["number"] if number is None else number}" smd {shape} (at {fmt(p["x"])} {fmt(p["y"])}) (size {fmt(w)} {fmt(h)}) (layers '+ ' '.join('"'+l+'"' for l in layers) + ')'
    if shape=='roundrect':
        s+=' (roundrect_rratio '+fmt(min(.5,p.get('cornerRadiusMm',.05)/min(w,h)))+')'
    return s+')'
for name, fp in fps.items():
    b=fp['bodyNominalMm']; ps=fp['pads']
    bound_x=max(max(abs(p['x'])+p['width']/2 for p in ps),b[0]/2)+.25
    bound_y=max(max(abs(p['y'])+p['height']/2 for p in ps),b[1]/2)+.25
    fp['courtyardMm']=[round(2*bound_x,6),round(2*bound_y,6)]
    fp['courtyardProvenance']='Local 0.25mm assembly margin, not manufacturer specified'
    fp['maskExpansionMm']=.04
    lines=[f'(footprint "{name}" (version 20240108) (generator "SmartVio_audio_audit")',
           '  (layer "F.Cu") (attr smd)', f'  (descr "Source-transcribed manufacturer land pattern; {fp["provenance"]["sourceId"]}; assembly HOLD")',
           '  (solder_mask_margin 0.04)',
           f'  (fp_text reference "REF**" (at 0 {-bound_y-1.0}) (layer "F.SilkS") (effects (font (size 1.0 1.0) (thickness 0.15))))',
           f'  (fp_text value "{name}" (at 0 {bound_y+.8}) (layer "F.Fab") hide (effects (font (size 0.7 0.7) (thickness 0.1))))',
           f'  (fp_rect (start {-b[0]/2} {-b[1]/2}) (end {b[0]/2} {b[1]/2}) (stroke (width 0.1) (type default)) (fill none) (layer "F.Fab"))',
           f'  (fp_rect (start {-bound_x} {-bound_y}) (end {bound_x} {bound_y}) (stroke (width 0.05) (type default)) (fill none) (layer "F.CrtYd"))']
    first=ps[0]
    mx=first['x'];my=first['y']
    if name=='ADI_T1633_4_Official':
        my=bound_y+.12
    elif name=='TI_YFF0009_Official':
        mx=-bound_x-.12;my=-.4
    else:
        mx=-bound_x-.12
    lines.append(f'  (fp_circle (center {mx} {my}) (end {mx+.12} {my}) (stroke (width 0.08) (type default)) (fill none) (layer "F.SilkS"))')
    for p in ps:
        separate='pasteSizeMm' in p
        lines.append(make_pad(p,['F.Cu','F.Mask'] if separate else ['F.Cu','F.Paste','F.Mask']))
        if separate:
            paste=copy.deepcopy(p);paste['cornerRadiusMm']=p.get('pasteCornerRadiusMm',.05)
            lines.append(make_pad(paste,['F.Paste'],number='',size=p['pasteSizeMm'],shape=p.get('pasteShape','roundrect')))
    lines.append(')')
    (LIB/(name+'.kicad_mod')).write_text('\n'.join(lines)+'\n',encoding='ascii')
    fp['file']='footprints/SmartVio_Audio_Official.pretty/'+name+'.kicad_mod'
    fp['sha256']=sha(OUT/fp['file'])
save('footprint-specifications.json',list(fps.values()))

assignments={'U101':'TI_PW0014A_Official','U201':'TI_PW0014A_Official','U401':'ST_USBLC6_2SC6_SOT23_6L_Official',
             'U601':'TI_DBT0030A_Official','U701':'TI_PW0020A_Official','U902':'ADI_T1633_4_Official',
             'U1401':'TI_YFF0009_Official','U1501':'TI_DGS0010A_Official'}
supply = {
 'U101':[dict(net='V3A',pins=['4'],minV=1.8,maxV=5.5)],
 'U201':[dict(net='V3A',pins=['4'],minV=1.8,maxV=5.5)],
 'U301':[dict(net='V3A',pins=['14'],minV=2.3,maxV=5.5),dict(net='HP_POS',pins=['12'],kind='internal_generated_output_capacitor_only'),dict(net='HP_NEG',pins=['8'],kind='internal_negative_output_capacitor_only')],
 'U401':[dict(net='USB_5V_SAFE',pins=['5'],kind='ESD_steering_reference_not_logic_supply',notes='Leakage specified at 5.25V; check actual protected-rail envelope and backfeed, not a 3.3V clamp.')],
 'U601':[dict(net='V3A',pins=['8'],minV=3,maxV=3.6),dict(net='V3D',pins=['13','14'],minV=3,maxV=3.6),dict(net='ADC_1V8',pins=['11'],kind='internal_LDO_output_capacitors_only_in_this_design')],
 'U701':[dict(net='V3A',pins=['1'],minV=3.1,maxV=3.46),dict(net='V3A',pins=['8'],minV=3.0,maxV=3.46,conditionalMinVrefMode=3.2),dict(net='V3D',pins=['20'],minV=3.1,maxV=3.46),dict(net='DAC_1V8',pins=['18'],kind='internal_LDO_output_capacitor_only_in_this_design')],
 'U902':[dict(net='SYS',pins=['7','8'],minV=2.5,maxV=5.5)],
 'U1401':[dict(net='V3D',pins=['C2','C3'],minV=2.7,maxV=4.5,notes='VPWR/VM same rail valid for CC/PD/FRS mode; low-resistance VCONN mode not selected.')],
 'U1501':[dict(net='USB_5V_SAFE',pins=['7'],minV=4.5,maxV=7),dict(net='V3D',pins=['8'],minV=3,maxV=3.6,notes='Mode0; shared rail transient injection HOLD.')]
}
records=[];rows=[];pin_deltas=[]
for ref in data['ownedRefs']:
    c=copy.deepcopy(byref[ref])
    c['release']='HOLD'
    c['verificationScope']='Official pin/land audit only; circuit integration, board DRC, assembly and physical samples are not released.'
    if ref in refs_to_source:
        sid=refs_to_source[ref];names,page,section=maps[sid]
        nums=list('A1 A2 A3 B1 B2 B3 C1 C2 C3'.split()) if ref=='U1401' else [str(i+1) for i in range(len(names))]
        if ref=='U902': nums[-1]='EP'
        original={p['number']:p for p in c['pins']}
        assert len(original)==len(names)
        corrected=[]
        for number,name in zip(nums,names):
            oldnum='EP' if ref=='U301' and number=='17' else number
            p=copy.deepcopy(original[oldnum])
            p['nativeName']=p['name'];p['name']=name;p['number']=number
            if oldnum!=number:
                p['legacyPinNumber']=oldnum
                pin_deltas.append(dict(ref=ref,fromNumber=oldnum,toNumber=number,net=p['net']))
            p['manufacturerNumber']='EP (unnumbered)' if ref=='U902' and number=='EP' else number
            p['footprintPad']=number;p['pinAuditStatus']='VERIFIED_OFFICIAL'
            p['evidence']=cite(sid,[page],section)
            typ='input'
            if number in power_in.get(ref,[]):typ='power_in'
            if number in power_out.get(ref,[]):typ='power_out'
            if number in output.get(ref,[]):typ='output'
            if number in bidir.get(ref,[]):typ='bidirectional'
            if ref in ['U1401','U1501'] and name=='FLT_N':typ='open_collector'
            if ref=='U902' and name=='NC':typ='no_connect'
            p['electricalType']=typ
            if p['net'] is None:
                p['noConnectReason']=nc_reasons[ref][number]
                p['intentionalNoConnect']=True
            corrected.append(p)
            rows.append(dict(ref=ref,nativeNumber=oldnum,number=number,name=name,net=p['net'] or '',footprintPad=number,status=p['pinAuditStatus'],source=sid,pdfPages=page,section=section,sha256=source[sid]['sha256'],ncReason=p.get('noConnectReason','')))
        c['pins']=corrected
        c['pinAuditStatus']='VERIFIED_OFFICIAL'
        c['supplyAudit']=dict(status='NOMINAL_SUITABLE_ENVELOPE_HOLD',constraints=supply[ref])
        if ref in assignments:
            fp=fps[assignments[ref]]
            c['footprint']=fp['id']
            c['footprintAudit']=dict(status='EXACT_LAND_GEOMETRY_VERIFIED',file=fp['file'],sha256=fp['sha256'],evidence=fp['provenance'],assemblyRelease='HOLD')
        else:
            c['footprint']=None
            c['footprintAudit']=dict(status='HOLD_RTE_VARIANT_SELECTION',candidates=[fps['TI_RTE0016'+v+'_Official']['id'] for v in ['B','C']],requiredPadMapping={'EP':'17'})
        c['exposedPadAudit']={'U301':'Board pad17 to GND, solder required; electrical floating also allowed by manufacturer.',
                              'U902':'Manufacturer EP unnumbered; local pad EP to GND solid plane required; no internal electrical connection.'}.get(ref,'No exposed pad in the exact selected package; do not add one.')
        if ref=='U601':
            c['firmwareAnalogInputMap']={'ADC1L':dict(pin='3',selectionRegister='0x06',value='0x01'),
                'ADC1R':dict(pin='4',selectionRegister='0x07',value='0x01'),
                'ADC2L':dict(pin='29',selectionRegister='0x08',value='0x04'),
                'ADC2R':dict(pin=None,selectionRegister='0x09',value='0x00')}
        if ref=='U902':
            c['gainDb']=3;c['channelMode']='I2S left selected by high SD_MODE; feed mono data in left slot'
        if ref=='U301':c['gainDb']=-6;c['invertingSignalPath']=True
    else:
        c['mpn']='1503 18';c['package']='Lumberg upright through-hole; solder-side drawing conflict, footprint HOLD'
        c['note']='Official 07/2025 p2: sleeve1, tip2, ring3; isolated NC switch is 7/8 in schematic but 7/6 in land drawing. DA is nonphysical HOLD, not a pad number.'
        c['footprint']=None;c['pinAuditStatus']='PARTIAL_VERIFIED_DETECT_CONTACT_CONFLICT'
        c['footprintAudit']=dict(status='HOLD_OFFICIAL_6_VS_8_CONFLICT',allowManufacturingExport=False,evidence=cite('Lumberg1503_18',[2],'Circuit and PCB solder-side drawings'))
        c['detectionSwitch']=copy.deepcopy(data['findings'][0]['detection'])
        for p in c['pins']:
            oldnum=p['number']
            if oldnum=='DB':
                p['number']='7';p['legacyPinNumber']='DB';p['footprintPad']='7';p['pinAuditStatus']='VERIFIED_OFFICIAL'
                pin_deltas.append(dict(ref=ref,fromNumber='DB',toNumber='7',net=p['net']))
            elif oldnum=='DA':
                p['footprintPad']=None;p['physicalPinCandidates']=['6','8'];p['pinAuditStatus']='HOLD_CONFLICT'
            else:
                p['footprintPad']=oldnum;p['pinAuditStatus']='VERIFIED_OFFICIAL'
            p['electricalType']='passive'
            p['evidence']=cite('Lumberg1503_18',[2],'Circuit and PCB solder-side drawings')
            if p['net'] is None:p['intentionalNoConnect']=True;p['noConnectReason']='Detection unused on this jack; retain unconnected physical lands once correspondence is resolved.'
            rows.append(dict(ref=ref,nativeNumber=oldnum,number=p['number'],name=p['name'],net=p['net'] or '',footprintPad=p['footprintPad'] or '',status=p['pinAuditStatus'],source='Lumberg1503_18',pdfPages=2,section='Circuit and PCB solder-side drawings',sha256=source['Lumberg1503_18']['sha256'],ncReason=p.get('noConnectReason','')))
    c['auditFindingIds']=[f['id'] for f in data['findings'] if ref in f['refs']]
    records.append(c)
assert set(c['ref'] for c in records)==set(data['ownedRefs'])
save('corrected-components.json',records)
save('pin-identifier-deltas.json',pin_deltas)
with (OUT/'per-pin-audit.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

vbus=read(OUT/'vbus-handoff.json')
vbus['nativeSourceSha256']=sha(native_path)
vbus['sourceCitations']=[cite('ST_AN4879',[11],'2.6 and 2.6.1'),cite('STM32H743',[80,103,104,136,137,207,208,241,242],'Pin PA9 LQFP100 pin68; FT_u limits and GPIO thresholds for silicon rev Y/V')]
vbus['dividerReview']={
 'notAMechanicalPresenceSensor':True,
 'nominalRatio':.5,'rTolerancePercent':1,'inputLeakageA':350e-9,
 'minimumSenseAtSafeRail4V5':round(4.5*.495-350e-9*50500,6),
 'guaranteedByDesignGpioVihAtVdd3V46':round(.47*3.46+.25,6),
 'minimumSenseAtSafeRail3V67':round(3.67*.495-350e-9*50500,6),
 'conclusion':'100k/100k passes the H743 design-guaranteed extended GPIO VIH at >=4.5V protected rail (VDD<=3.46V, pulls disabled, stated leakage). It does not guarantee detection at 3.67V like the AN4879 recommended divider. The generic 0.7*VDD CMOS line alone would be too pessimistic for H743; both rows of its actual table were considered.',
 'rawFaultConnectionAllowed':False,'automaticLatchResetAllowed':False,'dividerValueChangeApplied':False
}
save('vbus-handoff.json',vbus)
data['findings'].append(dict(id='AUD-010',severity='P1',status='HOLD_NO_PHYSICAL_UNPLUG_DETECTOR',refs=['U801','J401','R816','R817','C820','U1001'],
    title='Post-eFuse PA9 voltage loss cannot clear the fault latch',
    evidence=vbus['sourceCitations'],observation='U801.68 PA9 samples USB_5V_SAFE through 100k/100k, not raw connector VBUS. R1701 ADC path also samples the protected node. Both go low on a latched eFuse trip with cable still attached. Even raw voltage absence alone is not physical unplug proof.',
    requiredAction='Honor parent policy: keep fault latched until human-confirmed inspection/reset plus a newly authorized session. Do not use voltage loss/reboot alone. AIN3 is reserved for charge ISET; no autonomous off-state USB wake is implemented. Details in vbus-handoff.json.'))
data['requiredChanges'].append(dict(id='CHANGE-A08',action='preserve_fault_latch_until_manual_reset_and_new_authorization',refs=['U801','R816','R817'],
    status='HANDOFF_TO_PARENT_NO_HARDWARE_PATCH',details='GPIO PA9 represents protected power available only. Leave source on USB_5V_SAFE. Do not claim raw VBUS or physical detach.'))
for finding in data['findings']:
    finding['evidence']=[cite(e['sourceId'],e['pdfPages'],e['section']) for e in finding['evidence']]
data['findings'][1]['evidence'].append(cite('STM32H743',[80,103,104,207,208],'FT_u D+/D- pad identification and absolute maximum/pull conditions'))
data['findings'][1]['observation']+=' H743 PA11/PA12 are FT_u: generic powered-pad absolute ceiling can reach 6V, but this leaves no margin to the specified protector maximum, does not establish active USB-PHY tolerance with pull-up enabled, and drops with unpowered supplies (4V bound at zero). It is not valid to call every MCU pin a fixed 3.6V pin, or to approve 6V at all power states.'
data['requiredChanges'][6]['requirements'].append('Post-eFuse VBUS_SENSE low is not unplug; no automatic fault-latch clearing. See vbus-handoff.json.')
save('findings-and-required-changes.json',data)
save('integration-contract.json',dict(
    correctedRecords='corrected-components.json',recordCount=len(records),ownedRefs=data['ownedRefs'],
    baseInput={'file':str(native_path.relative_to(ROOT)).replace('\\','/'),'sha256':sha(native_path)},
    referenceInput={'file':str(circuits_path.relative_to(ROOT)).replace('\\','/'),'sha256':sha(circuits_path)},
    mergePolicy='Replace ONLY owned refs by ref identity; apply explicit pin-identifier deltas to symbols and matching footprints together. Preserve logical nets and all other components. Passive/net additions are proposals, not silently applied.',
    nonphysicalPinGuard='Any footprintPad=null or footprintAudit status starting HOLD blocks fabrication. DA on the four jacks is deliberately not a physical pad.',
    footprintLibrary='footprints/SmartVio_Audio_Official.pretty',footprintSpecifications='footprint-specifications.json',
    sourceManifest='source-manifest.json',requiredChanges='findings-and-required-changes.json',vbusHandoff='vbus-handoff.json',
    productionRelease='HOLD',benchTestsPerformed=0,fullBoardDrcPerformed=False))

report=['SmartVio V25 independent audio and USB-interface audit',
        'STATUS: HOLD. Official pinouts verified does not mean the product is fabrication-ready.',
        'Scope: 13 owned references; no parent electrical file was modified.',
        f'Sources: {len(sources)} manufacturer PDF files, each SHA-256 recorded.',
        'Deliverables: corrected-components.json; per-pin-audit.csv; findings-and-required-changes.json;',
        'vbus-handoff.json; integration-contract.json; footprint-specifications.json; footprints/.',
        '', 'Priority findings:']
for f in data['findings']:
    report += ['',f'{f["id"]} {f["severity"]} {f["title"]} [{f["status"]}]',f['observation'],'Action: '+f['requiredAction']]
    report += ['Evidence: '+'; '.join(e['sourceId']+' PDF p'+','.join(map(str,e['pdfPages']))+' '+e['section'] for e in f['evidence'])]
report += ['', 'Verified exact copper geometries (custom transcriptions, not manufacturer-supplied CAD files):']
for name,fp in fps.items():report.append(f'{name}: {len(fp["pads"])} electrical pads; {fp["provenance"]["sourceId"]} pages {fp["provenance"]["pdfPages"]}. {fp["note"] or "Board placement, routing and assembly still need approval."}')
report += ['', 'No footprint is fabricated for the Lumberg jack while its contact numbering conflicts.',
           'RTE0016B/C are both supplied; U301 assignment remains HOLD until the procurement variant is identified.',
           'Manufacturing hold is retained for all components. A footprint-only DRC coupon cannot validate the complete board, power, protection, firmware, acoustics or sample assembly.',
           'No MIC/XLR/DOCK, pickup replacement, charging change, system-boundary change, or deletion of user functions was made.']
(OUT/'AUDIT-REPORT.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
print(json.dumps({'records':len(records),'pins':len(rows),'sources':len(sources),'footprintVariants':len(fps),'output':str(OUT)},indent=2))
