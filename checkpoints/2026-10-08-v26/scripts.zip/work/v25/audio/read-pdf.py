import json
import sys
from pathlib import Path
from pypdf import PdfReader

root = Path(__file__).resolve().parents[3]
source = root / 'outputs/SmartVio-V25-Engineering/audit/audio/sources'
textdir = Path(__file__).parent / 'pdf-text'
textdir.mkdir(exist_ok=True)
if len(sys.argv) == 1:
    for path in sorted(source.glob('*.pdf')):
        reader = PdfReader(path)
        pages = [page.extract_text(extraction_mode='layout') for page in reader.pages]
        (textdir / (path.stem + '.json')).write_text(json.dumps(pages, ensure_ascii=False, indent=2), encoding='utf-8')
        (textdir / (path.stem + '.txt')).write_text('\n'.join(f'\n===== PDF PAGE {i+1} =====\n{t}' for i,t in enumerate(pages)), encoding='utf-8')
        print(path.stem, len(pages))
else:
    pages = json.loads((textdir / (sys.argv[1] + '.json')).read_text(encoding='utf-8'))
    for selection in sys.argv[2:]:
        for page in map(int, selection.split(',')):
            print(f'===== PDF PAGE {page} =====\n{pages[page-1]}')
