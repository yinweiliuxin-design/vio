import copy
import hashlib
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'outputs/SmartVio-V25-Engineering/audit/audio'
SUB = OUT / 'supplemental'
SUB.mkdir(exist_ok=True)
NATIVE = ROOT / 'outputs/SmartVio-V25-Engineering/electrical/native-components.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, data):
    # Replace a complete artifact, never a partially serialized file.
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    os.replace(temp, path)


native = read(NATIVE)
byref = {c['ref']: c for c in native}
assert len(byref) == len(native)
snapshot = {'path': str(NATIVE.relative_to(ROOT)).replace('\\', '/'), 'sha256': sha(NATIVE),
            'components': len(native), 'capturedAtUtc': datetime.now(timezone.utc).isoformat()}
source_urls = {
    'Panasonic_AQY221R2VY': 'https://api.pim.na.industrial.panasonic.com/file_stream/main/fileversion/279337',
    'PMV30UN2': 'https://assets.nexperia.com/documents/data-sheet/PMV30UN2.pdf',
    'Nexperia_2N7002': 'https://assets.nexperia.com/documents/data-sheet/2N7002.pdf',
    'GCT_USB4120': 'https://gct.co/files/drawings/usb4120.pdf',
    'Kycon_STX353K7A': 'https://www.kycon.com/Pub_Eng_Draw/STX-353K7A-6N-KTTR.pdf',
    'Kycon_STX3790': 'https://www.kycon.com/Pub_Eng_Draw/STX-3790-5N.pdf',
    'Lumberg1503_18_current': 'https://downloads.lumberg.com/datenblaetter/en/1503_18.pdf',
    'Lumberg1503_18_de': 'https://downloads.lumberg.com/datenblaetter/de/1503_18.pdf',
    'PUI_AS01808AO_SC18_WP_R': 'https://api.puiaudio.com/filename/AS01808AO-SC18-WP-R.pdf',
    'TLV9064': 'https://www.ti.com/lit/ds/symlink/tlv9064.pdf',
    'TPA6132A2': 'https://www.ti.com/lit/ds/symlink/tpa6132a2.pdf',
    'PCM1864': 'https://www.ti.com/lit/ds/symlink/pcm1864.pdf',
    'PCM5102A': 'https://www.ti.com/lit/ds/symlink/pcm5102a.pdf',
    'MAX98357A': 'https://www.analog.com/media/en/technical-documentation/data-sheets/max98357a-max98357b.pdf',
    'STM32H743': 'https://www.st.com/resource/en/datasheet/stm32h743vi.pdf',
}
sources = []
for name, url in source_urls.items():
    path = OUT / 'sources' / (name + '.pdf')
    assert path.read_bytes().startswith(b'%PDF'), name
    sources.append({'id': name, 'url': url, 'file': 'sources/' + path.name, 'sha256': sha(path),
                    'bytes': path.stat().st_size, 'publisherOrigin': 'official_manufacturer',
                    'retrievalTimeUtcFromFile': datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
ordering = OUT / 'sources/PMV30UN2_ordering-capture.json'
sources.append({'id': 'PMV30UN2_ordering', 'url': 'https://www.nexperia.com/chemical-content/PMV30UN2.html',
                'file': 'sources/' + ordering.name, 'sha256': sha(ordering), 'bytes': ordering.stat().st_size,
                'publisherOrigin': 'official_manufacturer_web_extraction', 'captureKind': 'structured transcription, not original HTML',
                'hashScope': 'local structured evidence capture only', 'exactOrderable': 'PMV30UN2R', '12NC': '934068491215'})
assert 'PMV30UN2R' in ordering.read_text(encoding='utf-8-sig')
source_by_id = {s['id']: s for s in sources}


def evidence(name, pages, section):
    src = source_by_id[name]
    return {'sourceId': name, 'pdfPages': pages, 'section': section, 'url': src['url'],
            'sha256': src['sha256'], 'sourceFile': src['file']}


ssr_e = evidence('Panasonic_AQY221R2VY', [2, 4, 11], 'ASCTB471E 202610; orderable table, ratings, electrical table, schematic and TOP VIEW mounting pads')
q_e = evidence('PMV30UN2', [2, 6, 10, 11], 'Rev1 24Apr2014 Tables2/7, SOT23 outline and Fig19 reflow land')
usb_e = evidence('GCT_USB4120', [1, 2], 'USB4120 A6 29Oct2024 ordering USB4120-03-C; terminal table and recommended PCB layout')
owned = ['K120' + str(i) for i in range(1, 8)] + ['Q1201', 'J401', 'U601']
records = [copy.deepcopy(byref[r]) for r in owned]
pin_rows = []
for c in records:
    c['release'] = 'HOLD'
    c['auditSnapshot'] = snapshot
    c['verificationScope'] = 'Official-source pin/configuration evidence and analytical calculations only; not PCB, sample, bench or production release.'
    if c['ref'].startswith('K'):
        c['package'] = 'Panasonic SSOP4; 4.45x2.65mm nominal body, 1.8mm nominal height, general tolerance +/-0.1mm; lead span4.85mm reference'
        c['pinAuditStatus'] = 'VERIFIED_OFFICIAL'
        c['exposedPadAudit'] = {'present': False, 'extraNcPins': [], 'evidence': ssr_e}
        c['loadTerminals'] = '3 and4 are nonpolar AC/DC switch terminals; LOAD_A/B are local names, not polarity.'
        c['footprint'] = 'SmartVio_Audio_Official:Panasonic_SSOP4_PhotoMOS_Official'
        c['footprintAudit'] = {'status': 'VERIFIED_OFFICIAL_COPPER_LAND', 'assemblyRelease': 'HOLD',
                              'file': 'footprints/SmartVio_Audio_Official.pretty/Panasonic_SSOP4_PhotoMOS_Official.kicad_mod', 'evidence': ssr_e}
        pe = ssr_e
    elif c['ref'] == 'Q1201':
        c['value'] = c['mpn'] = 'PMV30UN2R'
        c['candidateManufacturer'] = 'Nexperia'
        c['package'] = 'SOT23 (TO-236AB); exact OPN PMV30UN2R, 12NC934068491215'
        c['pinAuditStatus'] = 'VERIFIED_OFFICIAL'
        c['exposedPadAudit'] = {'present': False, 'extraNcPins': [], 'evidence': q_e}
        c['selectionStatus'] = 'PROPOSED_FOR_PARENT_APPROVAL_NOT_APPLIED_TO_NATIVE'
        c['netlistChanges'] = []
        c['footprintAudit'] = {'status': 'SAME_SOT23_PACKAGE_AND_PIN_MAPPING_EXISTING_LAND_COMPARISON_REQUIRED',
                              'reason': 'Do not move existing SOT23 pads. Manufacturer Fig19 is supplied, but the existing board footprint was not independently compared here.', 'evidence': q_e}
        c['orderingEvidence'] = source_by_id['PMV30UN2_ordering']
        pe = q_e
    elif c['ref'] == 'J401':
        assert c['mpn'] == 'USB4120-03-C'
        c['package'] = 'GCT USB4120 vertical USB2 Type-C16 contacts, H6.5mm; official PCB thickness1.00+/-0.10mm'
        c['pinAuditStatus'] = 'VERIFIED_OFFICIAL_CONTACTS_AND_SHELL_BINDING'
        c['exposedPadAudit'] = {'present': False, 'extraNcPins': [], 'evidence': usb_e}
        c['shellPhysicalBinding'] = {'logicalSymbolPin': 'SH', 'manufacturerTerminal': 'SHELL', 'net': 'GND',
                                    'physicalStakes': 4, 'footprintPadNumbers': ['SH'] * 4,
                                    'note': 'SH is a local aggregate ID. Do not invent official S1/S2/S3/S4 pin numbers.'}
        c['footprint'] = 'SmartVio_Audio_Official:GCT_USB4120_Official_A6'
        c['footprintAudit'] = {'status': 'VERIFIED_DRAWING_CONTACT_LANDS_AND_DRILLS_LAYOUT_VIEW_AND_BOARD_STACKUP_HOLD',
                              'file': 'footprints/SmartVio_Audio_Official.pretty/GCT_USB4120_Official_A6.kicad_mod',
                              'assemblyRelease': 'HOLD', 'requiredBoardThicknessMm': [0.9, 1.1],
                              'note': 'Coordinates transcribed as depicted in recommended PCB layout. Parent must check package orientation/mating axis against mechanical model and assembly view before CAM.', 'evidence': usb_e}
        pe = usb_e
    else:
        c['serialInterfaceContract'] = 'audit/audio/pcm1864-dual-dout-contract.json, schema v2; masked input-select writes0xBF preserve bit6'
        c['requiredFirmwareFix'] = {'registers': ['0x06', '0x07', '0x08', '0x09'], 'mask': '0xBF',
                                    'values': ['0x01', '0x01', '0x04', '0x00'], 'resetPreservingBytes': ['0x41', '0x41', '0x44', '0x40']}
        continue
    for p in c['pins']:
        p['manufacturerNumber'] = 'SHELL' if p['number'] == 'SH' else p['number']
        p['footprintPad'] = p['number']
        p['pinAuditStatus'] = 'VERIFIED_OFFICIAL'
        p['evidence'] = pe
        p['electricalType'] = 'passive'
        if c['ref'].startswith('K'):
            p['name'] = {'1': 'LED_A', '2': 'LED_K', '3': 'LOAD_A', '4': 'LOAD_B'}[p['number']]
        if p['net'] is None:
            p['intentionalNoConnect'] = True
            p['noConnectReason'] = 'SBU contact unused in USB2-only design; no alternate mode or dock.'
        pin_rows.append({'ref': c['ref'], **p})
assert len(pin_rows) == 48
for c in records:
    assert [(p['number'], p['net']) for p in c['pins']] == [(p['number'], p['net']) for p in byref[c['ref']]['pins']]

footprints = OUT / 'footprints/SmartVio_Audio_Official.pretty'
footprints.mkdir(parents=True, exist_ok=True)


def footprint(name, description, pads, courtyard):
    lines = ['(footprint "' + name + '" (version 20240108) (generator "smartvio_audio_audit") (layer "F.Cu")',
             '  (descr "' + description + '")',
             '  (fp_text reference "REF**" (at 0 -3.5) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))',
             '  (fp_text value "' + name + '" (at 0 3.5) (layer "F.Fab") (effects (font (size 1 1) (thickness 0.15))))']
    for number, kind, shape, x, y, w, h, drill in pads:
        dr = '' if drill is None else (' (drill ' + drill + ')')
        layers = '"F.Cu" "F.Paste" "F.Mask"' if kind == 'smd' else '"*.Cu" "*.Mask"'
        lines.append(f'  (pad "{number}" {kind} {shape} (at {x} {y}) (size {w} {h}){dr} (layers {layers}))')
    x, y = courtyard
    lines.append(f'  (fp_rect (start {-x} {-y}) (end {x} {y}) (stroke (width 0.05) (type default)) (layer "F.CrtYd"))')
    lines.append(')')
    path = footprints / (name + '.kicad_mod')
    temp = path.with_suffix('.kicad_mod.tmp')
    temp.write_text('\n'.join(lines) + '\n', encoding='ascii')
    os.replace(temp, path)
    return path


ssr_pads = [(n, 'smd', 'rect', x, y, 0.9, 0.7, None) for n, x, y in
            [('1', -2.175, -0.635), ('2', -2.175, 0.635), ('3', 2.175, 0.635), ('4', 2.175, -0.635)]]
ssr_fp = footprint('Panasonic_SSOP4_PhotoMOS_Official', 'ASCTB471E202610 p11 TOP VIEW copper pads; mask/paste same as copper is a project default, not manufacturer process approval.', ssr_pads, (2.95, 1.7))
usb_pads = []
xs = [-2.75, -1.25, -0.75, -0.25, 0.25, 0.75, 1.25, 2.75]
for row, y in [(('A1', 'A4', 'A5', 'A6', 'A7', 'A8', 'A9', 'A12'), -0.865),
               (('B12', 'B9', 'B8', 'B7', 'B6', 'B5', 'B4', 'B1'), 0.865)]:
    usb_pads += [(n, 'smd', 'rect', x, y, 0.30, 0.87, None) for n, x in zip(row, xs)]
usb_pads += [('SH', 'thru_hole', 'oval', x, y, 1.35, 1.10, 'oval 0.85 0.60') for x in (-2.4, 2.4) for y in (-2.15, 2.15)]
usb_pads += [('', 'np_thru_hole', 'circle', -3.75, 0, 0.52, 0.52, '0.52'),
             ('', 'np_thru_hole', 'oval', 3.75, 0, 0.72, 0.52, 'oval 0.72 0.52')]
usb_fp = footprint('GCT_USB4120_Official_A6', 'GCTUSB4120 A6 p2 recommended PCB layout as depicted; PCB1.00+/-0.10mm; orientation and stackup HOLD.', usb_pads, (5.0, 2.95))
for c in records:
    if c['ref'].startswith('K'):
        c['footprintAudit']['sha256'] = sha(ssr_fp)
    elif c['ref'] == 'J401':
        c['footprintAudit']['sha256'] = sha(usb_fp)

vmin = 3.258102857142858 - 0.0312
vnom = 3.296
vmax = 3.3340069669669665 + 0.0312
gate_min = (vmin - 0.4) * 99000 / (99000 + 1010) - 1e-7 * (99000 * 1010 / 100010)
if_min = (vmin - 1.5) / (272.7 + 7 * 0.043)
if_typ = (vnom - 1.14) / (270 + 7 * 0.043)
total_max = 7 * vmax / 267.3
q_calc = {'status': 'ANALYTICAL_25C_STATIC_MARGIN_ONLY_FULL_TEMPERATURE_AND_DYNAMIC_RAIL_HOLD',
          'railBasis': 'Parent audit/power/calculations.json: static min/typ/max plus +/-31.2mV feedback-leakage allowance. Not a new power audit or a transient guarantee.',
          'provisionalV3dV': [vmin, vnom, vmax], 'gateVMinUsingMcuVohVddMinus0p4AndDividerTolerance': gate_min,
          'mcuVohEvidence': evidence('STM32H743', [139, 243], 'Tables51/148 VOH >=VDD-0.4V at2.7..3.6V,8mA'),
          'resistorsUnchanged': {'R1201..R1207': '270ohm1%', 'R1210': '1kohm1%', 'R1211': '100kohm1%'},
          'ledCurrentMinEachMaConditionalVfLe1p5At25C': if_min * 1000,
          'ledCurrentTypicalEachMaUsingVfAt5mA': if_typ * 1000,
          'ledCurrentTypicalCaveat': 'VF1.14V is typical at5mA; actual7-8mA current is nonlinear and not guaranteed. VFmax1.5V table is measured at50mA,25C, used conservatively assuming monotonic LED I-V.',
          'totalCurrentUpperMaWithoutInventingVfMinimum': total_max * 1000,
          'sinkRdsMaxOhmAtVgs2p5V25C': 0.043,
          'sinkVdsUpperV25C': total_max * 0.043, 'sinkDissipationUpperW25C': total_max**2 * 0.043,
          'eachLedResistorUpperPowerWAt3p6VIgnoringVf': 3.6**2 / 267.3,
          'requiredV3dMinFor5mAUsingVf1p5AndRds0p043': 1.5 + 0.005 * (272.7 + 7 * 0.043),
          'rejectedPart': 'Nexperia2N7002 Rev7 p5 only gives maximumRDSon at4.5V and10V. VGSth is not adequate sink-current proof at3.3V.',
          'pmvPublishedMaximums25C': [{'vgs': 2.5, 'rdsOhm': 0.043, 'testA': 3.7}, {'vgs': 1.8, 'rdsOhm': 0.059, 'testA': 1}, {'vgs': 1.5, 'rdsOhm': 0.1, 'testA': 0.1}],
          'holds': ['Low-VGS RDS maxima specified25C; full-temperature maximum is published only at4.5V, not our gate voltage.',
                    'Rail dynamic/startup envelope must stay within the input/LED budget; no waveform test exists.',
                    'PORT_ENABLE source driver and turn-on sequencing must be implemented and checked. Seven LED load is roughly50-60mA, not negligible rail load.'], 'hardwareTests': 0}

gain_line = 10000 / (15000 + 10000)
gain_ret = 10000 / (22000 + 10000)
rin_hp = 26400
rhp_load = 1 / (1 / 10000 + 1 / rin_hp)
gain_hp = rhp_load / (22000 + rhp_load) * 0.5
ssr_hp_div = 32 / (32 + 1.25)
functions = {
    'LINEOUT_TRS_TO_TS': {'status': 'PROVEN_CONNECTIVITY_RIGHT_MUTED_NOT_MONO_SUM_SHORT_DISTORTION_AND_POP_HOLD',
        'path': 'U201.7 -> C212 -> R212220ohm -> K1204 -> J201.3RING; TS groundsRING.',
        'noHardOpampShort': True, 'automaticMonoSumming': False,
        'resistorsRecommendation': 'Keep R211/R212220ohm1% >=0.1W for now; do not short TIP/RING together. No resistor edit authorized/applied.',
        'nominalLineDividerGain': gain_line, 'nominalDacFullscaleVrms': 2.1,
        'nominalBufferFullscaleVrms': 2.1 * gain_line, 'nominalTsGroundedRightCurrentPeakMaIgnoringSsrRon': math.sqrt(2) * 2.1 * gain_line / 220 * 1000,
        'nominalR212SineDissipationWIntoShort': (2.1 * gain_line)**2 / 220,
        'couplingCapStartupWorstRailStepAt3p6VThroughMinRPeakMa': 3.6 / 217.8 * 1000,
        'limitCaveat': '220ohm prevents an unlimited direct short but this is not the10kohm opamp electrical-characteristic test load. Loaded THD, two-channel faults, heat and hot-plug pop need qualification. TLV9064 continuous output-short absmax footnote covers one amplifier/package only, not both.',
        'firmwareProposal': 'User-selectable mono-TS profile: calculate0.5*(L+R) with saturation/headroom, output that onTIP, muteR. No reliable TS/TRS discrimination exists on current unusedJ201 detect switch.',
        'evidence': [evidence('TLV9064', [10, 13, 14], '6.1 footnote3,6.10 output swing/test loads and typical short current'), evidence('PCM5102A', [1, 10], 'Nominal2.1Vrms output and performance conditions')]},
    'AUX_RETURN_LEVEL_AND_TS': {'status': 'ACTIVE_EFFECT_LOW_Z_COMPATIBILITY_CONDITIONAL_PASSIVE_INSTRUMENT_AND_AUTOMONO_NOT_SUPPORTED',
        'inputImpedanceNominalOhm': 32000, 'dividerGain': gain_ret, 'dividerDb': 20 * math.log10(gain_ret),
        'externalCouplingHpfHz': 1 / (2 * math.pi * 4.7e-6 * 32000), 'adcCouplingHpfHzTyp10kInput': 1 / (2 * math.pi * 1e-6 * 10000),
        'consumerMinus10dBV': {'sourceVrms': 10**(-10 / 20), 'adcVrmsAt0dBGain': 10**(-10 / 20) * gain_ret},
        'exampleInstrument100mVrmsAtPga0dB': {'adcVrms': 0.1 * gain_ret, 'dbfsUsing2p1VrmsFS': 20 * math.log10(0.1 * gain_ret / 2.1)},
        'portVoltsForAdcFullscaleAt0dB_NOT_BUFFER_SAFE': 2.1 / gain_ret,
        'bufferRailHeadroomIllustrativeOnly': 'VMID~1.65V: symmetric1.50Vpeak engineering allowance -> port~3.39Vrms maximum through0.3125 divider. Not a guaranteed swing at3.3V, actual ADC input load10kohm and temperature.',
        'ts': 'TS sleeve groundsRING. Left path remains AC-coupled and biased; right becomes audio-silent, not mirrored. Explicit mono-return-L routing required; do not average with silentR or retain a stereo assumption.',
        'instrumentCaveat': '32kohm is acceptable only for a qualified low-Z active-effect output. It is NOT a high-Z passive-instrument input; true-bypass effect can expose the passive source. Existing bridge pickup high-Z chain remains separate and unchanged.',
        'passiveRecommendation': 'Keep R231/R23222kohm and R241/R24210kohm for line/active-effect profile; no automatic high-Z resistor rewrite because noise/headroom/EMI would change.',
        'gainProposalsNotApplied': [{'profile': 'Line', 'gainDb': 0, 'page0Register02and03Value': '0x00', 'portVrmsForAdcFS': 6.72, 'caveat': 'Buffer clips before this theoretical ADC ceiling.'},
                                   {'profile': 'Active-effect nominal', 'gainDb': 10, 'page0Register02and03Value': '0x14', 'portVrmsForAdcFS': 2.1 / gain_ret / 10**0.5},
                                   {'profile': 'Low-level active-effect', 'gainDb': 20, 'page0Register02and03Value': '0x28', 'portVrmsForAdcFS': 2.1 / gain_ret / 10}],
        'gainRules': 'Global channel PGA2.1 format7.1; ADC1R=RETURN-L register02, ADC2L=RETURN-R register03. Keep PGA_LINK bit6 in register05=0 or all gains follow pickup. At+20dB a1Vrms line source exceeds ADCFS: no automatic high gain without profile/headroom/clipping controls. No newMIC feature.',
        'evidence': evidence('PCM1864', [13, 89, 90], '7.5 single-ended2.1VrmsFS,10kohm input;13.3.1..5 globalgain and independent gain link')},
    'SSR_HEADPHONE_AND_OTHER_LOADS': {'status': 'NORMAL_32OHM_CURRENT_SMALL_RON_LOSS_FAULT_PEAK_AND_TEMP_DISTORTION_HOLD',
        'aqy221r2': {'loadVoltageMaxV': 40, 'loadContinuousPeakAcDcA25C': 0.25, 'single100msDcPulseA': 0.75, 'outputPowerMaxW25C': 0.25,
                    'ronTypicalOhm25C': 0.75, 'ronMaxOhm25C': 1.25, 'ronTest': 'IF5mA IL250mA within1s at25C', 'offCapMaxPf': 18,
                    'turnOnMaxMs25C': 0.5, 'turnOffMaxMs25C': 0.2},
        '32ohmSsrOnlyMaxRonAmplitudeRatio': ssr_hp_div, '32ohmSsrOnlyMaxRonLossDb': 20 * math.log10(ssr_hp_div),
        '32ohmSsrOnlyMaxRonPowerRatio': ssr_hp_div**2,
        'example22mWAt32ohmFromTpaTypTable': {'vrms': math.sqrt(0.022 * 32), 'peakCurrentMa': math.sqrt(2 * 0.022 / 32) * 1000, 'ssrDissipationW': 0.022 / 32 * 1.25},
        'currentNativeHeadphoneLoadedDividerGainIncludingTpaMinus6dB': gain_hp,
        'nativeHeadphoneOutputVrmsAtDacFS2p1AndSsrMaxRon': 2.1 * gain_hp * ssr_hp_div,
        'nativeHeadphoneOutputMw32ohm': (2.1 * gain_hp * ssr_hp_div)**2 / 32 * 1000,
        'headphoneGainRecommendation': 'Keep current-6dB/pad for safety until calibrated loudness target; do not increase gain just to compensate0.33dB SSR loss. Current output roughly2.0mW/ch nominal with published typical26.4kohm TPA input loading; this may be quiet for inefficient headphones.',
        'lineSend': '220ohm source resistors dominate0.75..1.25ohm SSR contribution; normal high-Z line loads are not a250mA issue.',
        'return': '~32kohm divider load gives negligible SSR on-resistance error; hot-plug, power-off and overvoltage clamp not established by this.',
        'fault': 'TPA specifies short/thermal protection but no guaranteed maximum short-circuit current in the selected datasheet. Therefore its protection does NOT prove AQY221R2V peak current below250mA. Do not apply750mA100ms single-shot DC rating to repeated AC shorts.',
        'faultCandidatesNotApplied': [{'candidate': 'K1201/K1202 -> AQY221R6VY only', 'samePinsAndOfficialLand': True, 'loadA25C': 1.0, 'ronMaxOhm25C': 0.35, 'voltageV': 30, 'offCapMaxPf': 100, 'status': 'PROPOSAL_ONLY_REQUIRES_PARENT_APPROVAL_AND_SHORT_CURRENT_TEMPERATURE_PROOF'},
                                      {'candidate': '10ohm or22ohm series per HP channel', 'additionalLossAt32ohmWithExisting1p25ohmDb': [20 * math.log10(32 / (32 + r + 1.25)) for r in (10, 22)],
                                       'status': 'NOT_APPLIED_CHANGES_AUDIO_DRIVE_AND_PCB', 'caveat': 'Must budget maximum output voltage, resistor fault power/pulse, temperature derating and loudness; no exact MPN selected.'}],
        'dynamic': 'RON value is not a guaranteed audio THD/noise specification. Ron changes with current/temp; off-stateC and PCB coupling can leak signals. Common gate enables all7switches; no per-port automatic isolation. Need all-source mute/settle sequencing and zero-cross/ramped switching test.',
        'evidence': [ssr_e, evidence('Panasonic_AQY221R2VY', [8], 'CXR10 load-current and Ron temperature plots; typical characteristic plots are not full-temperature max guarantees'), evidence('TPA6132A2', [1, 5, 10, 12, 13], 'Output power/inputZ/gain; short circuit block; enable/source sequencing')]}
}

jack_review = {'status': 'HOLD_BLOCKS_WHOLE_INSTRUMENT_PRODUCTION_CAM', 'refs': ['J102', 'J201', 'J202', 'J301'],
    'verifiedAudioPins': {'1': 'SLEEVE', '2': 'TIP', '3': 'RING'},
    'unresolvedContact': {'logical': 'DA', 'circuitDiagram': '8', 'solderSideLandDrawing': '6', 'otherTerminal': '7'},
    'proof': [evidence('Lumberg1503_18_current', [2], '07/2025 English circuit and solder-side drawing disagree'), evidence('Lumberg1503_18_de', [2], '07/2025 German drawing repeats6vs8 conflict')],
    'decision': 'No official unambiguous electrical-to-pad mapping found. Do not alias6=8, export a guessed DA land or treat unused detection as absent physical lead. Existing four jack records remainHOLD.',
    'candidate': {'mpn': 'STX-353K7A-6N-KTTR', 'manufacturer': 'Kycon', 'selected': False, 'drawingRevision': 'A1 17Aug2016',
                  'bodyDimensionsMmFromViews': {'axialBody': 12.5, 'frontWidth': 7.65, 'frontHeight': 9.4},
                  'notDropIn': True, 'status': 'CLEAR_DRAWING_SMALLER_CANDIDATE_TRS_COMPATIBILITY_AND_PANEL_PCB_HOLD',
                  'pinMapFor4polePlug': {'2': 'SLEEVE', '1': 'RING2', '3': 'RING1', '4': 'TIP', '5': 'isolated switch', '6': 'isolated switch'},
                  'trsProposal': 'Tie pins2/1 toGND, map3 toexistingRING,4 toexistingTIP. Extra sleeve contact does not createMIC/XLR/DOCK. Manufacturer drawing shows4pole plug, not an explicit TRS-compatibility rating; keep HOLD until mating dimensions/contact action are qualified.',
                  'detectProposal': 'Isolated5/6 shown open unplugged; close on insertion. J301 pin5=HP_DETECT_RAW, pin6=GND (pair nonpolar). Proposed active-low insertion reverses current firmware detection polarity. Other3jacks5/6NC.',
                  'footprint': 'Six1.00x0.60 plated slots shown; no exact copper annulus drawing. Requires new parent footprint/panel/board-stress review; not a same-pad substitution.',
                  'evidence': evidence('Kycon_STX353K7A', [1], 'Pin-labeled top-view PCB layout and unplugged/plug-in schematics')},
    'rejectedAlternative': {'mpn': 'STX-3790-5N', 'reason': 'Tip/ring break contacts are electrically part of audio contacts, not an isolated plug-detect pair; cannot ground them without altering/shorting audio.', 'evidence': evidence('Kycon_STX3790', [1], 'Schematic')},
    'manufacturerContacted': False, 'physicalSamplesTested': 0}

speaker = {'mpn': 'AS01808AO-SC18-WP-R', 'refCandidate': 'LS901', 'selected': False, 'status': 'PROPOSAL_ONLY_MECHANICAL_AND_ACOUSTIC_HOLD',
           'officialDrawing': {'widthMm': 13, 'lengthMm': 18, 'widthLengthToleranceMm': 0.15, 'bodyThicknessMm': 2.5,
                               'bodyThicknessToleranceMm': 0.2, 'workingPositionHeightMm': 2.8, 'workingHeightToleranceMm': 0.2},
           'importantCorrection': '2.5mm describes body thickness, not installed working position; budget2.8+/-0.2mm plus mounting/compression/cavity tolerances.',
           'speakerElectrical': {'impedanceOhm': 8, 'impedanceTolerancePercent': 15, 'ratedW': 1, 'maxW': 1.2, 'coilInductanceMh': 0.008, 'resonanceHz': 420},
           'contacts': {'manufacturerNumbering': 'Unnumbered +/- contacts; local1/2 binding must be defined explicitly, not claimed manufacturer pin numbers.', 'drawingPositive': 'bottom contact in the far-right p4 view', 'networkProposal': 'plus->SPK_P,minus->SPK_N; no grounding either BTL terminal'},
           'acousticRatingConditions': '1cc back cavity; SPL1W10cm averaged0.8/1/1.2/1.5kHz;1W load reliability uses850Hz HPF12dB/oct or steeper. Not proof of1W full violin-band operation or assembled waterproofing.',
           'proposal': 'Do not replace selected LS901 geometry or increase firmware limit automatically. It needs18x13mm mounting/contact compression and1cc cavity, not the old10mm diameter pocket.850Hz HPF would attenuate violin fundamentals includingG3~196Hz, and affects speaker branch only.',
           'powerProtection': 'Keep existing conservative limiter pending selected speaker thermal/excursion/acoustic qualification. PUI8ohm-15% lower load is6.8ohm. MAX gain tolerance, DAC gain, crest factor, clipping and filter must be budgeted;1W rating is not a voltage-independent permission to raise gain.',
           'footprint': 'Manufacturer p4 contact pattern is explicitly Reference, spring contacts; not an independently qualified solder-land footprint.',
           'evidence': evidence('PUI_AS01808AO_SC18_WP_R', [1, 3, 4, 5], 'RevC09Dec2024 ratings, reliability conditions, body/working height and polarity'), 'hardwareTests': 0}

contract_path = OUT / 'pcm1864-dual-dout-contract.json'
contract = read(contract_path)
for address, value in zip(('0x06', '0x07', '0x08', '0x09'), ('0x01', '0x01', '0x04', '0x00')):
    entry = next(x for x in contract['page0RegisterIntent'] if x['address'] == address)
    assert entry['mask'] == '0xBF' and entry['value'] == value
pin_net = lambda ref, number: next(p['net'] for p in byref[ref]['pins'] if p['number'] == number)
assert pin_net('U601', '21') == pin_net('R691', '1') == 'ADC_DATA2_SRC'
assert pin_net('R691', '2') == pin_net('U801', '2') == 'ADC_DATA2'
assert pin_net('U601', '18') == pin_net('U801', '5') == 'ADC_DATA'
fw_path = ROOT / 'outputs/SmartVio-V25-Engineering/firmware/contracts/adc-dual-i2s.json'
fw = read(fw_path)
fw_inputs = [x for x in fw['pcm1864Intent']['page0'] if x['address'] in ('0x06', '0x07', '0x08', '0x09')]
fw_fix_present = all(x['mask'] == '0xBF' for x in fw_inputs) and len(fw_inputs) == 4
dual = {'status': 'FRAME_CLOCK_AND_CURRENT_LOGICAL_NETS_CONSISTENT_FIRMWARE_RESERVED_BIT_FIX_REQUIRED' if not fw_fix_present else 'LOGICAL_FRAME_CLOCK_AND_CORRECTED_REGISTER_CONTRACT_CONSISTENT_DRIVER_HOLD',
        'audioContract': {'file': 'pcm1864-dual-dout-contract.json', 'sha256': sha(contract_path), 'schema': contract['schemaVersion']},
        'firmwareContract': {'file': str(fw_path.relative_to(ROOT)).replace('\\', '/'), 'sha256': sha(fw_path), 'reservedBitFixPresentAtSnapshot': fw_fix_present},
        'frame': {'lanes': 2, 'frameBitsPerLane': 64, 'slotsPerLane': 2, 'slotWidthBits': 32, 'adcPayloadBits': 24, 'activeChannels': ['pickup', 'AUX-L', 'AUX-R'], 'fourthChannel': 'muted', 'sampleHz': 48000, 'bclkHz': 3072000, 'sckiHz': 24576000, 'sckiFs': 512},
        'gpio': {'pin': 'U601.21', 'function': 'GPIO1 DOUT2', 'net': 'ADC_DATA2_SRC', 'sourceR': 'R69133ohm', 'mcu': 'U801.2 PE3AF6SAI1_SD_B'},
        'gpioRegisters': [{'page': 0, 'address': '0x10', 'mask': '0xF0', 'value': '0x50', 'resetPreservingByte': '0x51'}, {'page': 0, 'address': '0x15', 'mask': '0x20', 'value': '0x20'}],
        'inputRegistersCorrection': {'mask': '0xBF', 'registers': ['0x06', '0x07', '0x08', '0x09'], 'values': ['0x01', '0x01', '0x04', '0x00'], 'resetPreservingBytes': ['0x41', '0x41', '0x44', '0x40'], 'evidence': evidence('PCM1864', [91, 92, 93, 94], 'Tables32-35 bit6RSV resets1 Do not access')},
        'clockAndMixer': 'TI9.3.16.3p58;512fs auto clock Table10p41;0x20maskF1value41,0x0Bmask1Fvalue00,0x0Cmask03value00,0x0D00. Unity4.20x100000 at virtual00/07/0E/15, allother00..17zero via bounded page1 arbiter protocol, readback.0x71mask8Fvalue08, setup0F. Full protocol retained in v2 contract.',
        'timing': contract['analyticalTiming'], 'driverImplemented': fw['saiIntent']['driverImplemented'], 'hardwareTests': 0,
        'firmwareOwnerNotified': '01a105da-8353-7601-99e8-2a10fd186631', 'release': 'HOLD_LAYOUT_SI_DRIVER_READBACK_AND_EVT'}
assert fw['frame']['bclkHz'] == contract['serial']['BCLK_Hz'] == 48000 * 2 * 32
assert fw['frame']['sckiHz'] == contract['serial']['SCKI_Hz'] == 48000 * 512

proposals = [
    {'id': 'SUP-Q1201', 'status': 'PROPOSAL_PARENT_APPROVAL_REQUIRED', 'operation': 'replace_component_metadata', 'refs': ['Q1201'],
     'before': {'mpn': '2N7002'}, 'after': {'mpn': 'PMV30UN2R', 'manufacturer': 'Nexperia', 'package': 'SOT23'}, 'pinNetDeltas': [],
     'footprintGeometryChange': False, 'parentPcbAction': 'Approve exact MPN and compare existing SOT23 footprint with official SOT23 outline/land, without moving pads. No production release from logical reuse alone.'},
    {'id': 'SUP-K-FOOTPRINT', 'status': 'VERIFIED_LAND_PARENT_COORDINATION_REQUIRED', 'operation': 'bind_verified_footprint_candidate', 'refs': ['K1201', 'K1202', 'K1203', 'K1204', 'K1205', 'K1206', 'K1207'],
     'pinNetDeltas': [], 'footprint': 'SmartVio_Audio_Official:Panasonic_SSOP4_PhotoMOS_Official', 'parentPcbAction': 'Compare/rebind source geometry with PCB owner; do not overwrite routed board. Mask/paste defaults and assembly validation remainHOLD.'},
    {'id': 'SUP-J401-FOOTPRINT', 'status': 'VERIFIED_GEOMETRY_ORIENTATION_STACKUP_HOLD', 'operation': 'bind_verified_footprint_candidate', 'refs': ['J401'], 'mpnUnchanged': 'USB4120-03-C',
     'pinNetDeltas': [], 'footprint': 'SmartVio_Audio_Official:GCT_USB4120_Official_A6', 'parentPcbAction': 'Verify orientation, all4SH stakesGND, asymmetrical locating holes,0.9..1.1mm PCB thickness and panel; existing1.6mm board is not approved by drawing.'},
    {'id': 'SUP-PCM-RSV', 'status': 'PROVEN_FIRMWARE_CONTRACT_CORRECTION_COORDINATED', 'operation': 'masked_firmware_register_intent', 'refs': ['U601'], 'pinNetDeltas': [],
     'registers': dual['inputRegistersCorrection'], 'parentPcbAction': 'None; logic/R691/PE3 nets already present. Firmware owner handles contract fix.'},
    {'id': 'SUP-JACK-ALT', 'status': 'PROPOSAL_ONLY_NOT_SELECTED', 'operation': 'conditional_jack_replacement', 'refs': jack_review['refs'],
     'beforeMpn': '1503 18', 'candidateMpn': 'STX-353K7A-6N-KTTR', 'details': 'Seejack-contact-review.json; new6contact symbol/pads, TRS compatibility, panel and reversed detect polarity all require approval. Do not apply automatically.'},
    {'id': 'SUP-HP-FAULT', 'status': 'PROPOSAL_ONLY_NOT_SELECTED', 'operation': 'evaluate_headphone_fault_hardware', 'refs': ['K1201', 'K1202'], 'details': functions['SSR_HEADPHONE_AND_OTHER_LOADS']['faultCandidatesNotApplied']},
    {'id': 'SUP-SPEAKER', 'status': 'PROPOSAL_ONLY_NOT_SELECTED', 'operation': 'evaluate_speaker_replacement', 'refs': ['LS901'], 'candidateMpn': speaker['mpn'], 'details': 'See speaker-candidate-review.json; no native, enclosure or gain change authorized/applied.'},
]
save(SUB / 'corrected-components.json', records)
save(SUB / 'authorized-deltas.json', {'schema': 'SmartVio.AudioSupplement.Deltas.v1', 'snapshot': snapshot,
     'writeScope': ['audit/audio/**', 'work/v25/audio/**'], 'globalNativeModified': False,
     'removeComponents': [], 'addComponents': [], 'automaticNetDeltas': [], 'proposals': proposals,
     'mergeRule': 'Only merge specifically approved proposals; match refs and pin/net preconditions, do not replace fullnative. No new jack/speaker/HP hardware has been authorized for production.'})
save(OUT / 'supplemental-pin-audit.json', {'schema': 'SmartVio.AudioSupplement.PinAudit.v1', 'snapshot': snapshot, 'pinRows': pin_rows,
     'noConnectAndEp': {'SSR': 'All4pins used, noNC/EP', 'Q1201': '3pins1G2S3D,noNC/EP', 'J401': '16contacts plus4shellstakes aggregatedSH; A8/B8 deliberatelyNC; noEP'},
     'q1201SinkReview': q_calc, 'sources': sources, 'correctedRecords': 'supplemental/corrected-components.json', 'release': 'HOLD_NOT_PRODUCTION_APPROVAL'})
save(OUT / 'jack-contact-review.json', jack_review)
save(OUT / 'speaker-candidate-review.json', speaker)
save(OUT / 'functional-audio-review.json', {'schema': 'SmartVio.AudioFunctionalReview.v1', 'snapshot': snapshot, 'functions': functions,
     'allCalculationsAnalytical': True, 'physicalTestsPerformed': 0, 'release': 'HOLD_FUNCTIONAL_EVT_SHORT_POP_THD_TEMP_AND_CABLE_TESTS'})
save(OUT / 'dual-dout-consistency-audit.json', dual)
save(OUT / 'supplemental-source-manifest.json', sources)
findings = [
    {'id': 'INC-001', 'severity': 'BLOCKER', 'proved': True, 'refs': jack_review['refs'], 'status': 'HOLD', 'finding': 'Official Lumberg English/German circuitDA8vsPCB6 conflict remains. Unambiguous pad assignment unavailable.', 'productionCamBlocked': True},
    {'id': 'INC-002', 'severity': 'HIGH', 'proved': True, 'refs': ['U601'], 'status': 'CORRECTED_AUDIO_CONTRACT_FIRMWARE_COORDINATED', 'finding': 'Current full0xFF input-selector writes clear reservedbit6 reset1. UsemaskBF and reset-preserving41/41/44/40.'},
    {'id': 'INC-003', 'severity': 'HIGH', 'proved': True, 'refs': ['Q1201'], 'status': 'PROPOSAL', 'finding': 'Generic2N7002 lacks a guaranteed3.3V sink bound. ExactPMV30UN2R provides2.5/1.8/1.5V RDSmax at25C; sevenLED static sink budget positive, temperature/transientsHOLD.'},
    {'id': 'INC-004', 'severity': 'HIGH', 'proved': False, 'refs': ['K1201', 'K1202', 'U301'], 'status': 'HOLD', 'finding': '32ohm normal audio current is comfortably small in nominal calculation; maximum/repeated short current through250mA SSR is not bounded by TPA protection claim.'},
    {'id': 'INC-005', 'severity': 'FUNCTIONAL', 'proved': True, 'refs': ['J201'], 'status': 'FIRMWARE_PROFILE_PROPOSAL', 'finding': 'TRS->TS groundsRING via existing220ohm series, losesR content; no automaticmono sum. Do not confuse this with a direct opamp-pin short.'},
    {'id': 'INC-006', 'severity': 'FUNCTIONAL', 'proved': True, 'refs': ['J202'], 'status': 'LIMITED_COMPATIBILITY_GAIN_PROFILE_PROPOSAL', 'finding': 'RETURN32kohm,-10.10dB pad: low-Z activepedal compatible only with qualified level; passiveinstrument/truebypass source high-Z compatibility unsupported;TS givesLonly.'},
    {'id': 'INC-007', 'severity': 'HIGH', 'proved': True, 'refs': ['J401'], 'status': 'PINS_PROVED_STACKUP_ORIENTATION_HOLD', 'finding': 'USB4120-03-C is exact17-symbol-entry/16physicalcontact part. Official recommended PCB is1.00+/-0.10mm, not automatically1.6mm.'},
    {'id': 'INC-008', 'severity': 'FUNCTIONAL', 'proved': True, 'refs': ['LS901'], 'status': 'CANDIDATE_ONLY', 'finding': 'PUIcandidate2.5+/-0.2body vs2.8+/-0.2workingheight; rated loadconditions1cc/850HzHPF. No claim1Wfullviolinband ordropin10mm speaker replacement.'},
]
review = {'schema': 'SmartVio.AudioIncrementalReview.v1', 'snapshot': snapshot, 'findings': findings,
          'proven': ['SSR1LED_A2LED_K3/4nonpolarload noEP/NC; official pad geometry', 'PMV30UN2R orderable/pin1G2S3D/lowVGS25Cmax',
                     'J401 all16contactroles plusSHELL=GND', 'Dual64bit/2x32slots perlane48k/3.072MHz/24.576MHz512fs clocks and currentlogic nets'],
          'holds': ['LumbergDA6vs8 blocks productionCAM', 'USB clamp coordination remainsHOLD; parent USB_MODE1/VREF update acknowledged, not duplicated',
                    'FL1501 exactCMC MPN stillunselectedHOLD', 'HeadphoneSSR repeatedshort/thermal/audioTHD validation', 'JackalternateTRS/panel/newpads/detectpolarity',
                    'J401PCBthickness/orientation', 'LowVGSQfulltemperature/currentrailtransients', 'SAIADCdriver/readback/SI/alignedDMA/EVT', 'Speakermechanical/acoustic/filter/limitqualification'],
          'correctedComponents': 'supplemental/corrected-components.json', 'authorizedDeltas': 'supplemental/authorized-deltas.json',
          'supportingFiles': ['supplemental-pin-audit.json', 'functional-audio-review.json', 'jack-contact-review.json', 'speaker-candidate-review.json', 'dual-dout-consistency-audit.json'],
          'productionCamAllowed': False, 'globalNativeModified': False, 'globalPcbModified': False, 'physicalTestsPerformed': 0,
          'firmwareOwnerNotified': dual['firmwareOwnerNotified'], 'parentReportedErcNotRerunOrIndependentlyClaimed': True}
save(OUT / 'incremental-review.json', review)
import pcbnew
fp_checks = []
for name, expected in [('Panasonic_SSOP4_PhotoMOS_Official', 4), ('GCT_USB4120_Official_A6', 22)]:
    parsed = pcbnew.FootprintLoad(str(footprints), name)
    assert parsed is not None
    pads = list(parsed.Pads())
    assert len(pads) == expected
    if name.startswith('GCT'):
        assert sum(p.GetNumber() == 'SH' for p in pads) == 4
        assert sum(p.GetNumber() == '' for p in pads) == 2
    fp_checks.append({'name': name, 'pads': len(pads), 'status': 'LOCAL_KICAD_PARSER_ACCEPTED_NOT_BOARD_DRC'})
assert sha(NATIVE) == snapshot['sha256'], 'Native changed during audit; rerun snapshot checks.'
verification = {'snapshot': snapshot, 'correctedRecordCount': len(records), 'newPinProofRows': len(pin_rows),
                'ownedRefsOnly': owned, 'pinNetPairsUnchanged': True, 'globalNativeHashUnchangedAtCompletion': True,
                'sourcePdfsValidHeadersAndHashed': True, 'footprints': fp_checks,
                'firmwareReservedBitFixPresentAtSnapshot': fw_fix_present, 'fullBoardErcDrcPerformed': False,
                'physicalTestsPerformed': 0, 'productionCamAllowed': False}
save(OUT / 'verification/incremental-validation.json', verification)
save(SUB / 'artifact-manifest-sha256.json', [{'file': str(p.relative_to(OUT)).replace('\\', '/'), 'sha256': sha(p)} for p in
     [OUT / 'incremental-review.json', SUB / 'corrected-components.json', SUB / 'authorized-deltas.json', OUT / 'supplemental-pin-audit.json',
      OUT / 'functional-audio-review.json', OUT / 'jack-contact-review.json', OUT / 'speaker-candidate-review.json', OUT / 'dual-dout-consistency-audit.json',
      OUT / 'supplemental-source-manifest.json', OUT / 'verification/incremental-validation.json', OUT / 'SUPPLEMENTAL-REPORT.txt', contract_path, ssr_fp, usb_fp]])
manifest_path = OUT / 'artifact-manifest-sha256.json'
save(manifest_path, [{'file': str(p.relative_to(OUT)).replace('\\', '/'), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                    for p in sorted(OUT.rglob('*')) if p.is_file() and p != manifest_path and not p.name.endswith('.tmp')])
print(json.dumps({'review': str(OUT / 'incremental-review.json'), 'records': len(records), 'newPinProofRows': len(pin_rows),
                  'nativeSha256': snapshot['sha256'], 'sources': len(sources), 'productionCamAllowed': False,
                  'firmwareReservedBitFixPresent': fw_fix_present, 'qSinkCalculation': q_calc}, indent=2))
