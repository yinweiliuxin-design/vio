"""Reproducible V25 power review; calculations are not hardware qualification."""
import copy
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V25-Engineering'
OUT = ROOT / 'audit/power'
OLD = BASE / 'outputs/SmartVio-V24-NativeEDA/electrical/native-components.json'
OUT.mkdir(parents=True, exist_ok=True)
parts = json.loads(OLD.read_text(encoding='utf-8'))
by = {c['ref']: copy.deepcopy(c) for c in parts}

# Pin names transcribed from the package-specific manufacturer tables.
maps = {
 'U501': ('bq24074', 'RGT, Table 6-1, pp7-8; sections 9.3.5.1/9.3.5.1.1',
          'TS BAT BAT CE EN2 EN1 PGOOD VSS CHG OUT OUT ILIM IN TMR ITERM ISET'.split()),
 'U1001': ('tps25947', 'RPW, Table 5-1, pp5-6',
           'EN_UVLO OVLO AUXOFF FLT IN OUT DVDT GND ILM ITIMER'.split()),
 'U1101': ('tps63070', 'RNM, section 6, p3',
           'PS_SYNC PG VAUX GND FB FB2 VOUT VOUT L2 PGND L1 VIN VIN EN VSEL'.split()),
 'U1301': ('ltc2954', 'TS8, pin functions p6; applications pp8-10',
           'VIN PB ONT GND INT_N EN PDT KILL'.split()),
 'Q1601': ('pmv30un2', 'SOT23, Table 2 p2; official web source checked 2026-10-04',
           'G S D'.split()),
 'U1701': ('ads1115', 'DGS, Table 4-1 p3',
           'ADDR ALERT_RDY GND AIN0 AIN1 AIN2 AIN3 VDD SDA SCL'.split()),
 'U1702': ('tmux1511', 'PW/TSSOP, Pin Functions p3',
           'SEL1 S1 D1 SEL2 S2 D2 GND D3 S3 SEL3 D4 S4 SEL4 VDD'.split()),
 'U1703': ('opa4330', 'PW/TSSOP, section 6, pin configuration p5',
           'OUT_A IN-_A IN+_A V+ IN+_B IN-_B OUT_B OUT_C IN-_C IN+_C V- IN+_D IN-_D OUT_D'.split()),
 'U1801': ('tmp117', 'DRV, Table 5-1 p4; thermal-pad guidance section 10.1',
           'SCL GND ALERT ADD0 V+ SDA PAD'.split()),
}
sources = {r['id']:r for r in json.loads((BASE/'work/v25/power/sources.json').read_text())}
sources['pmv30un2'] = {'url': 'https://assets.nexperia.com/documents/data-sheet/PMV30UN2.pdf',
 'localDownload': 'HTTP403', 'evidence': 'Official web search and indexed Table2 pinout, 2026-10-04; local PDF not archived'}
for row in sources.values():
 if isinstance(row, dict): row.pop('textPath', None)

def pin(ref, number):
 return next(p for p in by[ref]['pins'] if p['number'] == str(number))

changes = []
def net(ref, number, value):
 p = pin(ref, number)
 changes.append({'ref':ref, 'pin':str(number), 'before':p['net'], 'after':value})
 p['net'] = value

# Use the charger's documented current mirror, isolated while the MCU rail is off.
net('U1702', 12, 'RISET')
renames = {n:'MON_ICHG'+n[len('MON_3V3'):] for n in
           ('MON_3V3_BUF_IN','MON_3V3_BUF','MON_3V3_ADC')}
for c in by.values():
 for p in c['pins']:
  if p['net'] in renames:
   net(c['ref'], p['number'], renames[p['net']])
for ref in ('R1713','R1714'):
 changes.append({'ref':ref,'action':'remove obsolete 3V3 divider, AIN3 now measures ISET'})
 by.pop(ref)
by['R1715']['value'] = '10M; 1%; ISET buffer bias, include in mirror calibration'
by['R1715']['note'] = '4.99k || 10M effective ISET load while MON_ENABLE=1; do not fit 100k.'
by['Q1601']['mpn'] = 'PMV30UN2R'
for ref,value in [('R1101','312k'),('R1102','100k')]:
 by[ref]['value']=value+'; 0.1%; <=25ppm/K; exact MPN pending'
 by[ref]['package']='0603; 0.1%; exact MPN and temperature grade unapproved'
 changes.append({'ref':ref,'action':'tighten feedback ratio tolerance to 0.1%; no package change'})
ep = next(p for p in by['U501']['pins'] if p['number'] == 'EP')
ep['number'] = '17'
ep['name'] = 'PAD_GND'
assert ep['net'] == 'GND'
changes.append({'ref':'U501','pinAlias':'EP -> physical17', 'reason':'RGT exposed pad; solder to GND and thermal vias'})

purpose = {
 'U501': 'Hardware charger/NTC/timers/DPPM remain active. CE high by R503 until firmware and battery acceptance gate permit charging. CHG high alone is not completion proof.',
 'U1001': 'USB-only eFuse; UV/OV and 0.5A current ceiling. Latch-off event requires explicit reset policy; downstream zero volts is not physical unplug proof.',
 'U1101': '3.3V buck-boost. VAUX only decoupled; FB2 unused NC is permitted. PS_SYNC low forces PWM. Output budget and compensation/layout need real validation.',
 'U1301': 'Pushbutton controller. MCU must drive KILL high inside 512ms startup window. INT requests shutdown. No automatic USB wake exists in this circuit.',
 'Q1601': 'N-MOS sinks active-low charger CE only when CHARGE_ALLOW high. Pull-down makes reset/off default charging-disabled; shorted FET cannot be made safe by firmware alone.',
 'U1701': 'ADS1115 0x48; single-ended AIN0..3, PGA +/-4.096V. PGA range does not allow input above supply. Invalid/stale/bus fault inhibits charge.',
 'U1702': 'Four independent SPST; SEL low isolates. VDD=0 off protection only guaranteed to 3.6V on signal pins. All divided rail channels and ISET must stay below it.',
 'U1703': 'Quad unity-gain buffers, 3.3V supply. Rail headroom, settling, bias/leakage and calibration must be checked; no overvoltage protection function.',
 'U1801': 'TMP117 0x49 battery-surface sensor. It does not replace charger pack NTC. Thermal contact and lag must be measured; unsoldered thermal-pad option maintained.',
}
types = {
 'U501':'input passive passive input input input open_collector power_in open_collector power_out passive passive power_in passive passive passive power_in'.split(),
 'U1001':'input input open_collector open_collector power_in power_out passive power_in passive passive'.split(),
 'U1101':'input open_collector power_out power_in input passive power_out passive passive power_in passive power_in power_in input input'.split(),
 'U1301':'power_in input passive power_in open_collector open_collector passive input'.split(),
 'Q1601':'input passive passive'.split(),
 'U1701':'input open_collector power_in input input input input power_in bidirectional input'.split(),
 'U1702':'input passive passive input passive passive power_in passive passive input passive passive input power_in'.split(),
 'U1703':'output input input power_in input input output output input input power_in input input output'.split(),
 'U1801':'input power_in open_collector input power_in bidirectional no_connect'.split(),
}
aliases = {'PGOOD_N':'PGOOD', 'FLT_N':'FLT', 'ALERT/RDY':'ALERT_RDY', 'THERMAL_PAD':'PAD', 'V_PLUS':'V+', 'V_MINUS':'V-', 'EP':'PAD_GND'}
for ch in 'ABCD':
 aliases['IN_'+ch+'_PLUS']='IN+_'+ch
 aliases['IN_'+ch+'_MINUS']='IN-_'+ch
ledger = []
for ref,(source, location,names) in maps.items():
 expected = {str(i+1):name for i,name in enumerate(names)}
 if ref == 'U501': expected['17'] = 'PAD_GND'
 assert set(expected) == {p['number'] for p in by[ref]['pins']}, ref
 for p in by[ref]['pins']:
  want = expected[p['number']]
  actual = aliases.get(p['name'], p['name'])
  p['electricalType'] = types[ref][int(p['number'])-1]
  ledger.append({'ref':ref,'pin':p['number'],'manufacturerFunction':want,
   'captureName':p['name'],'net':p['net'],'electricalType':p['electricalType'],'nameMatches':actual==want,
   'source':source,'location':location,'pinoutReview':'MATCH' if actual==want else 'REVIEW_ALIAS',
   'behavior':purpose[ref], 'electricalValidation':'NOT_PHYSICALLY_TESTED'})

def limits(vmin,vtyp,vmax,rt,rb,tol=.01):
 return {'min':vmin*(1+rt*(1-tol)/(rb*(1+tol))),
         'typ':vtyp*(1+rt/rb),
         'max':vmax*(1+rt*(1+tol)/(rb*(1-tol)))}
req = 1/(1/4990+1/10000000)
calc = {
 'efuse_uv_rising_V':limits(1.183,1.20,1.223,26100,10000),
 'efuse_ov_rising_V':limits(1.183,1.20,1.223,37400,10000),
 'efuse_uv_falling_V':limits(1.076,1.09,1.116,26100,10000),
 'efuse_ov_falling_V':limits(1.076,1.09,1.116,37400,10000),
 'efuse_current_A_datasheet_6k65':{'min':.425,'typ':.5,'max':.575,
   'note':'Datasheet thresholds at nominal R; resistor tolerance adds error. Not USB authorization.'},
 'bq_charge_current_mA':{'min':797/(4990*1.01)*1000,'typ':890/req*1000,'max':975/(req*.99)*1000},
 'bq_adapter_input_current_mA':{'min':1330/(4420*1.01)*1000,'typ':1525/4420*1000,'max':1720/(4420*.99)*1000},
 'iset_effective_resistance_ohm':req,
 'iset_nominal_V_per_mA':req/400/1000,
 'iset_mirror_tolerance_percent':10,
 'rail_adc_divider_ratio_with_100k_bias':1/(1+15000/(1/(1/10000+1/100000))),
 'adc_nominal_V3D_V':.8*(1+312000/100000),
 'V3D_static_V_without_feedback_leakage':limits(.792,.8,.808,312000,100000,.001),
 'feedback_leakage_max_output_error_V':100e-9*312000,
 'buck_minimum_startup_input_V':3.0,
 'adc_single_ended_lsb_mV':.125,
 'power_boot_window_ms':512,
 'ont_additional_nominal_ms':.1/.000156+1,
 'pdt_additional_nominal_ms':.47/.000156+1,
 'ntc_hardware_trip_voltage_V':{'hot':[.270,.300,.330], 'cold':[2.0,2.1,2.2]},
 'limitations':['Divider tolerances omit input leakage; include in measurement uncertainty and calibration.',
  'ISET mirror is charge-current only, valid while charger is actively charging; not discharge current or cell-presence proof.',
  'NTC trip temperature depends on exact battery NTC curve and mounting; no temperature claim from 10k label alone.',
  'PD, USB enumeration/current negotiation, self-heating and cold start are not proven by these DC calculations.']}
checks = [
 ('CE reset disable', pin('U501',4)['net']=='CHARGE_DISABLE'),
 ('Default disabled Q gate', pin('Q1601',1)['net']=='CHARGE_GATE'),
 ('Charge monitor selected',pin('U1702',12)['net']==pin('U501',16)['net']==pin('R501',1)['net']),
 ('AIN3 current monitor',pin('U1701',7)['net']=='MON_ICHG_ADC'),
 ('No obsolete divider','R1713' not in by and 'R1714' not in by),
 ('Thermal pad ground', pin('U501',17)['net']=='GND'),
 ('Charging timer not defeated',pin('U501',14)['net'] is None),
 ('Termination default',pin('U501',15)['net'] is None),
 ('NTC preserved',pin('U501',1)['net']=='PACK_NTC'),
 ('Monitor off protection 3.6V',5.9*calc['rail_adc_divider_ratio_with_100k_bias']<3.6),
 ('ISET measurement headroom',calc['bq_charge_current_mA']['max']*calc['iset_nominal_V_per_mA']*1.1<3.3),
 ('Input-limit upper bound below eFuse nominal',calc['bq_adapter_input_current_mA']['max']<500),
]
report={'schema':'smartvio-power-audit-1','date':'2026-10-04','release':'HOLD',
 'reviewedDevices':len(maps),'reviewedPins':len(ledger),
 'checks':[{'name':n,'pass':v,'scope':'data/calculation, NOT hardware test'} for n,v in checks],
 'allChecksPassed':all(v for _,v in checks),
 'openBlockers':[
  'Exact protected 1S battery pack/NTC/vendor charging envelope and independent protection not selected.',
  'No autonomous USB wake circuit: OFF keeps CE high, therefore OFF-state charging is not implemented.',
  'Default 100mA USB budget cannot be declared sufficient for full audio/radio startup; measured gated boot required.',
  'Thermal layout, eFuse/BQ pad/thermal vias, DC bias MLCC and inductor Isat/DCR need complete PCB review.',
  'Charger self-heating and sensor contact lag untested. MCU firmware must not be sole cell protection.',
  'ADC failures, eFuse latchoff, charger timer expiry and missing pack need bench fault injection.'
 ]}
for name, data in [('corrected-components.json',[by[c['ref']] for c in parts if c['ref'] in by and (c['ref'] in maps or c['ref'] in {'R1715'})]),
                   ('changes.json',{'remove':['R1713','R1714'],'edits':changes,'renamedNets':renames}),
                   ('pin-audit.json',ledger),('calculations.json',calc),('review.json',report),('sources.json',sources)]:
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
# Include every component whose net was changed, not just active devices.
changed_refs={r['ref'] for r in changes if 'pin' in r}|set(maps)|{'R1715','R1101','R1102'}
(OUT/'corrected-components.json').write_text(json.dumps([by[r] for r in by if r in changed_refs],ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
