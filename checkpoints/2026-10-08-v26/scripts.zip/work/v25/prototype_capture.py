"""Capture the explicitly separate power experiment board, not the product PCB."""
import importlib.util
import json
from pathlib import Path

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V25-Engineering'
OUT=ROOT/'pcb-work'
info=json.loads((OUT/'verification/power-prototype.json').read_text(encoding='utf-8'))
source=json.loads((ROOT/'reference/v25-circuits.json').read_text(encoding='utf-8'))
mapping=json.loads((OUT/'footprint-review.json').read_text(encoding='utf-8'))
refs=set(info['placement'])
spec=importlib.util.spec_from_file_location('cap_proto',ROOT/'reproduce/capture_library.py')
lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
lib.mapping={r:{'id':d['footprint']} for r,d in mapping.items() if 'footprint' in d}
uid=lib.uid;q=lib.q;fx=lib.fx
project='PowerPrototype';rootuuid=uid(project)
flaglib='(symbol "SmartVio:PWR_FLAG" (power) (pin_names (offset 0) hide) (in_bom no) (on_board no) (property "Reference" "#FLG" (at 0 0 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at 0 2.54 0) (effects (font (size 1 1)))) (symbol "PWR_FLAG_1_1" (pin power_out line (at 0 0 90) (length 0) (name "pwr" (effects (font (size 1 1)))) (number "1" (effects (font (size 1 1)))))))'
sheets=[{**s,'components':[c for c in s['components'] if c['ref'] in refs]} for s in source]
sheets=[s for s in sheets if s['components']]
headers=[]
for ref,pins in info['interfaces'].items():
 headers.append({'ref':ref,'value':'TEST HEADER / 3.3V logic ONLY / HOLD','type':'J','mpn':None,
 'package':'6-pad bench harness; verify pads in PCB','release':'HOLD',
 'pins':[{'number':str(n),'name':net,'net':net} for n,net in pins.items()]})
sheets.append({'id':'TEST','title':'Bench interfaces / not product connectors','components':headers})
parts=[c for s in sheets for c in s['components']]
assert {c['ref'] for c in parts}==refs
root=f'(kicad_sch (version 20260101) (generator "smartvio_power_experiment") (uuid {rootuuid}) (paper "A2") (lib_symbols {flaglib})\n'
root+=lib.text('V25 POWER EXPERIMENT ONLY - NOT THE COMPLETE SMART VIOLIN',20,18,3)
root+=lib.text('Do not connect a real battery until its protection, NTC and charging requirements are approved.',20,26,1.3)
for i,s in enumerate(sheets):
 name='Power-'+s['id'];pageid=uid(name+'sheet');x=20+(i%4)*140;y=40+(i//4)*55
 root+=f'(sheet (at {x} {y}) (size 120 32) (stroke (width 0.254) (type default)) (fill (color 0 0 0 0)) (uuid {pageid})\n'
 root+=f'(property "Sheetname" {q(s["title"])} (at {x} {y-2} 0) (effects (font (size 1.1 1.1)) (justify left bottom)))\n'
 root+=f'(property "Sheetfile" {q(name+".kicad_sch")} (at {x} {y+34} 0) (effects (font (size 1.1 1.1)) (justify left top)))\n'
 root+=f'(instances (project {q(project)} (path "/{rootuuid}" (page "{i+2}")))))\n'
 (OUT/(name+'.kicad_sch')).write_text(lib.capture(name,s['components'],s['title'],pageid,project=project,parent_uuid=rootuuid),encoding='utf-8')
for i,net in enumerate(['GND','V3A','VBUS_RAW']):
 x,y=50.8+i*100.33,300.99;ref='#FLG'+str(i+1)
 root+=f'(symbol (lib_id "SmartVio:PWR_FLAG") (at {x} {y} 0) (unit 1) (in_bom no) (on_board no) (uuid {uid(project+ref)}) (property "Reference" {q(ref)} (at {x} {y} 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at {x} {y-3.81} 0) {fx}) (instances (project {q(project)} (path "/{rootuuid}" (reference {q(ref)}) (unit 1)))))\n'
 root+=f'(global_label {q(net)} (shape passive) (at {x} {y} 0) {fx} (uuid {uid(project+ref+net)}))\n'
root+='(sheet_instances (path "/" (page "1"))))\n'
(OUT/'PowerPrototype.kicad_sch').write_text(root,encoding='utf-8')
(OUT/'PowerPrototype.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "smartvio_power_experiment")\n'+''.join(lib.library(c,False) for c in parts)+flaglib.replace('SmartVio:PWR_FLAG','PWR_FLAG')+')\n',encoding='utf-8')
(OUT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "SmartVio") (type "KiCad") (uri "${KIPRJMOD}/PowerPrototype.kicad_sym") (options "") (descr "Power experiment capture")))',encoding='utf-8')
(OUT/'PowerPrototype.kicad_pro').write_text(json.dumps({'meta':{'filename':'PowerPrototype.kicad_pro','version':1},'erc':{'erc_exclusions':[]}},indent=2),encoding='utf-8')
(OUT/'power-prototype-components.json').write_text(json.dumps(parts,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'components':len(parts),'sheets':len(sheets)+1,'release':'HOLD'}))
