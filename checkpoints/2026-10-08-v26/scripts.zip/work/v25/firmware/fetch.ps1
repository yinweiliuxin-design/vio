param([switch]$Toolchain)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$downloads = Join-Path $root 'downloads'
$vendor = Join-Path $root 'vendor'
New-Item -ItemType Directory -Force $downloads,$vendor | Out-Null
Start-Transcript -Path (Join-Path $root $(if ($Toolchain) {'fetch-toolchain.log'} else {'fetch-vendor.log'})) -Append
function Fetch([string]$url, [string]$destination) {
    Write-Output "FETCH $url -> $destination"
    & curl.exe --fail --location --retry 2 --connect-timeout 20 --max-time 900 --output $destination $url
    if ($LASTEXITCODE -ne 0) { throw "Download failed: $url" }
    Get-FileHash -Algorithm SHA256 -LiteralPath $destination | Format-List
}
try {
    if ($Toolchain) {
        $name = 'arm-gnu-toolchain-14.2.rel1-mingw-w64-i686-arm-none-eabi'
        $base = 'https://developer.arm.com/-/media/Files/downloads/gnu/14.2.rel1/binrel/'
        Fetch ($base + $name + '.zip') (Join-Path $downloads ($name + '.zip'))
        Fetch ($base + $name + '.zip.sha256asc') (Join-Path $downloads ($name + '.zip.sha256asc'))
        $expected = (Get-Content -Raw (Join-Path $downloads ($name + '.zip.sha256asc'))).Trim().Split()[0].ToUpperInvariant()
        $actual = (Get-FileHash (Join-Path $downloads ($name + '.zip')) -Algorithm SHA256).Hash
        if ($expected -ne $actual) { throw 'Official archive checksum mismatch' }
        Expand-Archive -LiteralPath (Join-Path $downloads ($name + '.zip')) -DestinationPath (Join-Path $root 'tools') -Force
    } else {
        $st = 'https://raw.githubusercontent.com/STMicroelectronics/cmsis-device-h7/v1.10.4/'
        $arm = 'https://raw.githubusercontent.com/ARM-software/CMSIS_5/5.9.0/CMSIS/Core/Include/'
        New-Item -ItemType Directory -Force (Join-Path $vendor 'st'),(Join-Path $vendor 'cmsis') | Out-Null
        foreach ($path in @('Include/stm32h7xx.h','Include/stm32h743xx.h','Include/system_stm32h7xx.h','Source/Templates/system_stm32h7xx.c','Source/Templates/gcc/startup_stm32h743xx.s','LICENSE.md')) {
            Fetch ($st + $path) (Join-Path $vendor ('st/' + (Split-Path $path -Leaf)))
        }
        foreach ($name in @('core_cm7.h','cmsis_version.h','cmsis_compiler.h','cmsis_gcc.h','mpu_armv7.h','cachel1_armv7.h')) {
            Fetch ($arm + $name) (Join-Path $vendor ('cmsis/' + $name))
        }
        Fetch 'https://raw.githubusercontent.com/ARM-software/CMSIS_5/5.9.0/LICENSE.txt' (Join-Path $vendor 'cmsis/LICENSE.txt')
        Fetch 'https://www.st.com/resource/en/datasheet/stm32h743vi.pdf' (Join-Path $downloads 'stm32h743vi.pdf')
        Fetch 'https://documentation.espressif.com/esp32-mini-1_datasheet_en.pdf' (Join-Path $downloads 'esp32-mini-1.pdf')
        Fetch 'https://www.ti.com/lit/ds/symlink/bq24074.pdf' (Join-Path $downloads 'bq24074.pdf')
    }
} finally { Stop-Transcript }
