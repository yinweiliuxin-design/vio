$ErrorActionPreference='Stop'
$name='arm-gnu-toolchain-14.2.rel1-mingw-w64-i686-arm-none-eabi'
$url='https://developer.arm.com/-/media/Files/downloads/gnu/14.2.rel1/binrel/' + $name + '.zip'
$dir=Join-Path $PSScriptRoot 'downloads/ranges'
New-Item -ItemType Directory -Force $dir | Out-Null
Start-Transcript -Path (Join-Path $PSScriptRoot 'fetch-ranges.log') -Append
try {
    $headers=& curl.exe -sS -I -L --max-time 30 $url
    $headers
    $length=[long](($headers | Select-String '(?i)^Content-Length:\s*(\d+)' | Select-Object -Last 1).Matches.Groups[1].Value)
    if($length -lt 100000000){throw 'Invalid archive size'}
    $chunk=[long][Math]::Ceiling($length/12)
    $parts=0..11 | ForEach-Object -Parallel {
        $i=$_;$start=$i*$using:chunk;$end=[Math]::Min($using:length-1,$start+$using:chunk-1)
        $path=Join-Path $using:dir ($i.ToString('00')+'.part')
        & curl.exe -sS --fail --location --retry 1 --connect-timeout 20 --max-time 600 --range "$start-$end" --output $path $using:url
        if($LASTEXITCODE -ne 0){throw "Range $i failed"}
        if((Get-Item $path).Length -ne $end-$start+1){throw "Range $i size mismatch"}
        Write-Output "RANGE_OK $i $start $end"
    } -ThrottleLimit 12
    $parts
    if($parts.Count -ne 12){throw 'Not all ranges completed'}
    $zip=Join-Path $dir ($name+'.zip')
    $dest=[IO.File]::Create($zip)
    try { foreach($i in 0..11){
        $source=[IO.File]::OpenRead((Join-Path $dir ($i.ToString('00')+'.part')))
        try{$source.CopyTo($dest)}finally{$source.Dispose()}
    }}finally{$dest.Dispose()}
    $sha=Join-Path $dir 'official.sha256asc'
    & curl.exe -sS --fail --location --max-time 30 --output $sha ($url+'.sha256asc')
    if($LASTEXITCODE -ne 0){throw 'Official checksum download failed'}
    $expected=(Get-Content -Raw $sha).Trim().Split()[0].ToUpperInvariant()
    $actual=(Get-FileHash $zip -Algorithm SHA256).Hash
    Write-Output "EXPECTED_SHA256 $expected"
    Write-Output "ACTUAL_SHA256 $actual"
    if($expected -ne $actual){throw 'Checksum mismatch'}
    Expand-Archive -LiteralPath $zip -DestinationPath (Join-Path $PSScriptRoot 'tools') -Force
    Write-Output 'OFFICIAL_TOOLCHAIN_EXTRACTED'
}finally{Stop-Transcript}
