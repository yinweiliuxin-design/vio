$ErrorActionPreference='Stop'
$official=Join-Path $PSScriptRoot 'vendor/st/stm32h743xx.h'
$out=Join-Path $PSScriptRoot 'build/i2c-model-device.h'
$source=Get-Content $official -Raw -Encoding utf8
$lines=[Collections.Generic.List[string]]::new()
$lines.Add('/* GENERATED from pinned official ST CMSIS. Host RAM register model only. */')
$lines.Add('#ifndef SV_I2C_MODEL_DEVICE_H')
$lines.Add('#define SV_I2C_MODEL_DEVICE_H')
$lines.Add('#include <stdint.h>')
$lines.Add('#define __IO volatile')
$lines.Add('#define __I volatile const')
$lines.Add('#define __O volatile')
foreach($type in @('I2C_TypeDef','GPIO_TypeDef','RCC_TypeDef')){
    $match=[regex]::Match($source,('(?s)typedef struct\s*\{(?:(?!typedef struct).)*?\}\s*'+$type+'\s*;'))
    if(!$match.Success){throw "Missing official register type $type"}
    $lines.Add($match.Value)
}
foreach($line in $source -split '\r?\n'){
    if($line -match '^#define\s+(RCC|I2C)_[A-Z0-9_]+\s+'){$lines.Add($line)}
}
$lines.Add('extern I2C_TypeDef sv_fake_i2c;')
$lines.Add('extern GPIO_TypeDef sv_fake_gpiob;')
$lines.Add('extern RCC_TypeDef sv_fake_rcc;')
$lines.Add('#define I2C1 (&sv_fake_i2c)')
$lines.Add('#define GPIOB (&sv_fake_gpiob)')
$lines.Add('#define RCC (&sv_fake_rcc)')
$lines.Add('uint32_t sv_i2c_model_status(void);')
$lines.Add('#endif')
$lines | Set-Content $out -Encoding utf8
[ordered]@{source=$official;sourceSha256=(Get-FileHash $official -Algorithm SHA256).Hash;output=$out;outputSha256=(Get-FileHash $out -Algorithm SHA256).Hash;types=@('I2C_TypeDef','GPIO_TypeDef','RCC_TypeDef');meaning='Manufacturer register layouts/masks copied, pointers refer to host RAM. Not a peripheral simulator or hardware execution.'} | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot 'build/i2c-model-provenance.json') -Encoding utf8
Write-Output "Generated official-header host I2C register model: $out"
