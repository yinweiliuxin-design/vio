$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$out=Join-Path $root 'outputs/SmartVio-V25-Engineering/firmware'
$manifest=Join-Path $out 'verification/changed-paths.json'
$environment=Join-Path $out 'verification/native-esp-environment.txt'
$envResults=foreach($name in @('idf.py','xtensa-esp32-elf-gcc.exe','cmake.exe','ninja.exe')){
    $cmd=Get-Command $name -ErrorAction SilentlyContinue
    if($cmd){"$name FOUND $($cmd.Source)"}else{"$name NOT_ON_PATH"}
}
$envResults | Set-Content $environment -Encoding utf8
$files=@(Get-ChildItem $out,$PSScriptRoot -Recurse -File | Where-Object {$_.FullName -ne $manifest} | Sort-Object FullName)
$records=foreach($file in $files){
    $relative=$file.FullName.Substring($root.Length+1).Replace('\','/')
    $kind=if($relative -like 'work/v25/firmware/tools/*'){'official-toolchain-extracted'}elseif($relative -like 'work/v25/firmware/downloads/*'){'downloaded-evidence-or-toolchain-cache'}elseif($relative -like 'work/v25/firmware/vendor/*'){'official-CMSIS-dependency'}elseif($relative -match '/build/|/verification/|\.log$'){'generated-verification-or-build'}else{'source-or-contract'}
    $hash=if($kind -eq 'official-toolchain-extracted'){$null}else{(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash}
    [ordered]@{path=$relative;kind=$kind;bytes=$file.Length;sha256=$hash}
}
$result=[ordered]@{scope=@('outputs/SmartVio-V25-Engineering/firmware/**','work/v25/firmware/**');meaning='Exact files in this worker-owned deliverable and working scope; extracted toolchain files individually listed, archive checksum authenticates toolchain archive';originalVersionsModified=$false;edaFilesWritten=$false;overallReportWritten=$false;self='outputs/SmartVio-V25-Engineering/firmware/verification/changed-paths.json';selfHashExcluded=$true;files=$records}
$result | ConvertTo-Json -Depth 6 | Set-Content $manifest -Encoding utf8
Write-Output "MANIFEST $manifest files=$($records.Count) plus self"
$envResults | Write-Output
