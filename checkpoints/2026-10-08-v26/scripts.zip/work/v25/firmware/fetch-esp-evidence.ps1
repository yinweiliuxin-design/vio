$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$out=Join-Path $PSScriptRoot 'downloads/esp-idf-v5.4.3'
New-Item -ItemType Directory -Force $out | Out-Null
$paths=@(
 'components/bt/host/bluedroid/api/include/api/esp_a2dp_api.h',
 'components/bt/host/bluedroid/api/include/api/esp_gap_bt_api.h',
 'components/bt/host/bluedroid/api/include/api/esp_gap_ble_api.h',
 'components/bt/host/bluedroid/api/include/api/esp_gatts_api.h',
 'components/bt/host/bluedroid/api/include/api/esp_gatt_defs.h',
 'components/bt/host/bluedroid/api/include/api/esp_bt_defs.h',
 'components/bt/host/bluedroid/api/include/api/esp_bt_main.h',
 'components/bt/include/esp32/include/esp_bt.h',
 'components/bt/Kconfig',
 'components/esp_driver_uart/include/driver/uart.h',
 'examples/bluetooth/bluedroid/coex/a2dp_gatts_coex/main/bt_app_av.c',
 'examples/bluetooth/bluedroid/coex/a2dp_gatts_coex/sdkconfig.defaults',
 'examples/bluetooth/bluedroid/ble/gatt_server_service_table/main/gatts_table_creat_demo.c'
)
$records=foreach($path in $paths){
 $url='https://raw.githubusercontent.com/espressif/esp-idf/v5.4.3/'+$path
 $file=Join-Path $out ($path.Replace('/','__'))
 try {Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $file -TimeoutSec 30
      [ordered]@{path=$path;url=$url;local=$file;status='DOWNLOADED';sha256=(Get-FileHash $file -Algorithm SHA256).Hash}}
 catch {[ordered]@{path=$path;url=$url;status='FAILED';error=$_.Exception.Message}}
}
$records | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $out 'source-index.json') -Encoding utf8
$records | ForEach-Object {Write-Output ($_.path+' '+$_.status)}
