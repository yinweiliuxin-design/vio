"""Select only exact resistor MPNs with archived matching manufacturer sheets."""
import copy
import hashlib
import json
import re
import urllib.request
from pathlib import Path
from pypdf import PdfReader

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V25-Engineering'
OUT=ROOT/'audit/passives'; SOURCES=OUT/'sources'
SOURCES.mkdir(parents=True,exist_ok=True)
parts=json.loads((ROOT/'electrical/native-components.json').read_text(encoding='utf-8'))
# Value strings are explicit keys, not an unbounded engineering-value parser.
codes={'10k':'10K','4.7M':'4M7','100':'100R','220':'220R','100k':'100K',
 '22k':'22K','15k':'15K','1k':'1K','5.1k':'5K1','4.99k':'4K99','4.42k':'4K42',
 '4.7k':'4K7','470R':'470R','10R':'10R','33R':'33R','2k':'2K','26.1k':'26K1',
 '37.4k':'37K4','6.65k':'6K65','312k':'312K','270R':'270R','2.20k':'2K2',
 '100R':'100R','10M':'10M','140k':'140K','24.9k':'24K9'}
selected=[];records={};unresolved=[]
for c in parts:
 if c['type']!='R':continue
 token=c['value'].split()[0].rstrip(';')
 if token not in codes:
  unresolved.append({'ref':c['ref'],'reason':'No explicit supported value key; no guessed replacement'});continue
 precise='0.1%' in c['value'] or '0.1%' in c['package']
 mpn=('RT0603BRD07' if precise else 'RC0603FR-07')+codes[token]+'L'
 if mpn not in records:
  url='https://www.yageogroup.com/component-documentation/download/specsheet/'+mpn
  file=SOURCES/(mpn+'.pdf')
  try:
   if not file.exists():
    with urllib.request.urlopen(url,timeout=25) as r:data=r.read()
    assert data.startswith(b'%PDF'), 'Not a PDF'
    file.write_bytes(data)
   text='\n'.join(p.extract_text() for p in PdfReader(file).pages)
   normalized=re.sub(r'\s+',' ',text.replace('\u200b',''))
   assert mpn in normalized and '0603 / 1608' in normalized, 'Wrong part/package'
   assert ('0.1%' if precise else '1%') in normalized, 'Tolerance not found'
   assert '0.1 W' in normalized,'Power rating not found'
   if precise:assert '25 ppm' in normalized,'Required TCR not found'
   records[mpn]={'mpn':mpn,'url':url,'verified':True,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),
    'sourceFile':str(file.relative_to(ROOT)).replace('\\','/'),'facts':{'case':'0603 / 1608','ratedPowerWAt70C':.1,'tolerancePercent':.1 if precise else 1},
    'scope':'Exact manufacturer document, identity/package/tolerance/power; not circuit stress or lifetime approval'}
   file.with_suffix('.txt').write_text(text,encoding='utf-8')
   print(mpn,'VERIFIED',flush=True)
  except Exception as e:
   records[mpn]={'mpn':mpn,'url':url,'verified':False,'reason':str(e)}
   print(mpn,'HOLD',str(e),flush=True)
 if records[mpn]['verified']:
  updated=copy.deepcopy(c);updated['mpn']=mpn
  updated['candidateManufacturer']='YAGEO'
  updated['bomEvidence']=records[mpn]
  updated['procurementApproved']=False
  selected.append(updated)
 else:unresolved.append({'ref':c['ref'],'mpn':mpn,'reason':records[mpn]['reason']})
for name,data in [('corrected-components.json',selected),('source-manifest.json',list(records.values())),
 ('selection-summary.json',{'selectedReferences':len(selected),'verifiedUniqueMPNs':sum(r['verified'] for r in records.values()),
  'unresolved':unresolved,'applicationStressApproved':False,'release':'CANDIDATES_NOT_PRODUCTION_RELEASE'})]:
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
