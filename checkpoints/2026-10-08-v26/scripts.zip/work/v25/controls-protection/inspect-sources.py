import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'audio' / 'pythonlibs'))
import fitz
from PIL import Image

root = Path(__file__).resolve().parent
out = root / 'evidence'
out.mkdir(exist_ok=True)
for path in (root / 'sources').glob('*.pdf'):
    doc = fitz.open(path)
    text = '\n'.join(f'\n=== PDF PAGE {i + 1} ===\n{page.get_text()}' for i, page in enumerate(doc))
    (out / (path.stem + '.txt')).write_text(text, encoding='utf-8')
    for i, page in enumerate(doc):
        if (path.stem == '2954fb' and i in (2, 5, 13)) or (path.stem not in ('tpd1e10b06', '2954fb')) or (path.stem == 'tpd1e10b06' and (i in (2, 4) or 'DPY0002A' in page.get_text())):
            page.get_pixmap(matrix=fitz.Matrix(2, 2)).save(out / f'{path.stem}-p{i + 1}.png')
    print(path.name, len(doc), 'pages')
for path in (root / 'sources').glob('*.gif'):
    Image.open(path).convert('RGB').save(out / (path.stem + '.png'))
