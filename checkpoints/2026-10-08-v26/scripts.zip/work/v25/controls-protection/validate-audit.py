import hashlib
import json
from pathlib import Path
import pcbnew

root = Path(__file__).resolve().parents[3]
out = root / 'outputs/SmartVio-V25-Engineering/audit/controls-protection'
native = root / 'outputs/SmartVio-V25-Engineering/electrical/native-components.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic(name, obj):
    target = out / name
    temp = target.with_suffix(target.suffix + '.tmp')
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    temp.replace(target)


docs = {p.name: json.loads(p.read_text(encoding='utf-8-sig')) for p in out.glob('*.json')}
proposal = docs['proposal.json']
verification = docs['verification.json']
assert len(docs['corrected-components.json']) == 7
assert len(docs['candidate-components.json']) == 11
assert len(docs['pin-records.json']['records']) == 55
assert proposal['add_components'] == proposal['remove_components'] == proposal['passive_value_changes'] == []
assert not proposal['scope']['global_eda_or_pcb_edited']
current = {c['ref']: c for c in json.loads(native.read_text(encoding='utf-8-sig'))}
for c in docs['corrected-components.json']:
    assert c['release'] == 'HOLD'
    assert [(p['number'], p['net']) for p in c['pins']] == [(p['number'], p['net']) for p in current[c['ref']]['pins']]
for c in docs['candidate-components.json']:
    assert c['candidateOnly'] and c['release'] == 'HOLD' and not c['procurementApproved']
    assert set(p['net'] for p in c['pins']) == set(p['net'] for p in current[c['ref']]['pins'])
for s in docs['sources.json']:
    assert sha(root / s['path']) == s['sha256']

library = out / 'footprints/Controls_Protection_Official.pretty'
fpname = 'TI_DPY0002A_1x0.6mm_P0.7mm_NSMD'
fp = pcbnew.FootprintLoad(str(library), fpname)
assert fp is not None
pads = sorted(list(fp.Pads()), key=lambda p: p.GetNumber())
assert len(pads) == 2
pad_rows = []
for pad, num, x in zip(pads, ('1', '2'), (-0.35, 0.35)):
    assert pad.GetNumber() == num
    pos = pad.GetPosition()
    size = pad.GetSize()
    def mm(value):
        return pcbnew.ToMM(value)
    assert abs(mm(pos.x) - x) < 1e-6 and abs(mm(pos.y)) < 1e-6
    assert abs(mm(size.x) - 0.3) < 1e-6 and abs(mm(size.y) - 0.5) < 1e-6
    assert abs(mm(pad.GetRoundRectCornerRadius()) - 0.05) < 1e-6
    assert pad.GetAttribute() == pcbnew.PAD_ATTRIB_SMD
    margin = pad.GetLocalSolderMaskMargin()
    assert margin is not None and abs(mm(margin) - 0.07) < 1e-6
    paste = pad.GetLocalSolderPasteMargin()
    assert paste in (0, None)
    pad_rows.append({'number': num, 'center_mm': [mm(pos.x), mm(pos.y)],
                     'size_mm': [mm(size.x), mm(size.y)],
                     'corner_radius_mm': mm(pad.GetRoundRectCornerRadius()),
                     'local_mask_margin_mm': mm(margin),
                     'local_paste_margin_mm': None if paste is None else mm(paste),
                     'paste_inheritance_hold': paste is None})

verification['footprint_parser_status'] = 'PASS_OFFICIAL_EXAMPLE_PAD_GEOMETRY_ONLY'
verification['footprint_parser'] = {'runtime': 'work/v24/tools/kicad/bin/python.exe',
                                    'kicad_version': pcbnew.Version(), 'footprint': fpname,
                                    'pads': pad_rows, 'board_drc': 'NOT_RUN',
                                    'board_paste_margin_and_ratio': 'HOLD: KiCad loads zero paste margin as inherited; board settings must produce official 0.3x0.5mm apertures',
                                    'scope': 'Standalone parser and pad dimensions; not routed DRC, fabrication or physical assembly approval'}
verification['native_components_sha256_at_validation'] = sha(native)
verification['native_file_unchanged_through_validation'] = sha(native) == proposal['source_native_sha256']
verification['all_json_parsed'] = True
verification['candidate_functional_net_sets_preserved'] = True
atomic('verification.json', verification)
atomic('artifact-hashes.json', {p.relative_to(out).as_posix(): sha(p) for p in out.rglob('*') if p.is_file() and p.name != 'artifact-hashes.json'})
print(json.dumps({'status': verification['footprint_parser_status'], 'pins': 55,
                  'native_unchanged': verification['native_file_unchanged_through_validation'],
                  'CAM_release': False}, indent=2))
