$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$dir = Join-Path $root 'sources'
New-Item -ItemType Directory -Path $dir -Force | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$sources = @(
    @{ id='ti-tpd'; file='tpd1e10b06.pdf'; url='https://www.ti.com/lit/ds/symlink/tpd1e10b06.pdf' },
    @{ id='alps-switch'; file='skqg.pdf'; url='https://tech.alpsalpine.com/cms.media/product_catalog_ta_02_skqg_en_d003713f01.pdf' },
    @{ id='alps-pot'; file='rk10j.pdf'; url='https://tech.alpsalpine.com/cms.media/product_catalog_rv_03_rk10j_en_780020d1ea.pdf' },
    @{ id='kingbright-led'; file='apt1608lzgck.pdf'; url='https://www.kingbrightusa.com/images/catalog/spec/apt1608lzgck.pdf' },
    @{ id='alps-switch-page'; file='skqgabe010.html'; url='https://tech.alpsalpine.com/e/products/detail/SKQGABE010/' },
    @{ id='alps-pot-page'; file='rk10j11r0a0l.html'; url='https://tech.alpsalpine.com/e/products/detail/RK10J11R0A0L/' },
    @{ id='alps-taper'; file='taper.gif'; url='https://tech.alpsalpine.com/assets/products/detail-additional/2021-2022/RV/r1.gif' },
    @{ id='alps-pot-terminals'; file='rk10j-terminals.gif'; url='https://tech.alpsalpine.com/cms.media/product_detail_fig_rkj1_c_121_en_a96f083ec0.gif' },
    @{ id='adi-pb-bias'; file='2954fb.pdf'; url='https://www.analog.com/media/en/technical-documentation/data-sheets/2954fb.pdf' }
)
$records = foreach ($s in $sources) {
    $path = Join-Path $dir $s.file
    try {
        if (-not (Test-Path -LiteralPath $path)) {
            Invoke-WebRequest -UseBasicParsing -Uri $s.url -OutFile $path -TimeoutSec 40
        }
        [ordered]@{ id=$s.id; url=$s.url; path=$path; sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower(); bytes=(Get-Item -LiteralPath $path).Length; status='downloaded'; retrieved_utc=[DateTime]::UtcNow.ToString('o') }
        Write-Host "Downloaded $($s.id)"
    } catch {
        [ordered]@{ id=$s.id; url=$s.url; status='HOLD'; error=$_.Exception.Message }
        Write-Host "HOLD $($s.id)"
    }
}
$records | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $root 'source-manifest.json') -Encoding UTF8
