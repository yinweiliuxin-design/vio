import copy
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
OUT = ROOT / 'outputs/SmartVio-V25-Engineering/audit/controls-protection'
NATIVE = ROOT / 'outputs/SmartVio-V25-Engineering/electrical/native-components.json'
OUT.mkdir(parents=True, exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, obj):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(target.suffix + '.tmp')
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=True) + '\n', encoding='utf-8')
    temp.replace(target)


baseline_hash = digest(NATIVE)
native = json.loads(NATIVE.read_text(encoding='utf-8-sig'))
byref = {c['ref']: c for c in native}
sources = json.loads((WORK / 'source-manifest.json').read_text(encoding='utf-8-sig'))
for source in sources:
    assert source['status'] == 'downloaded', source
    assert digest(Path(source['path'])) == source['sha256']
    source['path'] = Path(source['path']).relative_to(ROOT).as_posix()
source_by_id = {s['id']: s for s in sources}


def evidence(source_id, pages, section):
    s = source_by_id[source_id]
    return {'source_id': source_id, 'url': s['url'], 'sha256': s['sha256'],
            'local_file': s['path'], 'pdf_pages_1based': pages, 'section': section}


TPD_PIN = evidence('ti-tpd', [3, 8, 9, 11], 'Section 4/Table 4-1; Sections 6.2, 7.2, 7.4')
TPD_PAD = evidence('ti-tpd', [27, 28, 29], 'DPY0002A, drawing 4224561/C 07/2024, outline/board/stencil')
SW_PIN = evidence('alps-switch', [1], 'SKQGABE010 product row; Drawing No.1 Dimensions, Circuit Diagram, Land Dimensions')
RV_PIN = evidence('alps-pot', [1, 2], 'RK10J11R0A0L product row; Drawing No.3, mounting and circuit diagram')
LED_PIN = evidence('kingbright-led', [1], 'Package Dimensions, numbered diode schematic, Recommended Soldering Pattern')

refs_tpd = [f'D120{i}' for i in range(1, 8)]
refs_sw = [f'SW81{i}' for i in range(5)]
refs_rv = [f'RV81{i}' for i in range(3)]
refs_led = [f'D85{i}' for i in range(3)]
refs = refs_tpd + refs_sw + refs_rv + refs_led
assert len(refs) == len(set(refs)) == 18
assert all(r in byref for r in refs)
baseline = [copy.deepcopy(byref[r]) for r in refs]
write('baseline-components.json', baseline)
write('sources.json', sources)

pin_records = []
corrected_tpd = []
metadata_deltas = []
candidate_components = []


def row(ref, number, role, net, prior, proof, selected, status='OFFICIAL_PIN_VERIFIED'):
    return {'ref': ref, 'manufacturer_pin': number, 'manufacturer_function': role,
            'proposed_net': net, 'existing_logical_pin': prior, 'pin_evidence_status': status,
            'part_is_already_in_native_bom': selected, 'physical_assembly_verified': False,
            'evidence': proof}


fpname = 'TI_DPY0002A_1x0.6mm_P0.7mm_NSMD'
for ref in refs_tpd:
    c = copy.deepcopy(byref[ref])
    assert c['mpn'] == 'TPD1E10B06DPYR'
    assert [p['number'] for p in c['pins']] == ['1', '2']
    assert c['pins'][1]['net'] == 'GND'
    for p in c['pins']:
        role = 'protected_signal' if p['number'] == '1' else 'local_ground_return'
        pin_records.append(row(ref, p['number'], 'ESD protected I/O; connect the other terminal to ground',
                               p['net'], p['number'], TPD_PIN, True))
        p['manufacturerFunction'] = 'ESD-protected I/O; opposite terminal to ground'
        p['localRole'] = role
        p['electricalType'] = 'passive'
    # Table 4-1 specifies I/O function rather than a separate pin NAME column.
    c['package'] = 'TI X1SON DPY0002A, 2 pins, 1.0 x 0.6 mm nominal, 0.45 mm max height'
    c['manufacturer'] = 'Texas Instruments'
    c['pinProof'] = TPD_PIN
    c['footprintProposal'] = {'library_id': 'Controls_Protection_Official:' + fpname,
                              'applied': False, 'evidence': TPD_PAD,
                              'status': 'OFFICIAL_EXAMPLE_GEOMETRY_VERIFIED_FAB_ASSEMBLY_HOLD'}
    c['ncPins'] = []
    c['exposedPadPins'] = []
    c['release'] = 'HOLD'
    c['verificationScope'] = 'Official pin function and footprint example only; routed protection coordination, fabrication, assembly and test not released'
    c['note'] = (c.get('note', '') + ' Pin2 GND is local use of an interchangeable bidirectional I/O terminal, not a dedicated supply pin.').strip()
    corrected_tpd.append(c)
    metadata_deltas.append({'ref': ref, 'requires_parent_approval': True,
                            'expected_mpn': byref[ref]['mpn'], 'before': byref[ref], 'after': c,
                            'operation': 'replace_record_if_precondition_matches',
                            'connectivity_change': False, 'protection_parameter_change': False,
                            'physical_footprint_change': 'proposed only; do not reuse generic resistor/X2SON pads'})

for ref in refs_sw:
    before = byref[ref]
    signal = before['pins'][0]['net']
    assert before['pins'][1]['net'] == 'GND'
    proposed_pins = []
    for number in ('1', '2', '3', '4'):
        prior = '1' if number in ('1', '2') else '2'
        net = signal if prior == '1' else 'GND'
        name = 'CONTACT_A' if prior == '1' else 'CONTACT_B'
        pin_records.append(row(ref, number, name, net, prior, SW_PIN, False))
        proposed_pins.append({'number': number, 'name': name, 'net': net, 'electricalType': 'passive'})
    c = copy.deepcopy(before)
    c.update(mpn='SKQGABE010', manufacturer='Alps Alpine',
             package='SKQG 5.2 x 5.2 x 1.5 mm body, terminals span 6.4 mm; top push SMT',
             pins=proposed_pins, release='HOLD', candidateOnly=True,
             procurementApproved=False, pinProof=SW_PIN)
    c['verificationScope'] = 'Candidate only; numbered contact groups verified; no validated footprint, panel/actuator or contact-load qualification'
    candidate_components.append(c)

for ref in refs_rv:
    before = byref[ref]
    assert [p['number'] for p in before['pins']] == ['1', '2', '3']
    assert before['pins'][0]['net'] == 'V3D' and before['pins'][2]['net'] == 'GND'
    c = copy.deepcopy(before)
    for p in c['pins']:
        number = p['number']
        role = 'resistor end terminal' if number != '2' else 'wiper'
        pin_records.append(row(ref, number, role, p['net'], number, RV_PIN, False))
        p['manufacturerFunction'] = role
    # Two drawing-labelled DUMMY metal lugs are not assigned speculative signal pin numbers.
    for label in ('DUMMY_LEFT', 'DUMMY_RIGHT'):
        pin_records.append(row(ref, label, 'Manufacturer-labelled dummy metal lug; solder to substrate; electrical bonding/net assignment not established',
                               None, None, RV_PIN, False, 'OFFICIAL_MECHANICAL_LUG_ELECTRICAL_MAPPING_HOLD'))
    c.update(mpn='RK10J11R0A0L', manufacturer='Alps Alpine', candidateOnly=True,
             package='RK10J single-unit SMT, 14 mm thumbwheel, wheel thickness 1.0 mm; drawing No.3',
             release='HOLD', procurementApproved=False, pinProof=RV_PIN)
    c['verificationScope'] = 'Candidate only; three resistor pins verified, two dummy-lug mappings, full footprint and panel clearance HOLD'
    candidate_components.append(c)

for ref in refs_led:
    before = byref[ref]
    anode = next(p['net'] for p in before['pins'] if p['name'] == 'A')
    cathode = next(p['net'] for p in before['pins'] if p['name'] == 'K')
    assert cathode == 'GND'
    pins = [{'number': '1', 'name': 'K', 'net': cathode, 'electricalType': 'passive'},
            {'number': '2', 'name': 'A', 'net': anode, 'electricalType': 'passive'}]
    for p in pins:
        prior = '2' if p['number'] == '1' else '1'
        pin_records.append(row(ref, p['number'], p['name'], p['net'], prior, LED_PIN, False))
    c = copy.deepcopy(before)
    c.update(mpn='APT1608LZGCK', manufacturer='Kingbright', value='GREEN low-current alternative, NOT CYAN',
             package='1.6 x 0.8 x 0.75 mm SMT; MSL3; official pin1 K, pin2 A', pins=pins,
             release='HOLD', candidateOnly=True, procurementApproved=False, pinProof=LED_PIN,
             colorChangeRequiresApproval=True)
    c['verificationScope'] = 'Optional GREEN alternative only; do not populate against CYAN requirement or reuse native 1=A numbering'
    candidate_components.append(c)

write('corrected-components.json', corrected_tpd)
write('candidate-components.json', candidate_components)
write('pin-records.json', {
    'schema': 'smartvio.controls-protection.pin-records.v1',
    'source_native_sha256': baseline_hash, 'records': pin_records,
    'native_logical_pin_count': sum(len(byref[r]['pins']) for r in refs),
    'candidate_or_existing_electrical_pin_rows': sum(p['manufacturer_pin'].isdigit() for p in pin_records),
    'mechanical_lug_rows': sum(not p['manufacturer_pin'].isdigit() for p in pin_records),
    'nc_ep': {'D1201-D1207': {'nc': [], 'ep': [], 'total_electrical_pins_each': 2},
              'switch_candidate': {'nc': [], 'ep': [], 'internal_short_groups': [['1', '2'], ['3', '4']]},
              'pot_candidate': {'electrical_pins': ['1', '2', '3'], 'dummy_lugs': ['DUMMY_LEFT', 'DUMMY_RIGHT'],
                                'dummy_lug_net': 'HOLD; do not invent GND/NC/EP assignment'},
              'led_candidate': {'nc': [], 'ep': [], 'pin1': 'K', 'pin2': 'A'}},
    'installed_part_claim': False,
})

footprint_dir = OUT / 'footprints/Controls_Protection_Official.pretty'
footprint_dir.mkdir(parents=True, exist_ok=True)
footprint = f'''(footprint "{fpname}"
  (version 20240108)
  (generator "smartvio_official_drawing_audit")
  (layer "F.Cu")
  (descr "TI DPY0002A 4224561/C 07/2024 PDF pp27-29. NSMD alternative; TI prefers SMD. Fabrication/assembly HOLD.")
  (tags "TPD1E10B06DPYR X1SON DPY0002A official-example NSMD")
  (attr smd)
  (fp_text reference "REF**" (at 0 -0.9) (layer "F.SilkS")
    (effects (font (size 0.6 0.6) (thickness 0.1))))
  (fp_text value "TPD1E10B06DPYR" (at 0 0.9) (layer "F.Fab")
    (effects (font (size 0.6 0.6) (thickness 0.1))))
  (fp_rect (start -0.5 -0.3) (end 0.5 0.3)
    (stroke (width 0.05) (type default)) (fill none) (layer "F.Fab"))
  (fp_line (start -0.5 -0.3) (end -0.3 -0.3)
    (stroke (width 0.1) (type default)) (layer "F.Fab"))
  (fp_rect (start -0.8 -0.65) (end 0.8 0.65)
    (stroke (width 0.05) (type default)) (fill none) (layer "F.CrtYd"))
  (pad "1" smd roundrect (at -0.35 0) (size 0.3 0.5)
    (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.166666667)
    (solder_mask_margin 0.07) (solder_paste_margin 0))
  (pad "2" smd roundrect (at 0.35 0) (size 0.3 0.5)
    (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.166666667)
    (solder_mask_margin 0.07) (solder_paste_margin 0))
)
'''
(footprint_dir / (fpname + '.kicad_mod')).write_text(footprint, encoding='ascii')

findings = [
    {'id': 'CP-01', 'severity': 'P1', 'status': 'PROVEN_METADATA_FIX_PROPOSED', 'refs': refs_tpd,
     'finding': 'Native package says X2SON. Official DPY is X1SON DPY0002A; two electrical terminals, no separate EP/NC.',
     'action': 'Apply seven corrected records only after precondition review; retain every current numbered net. Do not use generic 0402 resistor pads.',
     'evidence': [TPD_PIN, TPD_PAD]},
    {'id': 'CP-02', 'severity': 'P1', 'status': 'HOLD_PROTECTION_COORDINATION', 'refs': refs_tpd,
     'finding': 'Correct bidirectional signal-to-ground topology is not downstream clamp compatibility or whole-board ESD proof.',
     'action': 'Keep existing protection parameters. Verify connector placement, short/wide return, return inductance and residual clamp against downstream absolute maxima; bench IEC/audio tests remain required.',
     'evidence': [evidence('ti-tpd', [4, 5, 9, 10, 11], 'Sections 5.4/5.6/7.2/7.4')]},
    {'id': 'CP-03', 'severity': 'P1', 'status': 'HOLD_SW813_LOW_LOAD', 'refs': ['SW813'],
     'finding': 'SKQGABE010 minimum rated contact load is 10 uA / 1 V. PWR_PB uses LTC2954 internal bias, not R823 (R823 is on KEY_PWR/INT). No guaranteed >=10 uA closed-contact current is established by this review.',
     'action': 'Do not mark SW813 qualified. Use formal low-load contact qualification or a separately authorized alternative. No added pull-up or power-boundary change in this task.',
     'evidence': [SW_PIN, evidence('adi-pb-bias', [3, 6, 14], 'Electrical Characteristics PB current; PB Pin Functions; External Pull-Up Resistor On PB')]},
    {'id': 'CP-04', 'severity': 'P1', 'status': 'PROVEN_NUMBER_MAPPING_HOLD_FOOTPRINT', 'refs': refs_sw,
     'finding': 'Candidate has four terminals with internal shorts 1-2 and 3-4. Native logical pin2=GND cannot be blindly copied onto manufacturer pin2, which is in the signal group.',
     'action': 'If selected, map official 1/2 to existing logical pin1 net; official 3/4 to existing logical pin2 GND. Add no external nets. Validate mounting-face/top-view conversion and copper keepout before footprint integration.',
     'evidence': [SW_PIN]},
    {'id': 'CP-05', 'severity': 'P1', 'status': 'HOLD_POT_MOUNTING_ADC_ENVIRONMENT', 'refs': refs_rv,
     'finding': 'RK10J11R0A0L is exact 10k 1B single-unit DC-capable SMT candidate, but two dummy lugs, panel fit, ADC acquisition/load and DC migration environment are not production-qualified.',
     'action': 'Keep native 1=V3D, 2=wiper, 3=GND. Moving toward terminal3 lowers the native wiper voltage; define UI/firmware polarity without silently swapping nets. No invented clockwise viewing convention.',
     'evidence': [RV_PIN, evidence('alps-taper', [], 'Upper-left graph B(1B), straight-line taper'),
                  evidence('alps-pot-page', [], 'Cautions: Direct Voltage, output impedance >100 times total resistance, solder all metal lugs')]},
    {'id': 'CP-06', 'severity': 'P1', 'status': 'HOLD_CYAN_SELECTION_AND_DRIVE', 'refs': refs_led,
     'finding': 'Verified low-current candidate APT1608LZGCK is GREEN, not native CYAN; official numbering 1=K 2=A reverses current logical numbering. Its 2 mA luminous specification is not guaranteed with the current 1k resistor at 3.3 V.',
     'action': 'Cyan exact MPN remains unselected. Green requires explicit color approval and polarity-preserving renumbering. Keep R850..852=1k; no new resistor/rail changes are authorized here.',
     'evidence': [evidence('kingbright-led', [1, 2, 3], 'Selection Guide; Package Dimensions; VF at 2mA; typical curves')]},
]

proposal = {
    'schema': 'smartvio.controls-protection.proposal.v1',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'PARTIAL_OFFICIAL_SOURCE_VERIFIED_MANUFACTURING_HOLD',
    'source_native_sha256': baseline_hash,
    'scope': {'owned_refs': refs, 'global_eda_or_pcb_edited': False,
              'new_functions': [], 'new_nets': [], 'removed_functions': [],
              'changes_require_parent_approval': True, 'do_not_auto_populate_candidates': True,
              'no_new_DOCK_MIC': True, 'manufacturing_release': False},
    'metadata_only_atomic_deltas': metadata_deltas,
    'add_components': [], 'remove_components': [], 'passive_value_changes': [],
    'conditional_candidate_records_file': 'candidate-components.json',
    'conditional_switch_pin_count_delta': 10,
    'conditional_switch_pin_count_delta_note': 'If parent chooses official four-pin symbols, +2 pins each x5; electrical node set unchanged. Not applied.',
    'candidates': {
        'SW810-SW814': {
            'mpn': 'SKQGABE010', 'selection_status': 'PROPOSED_NOT_SELECTED',
            'body_mm': [5.2, 5.2, 1.5], 'terminal_span_mm': 6.4,
            'force_N': 1.57, 'travel_mm': 0.25, 'life_cycles': 1000000,
            'max_contact_resistance_ohm': 0.1, 'minimum_contact_load': {'uA': 10, 'Vdc': 1},
            'maximum_contact_load': {'mA': 50, 'Vdc': 12}, 'temperature_C': [-40, 90],
            'contact_mapping': {'official_1_2': 'native logical 1 signal', 'official_3_4': 'native logical 2 GND'},
            'dc_pullup_calculation': {'SW810_811_812_814_nominal_mA': 3.3 / 10,
                                      'min_mA_at_assumed_3V_and_10k_plus_1percent': 3 / 10.1,
                                      'supply_envelope_is_assumption_not_new_rail_contract': True,
                                      'SW813_guaranteed_min_current_uA': None,
                                      'SW813_note': 'LTC2954 p6 describes 100k to internal 1.9V bias; this is not a guaranteed 19uA minimum. p3 guarantees only 3uA magnitude minimum at PB=0.6V, and gives no closed-contact 0V minimum.'},
            'RC_debounce': {'current_tau_s': 10000 * 10e-9, 'hardware_bounce_proof': False,
                            'firmware_debounce_required': True, 'capacitive_contact_pulse_qualification': 'HOLD'},
            'installation': ['Panel plunger centered, 0.25mm stroke and 1.57N force; no lateral load or permanent preload.',
                             'Official land is viewed from mounting face; copper-track prohibited regions must be preserved.',
                             'Reflow switch surface <=260C, maximum two passes with cooling; no washing/flux entry.',
                             'No verified waterproof/dustproof claim. Public outline specification is not a production delivery specification.'],
            'footprint_status': 'HOLD_NO_VALIDATED_KICAD_FOOTPRINT',
            'evidence': [SW_PIN, evidence('alps-switch-page', [], 'Basic information; min rating; soldering conditions; cautions')]},
        'RV810-RV812': {
            'mpn': 'RK10J11R0A0L', 'selection_status': 'PROPOSED_NOT_SELECTED',
            'nominal_ohm': 10000, 'tolerance_percent': 30, 'taper': '1B linear, official curve verified',
            'wheel_diameter_mm': 14, 'wheel_thickness_mm': 1, 'body_series_size_mm': 10,
            'drawing_axial_dimension_mm': 2.5,
            'installed_height_mm': None,
            'installed_height_note': 'Wheel thickness is not PCB assembly height; panel/board-stack envelope HOLD.',
            'voltage_limit_dc_V': 20, 'rated_power_W': 0.03, 'rated_ambient_C': 50,
            'temperature_C': [-10, 60], 'travel_deg': [260, 280], 'life_cycles': 10000,
            'torque_mNm': [0.5, 10], 'switch_function': False,
            'electrical_pin_map': {'1': 'V3D', '2': 'native VOL_RAW/TONE_RAW/FX_RAW', '3': 'GND'},
            'mechanical_lugs': {'count': 2, 'labels': ['DUMMY', 'DUMMY'],
                                'electrical_bonding': 'HOLD', 'instruction': 'Solder all metal lugs to substrate; no guessed GND net.'},
            'division_calculations': {'nominal_each_at_3V3_mW': 3.3 ** 2 / 10000 * 1000,
                                     'worst_each_at_assumed_3V6_7k_mW': 3.6 ** 2 / 7000 * 1000,
                                     'three_nominal_total_mA': 3 * 3.3 / 10000 * 1000,
                                     'max_Thevenin_plus_1k_1percent_ohm': 13000 / 4 + 1010,
                                     'nominal_100nF_pole_at_worst_R_Hz': 1 / (2 * math.pi * 4260 * 100e-9),
                                     'assumed_supply_upper_V': 3.6,
                                     'ADC_dynamic_settling_verified': False,
                                     'measured_temperature_rise_C': None},
            'installation': ['Do not substitute RK10J12R0A0B: dual 15A taper and DC not applicable in official table.',
                             'Moving from terminal1 end to terminal3 end decreases native ADC voltage. Clockwise direction/panel viewpoint remains HOLD.',
                             'Output impedance must exceed 100 times total resistance per manufacturer; assess ADC leakage/sample duty and settling.',
                             'Surface must remain below 250C; terminal profile maximum 250C for 3s, two reflows maximum.',
                             'Avoid moisture, condensation, corrosive chemicals and terminal stress. DC migration warning remains; formal supply specification not obtained.'],
            'footprint_status': 'HOLD_FULL_PAD_DUMMY_LUG_VIEW_AND_PANEL_MAPPING_NOT_CLOSED',
            'evidence': [RV_PIN, evidence('alps-taper', [], 'Upper-left B(1B) linear taper'),
                         evidence('alps-pot-terminals', [], 'Terminal layout: 1,2,DUMMY,DUMMY,3'),
                         evidence('alps-pot-page', [], 'Electrical specifications, rated power methods, soldering and DC/load cautions')]},
        'D850-D852': {
            'mpn': 'APT1608LZGCK', 'selection_status': 'OPTIONAL_COLOR_CHANGE_ONLY_NOT_SELECTED',
            'color': 'GREEN', 'native_color': 'CYAN', 'cyan_exact_mpn': None,
            'body_mm': [1.6, 0.8, 0.75], 'physical_pin_map': {'1': 'K GND', '2': 'A LED_ZONE_n_A'},
            'existing_symbol_pin_mapping': {'native_1_A': 'official_2_A', 'native_2_K': 'official_1_K'},
            'land_example_mm': {'pads_xy': [[-0.825, 0], [0.825, 0]], 'pad_size_xy': [0.8, 0.8],
                                'inner_gap': 0.85, 'tolerance': 0.1, 'numbering': ['1 K left', '2 A right'],
                                'kicad_footprint_generated': False},
            'VF_at_2mA_V': {'min': 2.2, 'typ': 2.65, 'max': 3},
            'luminous_mcd_at_2mA': {'min': 50, 'typ': 100}, 'dominant_nm_typ': 525,
            'current_network_resistor_ohm': 1000,
            'load_line_reference_mA': (3.3 - 2.65) / 1,
            'load_line_reference_note': '0.65mA is only an illustrative estimate using VF specified at 2mA; actual diode load line/MCU VOH must be solved. Does not inherit the 2mA optical guarantee.',
            'headroom_for_2mA_with_current_1k_and_min_VF_V': 2.2 + 2,
            'installation': ['MSL3: floor life/dry storage must follow the label and moisture-control process.',
                             'Reflow only, maximum two passes; no stress while hot; polarity marker/official numbering must be respected.',
                             'Panel visibility and whole-board thermal/optical validation not performed.'],
            'evidence': [evidence('kingbright-led', [1, 2, 3, 4], 'Package/polarity/land; optical and electrical tables; reflow; packaging')]}
    },
    'tpd_footprint_proposal': {
        'library_id': 'Controls_Protection_Official:' + fpname,
        'source_drawing': TPD_PAD, 'pad_numbers': ['1', '2'],
        'pad_centers_mm': [[-0.35, 0], [0.35, 0]], 'copper_pad_size_mm': [0.3, 0.5],
        'corner_radius_mm': 0.05, 'paste_aperture_size_mm': [0.3, 0.5],
        'stencil_thickness_example_mm': 0.1, 'solder_mask_margin_mm': 0.07,
        'solder_mask_opening_size_mm': [0.44, 0.64],
        'land_variant': 'Official NSMD alternative; TI marks SMD preferred, not implemented in this artifact.',
        'paste_inheritance_hold': 'KiCad zero paste margin can load as inherited. Full-board paste margin and ratio must be verified to yield the official 0.3x0.5mm aperture; standalone copper/mask verification is not paste-layer release.',
        'engineering_choices_not_vendor_dimensions': {'courtyard_mm': [1.6, 1.3], 'reference_text_placement': True},
        'applied_to_board': False, 'fab_and_assembly_approval': 'HOLD'},
    'tpd_limits_unchanged': {'recommended_pin_to_pin_V': [-5.5, 5.5],
                            'breakdown_min_V_magnitude': 6,
                            'clamp_pin1_signal_pin2_ground_1A_max_V': 10,
                            'clamp_pin1_signal_pin2_ground_5A_max_V': 14,
                            'surge_absolute_max_8_20us_A': 6, 'capacitance_typ_pF': 12,
                            'passive_no_supply_required': True, 'system_ESD_test_pass_claim': False,
                            'evidence': evidence('ti-tpd', [4, 5, 10], 'Tables 5.1/5.4/5.6 and Section 7.3')},
    'findings': findings,
    'holds': ['TPD connector-ground layout and downstream clamp coordination',
              'TPD footprint fabrication/assembly and inherited board paste settings; no blanket reuse of current pads',
              'SW813 guaranteed minimum contact current and capacitive contact suitability',
              'All five switch footprint keepout/view, mechanical actuation and panel fit',
              'All three pot dummy-lug electrical identity, full footprint and installed stack height',
              'Pot ADC acquisition/load, DC migration/environment and UI direction',
              'Cyan exact LED MPN or explicit green approval; polarity and visibility at current drive',
              'Formal Alps supply specifications and sample/lifetime qualification',
              'All physical, manufacturing, temperature-rise, IEC and assembled tests absent'],
    'stop_search_reason': 'Bounded official-source search complete; no invented MPN, no generic pad carryover, no physical contact with manufacturers required by this task.'
}
write('proposal.json', proposal)

verification = {
    'schema': 'smartvio.controls-protection.verification.v1',
    'status': 'PARTIAL_OFFICIAL_SOURCE_VERIFIED_CAM_HOLD',
    'source_hashes_recomputed_match': True, 'official_sources_count': len(sources),
    'native_components_sha256_before': baseline_hash,
    'native_components_sha256_after': digest(NATIVE),
    'native_file_unchanged_during_generation': baseline_hash == digest(NATIVE),
    'global_writes_attempted': [], 'global_edits_applied': False,
    'scope_owned_refs_count': len(refs), 'native_logical_pins_count': sum(len(byref[r]['pins']) for r in refs),
    'official_existing_TPD_electrical_pin_rows': 14,
    'official_candidate_electrical_pin_rows': 35,
    'pot_mechanical_lug_rows_mapping_hold': 6,
    'proposed_metadata_record_count': len(corrected_tpd),
    'conditional_unselected_candidate_count': len(candidate_components),
    'numbered_TPD_net_mapping_unchanged': all(a['pins'][i]['net'] == byref[a['ref']]['pins'][i]['net'] for a in corrected_tpd for i in (0, 1)),
    'new_external_nets': [], 'passive_value_changes': [], 'new_functions': [],
    'independent_DRC_or_ERC_run': False,
    'footprint_parser_status': 'PENDING_INDEPENDENT_KICAD_LOAD',
    'physical_tests': {'assembled_boards': 0, 'manufacturing_trials': 0, 'temperature_rise_measurements': 0,
                       'sample_contact_tests': 0, 'IEC_ESD_tests': 0, 'pot_ADC_capture_tests': 0,
                       'LED_photometric_tests': 0, 'manufacturer_contact_attempts': 0},
    'CAM_release_authorized': False,
    'holds': proposal['holds'],
}
write('verification.json', verification)
write('artifact-hashes.json', {p.relative_to(OUT).as_posix(): digest(p) for p in OUT.rglob('*') if p.is_file() and p.name != 'artifact-hashes.json'})
print(json.dumps({'out': str(OUT), 'TPD_records': 7, 'candidates_not_selected': 11,
                  'pins': len(pin_records), 'sources': len(sources),
                  'native_unchanged': verification['native_file_unchanged_during_generation']}, indent=2))
