import hashlib
import json
from pathlib import Path
import urllib.request

root = Path(__file__).resolve().parent / 'tools'
root.mkdir(parents=True, exist_ok=True)
downloads = [
    ('7zr.exe', 'https://github.com/ip7z/7zip/releases/download/26.03/7zr.exe'),
    ('7z2603-x64.exe', 'https://github.com/ip7z/7zip/releases/download/26.03/7z2603-x64.exe'),
    ('kicad-10.0.6-x86_64.exe', 'https://mirror.tuna.tsinghua.edu.cn/kicad/windows/stable/kicad-10.0.6-x86_64.exe'),
]
records = []
for name, url in downloads:
    target = root / name
    if not target.exists():
        print('Downloading', name, flush=True)
        with urllib.request.urlopen(url, timeout=90) as r, target.with_suffix('.part').open('wb') as f:
            total = 0
            next_report = 100_000_000
            while chunk := r.read(1024 * 1024):
                f.write(chunk)
                total += len(chunk)
                if total >= next_report:
                    print(name, total, flush=True)
                    next_report += 100_000_000
        target.with_suffix('.part').rename(target)
    digest = hashlib.file_digest(target.open('rb'), 'sha256').hexdigest()
    records.append(dict(name=name, url=url, bytes=target.stat().st_size, sha256=digest))
    print(name, target.stat().st_size, digest, flush=True)
(root / 'download-record.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
