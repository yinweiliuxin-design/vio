import hashlib
import json
import zipfile
from pathlib import Path

root=Path('outputs/SmartVio-V24-NativeEDA').resolve()
def read(name):return json.loads((root/name).read_text(encoding='utf-8'))
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

main=read('verification/main-drc.json')
sensor=read('verification/sensor-drc.json')
parity=read('verification/sensor-parity-and-routes.json')
visual=read('verification/visual-qa.json')
assert read('verification/netlist-roundtrip.json')['pass']
assert not sensor['violations'] and not sensor['unconnected_items']
assert parity['pass']
assert not visual['errors']
assert all(not p['missing'] and p['scrollWidth']<=p['innerWidth'] for p in visual['html'])
assert len(read('electrical/bom-review.json'))==291
assert read('verification/release-status.json')['fullProductRelease'] is False
assert all(t['status']=='NOT_EXECUTED' and t['result'] is None for t in read('assembly/commissioning-plan.json'))
status={'date':'2026-10-04','reviewPackageChecksPassed':True,'fullProductManufacturingApproved':False,
        'mainUnconnectedItems':len(main['unconnected_items']),'mainDrcViolations':len(main['violations']),
        'sensorDrcViolations':len(sensor['violations']),'sensorUnconnectedItems':len(sensor['unconnected_items']),
        'sensorSchematicPadParity':parity['pass'],'htmlViewportChecks':len(visual['html']),
        'schematicAndBoardSvgRenders':len(visual['drawings']),'hardwareTestsExecuted':0}
(root/'verification/package-review.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
def files():
    return sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts
      and p.suffix not in ('.pyc','.lck','.prl') and p.name!='manifest-sha256.json')
manifest={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':digest(p)} for p in files()}
(root/'manifest-sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
archive=root.parent/'SmartVio-V24-NativeEDA-Review.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files()+[root/'manifest-sha256.json']:
        z.write(p,root.name+'/'+p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,item in manifest.items():
        assert hashlib.sha256(z.read(root.name+'/'+name)).hexdigest()==item['sha256']
result={'archive':str(archive),'files':len(manifest)+1,'bytes':archive.stat().st_size,
        'sha256':digest(archive),'crcAndEveryFileHashVerified':True,**status}
(root.parent/'SmartVio-V24-NativeEDA-Review-verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
