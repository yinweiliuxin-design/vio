import urllib.request
from pathlib import Path

out=Path('outputs/SmartVio-V24-NativeEDA/eda/SmartVio.pretty')
for name,url in [('LICENSE.md','https://raw.githubusercontent.com/KiCad/kicad-footprints/master/LICENSE.md'),
                 ('CC-BY-SA-4.0.txt','https://raw.githubusercontent.com/spdx/license-list-data/main/text/CC-BY-SA-4.0.txt')]:
    with urllib.request.urlopen(url,timeout=60) as response:
        data=response.read()
    assert len(data)>100
    (out/name).write_bytes(data)
    print(name,len(data))
