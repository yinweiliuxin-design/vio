import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
env = os.environ.copy()
env['KICAD_CONFIG_HOME'] = str(root / 'config')
env['KICAD_DOCUMENTS_HOME'] = str(root / 'documents')
env['KICAD10_FOOTPRINT_DIR'] = str(root / 'tools/kicad/share/kicad/footprints')
env['KICAD10_SYMBOL_DIR'] = str(root / 'tools/kicad/share/kicad/symbols')
result = subprocess.run([str(root / 'tools/kicad/bin/kicad-cli.exe'), *sys.argv[1:]], env=env)
sys.exit(result.returncode)
