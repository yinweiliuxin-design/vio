const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const {chromium} = require('<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = path.resolve('outputs/SmartVio-V24-NativeEDA');
const out = path.join(root,'verification','screenshots');
fs.mkdirSync(out,{recursive:true});
(async()=>{
  const browser = await chromium.launch({headless:true,channel:'chrome'});
  const page = await browser.newPage({viewport:{width:1600,height:1132}});
  const errors=[];
  page.on('pageerror',e=>errors.push(String(e)));
  const svgs = fs.readdirSync(path.join(root,'drawings')).filter(x=>x.endsWith('.svg'));
  const results=[];
  for (const [i,file] of svgs.entries()) {
    await page.goto(pathToFileURL(path.join(root,'drawings',file)).href);
    await page.evaluate(()=>{const s=document.querySelector('svg');s.style.width='1560px';s.style.height='1080px';});
    const info=await page.evaluate(()=>({paths:document.querySelectorAll('path').length, text:document.querySelectorAll('text').length, svg:!!document.querySelector('svg')}));
    await page.screenshot({path:path.join(out,`drawing-${String(i).padStart(2,'0')}.png`)});
    results.push({file,screenshot:`drawing-${String(i).padStart(2,'0')}.png`,...info});
  }
  const html=[];
  for(const width of [390,1440]){
    await page.setViewportSize({width,height:1000});
    for(const file of ['index.html','bom.html','mechanical.html','factory.html']){
      await page.goto(pathToFileURL(path.join(root,file)).href);
      const result=await page.evaluate(()=>({scrollWidth:document.documentElement.scrollWidth,innerWidth:innerWidth,links:[...document.querySelectorAll('a[href]')].map(a=>a.href),images:[...document.images].map(i=>({src:i.src,complete:i.complete,naturalWidth:i.naturalWidth}))}));
      const missing=result.links.filter(l=>l.startsWith('file:')).filter(l=>!fs.existsSync(require('node:url').fileURLToPath(new URL(l.split('#')[0]))));
      await page.screenshot({path:path.join(out,`${file}-${width}.png`),fullPage:false});
      html.push({file,width,...result,missing});
    }
  }
  await browser.close();
  fs.writeFileSync(path.join(root,'verification/visual-qa.json'),JSON.stringify({drawings:results,html,errors},null,2));
  console.log(JSON.stringify({drawingCount:results.length,htmlChecks:html.length,errors,overflow:html.filter(x=>x.scrollWidth>x.innerWidth),missing:html.flatMap(x=>x.missing)}));
})().catch(e=>{console.error(e);process.exitCode=1;});
