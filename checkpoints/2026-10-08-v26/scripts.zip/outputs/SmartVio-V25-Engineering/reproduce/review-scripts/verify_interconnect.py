"""Check exported internal wiring against the explicit endpoint schedule."""
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V25-Engineering'
V = ROOT / 'verification'
logs = []

def cli(*args):
    cmd = [sys.executable, '-X', 'utf8', str(BASE/'work/v24/kicad_cli.py'), *map(str,args)]
    p = subprocess.run(cmd, capture_output=True, encoding='utf-8', errors='replace')
    logs.append({'command':cmd,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    if p.returncode:
        raise RuntimeError(p.stdout+p.stderr)

source = ROOT/'assembly/Interconnect.kicad_sch'
cli('sch','erc','--format','json','-o',V/'interconnect-erc.json',source)
cli('sch','export','netlist','--format','kicadxml','-o',V/'interconnect-netlist.xml',source)
cli('sch','export','pdf','-o',ROOT/'drawings/SmartVio-V25-Internal-Wiring-HOLD.pdf',source)
schedule = json.loads((ROOT/'assembly/interconnect.json').read_text(encoding='utf-8'))
expected = {}
for w in schedule['wireSchedule']:
    expected.setdefault(w['net'],set()).update([(w['fromRef'],w['fromPad']),(w['toRef'],w['toPad'])])
actual = {}
tree = ET.parse(V/'interconnect-netlist.xml')
for net in tree.findall('.//nets/net'):
    name = net.get('name')
    if name.startswith('unconnected-'):
        continue
    actual[name] = {(n.get('ref'),n.get('pin')) for n in net.findall('node')}
differences = [{'net':n,'missing':sorted(expected.get(n,set())-actual.get(n,set())),
                'extra':sorted(actual.get(n,set())-expected.get(n,set()))}
               for n in sorted(set(actual)|set(expected)) if actual.get(n,set())!=expected.get(n,set())]
erc = json.loads((V/'interconnect-erc.json').read_text(encoding='utf-8'))
violations = [v for s in erc['sheets'] for v in s['violations']]
result = {'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'endpointCount':schedule['endpointCount'],'wireCount':schedule['wireCount'],
          'ercViolationCount':len(violations),'netlistDifferences':differences,
          'pass':not violations and not differences,'manufacturingApproved':False,
          'scope':'Logical endpoint capture only; no approved wire MPN, gauge, length, solder process, USB impedance or mechanical qualification.'}
(V/'interconnect-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
(V/'interconnect-export-log.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
if not result['pass']:
    raise SystemExit(1)
