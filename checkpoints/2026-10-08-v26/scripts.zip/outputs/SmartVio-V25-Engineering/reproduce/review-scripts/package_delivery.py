"""Snapshot the review pack with per-file SHA256 and ZIP CRC verification."""
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE/'outputs/SmartVio-V25-Engineering'
OUT = BASE/'outputs/SmartVio-V25-Engineering-HOLD-20261008.zip'
DEST = ROOT/'reproduce/review-scripts'
DEST.mkdir(parents=True,exist_ok=True)
for name in ['integrate.py','system_review.py','verify_electrical.py','verify_interconnect.py',
             'release_review.py','delivery_review.py','report.py','pdf_check.py','package_delivery.py']:
    shutil.copyfile(BASE/'work/v25'/name,DEST/name)
for name in ['archive_evidence.py','ui_check.cjs']:
    shutil.copyfile(BASE/'work/v25'/name,DEST/name)
(ROOT/'reproduce/REPRODUCIBILITY.txt').write_text(
    'Review-script snapshot only. Scripts retain the original workspace layout and require the\n'
    'workspace KiCad CLI helper, Python/pcbnew, source baselines and domain review artifacts.\n'
    'This ZIP is not an offline installer for KiCad, Arm GNU, ESP-IDF, SDKs or router tools.\n'
    'Native EDA can be opened with KiCad10; firmware build prerequisites and actual results are\n'
    'documented in firmware/INTEGRATION.txt. Use released software/toolchain licenses.\n'
    'Do not run a script that silently overwrites a supplier-approved version. Review hashes/ECO.\n',encoding='utf-8')
def include(p):
    return p.is_file() and not any(x in {'__pycache__','.git','node_modules'} for x in p.parts) and p.suffix not in {'.prl','.pyc'}
files = sorted(p for p in ROOT.rglob('*') if include(p) and p.name!='SHA256SUMS.json')
records = [{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,
            'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest = {'revision':'V25-20261008','createdAtUtc':datetime.now(timezone.utc).isoformat(),
            'status':'HOLD_NOT_MANUFACTURING_APPROVAL','hardwareTests':0,'files':records}
(ROOT/'SHA256SUMS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
files.append(ROOT/'SHA256SUMS.json')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:
        z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUT) as z:
    bad = z.testzip()
    names = z.namelist()
    for rec in records:
        data = z.read(ROOT.name+'/'+rec['path'])
        assert hashlib.sha256(data).hexdigest()==rec['sha256'],rec['path']
    assert len(names)==len(set(names)),'duplicate archive path'
assert bad is None,bad
result = {'archive':str(OUT),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
          'bytes':OUT.stat().st_size,'fileCount':len(files),'crcValid':True,
          'manifestHashesVerified':len(records),'productionApproved':False}
(BASE/'outputs/SmartVio-V25-Engineering-HOLD-20261008-package-check.json').write_text(
    json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
