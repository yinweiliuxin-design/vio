"""Preserve downloaded primary power evidence without rewriting audit history."""
import hashlib
import json
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE/'outputs/SmartVio-V25-Engineering'
folder = ROOT/'audit/power'
sources = json.loads((folder/'sources.json').read_text(encoding='utf-8'))
records = []
for key,source in sources.items():
    row = {'id':key,'url':source['url'],'originalRecord':source}
    if source.get('file') and source.get('sha256'):
        original = Path(source['file'])
        if not original.is_absolute():
            original = BASE/original
        assert original.is_file(),original
        digest = hashlib.sha256(original.read_bytes()).hexdigest()
        assert digest==source['sha256'],original
        destination = folder/'source-evidence'/original.name
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(original,destination)
        row.update({'packPath':destination.relative_to(ROOT).as_posix(),
                    'sha256':digest,'bytes':destination.stat().st_size,
                    'status':'ARCHIVED_HASH_VERIFIED'})
    else:
        row.update({'packPath':None,'status':'NO_LOCAL_FILE_NOT_FABRICATED'})
    records.append(row)
(folder/'parent-source-manifest.json').write_text(
    json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'archived':sum(r['packPath'] is not None for r in records),
                  'notArchived':sum(r['packPath'] is None for r in records)}))
