"""Assemble evidence coverage without converting rule checks into release approval."""
import hashlib
import html
import json
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V25-Engineering'

def read(path, fallback):
    p = ROOT / path
    return json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else fallback

def write(path, value):
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

parts = read('electrical/native-components.json', [])
power = {(p['ref'], str(p['pin'])): p for p in read('audit/power/pin-audit.json', [])}
contracts = read('firmware/contracts/pins.json', {})
fw_check = read('firmware/verification/contracts-check.json', {})
stm = {str(p['pin']): p for p in contracts.get('stm32', {}).get('signals', [])}
stm_special = {str(p['pin']): p for p in fw_check.get('stmSpecialPins', [])}
esp = {str(p['pin']): p for p in contracts.get('esp32', {}).get('signals', [])}
esp_ground = set(map(str, contracts.get('esp32', {}).get('groundPins', [])))
esp_nc = set(map(str, contracts.get('esp32', {}).get('ncPins', [])))
footprints = read('pcb-work/footprint-review.json', {})
unused = read('firmware/verification/unused-pin-audit.json', {})
identity = {(r['ref'],str(r['pin'])):r for r in unused.get('records', [])}
rows = []
for c in parts:
    for p in c['pins']:
        ref, num = c['ref'], p['number']
        state, evidence = 'REQUIRES_REVIEW', None
        if (ref, num) in power:
            record = power[(ref, num)]
            state = 'PIN_FUNCTION_DOCUMENTED' if record['net'] == p['net'] else 'STALE_NET_REVIEW'
            evidence = {'source': 'audit/power/pin-audit.json', 'location': record['location']}
        elif p.get('evidence'):
            state = 'PIN_FUNCTION_DOCUMENTED' if p.get('pinAuditStatus') == 'VERIFIED_OFFICIAL' else 'HOLD_PHYSICAL_PAD_OR_FUNCTION'
            evidence = p['evidence']
        elif ref == 'U801' and num in stm:
            state = 'PIN_FUNCTION_DOCUMENTED' if stm[num]['net'] == p['net'] else 'CONTRACT_NET_MISMATCH'
            evidence = {'source': 'firmware/contracts/pins.json', 'function': stm[num]['function'], 'af': stm[num]['af']}
        elif ref == 'U801' and num in stm_special:
            state, evidence = 'PIN_FUNCTION_DOCUMENTED', {'source': 'firmware/verification/contracts-check.json', 'special': stm_special[num]}
        elif ref == 'U901' and num in esp:
            state = 'PIN_FUNCTION_DOCUMENTED' if esp[num]['net'] == p['net'] else 'CONTRACT_NET_MISMATCH'
            evidence = {'source': 'firmware/contracts/pins.json', 'function': esp[num]['function']}
        elif ref == 'U901' and num in esp_ground and p['net'] == 'GND':
            state, evidence = 'PIN_FUNCTION_DOCUMENTED', {'source': 'firmware/contracts/pins.json', 'function': 'GND'}
        elif ref == 'U901' and num in esp_nc and p['net'] is None:
            state, evidence = 'PIN_FUNCTION_DOCUMENTED', {'source': 'firmware/contracts/pins.json', 'function': 'NC'}
        elif (ref, num) in identity:
            record = identity[(ref,num)]
            state = 'PIN_IDENTITY_NC_CONDITIONAL' if record['v25Net']==p['net'] else 'STALE_NET_REVIEW'
            evidence = {'source':'firmware/verification/unused-pin-audit.json','identity':record['manufacturerName'],
                        'category':record['category'],'conditions':record['conditions']}
        elif c['type'] == 'R' and c.get('bomEvidence'):
            state, evidence = 'NONPOLAR_PART_IDENTITY_DOCUMENTED', c['bomEvidence']
        elif c['type'] in ('R', 'C', 'L'):
            state = 'PASSIVE_APPLICATION_AND_MPN_REVIEW_PENDING'
        rows.append({'ref': ref, 'pin': num, 'name': p['name'], 'net': p['net'], 'mpn': c.get('mpn'),
                     'reviewStatus': state, 'evidence': evidence,
                     'physicalPad': p.get('footprintPad', num if num.isdigit() else None),
                     'footprintStatus': footprints.get(ref, {}).get('review', 'NOT_ASSIGNED'),
                     'ercIsElectricalProof': False, 'hardwareVerified': False})
write('audit/all-pins.json', rows)
counts = dict(Counter(r['reviewStatus'] for r in rows))
write('verification/pin-review-coverage.json', {'enumeratedPins': len(rows), 'counts': counts,
      'allPinsElectricallyApproved': False, 'physicalTests': 0,
      'meaning': 'Enumeration covers every capture pin. Documentation/capability coverage is not application signoff, unused-pin validation, PCB continuity or hardware validation.'})

faults = [
    ('F01', '主控复位、启动及故障', 'CE硬件拉高，CHARGE_ALLOW低；RF_CHIP_EN经R901拉低，R907限制C901驱动电流；USB100输入状态保留供电。', '先写BSRR安全值，再设GPIO输出；未通过自检不得使能负载；射频高后至少5ms，复位低至少30ms。', '复位示波器捕获；欠压、HardFault及异常启动测试，RC有效容量及IO总电流待核验。'),
    ('F02', 'NTC开路/短路或温区异常', 'BQ24074 TS独立检测；成品电池包保护不得由固件代替。', '传感器失效/过期值禁止充电；不能凭ISET判断电池存在。', '电阻箱验证真实NTC曲线；未选电池前不接真实锂电芯。'),
    ('F03', 'USB过压或短路', 'TPS25947输入限流/OVP锁存；TPD2S703改独立USB_VREF、MODE1反馈；系统侧瞬态钳位与PHY限值仍未闭环。', '故障默认禁止USB数据和充电；保护后VBUS为零不能当拔线清锁；参考稳态和使能时序需实测。', '专用故障注入夹具；手机和电脑不得作为故障试验负载。'),
    ('F04', '采样失效/I2C卡死', '监测前端隔离；硬件充电保护保留。', 'I2C超时、NACK、ADC饱和或读数过期保持禁充；实际总线恢复仍待验证。', '断SDA、断SCL、传感器断开、卡低及上电时序测试。'),
    ('F05', '时钟未锁定/音频帧错误', '上电静音路径；耳机及扬声器使能保持低。', 'ADC双I2S、DAC及扬声器时钟/槽顺序验证前不开放输出。', '逐路已知频率输入、逻辑分析仪解码、DMA顺序及帧丢失验证。'),
    ('F06', '耳机插入/半插', '检测触点物理编号冲突尚未解决，不允许据此投板。', '候选插入极性为HIGH；先静音再切换，防止爆音和扬声器误响。', '实物触点连续性、TS/TRS/半插、假负载直流与爆音测试。'),
    ('F07', '输出过大或反馈啸叫', 'MAX98357低增益候选；BTL输出两端都不能接地。', '仅喇叭流临时峰值限制0.40FS；RETURN不回送SEND；仍需直流、高通、声反馈验证。', '任意码/方波/直流/正弦、实际最小阻抗、机械反馈、热压缩。'),
    ('F08', '无线断连/未知命令', '射频默认禁用，主板音频不能依赖无线连接存活。', 'CRC、长度、序号、超时及重放处理；蓝牙代码替身不是无线驱动。', '真正ESP固件编译、配对/重连/干扰/延迟实测；当前未完成。'),
    ('F09', '用户关机、USB插入', '目前关机CE高，未实现自动插USB唤醒。', '不能声称关机自动充电已完成；负载和唤醒电路闭环后才开放该功能。', '电池耗尽、USB源受限、边充边用、拔线、冷启动与关机功耗测试。'),
]
write('electrical/fault-handling.json', [{'id': i, 'fault': f, 'hardware': h, 'firmware': s, 'verification': v, 'hardwareTest': 'NOT_EXECUTED'} for i,f,h,s,v in faults])

escape = html.escape
css = 'body{font:14px/1.6 "Microsoft YaHei",sans-serif;margin:24px;color:#202b2c}h1{font-size:24px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd5d5;padding:7px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#e8eeee}a{color:#076da0}.scroll{overflow:auto}.hold{background:#fff0eb;padding:12px;border-left:4px solid #bc4030}input{padding:9px;width:300px;max-width:100%;margin:12px 0}@media(max-width:600px){body{margin:14px}table{min-width:700px}}'
def table(headers, values):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+escape(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(v))+'</td>' for v in row)+'</tr>' for row in values)+'</tbody></table></div>'

body = '<h1>SmartVio V25 逐脚审核台账</h1><p><a href="../index.html">返回工程总览</a></p>'
body += '<p class="hold">已枚举所有引脚，但不是所有引脚都完成应用电路批准。PIN_FUNCTION_DOCUMENTED仅表示有原厂引脚或能力证据；不等于焊接、连通、供电时序或实物通过。无硬件实测。</p>'
body += table(['分类','引脚数量'], counts.items())
body += '<input type="search" aria-label="查找器件、引脚或网络" placeholder="查找器件、引脚或网络" id="search">'
body += '<div id="pins">'+table(['位号','脚号','功能','网络','料号','审核状态'], [[r['ref'],r['pin'],r['name'],r['net'],r['mpn'],r['reviewStatus']] for r in rows])+'</div>'
body += '<p><a href="all-pins.json">逐脚证据与封装状态JSON</a></p><h2>故障处理及实测要求</h2>'
body += table(['编号','故障','硬件','软件','验证'], faults)
body += '<script>document.getElementById("search").addEventListener("input",e=>{const q=e.target.value.toLowerCase();document.querySelectorAll("#pins tbody tr").forEach(r=>r.hidden=!r.textContent.toLowerCase().includes(q))})</script>'
(ROOT/'audit/pin-review.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>逐脚审核</title><style>'+css+'</style>'+body+'</html>',encoding='utf-8')
print(json.dumps({'pins':len(rows),'coverage':counts},ensure_ascii=False))
