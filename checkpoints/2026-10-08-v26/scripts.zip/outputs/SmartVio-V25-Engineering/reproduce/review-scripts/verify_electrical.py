"""Independent capture/parity checks, including deliberate fault injection."""
import copy
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V25-Engineering'
V=ROOT/'verification'
V.mkdir(parents=True,exist_ok=True)
records=[]
def cli(*args):
 cmd=[sys.executable,'-X','utf8',str(BASE/'work/v24/kicad_cli.py'),*map(str,args)]
 cp=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
 records.append({'command':cmd,'exitCode':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr})
 if cp.returncode: raise RuntimeError(cp.stdout+cp.stderr)

def circuit_checks(parts):
 by={c['ref']:c for c in parts}
 def n(ref,pin):return next(p['net'] for p in by[ref]['pins'] if p['number']==str(pin))
 return {
  'charge_current_path_connected':n('U501',16)==n('R501',1)==n('U1702',12),
  'charger_thermal_pad_ground':n('U501',17)=='GND',
  'charge_gate_active_low':n('Q1601',3)==n('U501',4)==n('R503',2),
  'charge_gate_default_low':n('Q1601',1)==n('R1602',1) and n('R1602',2)=='GND',
  'ntc_hardware_preserved':n('U501',1)==n('J501',3)=='PACK_NTC',
  'current_buffer_negative_feedback':n('U1703',13)==n('U1703',14)==n('R1716',1),
  'current_input_bias_not_old_100k':by['R1715']['value'].startswith('10M'),
  'current_channel_no_old_divider':'R1713' not in by and 'R1714' not in by,
  'bq_safety_timer_enabled':n('U501',14) is None,
  'usb_raw_not_mcu_sense':n('R816',1)=='USB_5V_SAFE',
  'headphone_negative_reservoir_updated':by['C304']['value'].startswith('2.2uF'),
  'adc_lane2_source_damping':n('U601',21)==n('R691',1)=='ADC_DATA2_SRC' and by['R691']['value'].startswith('33R'),
  'adc_lane2_mcu_input':n('R691',2)==n('U801',2)=='ADC_DATA2' and next(p for p in by['U801']['pins'] if p['number']=='2')['electricalType']=='input',
  'radio_default_off_pulldown':n('R901',1)==n('C901',1)==n('U901',8)==n('J902',6)=='RF_CHIP_EN' and n('R901',2)=='GND',
  'radio_cap_not_direct_gpio':n('R907',1)==n('U801',33)=='RF_ENABLE' and n('R907',2)=='RF_CHIP_EN' and by['R907']['value']=='470R',
  'speaker_gain_resistor_preserved':n('R903',1)==n('U902',2)=='SPK_GAIN' and n('R903',2)=='SYS',
  'usb_reference_not_v3d':n('U1501',8)==n('C1502',1)==n('R1504',1)=='USB_VREF' and n('R1504',2)==n('R1501',1)==n('U1501',6)=='USB_OVP_MODE',
  'usb_mode1_feedback_values':by['R1504']['value']=='140k 1%' and by['R1501']['value']=='24.9k 1%' and n('R1501',2)=='GND',
 }

parts=json.loads((ROOT/'electrical/native-components.json').read_text(encoding='utf-8'))
checks=circuit_checks(parts)
mutations=[]
for ref,pin,bad,key in [
 ('U1702','12','WRONG_FLOATING_ISET','charge_current_path_connected'),
 ('U501','17','PACK_PLUS','charger_thermal_pad_ground'),
 ('U501','14','GND','bq_safety_timer_enabled'),
 ('R816','1','VBUS_RAW','usb_raw_not_mcu_sense'),
 ('U801','2','ADC_DATA','adc_lane2_mcu_input'),
 ('R901','2','V3D','radio_default_off_pulldown'),
 ('R907','2','RF_ENABLE','radio_cap_not_direct_gpio'),
 ('U1501','8','V3D','usb_reference_not_v3d'),
 ('R903','1','RF_ENABLE','speaker_gain_resistor_preserved')]:
 altered=copy.deepcopy(parts)
 c=next(c for c in altered if c['ref']==ref)
 next(p for p in c['pins'] if p['number']==pin)['net']=bad
 result=circuit_checks(altered)
 mutations.append({'ref':ref,'pin':pin,'injectedNet':bad,'expectedCheck':key,'detected':not result[key]})
cli('sch','erc','--format','json','-o',V/'erc.json',ROOT/'eda/SmartVio.kicad_sch')
cli('sch','export','netlist','--format','kicadxml','-o',V/'native-netlist.xml',ROOT/'eda/SmartVio.kicad_sch')
cli('sch','export','svg','-o',str(ROOT/'drawings')+'/',ROOT/'eda/SmartVio.kicad_sch')
cli('sch','export','pdf','-o',ROOT/'drawings/SmartVio-V25-Schematic-HOLD.pdf',ROOT/'eda/SmartVio.kicad_sch')
tree=ET.parse(V/'native-netlist.xml'); expected={}; actual={}
for c in parts:
 for p in c['pins']:
  if p['net']:expected.setdefault(p['net'],set()).add((c['ref'],p['number']))
for net in tree.findall('.//nets/net'):
 name=net.get('name')
 if name.startswith('unconnected-'):continue
 actual[name]={(n.get('ref'),n.get('pin')) for n in net.findall('node') if not n.get('ref').startswith('#')}
differences=[{'net':n,'missing':sorted(expected.get(n,set())-actual.get(n,set())),
              'extra':sorted(actual.get(n,set())-expected.get(n,set()))}
             for n in sorted(set(expected)|set(actual)) if expected.get(n,set())!=actual.get(n,set())]
erc=json.loads((V/'erc.json').read_text(encoding='utf-8'))
violations=[v for s in erc['sheets'] for v in s['violations']]
summary={'components':len(parts),'pins':sum(len(c['pins']) for c in parts),'nets':len(expected),
 'ercViolationCount':len(violations),'netlistDifferences':differences,'targetedCircuitChecks':checks,
 'negativeControls':mutations,'sourceSha256':hashlib.sha256((ROOT/'electrical/native-components.json').read_bytes()).hexdigest(),
 'pass':not violations and not differences and all(checks.values()) and all(m['detected'] for m in mutations),
 'scope':'Native capture transfer, specific logical topology, and ERC only; not analog simulation, EMC or hardware testing.'}
(V/'electrical-check.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(V/'export-log.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
if not summary['pass']:raise SystemExit(1)
