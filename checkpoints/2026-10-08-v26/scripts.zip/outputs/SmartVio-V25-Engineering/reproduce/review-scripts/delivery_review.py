"""Publish versioned evidence and explicit factory release gates, not approval."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE/'outputs/SmartVio-V25-Engineering'

def read(path,default=None):
    p = ROOT/path
    return json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else default

def write(path,obj):
    p = ROOT/path
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def sha(path):
    p = ROOT/path
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None

source = sha('electrical/native-components.json')
electrical = read('verification/electrical-check.json',{})
coverage = read('verification/pin-review-coverage.json',{})
firmware = read('firmware/verification/build-status.json',{})
parity = read('firmware/verification/live-net-parity.json',{})
interconnect = read('verification/interconnect-check.json',{})
pcb = read('pcb-work/verification/final-summary.json',{})
write('verification/jack-continuity-worksheet.json',{
    'mpn':'Lumberg1503 18','purpose':'Resolve official schematicDA8 versus physical solder-layout6 by an unpowered sample and supplier clarification.',
    'status':'NOT_EXECUTED','notATestResult':True,'supplyConnected':False,
    'instructions':['Photograph exact part and supplier lot/physical leads against official solder-side drawing.',
       'Never connect the jack, instrument, battery, amp or phone to power for this continuity test.',
       'Record the meter resistance numerically and probe pair for unplugged, full TRS, TS and half-inserted states.',
       'Identify sleeve/tip/ring with a separate accessible TRS test plug; do not treat DA as a physical pad number.',
       'Return clear physical pad photos, manufacturer document version and every reading to the engineer before mapping DA or producing the audio PCB.'],
    'contacts':[{'physicalPad':'1','claimedFunction':'SLEEVE_DOCUMENTED','measuredFunction':None},
                {'physicalPad':'2','claimedFunction':'TIP_DOCUMENTED','measuredFunction':None},
                {'physicalPad':'3','claimedFunction':'RING_DOCUMENTED','measuredFunction':None},
                {'physicalPad':'6_on_land_drawing_or_8_on_circuit','claimedFunction':'DETECT_A_UNRESOLVED','measuredFunction':None},
                {'physicalPad':'7','claimedFunction':'DETECT_B_DOCUMENTED','measuredFunction':None}],
    'measurements':[{'state':s,'pair':pair,'resistanceOhm':None,'operator':None,'partLot':None}
      for s in ['UNPLUGGED','TRS_FULL','TS_FULL','HALF_INSERTED']
      for pair in [('1','2'),('1','3'),('2','3'),('1','DA_PHYSICAL_TBD'),('2','DA_PHYSICAL_TBD'),
                   ('3','DA_PHYSICAL_TBD'),('7','DA_PHYSICAL_TBD')]],
    'manufacturerEvidence':'audit/audio/jack-contact-review.json',
    'allowProductionPadAlias':False})
write('verification/structural-budget.json',{
    'revision':'V25-20261008','referencePlane':'Existing violin BACK mounting face, z=0; module control face points outward.',
    'scope':'Nominal geometry diagnostics from current candidate dimensions, not 3D tolerance signoff or physical testing.',
    'manufacturingApproved':False,'hardwareTests':0,
    'constraints':{'oldCavityMm':[78,47,22],'coverCandidateMm':[148,49],
                   'noNewBodyCavity':True,'outsideHeightMaxMmExcludingRollers':5,
                   'completeModuleThicknessMaxMm':25,'screwUnderHeadLengthMaxMm':6,
                   'shellConnection':'Snap-only upper/lower; four upper-cover screws to plywood violin.'},
    'diagnostics':[
        {'item':'Cup76x43x18 versus cavity78x47x22','nominalLengthPerSideMm':(78-76)/2,
         'nominalWidthPerSideMm':(47-43)/2,'nominalDepthMarginMm':22-18,
         'status':'NOMINAL_ENVELOPE_ONLY_BODY_CURVATURE_AND_TOLERANCES_UNKNOWN'},
        {'item':'Audio board73.4 versus nominal cup inner74','nominalPerSideMm':(74-73.4)/2,
         'worstPerSideFromExistingBudgetMm':(73.6-73.5)/2,'status':'HOLD_INSERTION_ALLOWANCE'},
        {'item':'Audio clipped pins to main top','nominalClearanceMm':0.3,
         'insulationAndToleranceApproved':False,'status':'HOLD'},
        {'item':'Existing1mm bottom wire endpoints to main top','nominalClearanceMm':-0.2,
         'status':'FAIL_GEOMETRIC_COLLISION_NEEDS_TERMINATION_CHANGE'},
        {'item':'Existing34mm-wide protected pack candidate versus free strip','freeStripWidthMm':41-11.8,
         'packCandidateWidthMm':34,'nominalWidthShortfallMm':34-(41-11.8),
         'status':'FAIL_NO_APPROVED_REPLACEMENT_PACK'},
        {'item':'Current maximum thickness budget including roller','nominalBudgetMm':18.3+6.3,
         'marginMm':25-(18.3+6.3),'status':'HOLD_ACTUAL_MAXIMUM_STACK_AND_TOLERANCES'},
        {'item':'Four screws','lengthLimitMm':6,'woodEngagementFormula':'Under-head length minus head-bearing-plane-to-wood-surface distance.',
         'remainingWoodThicknessMm':None,'pilotDiameterMm':None,'threadMpn':None,'torqueNm':None,
         'status':'HOLD_RECESSED_SEAT_GEOMETRY_MATERIAL_AND_TORQUE_TEST_REQUIRED'},
        {'item':'Thin speaker alternative','candidateReview':'audit/audio/speaker-candidate-review.json',
         'status':'HOLD_BODY_AND_WORKING_HEIGHT_NOT_INTERCHANGEABLE_BACK_VOLUME_HPF_AND_ACOUSTIC_TEST_REQUIRED'}]})
checks = []

def check(id,status,reason,evidence):
    checks.append({'id':id,'status':status,'reason':reason,'evidence':evidence})

capture_pass = electrical.get('pass') is True and electrical.get('sourceSha256','').lower()==(source or '').lower()
check('G01 原生电路转录','PASS_LOGICAL_ONLY' if capture_pass else 'HOLD_STALE_OR_FAILED',
      '原生ERC、网表一致性及指定拓扑反例；不是模拟仿真或硬件电气批准。',
      ['verification/electrical-check.json','verification/erc.json','verification/native-netlist.xml'])
pending = sum(n for k,n in coverage.get('counts',{}).items() if k in
              {'REQUIRES_REVIEW','PASSIVE_APPLICATION_AND_MPN_REVIEW_PENDING','HOLD_PHYSICAL_PAD_OR_FUNCTION','STALE_NET_REVIEW','CONTRACT_NET_MISMATCH'})
check('G02 逐脚应用批准','HOLD',
      f"已枚举{coverage.get('enumeratedPins','待统计')}脚，仍有{pending}脚待功能、应用或物理焊盘核对；有引脚证据不等于全部批准。",['audit/all-pins.json','verification/pin-review-coverage.json'])
pcb_by_kind={b['kind']:b for b in pcb.get('boards',[])}
main=pcb_by_kind.get('main',{})
usb=pcb_by_kind.get('usb',{})
pcb_reason=(f"主板未连接{main.get('unconnected','待查')}项、已报警告{main.get('drc',{}).get('warnings','待查')}项；"
            f"USB板未连接{usb.get('unconnected','待查')}项。仅电源/温度专项板导出工程CAM，不替代整机；被忽略的规则类别仍须评审。") if pcb else 'PCB原始汇总未提供；专项板与整机各自独立，能导出Gerber不等于整机放行。'
check('G03 PCB布局布线及CAM','HOLD',
      pcb_reason,
      ['pcb-work/verification/final-summary.json'])
check('G04 器件与封装','HOLD','插座检测焊盘编号、电池包、关键电容有效容量、替代料及采购批准未全部闭环。',
      ['electrical/bom-review.json','pcb-work/footprint-review.json','audit/critical-passives/verification.json'])
check('G05 结构堆叠与固定','HOLD','需消除针脚/线束干涉、确认带保护及NTC电池包；6mm仅螺钉头下长度上限，剩余木厚、导孔与扭矩未实测。',
      ['pcb-work/GEOMETRY-REVIEW.txt','verification/structural-budget.json','verification/bench-test-plan.json'])
check('G06 USB保护协调','HOLD','独立USB_VREF及MODE1已修订；系统侧残余瞬态、反向供电与主控PHY限值仍需闭环及受控实测。',
      ['audit/system/review.json','electrical/fault-handling.json'])
check('G07 STM32构建','PASS_BUILD_ONLY' if firmware.get('armCrossCompile')=='PASS' else 'HOLD',
      'HOLD诊断镜像可编译；不得视为完整演奏固件、音频时钟已验证或实物烧录成功。',
      ['firmware/verification/build-status.json','firmware/verification/startup-check.json'])
live_pass = parity.get('status')=='PASS_LOGICAL_NET_PARITY_ONLY' and parity.get('sourceSha256','').lower()==(source or '').lower()
check('G08 固件引脚合同','PASS_LOGICAL_ONLY' if live_pass else 'HOLD_STALE_OR_FAILED',
      '现行原生网络与合同核对；版本固定仅适用于工程复现，不是量产冻结。',
      ['firmware/verification/live-net-parity.json','firmware/contracts/pins.json'])
check('G09 全功能音频与无线','HOLD','SAI/DMA、音频PLL、USB音频及完整ESP无线音频链路尚未全部实现并交叉编译/实测。',
      ['firmware/contracts/driver-status.json','firmware/verification/esp-native-build.json'])
check('G10 内部板间连接','PASS_LOGICAL_ONLY' if interconnect.get('pass') else 'HOLD',
      '仅端点逻辑及ERC核对；线规、切长、剥线、焊接参数、弯曲与USB阻抗尚未冻结。',
      ['assembly/interconnect.json','verification/interconnect-check.json'])
check('G11 充电与温升','HOLD_NOT_EXECUTED','成品保护电池包未批准；预充/恒流/恒压/终止/再充、DPPM、受限USB启动、故障及温升实测0次。',
      ['verification/bench-test-plan.json','audit/power/review.json'])
check('G12 工程签署','HOLD','电子厂须完成元器件、工艺、整机设计评审与测试签署后，才可发出试产指令。',
      ['FACTORY-HANDOFF.txt'])
write('verification/release-gate.json',{
    'revision':'V25-20261008','verifiedAtUtc':datetime.now(timezone.utc).isoformat(),
    'nativeSourceSha256':source,'status':'HOLD','productionApproved':False,
    'integratedPrototypeManufacturingApproved':False,'hardwareTests':0,
    'checks':checks,'pcbSummaryAvailable':bool(pcb),
    'cannotInfer':['Gerber export implies valid hardware','ERC zero implies all pins electrically approved',
                   'Host or ARM build implies Bluetooth or audio measured','User can-produce statement implies supplier DFM approval']})

contracts = []
for p in sorted((ROOT/'firmware/contracts').glob('*.json')):
    contracts.append({'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
write('verification/contract-revision.json',{
    'revision':'V25-20261008-CANDIDATE','nativeSourceSha256':source,'files':contracts,
    'reproductionSnapshotFrozen':True,'productionPinClockProtocolFrozen':False,
    'freezeScope':'Exact files/hashes for review and reproducible host/ARM build only.',
    'clockAndProtocolHardwareValidated':False,
    'requiredBeforeProductionFreeze':['Qualified final BOM/footprints and routed PCB parity',
      'MCLK/BCLK/LRCK and ADC/DAC/ESP sampling measurements','Actual target firmware builds and UART/wireless interoperability',
      'Fault handling, startup, USB and thermal tests','Engineer signoff and controlled ECO']})

handoff = '''SmartVio V25 电子厂工程交接 / 2026-10-08 / HOLD

一、交付用途
本包供电子厂审图、工艺评审与分阶段验证，不是完整一体机样机生产放行单。
原生EDA是逐脚、全局网络标签连接的电路捕获，需电子工程师审核应用电路。
不同文件里的PASS仅表示各自限定范围；实物音频、蓝牙、充电、温升测试均未执行。
历史PCB试验变体保留用于追溯，不得混用其Gerber、钻孔、钢网、坐标和BOM。

二、从哪里开始
1. 打开index.html，检查verification/release-gate.json及本包SHA256清单。
2. 看pcb-work/verification/final-summary.json；仅使用其中点名的最新板和CAM集合。
3. 阅读eda/SmartVio.kicad_sch、electrical/native-components.json和audit/all-pins.json。
4. 逐一签署器件料号、封装、引脚一号/极性、DNP、裸露焊盘钢网及厂家装配要求。
5. 对HOLD或没有焊盘的插座，不得凭常用封装或外观猜测补焊盘后投板。
6. 可以先取得一只准确料号和批次的3.5mm插座，在完全不通电的情况下按
   verification/jack-continuity-worksheet.json测量。得到照片、全部读数及厂家澄清后，
   再冻结检测触点映射；这一步不要求先制造整机PCB。

三、结构与固定，不得擅改约束
四个3.5mm音频口和USB-C在控制正面；不设DOCK、话筒、XLR或48V。
保留琴码拾音器、旧穿线孔；不新增琴体开腔。旧腔78x47x22mm。
候选上盖148x49mm；最大150x55mm，安装承力柱最窄50mm。
安装后非旋钮最高外凸<=5mm、整体机器厚度<=25mm。
上下壳只卡扣连接；上盖四角孔连接琴身，螺钉头下长度不超过6mm。
必须实际测四点剩余木厚、旧孔、曲率、层压板结构；导孔和扭矩不能由长度推出。
螺钉安装座需局部下沉接近琴背，否则5mm外凸会吃掉6mm螺钉的有效木内啮合。
先做无电结构模型并测量针脚、线束弯曲、绝缘、喇叭、电池包与壳体公差，再定模。

四、无电装配及首次上电
按最终厂家批准的回流曲线/钢网/焊膏/手焊工艺操作；本包没有虚构统一焊接温度。
先不开启扬声器、不接外部音频设备、不接真实锂电池，显微镜检查及对地阻抗检查。
按verification/bench-test-plan.json的T01～T14顺序执行并填写操作者、设备、原始值。
用限流实验电源先核对电源轨和默认禁充/静音，不用电脑、手机作为故障注入负载。
只能烧录已核对目标型号、哈希的HOLD诊断镜像，不改读保护或选项字节。
固件目录包含构建、烧录前检查和测试资料；源码存在不等于ESP可用固件。
蓝牙ROM烧录时，EN有下拉：仅开漏拉低/释放不足以启动模块。夹具须保持STM32复位，
核对目标V3D及共地，再用经批准的目标电压、限流、可三态输出控制EN；禁止直接接夹具
电源，禁止目标掉电时驱动EN。夹具电路与时序尚待电子厂验证，不得误接。

五、充电完整闭环
当前关机自动USB唤醒/充电未实现，不得对客户宣称该功能已可用。
真实电池必须是有明确料号、保护、NTC曲线、尺寸公差和充电规格的成品电池包。
先用电池模拟器确认输入限流、CE默认禁充、NTC开短路、过压与故障锁存。
再在合格安全环境实测预充、恒流、恒压、终止、再充、DPPM、边充边用和欠压。
ISET监测只反映充电电流，不证明电池存在，也不是放电电流计。
任一异常、旧采样、I2C失联、温度越界或自检未通过，必须禁充、静音并记录故障。

六、试产前签署
PCB工程师：逐脚/全部网络、供电回路、规则、铜皮、USB回流与阻抗、热/EMI评审。
结构工程师：所有器件最大包络、针脚与线束、卡扣、螺钉啮合/保持力/扭矩、公差。
固件工程师：引脚/时钟/协议、完整目标构建、烧录日志、自检、音频和无线实测。
测试工程师：充电、安全故障、温升、端口插拔、模拟音频及无线原始测试记录。
上述签署与ECO完成前，不得把本包改名为“最终直接生产样机”。
'''
(ROOT/'FACTORY-HANDOFF.txt').write_text(handoff,encoding='utf-8')
print(json.dumps({'status':'HOLD','nativeSourceSha256':source,'gates':len(checks),
                  'logicalCaptureCurrent':capture_pass,'firmwareParityCurrent':live_pass},ensure_ascii=False))
