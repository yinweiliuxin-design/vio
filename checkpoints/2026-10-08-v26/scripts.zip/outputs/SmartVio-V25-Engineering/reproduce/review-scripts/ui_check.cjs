const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { chromium } = require('<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = path.resolve(__dirname, '../../outputs/SmartVio-V25-Engineering');

(async () => {
  const executablePath = fs.existsSync(chromium.executablePath()) ? chromium.executablePath() :
    ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(p => fs.existsSync(p));
  if (!executablePath) throw new Error('No installed browser available for local review');
  const browser = await chromium.launch({ headless: true, executablePath });
  const checks = [];
  for (const viewport of [{ width: 1440, height: 1000 }, { width: 390, height: 844 }]) {
    const page = await browser.newPage({ viewport });
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(pathToFileURL(path.join(root, 'index.html')).href);
    const body = await page.evaluate(() => ({
      width: document.documentElement.scrollWidth,
      viewport: innerWidth,
      title: document.querySelector('h1').textContent,
      hold: document.body.textContent.includes('当前不是整机生产放行包'),
      links: Array.from(document.querySelectorAll('a[href]')).map(a => a.getAttribute('href'))
    }));
    const missing = body.links.filter(p => !p.startsWith('#') && !/^https?:/i.test(p) && !fs.existsSync(path.resolve(root, p)));
    await page.screenshot({ path: path.join(root, 'verification', `index-${viewport.width}.png`), fullPage: false });
    const row = { viewport, errors, missing, noBodyOverflow: body.width <= body.viewport, holdVisibleInText: body.hold };
    checks.push(row);
    await page.goto(pathToFileURL(path.join(root, 'audit/pin-review.html')).href);
    const initial = await page.locator('#pins tbody tr:visible').count();
    await page.locator('#search').fill('RF_CHIP_EN');
    const filtered = await page.locator('#pins tbody tr:visible').count();
    const correct = await page.locator('#pins tbody tr:visible').allTextContents();
    row.pinFilter = { initial, filtered, pass: filtered > 0 && filtered < initial && correct.every(t => t.includes('RF_CHIP_EN')) };
    await page.close();
  }
  await browser.close();
  const pass = checks.every(x => !x.errors.length && !x.missing.length && x.noBodyOverflow && x.holdVisibleInText && x.pinFilter.pass);
  fs.writeFileSync(path.join(root, 'verification/ui-check.json'), JSON.stringify({ pass, executablePath, checks, scope: 'Local review index and pin search only; not device/client integration tests.' }, null, 2));
  process.stdout.write(JSON.stringify({ pass, checks }, null, 2));
  if (!pass) process.exitCode = 1;
})().catch(e => { process.stderr.write(e.stack); process.exitCode = 1; });
