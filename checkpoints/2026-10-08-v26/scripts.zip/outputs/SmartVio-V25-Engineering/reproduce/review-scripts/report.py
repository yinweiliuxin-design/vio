"""Publish a Chinese review index; no manufacturing approval is inferred."""
import html
import json
from pathlib import Path

BASE=Path(__file__).resolve().parents[2]
ROOT=BASE/'outputs/SmartVio-V25-Engineering'
def read(path,default=None):
 f=ROOT/path
 return json.loads(f.read_text(encoding='utf-8-sig')) if f.exists() else default
def esc(x):return html.escape(str(x))
def link(path,label):return f'<a href="{esc(path)}">{esc(label)}</a>' if (ROOT/path).exists() else esc(label)+'（未提供）'
def packpath(path):
 try:return Path(path).relative_to(ROOT).as_posix()
 except ValueError:return None
def table(headers,rows):
 return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(v)+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div>'

electrical=read('verification/electrical-check.json',{})
capture=read('verification/capture-summary.json',{})
coverage=read('verification/pin-review-coverage.json',{})
fwbuild=read('firmware/verification/build-status.json',{})
passives=read('audit/passives/selection-summary.json',{})
power=read('audit/power/review.json',{})
system=read('audit/system/review.json',{})
gate=read('verification/release-gate.json',{})
pcbsummary=read('pcb-work/verification/final-summary.json',{})
espbuild=read('firmware/verification/esp-native-build.json',{})
audio=read('audit/audio/findings-and-required-changes.json',{})
parts=read('electrical/native-components.json',[])
powerpins=read('audit/power/pin-audit.json',[])
audio_records=read('audit/audio/corrected-components.json',[])
audio_index={c['ref']:c for c in audio_records}
power_index={p['ref'] for p in powerpins}
footprint_review=read('pcb-work/footprint-review.json',{})
critical=read('audit/critical-passives/proposal.json',{})
critical_index={c['ref']:c for c in critical.get('components',[])}
controls=read('audit/controls-protection/candidate-components.json',[])
controls_index={c['ref']:c for c in controls}
controls_check=read('audit/controls-protection/verification.json',{})
bom=[]
for c in parts:
 domain='电源逐脚核对' if c['ref'] in power_index else '音频/接口逐脚核对' if c['ref'] in audio_index else '需查相应专项记录'
 bom.append({'ref':c['ref'],'value':c['value'],'mpn':c.get('mpn'), 'pinCount':len(c['pins']),
 'footprint':footprint_review.get(c['ref'],{}).get('footprint'),
 'footprintReview':footprint_review.get(c['ref'],{}).get('review','NOT_ASSIGNED'),
 'reviewDomain':domain,'documentedCandidateMpn':critical_index.get(c['ref'],{}).get('proposed_mpn') or controls_index.get(c['ref'],{}).get('mpn'),
 'candidateDisposition':critical_index.get(c['ref'],{}).get('candidate_disposition'),
 'candidateHolds':critical_index.get(c['ref'],{}).get('hold_reasons',[]),
 'controlCandidateScope':controls_index.get(c['ref'],{}).get('verificationScope'),
 'procurementApproved':False,'productionApproved':False,
 'reason':'引脚核对不等于元器件采购、供应商、封装/装配及整机验证批准'})
(ROOT/'electrical/bom-review.json').write_text(json.dumps(bom,ensure_ascii=False,indent=2),encoding='utf-8')

tests=[
 ('T01','到料和装配前检查','原理图/BOM/封装/PCB版本与哈希；首件显微镜、万用表、X-ray按封装需要','逐器件核对型号、封装一脚方向、极性、贴装坐标、BGA/裸露焊盘工艺；核对飞线与DNP；不安装锂电池。','不得存在版本不匹配、短路、开路或未确认的插座触点。'),
 ('T02','无电池首次上电','有电流限制的5.0V实验电源，示波器，热像/接触温度计','先断开所有外部音频设备、扬声器和电池；验证电源对地无异常短路，再从限流小电流启动；记录VBUS_RAW、USB_5V_SAFE、SYS、V3D、V3A。','首次限流是调试保护措施，不是设计额定电流。突增、振荡、局部异常发热立即断电；各轨必须在芯片推荐工作范围。'),
 ('T03','上电保持与默认禁充','SWD、示波器、逻辑分析仪','按PWR，捕获PE7/KILL、PE14、EN1/EN2、CE、V3D；验证复位前后CE高；默认100mA输入模式不得被启动程序意外切断。','KILL在512ms内达到有效高；充电和音频默认关闭；不把已编译程序视为测试通过。'),
 ('T04','烧录与自检','受控SWD夹具，已核验的目标MCU与电源','读芯片ID、闪存大小及硅版本；禁止修改读保护/安全选项；烧录前比对固件哈希；复位后读取调试状态、自检未通过项。','目标必须为正确STM32型号；本包HOLD镜像不是功能固件。保留读取、烧录、校验日志。'),
 ('T05','电压与充电电流采样','精密源、万用表、独立电流计、经批准的电池模拟器','分别标定USB/BAT/SYS三个分压通道及ISET通道；比较MON_ENABLE开/关、掉电状态；校验ADS1115量程和采样时间。','ISET只表示充电电流，约±10%镜像误差还需叠加其他误差；不用于证明电池存在或放电电流。'),
 ('T06','NTC、断线与传感器失效','电阻箱、温度参考仪、受控电池模拟器','电池仍不接真实锂电芯。模拟NTC开路/短路、温区边界；拔掉TMP117、卡住I2C、延迟数据、ADC饱和。','硬件与软件各自禁止异常充电；不得用固定电阻代替成品电池NTC。温度换算需真实NTC曲线。'),
 ('T07','充电全流程','已批准电池包及其规格书，电子负载，充放电测试仪，防火测试环境','仅在电池、独立保护、NTC、热设计签署后执行：预充、恒流、恒压、终止、再充；同时加系统负载检查DPPM/电池补充；记录全部数据。','实际电芯规定的电压、电流、温度、终止条件优先；禁止把软件阈值当成电芯的规格或独立保护。关机自动充电仍未实现。'),
 ('T08','USB故障及锁存','专用可控故障注入夹具、差分探头、负载板','先完成USB短接保护重新协调，不得直接拿手机/电脑当故障负载；记录连接器端、系统端、VREF/V3D和MCU引脚瞬态。','峰值、时间、注入电流均需满足器件限值；保护后电压为0不得自动清除锁存或判定拔线。'),
 ('T09','音频时钟与双路I2S','逻辑分析仪、示波器、信号发生器','保持所有输出静音，验证24.576MHz MCLK、3.072MHz BCLK、48kHz LRCK、32bit槽及双DOUT顺序；逐路输入不同频率识别拾音和RETURN通道；读取ADC寄存器。','旧四通道TDM方案时序余量不足；新双I2S计算只是候选，必须验证实际晶体/PLL误差、DMA采样顺序和GPIO1路由。无法确认时保持静音。'),
 ('T10','模拟音频和耳机','音频分析仪、电阻假负载、隔离输入信号源','测试静音/开关机爆音、直流偏置、增益、削顶、噪声、失真；分别测试PHONES/LINE OUT/FX SEND/AUX；模拟TS、TRS插头及半插。','耳机先使用假负载，不直接佩戴测试；SEND不得包含RETURN；通过测试后再接真实拾音器和外部设备。'),
 ('T11','喇叭及限幅','受控假负载及最终喇叭，音频分析仪、温度探头','单独检查扬声器数据流、LEFT槽、软件限幅；用正弦、方波、削顶、最大码和静音输入验证；最后测试木琴体机械反馈。','临时峰值限幅不是喇叭功率认证；按实际最小阻抗与温升确定阈值。BTL两端均不得接地。'),
 ('T12','蓝牙基本联调','拟定ESP固件、两台目标设备、射频/音频测试工具','先验ESP供电/复位/UART帧/超时/CRC；再测配对、断线、重新连接、拒绝未知命令、异常包；区分BLE控制与Classic音频发射。','状态机测试不是射频或音频实测；普通蓝牙音箱延迟不得承诺为演奏级实时监听。'),
 ('T13','温升与带载稳定性','最终壳体、电池、喇叭、经校准探头与环境箱','覆盖充电、边充边用、外接音箱、耳机、扬声器、蓝牙、高低电量及受限USB源；记录芯片/电芯/可触摸表面的温度与时间。','温度限值取电池/器件/适用安全标准与最终产品要求中的严格者；PCB规则通过不能替代温升。'),
 ('T14','固定、插拔与线缆应力','实际琴体、深度规、扭矩仪、拉力设备','测四点剩余木厚、旧孔、曲率；确认螺钉头下长度上限6mm；检查卡扣、插头干涉、线束弯曲/夹伤和拾音器原孔；进行分级扭矩与拔出试验。','6mm是长度上限，不是扭矩依据；未做破坏/保持力试验不得冻结扭矩。不得新增琴体开腔。'),
]
testrows=[{'id':id,'item':name,'equipment':equip,'steps':steps,'acceptance':accept,'status':'NOT_EXECUTED','operator':None,'measuredData':None} for id,name,equip,steps,accept in tests]
(ROOT/'verification/bench-test-plan.json').write_text(json.dumps(testrows,ensure_ascii=False,indent=2),encoding='utf-8')

css='''*{box-sizing:border-box}body{margin:0;color:#1f2929;background:#f4f6f6;font:15px/1.65 "Microsoft YaHei",sans-serif;letter-spacing:0}header{background:#fff;border-bottom:3px solid #087f80;padding:24px max(20px,calc((100% - 1240px)/2))}main{max-width:1280px;margin:auto;padding:20px}h1{font-size:27px;margin:0}h2{font-size:21px;margin:28px 0 10px}p{margin:8px 0}a{color:#075eac;overflow-wrap:anywhere}code{overflow-wrap:anywhere}.notice{border-left:5px solid #bd3636;padding:12px 16px;background:#fff0ed}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;background:#fff;font-size:13px}td,th{text-align:left;vertical-align:top;padding:10px;border:1px solid #d7dede;overflow-wrap:anywhere}th{background:#e7eeee}td:first-child{white-space:nowrap}.good{color:#14714c}.bad{color:#a92929}.muted{color:#566665}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#fff;padding:12px;font-size:12px}section{border-bottom:1px solid #cfd8d8;padding-bottom:20px}img{max-width:100%;height:auto}nav{display:flex;flex-wrap:wrap;gap:18px;margin-top:12px}@media(max-width:600px){header{padding:18px}main{padding:14px}h1{font-size:22px}table{min-width:660px}}'''
body='<header><h1>SmartVio V25 工程审核与修订</h1><p>2026-10-08 · 原生电路 / PCB候选 / 固件基础 / 实测准备</p><nav><a href="#electrical">电路</a><a href="#pcb">PCB</a><a href="#firmware">固件</a><a href="#factory">工厂测试</a><a href="bom.html">BOM审查记录</a></nav></header><main>'
body+='<p class="notice"><strong>当前不是整机生产放行包。</strong>Gerber文件能导出，不等于电路正确或样机能用。必须区分整机主板、专项试验板、候选布局，以及真实硬件测试。所有未完成项保留HOLD，不用占位参数伪装为冻结规格。</p>'
body+='<p>'+link('audit/pin-review.html','逐脚审核台账与故障处理')+' · '+link('verification/release-gate.json','制造放行门禁')+'</p>'
body+='<p>'+link('FACTORY-HANDOFF.txt','电子厂交接与使用边界')+' · '+link('verification/contract-revision.json','候选合同版本与冻结范围')+'</p>'
if gate.get('checks'):
 body+='<h2>当前交付门禁</h2>'+table(['项目','状态','说明'],[[esc(x['id']),esc(x['status']),esc(x['reason'])] for x in gate['checks']])
body+='<section id="electrical"><h2>1. 已合并的电路修改</h2>'
body+=table(['项目','本次结果','证据'],[
 ['原生原理图',f"{capture.get('sheets','待检查')}页，{electrical.get('components','待检查')}器件，{electrical.get('pins','待检查')}引脚；ERC {electrical.get('ercViolationCount','未执行')}项",link('eda/SmartVio.kicad_sch','KiCad原理图')],
 ['网表与反例验证',f"导出网表逐节点比对；另注入{len(electrical.get('negativeControls',[]))}种错误检查检出能力。仅代表数据与规则检查。",link('verification/electrical-check.json','检查原始记录')],
 ['充电电流','原3.3V监测通道改为隔离缓冲的ISET充电电流通道；移除旧分压。保留USB/BAT/SYS监测。',link('audit/power/changes.json','修改清单')],
 ['电源逐脚审核',f"{power.get('reviewedDevices',0)}个器件、{power.get('reviewedPins',0)}个引脚；检查供电、引脚类型、默认状态、裸露焊盘和故障边界。",link('audit/power/pin-audit.json','逐脚记录')],
 ['音频/接口','复核音频芯片、USB保护和四个音频插座；修正U301裸露焊盘编号，C304改为2.2uF候选。',link('audit/audio/AUDIT-REPORT.txt','专项审核全文')],
 ['ADC时序修订','从时序未闭环的TDM改为双路I2S候选，保留拾音及立体声RETURN三路模拟输入；不减少外部功能。',link('firmware/contracts/adc-dual-i2s.json','双I2S合同')],
 ['射频默认状态','RF_CHIP_EN独立下拉，R907限制使能电容驱动电流；R903仍是原扬声器增益电阻，不被复用。时序和有效电容仍需实测。',link('audit/system/review.json','系统边界核对')],
 ['USB保护参考','TPD2S703采用独立USB_VREF及MODE1反馈，不再把V3D直接当保护参考；系统侧残余瞬态和PHY限值仍未闭环。',link('audit/system/corrected-components.json','精确修改器件')],
 ['音频补充审核','SSR与USB-C引脚证据补齐；Q1201改低栅压有保证参数的PMV30UN2R候选，网络不变；ADC输入寄存器保留位改为掩码处理。',link('audit/audio/incremental-review.json','本轮新增发现')],
 ['逐脚覆盖',f"枚举{coverage.get('enumeratedPins','待汇总')}个引脚，按原厂证据、待核对、网络不一致分别列示。不是全部引脚电气批准。",link('audit/pin-review.html','可搜索逐脚台账')],
 ['电阻料号','候选电阻逐料号核对原厂规格；稳压反馈采用0.1%候选。仍需应用功耗/电压和采购批准。',link('audit/passives/selection-summary.json','料号核查结果')],
 ['关键无源器件','31个位号、16种原厂有据候选；不匹配的电感、磁珠和共模器件不盲替换。纠正5处0603描述与实际0805焊盘类别不一致。有效容量和实际应用仍待批准。',link('audit/critical-passives/report.html','候选与装配审查')],
 ['接口保护与控制件','7只TPD的X1SON封装及双向I/O引脚证据已修正；11个按钮、滚轮和LED仅列准确候选，未选定。保护协调、焊膏、触点负载、ADC及外观颜色仍HOLD。',link('controls.html','保护与控制件审查')],
 ['元件清单','候选BOM保留MPN、引脚和审核归属；尚未伪称全部采购/封装批准。',link('electrical/bom-review.json','BOM JSON')],
 ])
body+='<h2>2. 必须闭环的问题</h2>'+table(['优先级','问题','放行条件'],[
 ['P1','USB独立参考已修订，但系统端瞬态、反向供电及PHY协调仍不足以证明安全。','核对主控引脚瞬态/注入限制，完善保护网络及器件选择，并通过受控故障注入。'],
 ['P1','Lumberg插座检测触点在官方电路图与焊盘图中出现6/8编号冲突。','厂商澄清或实物连续性测量；不能凭外观猜焊盘。四口布局功能保留。'],
 ['P1','耳机PhotoMOS重复短路电流和温度未闭环；3.5mm物理通用不代表所有电平与设备即插即用。','限定TS/TRS、耳机/线路/RETURN用途；测试短路、半插、增益、左右混音、声压和失真，不能将普通TRS当平衡输出或话筒口。'],
 ['P1','关机时CE默认禁充，尚无自动USB唤醒；USB100mA冷启动负载未实测。','完成低功耗启动/充电模式供电与负载预算、真实上电测试。'],
 ['P1','电池包、薄型喇叭、部分滤波器/储能电感及关键电容未完成最终料号及参数批准。','真实规格书、有效电容量、保护/NTC曲线、最小阻抗、尺寸公差、替代料管理。'],
 ['P1','整机主板和完整结构未达到生产放行。','布线/铺铜/网表一致性/DRC/堆叠/热设计全部闭环；工程师签署后才能交付制造。'],
 ['P1','候选音频板接线端与主板发生约0.2mm名义干涉；插口针脚与主板也仅有约0.3mm名义间隙。','调整接线落点或载板方向，重新做绝缘、针脚、壳体和装配公差检查。不能直接按当前堆叠焊接。'],
 ['P1','原候选34×36×6mm电池放不进插座排旁剩余约29.2mm宽的区域。','更换有独立保护/NTC及正式规格书的窄型电池包，重新计算续航、峰值电流、充电和结构；不按电芯裸尺寸冒充整包尺寸。'],
 ['P2','四个螺钉长度上限6mm已知，剩余木厚和扭矩依据未齐。','实际琴体测量、导孔与材料试验，记录滑牙/破坏扭矩和保持力；不编造扭矩数值。'],
 ])+'</section>'
body+='<section id="pcb"><h2>3. 原生PCB与制造文件</h2><p>以下文件是各自独立的工程阶段。专项板不能替代完整一体机主板；试验板的制造文件也不代表整机批准。</p>'
body+='<p>'+link('pcb-work/GEOMETRY-REVIEW.txt','封装及堆叠冲突明细')+' · '+link('verification/structural-budget.json','固定与堆叠名义诊断')+' · '+link('assembly/Interconnect.kicad_sch','内部板间连接原生图')+' · '+link('assembly/interconnect.json','33条内部连线候选端点表')+'</p>'
if pcbsummary:
 body+='<p>'+link('pcb-work/verification/final-summary.json','本轮PCB、规则及CAM原始汇总')+' · '+link('pcb-work/verification/CAM-index.json','专项CAM相对路径索引')+'</p>'
 rows=[]
 for board in pcbsummary.get('boards',[]):
  path=packpath(board['boardPath'])
  drc=board.get('drc',{})
  parity=board.get('parity',{})
  rows.append([esc(board['kind']),esc(str(board['tracks'])+' / '+str(board['vias'])),
               esc(str(drc.get('errors','未查'))+' / '+str(drc.get('warnings','未查'))),
               esc(board.get('unconnected','未查')),esc(parity.get('differences','未查')),
               link(path,'原生PCB') if path else '路径待核对',esc(board['status'])])
 body+=table(['板别','走线/过孔','已报DRC错误/警告','未连接项','引脚网表差异','最新文件','状态'],rows)
 body+='<p>上述网表差异是物理焊盘对源脚号的比较；无铜焊盘的插口和控制件不能以规则0项视为闭合。主板保留实际布线、过孔和铜区，不将未完成连接伪装成成功。</p>'
 body+='<h2>已导出的专项板CAM</h2><p>仅供工程评审：包括真实铜层、钻孔、焊膏开口层和坐标，尚无整机或工艺批准。原生全坐标含手工端点，贴装候选坐标已另列；不可混用。</p>'
 for board in pcbsummary.get('boards',[]):
  if board.get('CAM'):
   body+='<h3>'+esc(board['kind'])+'</h3>'+table(['文件','打开'],[[esc(Path(f['path']).name),link(packpath(f['path']),'查看')] for f in board['CAM'] if packpath(f['path'])])
 body+='<h2>规则范围和阻断项</h2><p>以下规则类别仍按KiCad检查范围忽略，不宣称全部规则通过：</p>'+table(['类别'],[[esc(x['key'])] for x in pcbsummary.get('ignoredCheckCategories',[])])
 body+=table(['必须闭环'],[[esc(x)] for x in pcbsummary.get('blockers',[])])
 body+='<p>'+link('pcb-work/verification/controls-land-eco.json','TVS原厂焊盘下一步精确ECO')+'</p>'
pcbfiles=sorted((ROOT/'pcb-work').glob('*.kicad_pcb'))
body+='<details><summary>历史及研究变体，仅供追溯，不得直接混用CAM</summary>'+table(['文件','读取方式'],[[esc(f.name),link(str(f.relative_to(ROOT)).replace('\\','/'),'打开原生PCB')] for f in pcbfiles])+'</details>'
for name in ['placement-check.json','power-prototype.json','power-route-check.json','final-summary.json']:
 path='pcb-work/verification/'+name
 if (ROOT/path).exists():body+='<p>'+link(path,name)+'</p>'
for f in sorted((ROOT/'pcb-work').rglob('*.svg')):
 if 'drill' not in f.name.lower() and ('front' in f.name.lower() or 'power' in f.name.lower()):
  path=str(f.relative_to(ROOT)).replace('\\','/')
  body+='<p>'+link(path,f.name)+'</p>'
body+='</section><section id="firmware"><h2>4. 固件、引脚与协议</h2><p>主机单元测试、ARM交叉编译、真实烧录和硬件联调是四件不同的事。本包仅按实际证据列示，不把测试替身或HOLD固件称为完整功能固件。</p>'
body+=f"<p>当前记录：主机测试 {esc(fwbuild.get('hostGroups','待汇总'))}组；ARM交叉编译 {esc(fwbuild.get('armCrossCompile','待执行'))}；实物执行 {esc(fwbuild.get('hardwareTests',0))}次。ESP原生构建状态单独列示，源码、语法验证、工具链编译和无线实测不能互相替代。</p>"
body+='<p>'+link('firmware/verification/esp-native-build.json','ESP原生构建与缺项')+' · '+link('firmware/contracts/driver-status.json','真实驱动完成情况')+'</p>'
if espbuild:body+='<pre>'+esc(json.dumps(espbuild,ensure_ascii=False,indent=2))+'</pre>'
fwlinks=[]
for f in sorted((ROOT/'firmware').rglob('*')):
 if f.is_file() and (f.suffix.lower() in {'.json','.txt','.md','.hex','.elf','.bin','.ps1'} or f.name.startswith('build-') and f.suffix=='.log'):
  if 'disassembly' in f.name:continue
  p=str(f.relative_to(ROOT)).replace('\\','/')
  fwlinks.append([esc(str(f.relative_to(ROOT/'firmware'))),link(p,'查看')])
body+=table(['固件材料','文件'],fwlinks)
body+='</section><section id="factory"><h2>5. 电子厂实测顺序</h2><p class="notice">所有下列实测状态均为 NOT_EXECUTED。先审核器件与版本，再无电池上电；真实锂电池接入晚于充电保护验证。禁止将状态机模拟结果填写成实测值。</p>'
body+=table(['编号/项目','设备','步骤','停止/验收条件'],[[esc(id+' '+name),esc(equip),esc(steps),esc(accept)] for id,name,equip,steps,accept in tests])
body+='<p>'+link('verification/bench-test-plan.json','可记录实测结果的测试计划')+'</p></section>'
body+='<section><h2>6. 资料与验证边界</h2><p>保留原琴码拾音器及穿线孔；四个3.5mm接口和USB-C均为一体机控制正面接口；不新增DOCK、话筒、XLR或48V供电；不新增琴体开腔。旧腔78×47×22mm，候选上盖148×49mm，外凸目标不超过5mm（调节旋钮不计），总厚度不超过25mm。</p>'
body+='<p>元器件原厂证据：'+link('audit/power/parent-source-manifest.json','电源随包原件与来源')+' · '+link('audit/audio/source-manifest.json','音频接口规格书来源')+' · '+link('audit/controls-protection/parent-source-manifest.json','接口与控制件随包来源')+'</p>'
body+='<p>本轮未开展声学测量、蓝牙射频测试、温升、跌落、EMC、电池安全或四国市场认证。它们不能由KiCad或单元测试替代。</p></section></main>'
(ROOT/'index.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SmartVio V25 工程审核</title><style>'+css+'</style>'+body+'</html>',encoding='utf-8')
tbody='<header><h1>SmartVio V25 候选BOM与封装</h1><p><a href="index.html">返回工程总览</a></p></header><main><p class="notice">本表不构成采购/生产批准。准确料号、封装几何、应用额定值、可采购性和实物验证是不同事项；缺项不得由代料自行填补。</p>'
tbody+=table(['位号','规格','原生电路料号','另拟评审候选','候选封装','封装审核状态'],[[esc(c['ref']),esc(c['value']),esc(c['mpn'] or '待选'),esc(c['documentedCandidateMpn'] or '无另列候选'),esc(c['footprint'] or '待关联'),esc(c['footprintReview'])] for c in bom])+'</main>'
(ROOT/'bom.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>候选BOM</title><style>'+css+'</style>'+tbody+'</html>',encoding='utf-8')
controlbody='<header><h1>SmartVio V25 接口保护与控制件</h1><p><a href="index.html">返回工程总览</a></p></header><main><p class="notice">本页是原厂资料审查，不是全功能、生产或实物测试批准。七只TVS仅合入同网络逐脚证据；其他11项候选不自动写入定型BOM。</p>'
controlbody+='<h2>七只接口TVS</h2><p>D1201～D1207维持TPD1E10B06DPYR及原信号网络，纠正为X1SON DPY封装。两个端子均为双向I/O，pin2在本应用作接地端。原厂示例铜焊盘0.3×0.5mm、中心距0.7mm；独立封装读取检查不能替代整板铜皮、焊膏和下游钳位评审。</p>'
controlbody+='<p>'+link('audit/controls-protection/corrected-components.json','限定修正记录')+' · '+link('audit/controls-protection/verification.json','原始检查结果')+'</p>'
controlbody+='<h2>尚未选定的控制件</h2>'+table(['位号','功能','拟评审型号','尺寸/安装','批准边界'],[[esc(c['ref']),esc(c['value']),esc(c.get('mpn') or '未确定'),esc(c.get('package','待定')),esc(c.get('verificationScope','HOLD'))] for c in controls])
controlbody+='<h2>待闭环项</h2>'+table(['问题'],[[esc(x)] for x in controls_check.get('holds',[])])
controlbody+='<h2>随包原厂证据</h2>'+table(['来源','本地证据','原厂地址'],[[esc(s['id']),link(s['packPath'],'查看随包原件'),'<a href="'+esc(s['url'])+'">原厂资料</a>'] for s in read('audit/controls-protection/parent-source-manifest.json',[])])
controlbody+='<p>制造、装配、温升、IEC静电、按钮寿命、滚轮ADC与LED亮度实物测试均未执行。</p></main>'
(ROOT/'controls.html').write_text('<!doctype html><html lang="zh-CN"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>接口保护与控制件</title><style>'+css+'</style>'+controlbody+'</html>',encoding='utf-8')
print('Report regenerated:',ROOT/'index.html')
