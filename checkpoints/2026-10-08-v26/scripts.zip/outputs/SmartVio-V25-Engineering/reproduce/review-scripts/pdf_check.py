"""Inspect native EDA exports without treating readability as circuit approval."""
import hashlib
import json
from pathlib import Path
from pypdf import PdfReader

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE/'outputs/SmartVio-V25-Engineering'
records = []
for name,expected in [('SmartVio-V25-Schematic-HOLD.pdf',22),('SmartVio-V25-Internal-Wiring-HOLD.pdf',1)]:
    p = ROOT/'drawings'/name
    doc = PdfReader(p)
    pages = []
    for i,page in enumerate(doc.pages):
        text = page.extract_text() or ''
        pages.append({'page':i+1,'widthPt':float(page.mediabox.width),'heightPt':float(page.mediabox.height),
                      'textCharacters':len(text),'containsHold':any(x in text.upper() for x in ['HOLD','NOT RELEASED'])})
    records.append({'file':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                    'pageCount':len(pages),'expectedPages':expected,'allPagesHaveText':all(x['textCharacters']>20 for x in pages),
                    'pages':pages})
result = {'pass':all(x['pageCount']==x['expectedPages'] and x['allPagesHaveText'] for x in records),
          'records':records,'scope':'Page/text inspection only; selected pages rendered for visual review. Native exports use pin-level blocks/global labels, not polished application schematic sheets. No hardware approval.'}
(ROOT/'verification/pdf-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pass':result['pass'],'pages':[x['pageCount'] for x in records]}))
if not result['pass']:
    raise SystemExit(1)
