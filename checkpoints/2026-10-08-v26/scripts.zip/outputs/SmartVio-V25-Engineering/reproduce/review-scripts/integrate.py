"""Merge reviewed changes without modifying V24 or silently dropping parts."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE/'outputs/SmartVio-V25-Engineering'
OLD = BASE/'outputs/SmartVio-V24-NativeEDA'
for d in ('reference','electrical','eda','verification','reproduce'):
 (ROOT/d).mkdir(parents=True,exist_ok=True)
def write(path,data):
 path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
 old = json.loads((OLD/'electrical/native-components.json').read_text(encoding='utf-8'))
 by = {c['ref']:copy.deepcopy(c) for c in old}
 journal=[]
 # Review artifacts are explicit patches, not free-form instructions.
 for domain in ('power','audio'):
  folder=ROOT/'audit'/domain
  patch=folder/'corrected-components.json'
  if not patch.exists():
   journal.append({'domain':domain,'status':'PATCH_NOT_READY'})
   continue
  data=json.loads(patch.read_text(encoding='utf-8'))
  if isinstance(data,dict): data=data.get('components',data.get('correctedComponents',[]))
  for c in data:
   assert 'pins' in c and 'ref' in c, c
   journal.append({'domain':domain,'ref':c['ref'],'action':'replace' if c['ref'] in by else 'add'})
   by[c['ref']]=c
  ch=folder/'changes.json'
  if ch.exists():
   changes=json.loads(ch.read_text(encoding='utf-8'))
   for ref in changes.get('remove',[]):
    assert ref in by, ref
    by.pop(ref)
    journal.append({'domain':domain,'ref':ref,'action':'remove'})
 # Increase the headphone negative charge-pump reservoir relative to the flying
 # capacitor. Effective-C qualification remains a separate BOM gate.
 assert by['C304']['pins'][0]['net']=='HP_NEG'
 by['C304']['value']='2.2uF / 10V X7R; Ceff_min >= C303_Ceff_max'
 by['C304']['note']='V25 audio review CHANGE-A03; nominal value corrected, exact MPN/DC-bias qualification still HOLD.'
 journal.append({'domain':'audio','ref':'C304','action':'1uF -> 2.2uF nominal; effective-C gate retained'})
 dual=ROOT/'audit/audio/authorized-net-deltas.json'
 if dual.exists():
  delta=json.loads(dual.read_text(encoding='utf-8'))
  for change in delta['ownedPinChanges']:
   pin=next(p for p in by[change['ref']]['pins'] if p['number']==change['pin'])
   assert pin['net']==change['newNet'], 'Audio-owned patch was not applied atomically'
  for change in delta['parentPinChanges']:
   pin=next(p for p in by[change['ref']]['pins'] if p['number']==change['pin'])
   assert pin['net']==change['expectedOldNet'], 'Existing allocation conflict'
   pin.update({'net':change['newNet'],'name':change['name'],'electricalType':change['electricalType']})
   journal.append({'domain':'audio-mcu','ref':change['ref'],'pin':change['pin'],'action':'connect dual-I2S lane 2','evidence':change})
  for c in json.loads((ROOT/'audit/audio'/delta['addComponentsFile']).read_text(encoding='utf-8')):
   assert c['ref'] not in by, 'Duplicate new audio component'
   by[c['ref']]=c
   journal.append({'domain':'audio','ref':c['ref'],'action':'add source-series resistor for DOUT2'})
 # Native MCU pin corrections, if supplied by firmware reviewer.
 patch=ROOT/'firmware/contracts/corrected-components.json'
 if patch.exists():
  for c in json.loads(patch.read_text(encoding='utf-8')):
   by[c['ref']]=c
   journal.append({'domain':'firmware','ref':c['ref'],'action':'replace'})
 # Apply independently reviewed interface/reset deltas after domain patches.
 patch=ROOT/'audit/system/corrected-components.json'
 if patch.exists():
  for c in json.loads(patch.read_text(encoding='utf-8')):
   by[c['ref']]=c
   journal.append({'domain':'system','ref':c['ref'],'action':'replace' if c['ref'] in {x['ref'] for x in old} else 'add'})
 # Supplemental audio audit is approved only for identical pin/net mappings.
 # Q1201 is the sole exact-MPN replacement; no jack/speaker/HP load change here.
 patch=ROOT/'audit/audio/supplemental/corrected-components.json'
 if patch.exists():
  approved={*(f'K120{i}' for i in range(1,8)),'Q1201','J401','U601'}
  for c in json.loads(patch.read_text(encoding='utf-8')):
   ref=c['ref']
   assert ref in approved and ref in by, ref
   assert {p['number']:p['net'] for p in c['pins']}=={p['number']:p['net'] for p in by[ref]['pins']}, f'{ref}: unapproved audio net delta'
   if ref=='Q1201':
    assert by[ref]['mpn'] in ('2N7002','PMV30UN2R') and c['mpn']=='PMV30UN2R'
   else:
    assert c['mpn']==by[ref]['mpn'], f'{ref}: unapproved MPN change'
   by[ref]=c
   journal.append({'domain':'audio-supplement','ref':ref,'action':'same-net pin evidence/exact candidate MPN update; no physical approval'})
 # Merge only the seven existing TVS pin proofs. Control/LED alternatives stay
 # unselected, and the independently proposed footprint is not applied here.
 folder=ROOT/'audit/controls-protection'
 patch=folder/'corrected-components.json'
 if patch.exists():
  copied=[]
  for source in json.loads((folder/'sources.json').read_text(encoding='utf-8')):
   original=BASE/source['path']
   assert hashlib.sha256(original.read_bytes()).hexdigest()==source['sha256']
   destination=folder/'source-evidence'/original.name
   destination.parent.mkdir(parents=True,exist_ok=True)
   shutil.copyfile(original,destination)
   copied.append({**source,'packPath':destination.relative_to(ROOT).as_posix()})
  write(folder/'parent-source-manifest.json',copied)
  approved={f'D120{i}' for i in range(1,8)}
  for c in json.loads(patch.read_text(encoding='utf-8')):
   ref=c['ref']
   assert ref in approved and ref in by
   assert c['mpn']==by[ref]['mpn']=='TPD1E10B06DPYR'
   assert {p['number']:p['net'] for p in c['pins']}=={p['number']:p['net'] for p in by[ref]['pins']}
   assert c['release']=='HOLD' and c['footprintProposal']['applied'] is False
   for proof in (c['pinProof'],c['footprintProposal']['evidence']):
    proof['local_file']='audit/controls-protection/source-evidence/'+Path(proof['local_file']).name
   for p in c['pins']:
    p['evidence']={**c['pinProof'],'function':p['manufacturerFunction'],
                   'scope':'Manufacturer pin identity only; application, layout, paste and physical testing HOLD'}
    p['pinAuditStatus']='VERIFIED_OFFICIAL'
   by[ref]=c
   journal.append({'domain':'controls-protection','ref':ref,'action':'correct X1SON package and document same-net bidirectional pin identity; no footprint or protection approval'})
 # Correct known stale package descriptions to the actual candidate PCB class.
 # Do not assign conditional MPNs or imply effective capacitance approval.
 for ref in ('C1102','C1104','C1105','C1106','C1501'):
  if '0805' not in by[ref].get('package',''):
   by[ref]['package']='0805/2012 actual candidate PCB class; exact MPN, height and effective capacitance HOLD'
   journal.append({'domain':'critical-passives','ref':ref,'action':'correct stale0603 description to actual0805 land class; no pad/net/value change'})
 # Full-footprint identifiers are attached only when every symbol pad has an
 # explicit physical mapping. Unresolved jack aliases stay unassigned.
 footprint_review=ROOT/'pcb-work/footprint-review.json'
 if footprint_review.exists():
  review=json.loads(footprint_review.read_text(encoding='utf-8'))
  mapping={ref:{'id':r['footprint'],'status':r['review'],'fabricationApproved':False}
           for ref,r in review.items() if ref in by and r.get('footprint')
           and not r.get('missingPhysicalPads') and not r.get('pinAliases')}
  write(ROOT/'electrical/footprint-map.json',mapping)
  library=ROOT/'pcb-work/SmartVioV25.pretty'
  if library.exists():shutil.copytree(library,ROOT/'eda/SmartVioV25.pretty',dirs_exist_ok=True)
  (ROOT/'eda/fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "SmartVioV25") (type "KiCad") (uri "${KIPRJMOD}/SmartVioV25.pretty") (options "") (descr "V25 candidate footprints; see footprint review")))',encoding='utf-8')
 passive=ROOT/'audit/passives/corrected-components.json'
 if passive.exists():
  for c in json.loads(passive.read_text(encoding='utf-8')):
   if c['ref'] not in by or c['value']!=by[c['ref']]['value']:
    journal.append({'domain':'passives','ref':c['ref'],'action':'SKIP_STALE_VALUE'})
    continue
   for key in ('mpn','candidateManufacturer','bomEvidence','procurementApproved'):
    by[c['ref']][key]=c[key]
   journal.append({'domain':'passives','ref':c['ref'],'action':'assign exact manufacturer-documented candidate'})
 aliases=json.loads((OLD/'electrical/reference-aliases.json').read_text())
 original_sheets=json.loads((OLD/'reference/v23-circuits.json').read_text(encoding='utf-8'))
 sheets=[]; consumed=set()
 for s in original_sheets:
  ns={k:copy.deepcopy(v) for k,v in s.items() if k!='components'}
  ns['components']=[]
  for c in s['components']:
   ref=aliases.get(c['ref'],c['ref'])
   if ref=='U801P': ref='U801'
   if ref=='U801S' or ref not in by or ref in consumed: continue
   ns['components'].append(by[ref]);consumed.add(ref)
  if ns['components']:sheets.append(ns)
 for ref,c in by.items():
  if ref not in consumed and c.get('sheet'):
   sheet=next(s for s in sheets if s['id']==c['sheet'])
   sheet['components'].append(c);consumed.add(ref)
 additions=[c for ref,c in by.items() if ref not in consumed]
 if additions:sheets.append({'id':'A31','title':'V25 reviewed additions','components':additions})
 write(ROOT/'reference/v25-circuits.json',sheets)
 write(ROOT/'reference/v24-native-components.json',old)
 write(ROOT/'electrical/native-components.json',list(by.values()))
 write(ROOT/'verification/change-journal.json',journal)
 shutil.copyfile(OLD/'electrical/reference-aliases.json',ROOT/'electrical/reference-aliases.json')
 # Reuse the existing tested capture geometry; only the source path/revision/explicit
 # pin types change. Native KiCad ERC and exported netlist parity run separately.
 source=(OLD/'reproduce/native_schematic.py').read_text(encoding='utf-8')
 source=source.replace('v23-circuits.json','v25-circuits.json').replace('V24','V25')
 source=source.replace('2026-10-01','2026-10-08').replace('2026-10-04','2026-10-08')
 source=source.replace("def role(c, p):\n", "def role(c, p):\n    if 'electricalType' in p:\n        return p['electricalType']\n")
 (ROOT/'reproduce/capture_library.py').write_text(source,encoding='utf-8')
 spec=importlib.util.spec_from_file_location('capture_v25',ROOT/'reproduce/capture_library.py')
 lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
 eda=ROOT/'eda'; uid=lib.uid; q=lib.q; fx=lib.fx
 rootuuid=uid('SmartVio')
 flaglib='(symbol "SmartVio:PWR_FLAG" (power) (pin_names (offset 0) hide) (in_bom no) (on_board no) (property "Reference" "#FLG" (at 0 0 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at 0 2.54 0) (effects (font (size 1 1)))) (symbol "PWR_FLAG_1_1" (pin power_out line (at 0 0 90) (length 0) (name "pwr" (effects (font (size 1 1)))) (number "1" (effects (font (size 1 1)))))))'
 root=f'(kicad_sch (version 20260101) (generator "smartvio_v25_review") (uuid {rootuuid}) (paper "A2") (lib_symbols {flaglib})\n'
 root+=lib.text('SmartVio V25 - Reviewed native capture / HOLD',20,18,3)
 root+=lib.text('Read audit findings and manufacturing gate. Native capture does not mean physical validation.',20,26,1.3)
 for i,sheet in enumerate(sheets):
  name=sheet['id']; pageid=uid(name+'sheet');x=20+(i%4)*140;y=40+(i//4)*55
  root+=f'(sheet (at {x} {y}) (size 120 32) (stroke (width 0.254) (type default)) (fill (color 0 0 0 0)) (uuid {pageid})\n'
  root+=f'(property "Sheetname" {q(name+" "+sheet["title"])} (at {x} {y-2} 0) (effects (font (size 1.1 1.1)) (justify left bottom)))\n'
  root+=f'(property "Sheetfile" {q(name+".kicad_sch")} (at {x} {y+34} 0) (effects (font (size 1.1 1.1)) (justify left top)))\n'
  root+=f'(instances (project "SmartVio" (path "/{rootuuid}" (page "{i+2}")))))\n'
  (eda/(name+'.kicad_sch')).write_text(lib.capture(name,sheet['components'],name+' '+sheet['title'],pageid,parent_uuid=rootuuid),encoding='utf-8')
 root+=lib.text('Supply sources: USB VBUS is external; V3A/MCU_VDDA are passive-filtered V3D. No exclusion of ERC errors.',20,375,1.2)
 for i,net in enumerate(['GND','V3A','MCU_VDDA','VBUS_RAW']):
  x,y=50.8+i*100.33,386.08;ref='#FLG'+str(i+1)
  root+=f'(symbol (lib_id "SmartVio:PWR_FLAG") (at {x} {y} 0) (unit 1) (in_bom no) (on_board no) (uuid {uid(ref)}) (property "Reference" {q(ref)} (at {x} {y} 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at {x} {y-3.81} 0) {fx}) (instances (project "SmartVio" (path "/{rootuuid}" (reference {q(ref)}) (unit 1)))))\n'
  root+=f'(global_label {q(net)} (shape passive) (at {x} {y} 0) {fx} (uuid {uid(ref+net)}))\n'
 root+='(sheet_instances (path "/" (page "1"))))\n'
 (eda/'SmartVio.kicad_sch').write_text(root,encoding='utf-8')
 (eda/'SmartVio.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "smartvio_v25_review")\n'+''.join(lib.library(c,False) for c in by.values())+flaglib.replace('SmartVio:PWR_FLAG','PWR_FLAG')+')\n',encoding='utf-8')
 (eda/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "SmartVio") (type "KiCad") (uri "${KIPRJMOD}/SmartVio.kicad_sym") (options "") (descr "V25 native review symbols")))',encoding='utf-8')
 write(eda/'SmartVio.kicad_pro',{'meta':{'filename':'SmartVio.kicad_pro','version':1},'erc':{'erc_exclusions':[]}})
 write(ROOT/'verification/capture-summary.json',{'sheets':len(sheets)+1,'components':len(by),'pins':sum(len(c['pins']) for c in by.values()),'release':'HOLD','domainsMerged':journal})
 print(json.dumps({'components':len(by),'sheets':len(sheets)+1}))
if __name__=='__main__':main()
