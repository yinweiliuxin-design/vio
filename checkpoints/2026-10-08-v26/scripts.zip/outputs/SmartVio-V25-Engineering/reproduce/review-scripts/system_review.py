"""Apply explicit reset and USB reference corrections from manufacturer evidence."""
import copy
import json
import math
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
ROOT = BASE / 'outputs/SmartVio-V25-Engineering'
OUT = ROOT / 'audit/system'
OUT.mkdir(parents=True, exist_ok=True)
parts = json.loads((ROOT/'electrical/native-components.json').read_text(encoding='utf-8'))
by = {c['ref']: copy.deepcopy(c) for c in parts}
esp = {'url':'https://documentation.espressif.com/esp32-mini-1_datasheet_en.pdf',
       'section':'v1.8 Table3 EN pin8; Table9 reset/stabilization 50us; Table15 VIH_nRST >=0.75VDD, VIL_nRST <=0.6V'}
st = {'url':'https://www.st.com/resource/en/datasheet/stm32h743vi.pdf',
      'section':'DS12110 Rev11 output characteristics Tables50/148: VOH>=VDD-0.4, VOL<=0.4 at8mA, VDD2.7..3.6'}
ti = {'url':'https://www.ti.com/lit/ds/symlink/tpd2s703-q1.pdf',
      'section':'RevB 8.4 and9.2.2.2 mode1; Table6.8 140k/24.9k +/-1% gives3.04..3.58V; disabled reference discharges'}

def pin(ref, number):
    return next(p for p in by[ref]['pins'] if p['number'] == str(number))

def change(ref, number, allowed, target):
    p = pin(ref, number)
    assert p['net'] in allowed, (ref, number, p['net'])
    p['net'] = target

change('U901',8,('RF_ENABLE','RF_CHIP_EN'),'RF_CHIP_EN')
change('R901',1,('RF_ENABLE','RF_CHIP_EN'),'RF_CHIP_EN')
change('R901',2,('V3D','GND'),'GND')
change('C901',1,('RF_ENABLE','RF_CHIP_EN'),'RF_CHIP_EN')
change('J902',6,('RF_ENABLE','RF_CHIP_EN'),'RF_CHIP_EN')
by['R901']['note']='External EN pulldown; prevents boot during STM32 reset. R907 limits capacitor charge/discharge current.'
by['C901']['note']='EN timing capacitor; effective-C and oscilloscope reset/ramp qualification required; no direct GPIO-capacitor connection.'
by['U901']['package']='13.2x13.5x2.4mm; ESP32-MINI-1U-N4; external antenna and coax keepout pending'
pin('U901',8).update({'name':'EN','electricalType':'input','pinAuditStatus':'VERIFIED_OFFICIAL','evidence':esp})
by['J902']['note']='Factory EN pad is RF_CHIP_EN after R907. Open-drain can assert reset but cannot enable against R901 pulldown. ROM jig needs current-limited tri-state target-voltage EN drive with STM32 NRST held low, target V3D valid and common GND. Never tie adapter power directly; no EN drive when target V3D is off. Jig qualification pending.'

def resistor(ref,value,mpn,n1,n2,sheet):
    return {'ref':ref,'type':'R','value':value,'mpn':mpn,'package':'0603;1%;0.1W candidate',
            'sheet':sheet,'release':'HOLD','procurementApproved':False,
            'pins':[{'number':'1','name':'1','net':n1},{'number':'2','name':'2','net':n2}],
            'verificationScope':'Manufacturer circuit calculation and logical capture; board and physical qualification remain pending.'}

if 'R907' in by:
    assert [p['net'] for p in by['R907']['pins']]==['RF_ENABLE','RF_CHIP_EN']
by['R907']=resistor('R907','470R','RC0603FR-07470RL','RF_ENABLE','RF_CHIP_EN','A19')
by['R907']['note']='Series EN drive current limiter. RC rise/fall and overall GPIO sum-current require board qualification.'
# Mode1 uses the protector internal regulator, independent of V3D. Its transient
# clamp still must be coordinated with the actual STM32 USB PHY; do not mark safe.
change('U1501',8,('V3D','USB_VREF'),'USB_VREF')
pin('U1501',8)['electricalType']='power_out'
change('C1502',1,('V3D','USB_VREF'),'USB_VREF')
by['R1501'].update({'value':'24.9k 1%','mpn':'RC0603FR-0724K9L','note':'Mode1 lower feedback resistor; do not substitute old2.20k mode0 value.'})
by['R1501'].pop('bomEvidence',None)
by['R1501']['procurementApproved']=False
by['R1504']=resistor('R1504','140k 1%','RC0603FR-07140KL','USB_VREF','USB_OVP_MODE','A26')
by['U1501']['note']='Mode1 dedicated VREF:140k top/24.9k bottom, independent of MCU3V3. System-side transient and powered-off USB PHY remain HOLD.'
by['C1502']['note']='Dedicated USB_VREF reservoir, close to U1501pin8; not V3D decoupling. Exact MPN/effective0.3..3uF and pulse behavior pending.'
by['U1501']['supplyAudit']={'status':'MODE1_REFERENCE_CORRECTED_TRANSIENT_COORDINATION_HOLD',
   'evidence':ti,'constraints':[{'net':'USB_VREF','pins':['8'],'rangeV':[3.04,3.58],
                              'purpose':'Dedicated ESD/OVP reference, never tied to V3D'}]}
selected=['U901','R901','C901','J902','R907','U1501','C1502','R1501','R1504']
(OUT/'corrected-components.json').write_text(json.dumps([by[r] for r in selected],ensure_ascii=False,indent=2),encoding='utf-8')
rs_min,rs_max=470*.99,470*1.01
rp_min,rp_max=10000*.99,10000*1.01
vmin,vmax=3.0,3.6
voh_min=(vmin-.4)*rp_min/(rp_min+rs_max)
tau_max=rs_max*rp_max/(rs_max+rp_max)*1.2e-6
ven_low=.4*rp_max/(rp_max+rs_min)
# With MCU high-impedance, the reset pulldown discharges the cap more slowly.
off_time=-rp_max*1.2e-6*math.log(.6/vmax)
calculations={
 'gpioPeakBoundA':vmax/rs_min,'gpioPeakBelow8mA':vmax/rs_min<.008,
 'enHighConservativeV':voh_min,'enHighRequiredAt3V':.75*vmin,'highMarginV':voh_min-.75*vmin,
 'enLowDrivenBoundV':ven_low,'enLowShutdownMaxV':.6,'lowMarginV':.6-ven_low,
 'enableDrivenTauMaxS':tau_max,'enableWaitMinimumMs':5,
 'resetHighImpedanceDischargeTo0_6VBoundS':off_time,'resetWaitMinimumMs':30,
 'mode1EquivalentResistanceNominalOhm':1/(1/140000+1/24900),
 'mode1EquivalentResistanceWorstMinOhm':1/(1/(140000*.99)+1/(24900*.99)),
 'mode1EquivalentAbove14k':1/(1/(140000*.99)+1/(24900*.99))>14000,
 'mode1VrefNominalV':.5*(1+140000/24900),'datasheetVrefRangeV':[3.04,3.58],
 'mode1TopResistorWorstPowerW':(3.58-.47)**2/(140000*.99),
 'capacitanceAssumptionF':[.8e-6,1.2e-6],
 'limits':'1uF effective capacitance envelope is an assumed candidate; actual MPN, IO aggregate load, reset ramp, faults and scope tests remain HOLD.'}
assert calculations['gpioPeakBelow8mA'] and calculations['highMarginV']>0 and calculations['lowMarginV']>0 and calculations['mode1EquivalentAbove14k']
review={'revision':'2026-10-08','status':'LOGICAL_CORRECTIONS_APPLIED_PHYSICAL_HOLD',
 'refs':selected,'evidence':[esp,st,ti],'calculations':calculations,
 'faults':[{'trigger':'STM32 reset/high impedance','response':'RF_CHIP_EN pulldown forces shutdown after bounded RC discharge; wait>=30ms before reset release/reflash.'},
           {'trigger':'USB_DATA_DISABLE high or VPWR loss','response':'Mode1 VREF discharges through feedback divider; MCU3V3 is no longer the protector clamp reference.'}],
 'remaining':['Actual USB transient residual at PHY and ESD steering/backpower remain unqualified.',
              'Factory ROM jig EN drive is not yet a manufactured/qualified adapter: open-drain release alone cannot overcome R901 pulldown; hold STM32 in reset, qualify target-voltage tri-state drive and prevent unpowered injection.',
              'EN steady low during initial cold boot is a topology result; capacitor starts uncharged only after adequate off/reset time.',
              'New resistors exact supplier documents/procurement and PCB routes/clearance must be audited.',
              'Physical tests executed:0. This is not a full charging, EMC or hardware pass.']}
(OUT/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'patchRefs':selected,'calculations':calculations},ensure_ascii=False))
