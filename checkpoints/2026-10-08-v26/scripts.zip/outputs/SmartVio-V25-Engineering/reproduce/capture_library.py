"""Generate editable KiCad capture from the V23 logical circuit, without releasing it."""
import copy
import json
import math
import re
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'reference' / 'v25-circuits.json'
EDA = ROOT / 'eda'
PROJECT = 'SmartVio'
NS = uuid.UUID('c685bbf5-4501-4b05-863b-4d22a3de6523')
uid = lambda key: str(uuid.uuid5(NS, key))
q = lambda value: json.dumps(str(value), ensure_ascii=False)
fx = '(effects (font (size 1.0 1.0)))'
parts = json.loads(SOURCE.read_text(encoding='utf-8'))
mapping_path = ROOT / 'electrical' / 'footprint-map.json'
mapping = json.loads(mapping_path.read_text()) if mapping_path.exists() else {}


def role(c, p):
    if 'electricalType' in p:
        return p['electricalType']
    n = p['name'].upper()
    explicit = {'U501': {'11': 'passive'}, 'U1101': {'8': 'passive'},
                'U401': {'5': 'power_in'}, 'U1501': {'8': 'power_in'},
                'U701': {'1':'power_in','3':'power_in','10':'input','11':'input','16':'input'},
                'U601': {'25':'input','26':'input'},'U801': {'20':'power_in'},
                'U1801': {'1':'input','7': 'no_connect'}}
    if p['number'] in explicit.get(c['ref'], {}):
        return explicit[c['ref']][p['number']]
    if c['type'] not in ('IC', 'MODULE'):
        return 'passive'
    if n in ('NC', 'UNUSED'):
        return 'no_connect'
    if n in ('VOUT', 'OUT', '3V3_OUT', 'LDO', 'VREF', 'VAUX'):
        return 'power_out'
    if n.startswith(('VINL','VINR')):
        return 'input'
    if re.match(r'^(GND|AGND|DGND|PGND|SGND|VSS|VDD|VDDA|VSSA|AVDD|DVDD|IOVDD|VBAT|VIN$|V_PLUS|V_MINUS|V\+|V-|VPWR|VM$)', n) or n == '3V3' or n == 'PAD':
        return 'power_in'
    if n in ('BAT', 'IN', 'HPVDD', 'HPVSS'):
        return 'passive'
    if n in ('SDA', 'SCL', 'CC1', 'CC2') or n.startswith(('PA', 'PB', 'PC', 'PD', 'PE', 'IO')):
        return 'bidirectional'
    if n in ('PG', 'PGOOD', 'CHG', 'FLT', 'FLT_N', 'INT_N', 'ALERT', 'ALERT_RDY'):
        return 'open_collector'
    if n.startswith(('OUT', 'DOUT', 'TXD', 'MISO')):
        return 'output'
    if n.startswith(('IN+', 'IN-', 'IN_', 'INL', 'INR', 'AIN', 'VINL', 'VINR')):
        return 'input'
    if n in ('EN', 'EN_N', 'EN1', 'EN2', 'CE', 'SD_MODE', 'DIN', 'BCLK', 'LRCLK', 'SCKI', 'SCK', 'SCL', 'ADDR', 'ADD0', 'KILL', 'MODE', 'G0', 'G1', 'FB', 'FB2', 'PS_SYNC', 'VSEL', 'EN_UVLO', 'OVLO') or n.startswith('SEL'):
        return 'input'
    if n.startswith(('IN_A', 'IN_B', 'IN_C', 'IN_D')):
        return 'input'
    return 'bidirectional'


def geometry(c):
    n = len(c['pins'])
    simple = n == 2 and c['type'] in ('R', 'C', 'L')
    if simple:
        return 2.54, 7.62, [(c['pins'][0], -7.62, 0, 0), (c['pins'][1], 7.62, 0, 180)]
    left_n = math.ceil(n / 2)
    h = max(7.62, (left_n + 1) * 2.54)
    pp = []
    for i, p in enumerate(c['pins']):
        right = i >= left_n
        row = i - left_n if right else i
        y = (left_n - 1) * 1.27 - row * 2.54
        pp.append((p, 25.4 if right else -25.4, y, 180 if right else 0))
    return h, 25.4, pp


def library(c, embedded=True):
    name = c['ref']
    libname = 'SmartVio:' + name if embedded else name
    h, w, pp = geometry(c)
    bodyw = w - 5.08
    s = f'(symbol {q(libname)} (pin_names (offset 0.508)) (in_bom yes) (on_board yes)\n'
    s += f'(property "Reference" {q(re.sub(r"[^A-Z]", "", name))} (at 0 {-h/2-3.81} 0) {fx})\n'
    s += f'(property "Value" {q(c["value"])} (at 0 {-h/2-1.27} 0) {fx})\n'
    s += f'(symbol {q(name+"_0_1")} (rectangle (start {-bodyw} {h/2}) (end {bodyw} {-h/2}) (stroke (width 0.254) (type default)) (fill (type background))))\n'
    s += f'(symbol {q(name+"_1_1")}\n'
    for p, x, y, angle in pp:
        s += f'(pin {role(c,p)} line (at {x} {y} {angle}) (length 5.08) (name {q(p["name"])} {fx}) (number {q(p["number"])} {fx}))\n'
    return s + '))\n'


def text(value, x, y, size=1.27):
    return f'(text {q(value)} (at {x} {y} 0) (effects (font (size {size} {size})) (justify left)) (uuid {uid(value+str(x)+str(y))}))\n'


def capture(name, components, title, pageid, project=PROJECT, parent_uuid=None):
    root_uuid = uid(project)
    instance_path = '/' + root_uuid + ('/' + pageid if parent_uuid else '')
    sid = uid(name + project)
    s = f'(kicad_sch (version 20260101) (generator "smartvio_native_capture") (uuid {root_uuid if not parent_uuid else sid}) (paper "A2")\n'
    s += f'(title_block (title {q(title)}) (date "2026-10-08") (rev "V25 REVIEW") (company "SmartVio") (comment 1 "ENGINEERING CAPTURE - NOT RELEASED FOR MANUFACTURE"))\n'
    s += '(lib_symbols\n' + ''.join(library(c) for c in components) + ')\n'
    s += text(title, 15, 15, 2.0)
    s += text('Pin-level capture. Global net labels connect sheets. Review findings remain open.', 15, 21)
    heights = [32., 32., 32., 32.]
    for c in components:
        h, w, pp = geometry(c)
        col = min(range(4), key=lambda i: heights[i])
        x, y = 78 + col * 140, heights[col] + h / 2 + 10
        x, y = round(x/1.27)*1.27, round(y/1.27)*1.27
        heights[col] += h + 26
        if heights[col] > 365:
            raise ValueError('Page overflow ' + name)
        ref = c['ref']
        footprint = mapping.get(ref, {}).get('id', '')
        s += f'(symbol (lib_id {q("SmartVio:"+ref)}) (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {uid(project+ref)})\n'
        # Values are shortened only visually; the complete specification remains a field.
        val = c['mpn'] or c['value'].split('/')[0].split(';')[0]
        if len(val) > 45:
            val = val[:42] + '...'
        s += f'(property "Reference" {q(ref)} (at {x} {y-h/2-6} 0) {fx})\n'
        s += f'(property "Value" {q(val)} (at {x} {y-h/2-3} 0) {fx})\n'
        for key, value in [('Footprint',footprint),('Specification',c['value']),('MPN',c.get('mpn') or ''),('Release','HOLD - design review required')]:
            s += f'(property {q(key)} {q(value)} (at {x} {y} 0) (effects (font (size 1 1)) hide))\n'
        s += f'(instances (project {q(project)} (path {q(instance_path)} (reference {q(ref)}) (unit 1)))))\n'
        for p, px, py, angle in pp:
            ax, ay = x + px, y - py
            if p['net'] is None:
                s += f'(no_connect (at {ax} {ay}) (uuid {uid(project+ref+p["number"]+"nc")}))\n'
            else:
                bx = ax + (5.08 if px > 0 else -5.08)
                s += f'(wire (pts (xy {ax} {ay}) (xy {bx} {ay})) (stroke (width 0) (type default)) (uuid {uid(project+ref+p["number"]+"wire")}))\n'
                rot = 0 if px < 0 else 180
                s += f'(global_label {q(p["net"])} (shape passive) (at {bx} {ay} {rot}) (effects (font (size 0.85 0.85)) (justify {"left" if px<0 else "right"})) (uuid {uid(project+ref+p["number"]+"label")}))\n'
    if not parent_uuid:
        s += '(sheet_instances (path "/" (page "1")))\n'
    return s + ')\n'


def main():
    EDA.mkdir(parents=True, exist_ok=True)
    for folder in ['reference','electrical','verification']:
        (ROOT/folder).mkdir(exist_ok=True)
    merged = copy.deepcopy(parts)
    power = next(c for s in merged for c in s['components'] if c['ref']=='U801P')
    signal = next(c for s in merged for c in s['components'] if c['ref']=='U801S')
    power['pins'] += signal['pins']
    power['pins'].sort(key=lambda p:int(p['number']))
    power['ref'] = 'U801'
    power['value'] = 'STM32H743VIT6'
    for s in merged:
        s['components'] = [c for c in s['components'] if c['ref']!='U801S']
    # Preserve unresolved DA/DB aliases. Do not silently translate these to physical pads.
    rootuuid = uid(PROJECT)
    aliases = {'JPU':'J101','JSEND':'J102','JLINE':'J201','JRETURN':'J202','JHP':'J301','JUSB':'J401'}
    for sheet in merged:
        for c in sheet['components']:
            if c['ref'] in aliases:
                c['legacyRef'] = c['ref']
                c['ref'] = aliases[c['ref']]
    (ROOT/'electrical/reference-aliases.json').write_text(json.dumps(aliases,indent=2))
    flaglib = '(symbol "SmartVio:PWR_FLAG" (power) (pin_names (offset 0) hide) (in_bom no) (on_board no) (property "Reference" "#FLG" (at 0 0 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at 0 2.54 0) (effects (font (size 1 1)))) (symbol "PWR_FLAG_1_1" (pin power_out line (at 0 0 90) (length 0) (name "pwr" (effects (font (size 1 1)))) (number "1" (effects (font (size 1 1)))))))'
    root = f'(kicad_sch (version 20260101) (generator "smartvio_native_capture") (uuid {rootuuid}) (paper "A2") (lib_symbols {flaglib})\n'
    root += text('SmartVio V25 - Native engineering capture',20,18,3)
    root += text('REVIEW / NOT A PRODUCTION RELEASE. Read ../index.html and the ERC report before changes.',20,26,1.5)
    allcomponents = []
    for i, sheet in enumerate(merged):
        name = sheet['id']
        pageid = uid(name+'sheet')
        x,y = 20+(i%4)*140, 40+(i//4)*55
        root += f'(sheet (at {x} {y}) (size 120 32) (stroke (width 0.254) (type default)) (fill (color 0 0 0 0)) (uuid {pageid})\n'
        root += f'(property "Sheetname" {q(name+" "+sheet["title"])} (at {x} {y-2} 0) (effects (font (size 1.1 1.1)) (justify left bottom)))\n'
        root += f'(property "Sheetfile" {q(name+".kicad_sch")} (at {x} {y+34} 0) (effects (font (size 1.1 1.1)) (justify left top)))\n'
        root += f'(instances (project "SmartVio" (path "/{rootuuid}" (page "{i+2}")))))\n'
        (EDA/(name+'.kicad_sch')).write_text(capture(name,sheet['components'],name+' '+sheet['title'],pageid,parent_uuid=rootuuid),encoding='utf-8')
        allcomponents += sheet['components']
    root += text('Supply declarations: GND is the external return. V3A and MCU_VDDA are passive-filtered V3D.',20,375,1.27)
    for i,net in enumerate(['GND','V3A','MCU_VDDA']):
        x,y=50.8+i*100.33,386.08
        ref='#FLG'+str(i+1)
        root += f'(symbol (lib_id "SmartVio:PWR_FLAG") (at {x} {y} 0) (unit 1) (in_bom no) (on_board no) (uuid {uid(ref)}) (property "Reference" {q(ref)} (at {x} {y} 0) (effects (font (size 1 1)) hide)) (property "Value" "PWR_FLAG" (at {x} {y-3.81} 0) {fx}) (instances (project "SmartVio" (path "/{rootuuid}" (reference {q(ref)}) (unit 1)))))\n'
        root += f'(global_label {q(net)} (shape passive) (at {x} {y} 0) {fx} (uuid {uid(ref+net)}))\n'
    root += '(sheet_instances (path "/" (page "1"))))\n'
    (EDA/'SmartVio.kicad_sch').write_text(root,encoding='utf-8')
    (EDA/'SmartVio.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "smartvio_native_capture")\n'+''.join(library(c,False) for c in allcomponents)+flaglib.replace('SmartVio:PWR_FLAG','PWR_FLAG')+')\n',encoding='utf-8')
    (EDA/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "SmartVio") (type "KiCad") (uri "${KIPRJMOD}/SmartVio.kicad_sym") (options "") (descr "V25 review symbols")))',encoding='utf-8')
    (EDA/'SmartVio.kicad_pro').write_text(json.dumps({'meta':{'filename':'SmartVio.kicad_pro','version':1},'erc':{'erc_exclusions':[]}},indent=2),encoding='utf-8')
    (ROOT/'electrical/native-components.json').write_text(json.dumps(allcomponents,ensure_ascii=False,indent=2),encoding='utf-8')
    (ROOT/'verification/pin-types-review.json').write_text(json.dumps([{'ref':c['ref'],'pin':p['number'],'name':p['name'],'type':role(c,p),'basis':'derived from logical function; manufacturer electrical type review incomplete'} for c in allcomponents for p in c['pins']],indent=2),encoding='utf-8')
    print(json.dumps({'sheets':len(merged)+1,'physicalComponents':len(allcomponents),'pins':sum(len(c['pins']) for c in allcomponents)}))


if __name__ == '__main__':
    main()
