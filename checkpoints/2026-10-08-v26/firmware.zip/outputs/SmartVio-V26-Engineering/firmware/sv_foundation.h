#ifndef SV_FOUNDATION_H
#define SV_FOUNDATION_H
#include "sv_telemetry.h"
#include "sv_audio_contract.h"

enum { SV_AUDIO_FRAMES_MAX=128, SV_UART_RX_BUDGET=128, SV_UART_TX_CAPACITY=1024 };
typedef enum { SV_AUDIO_SILENT, SV_AUDIO_TONE, SV_AUDIO_LOOPBACK } sv_audio_mode;
typedef struct { sv_audio_mode mode; uint8_t phase; } sv_audio;
/* Explicit local factory test authorization; no UART command enables tests. */
bool sv_audio_set_test(sv_audio *, sv_audio_mode, bool local_factory_authorized);
bool sv_audio_process(sv_audio *, const int16_t *stereo_in, int16_t *stereo_out,
                      size_t frames, bool output_authorized);
bool sv_audio_speaker_left(const int16_t *mono_in, int16_t *stereo_out,
                           size_t frames, uint16_t gain_q15, bool factory_qualified);

typedef enum { SV_BT_OFF, SV_BT_IDLE, SV_BT_PAIRING, SV_BT_CONNECTED, SV_BT_FAULT } sv_bt_state;
typedef struct {
    void *ctx;
    bool (*discoverable)(void *, bool, uint32_t timeout_ms);
    bool (*disconnect)(void *, uint32_t timeout_ms);
} sv_bt_hal;
typedef struct {
    sv_bt_state state;
    sv_bt_hal hal;
    bool authenticated;
    uint32_t pairing_at, last_tick, generation;
} sv_bt;
void sv_bt_init(sv_bt *, sv_bt_hal, uint32_t now);
bool sv_bt_pair_local(sv_bt *, bool physical_window_consumed, uint32_t now);
void sv_bt_tick(sv_bt *, uint32_t now);
void sv_bt_disconnect(sv_bt *);
/* Called ONLY by trusted radio adapter after peer/encryption/bond checks. */
bool sv_bt_authenticated_event(sv_bt *, bool peer_verified, uint32_t now);
void sv_bt_disconnected_event(sv_bt *);

enum { SV_ST_CORE=1, SV_ST_POWER=2, SV_ST_CLOCKS=4, SV_ST_SENSOR=8, SV_ST_AUDIO=16 };
typedef struct { uint32_t passed, pending, failed, started_at; } sv_selftest;
void sv_selftest_init(sv_selftest *, uint32_t now);
void sv_selftest_tick(sv_selftest *, uint32_t now, const sv_inputs *, bool sensor_ready);
bool sv_selftest_passed(const sv_selftest *);

typedef struct {
    void *ctx;
    /* Return false for unavailable, invalid or expired board evidence. */
    bool (*sample)(void *, uint32_t now, sv_inputs *, bool *monitor_settled);
    bool (*apply)(void *, const sv_outputs *);
    /* Independent fail-off path; required even when apply fails. */
    void (*fail_off)(void *);
} sv_board_hal;
typedef struct {
    sv_control control;
    sv_monitor monitor;
    sv_charge_guard charge;
    sv_parser parser;
    sv_session session;
    sv_bt bt;
    sv_selftest selftest;
    sv_board_hal board;
    uint8_t tx[SV_UART_TX_CAPACITY];
    uint16_t tx_head, tx_count, rx_this_tick;
    uint32_t now, session_at, session_bt_generation, transport_errors, replies_dropped;
    bool board_failed;
} sv_runtime;
void sv_runtime_init(sv_runtime *, uint32_t now, const sv_config *,
                     sv_board_hal, sv_mon_bus, const sv_mon_cal *, sv_bt_hal);
void sv_runtime_tick(sv_runtime *, uint32_t now);
bool sv_runtime_rx(sv_runtime *, const uint8_t *, size_t length);
bool sv_runtime_tx_byte(sv_runtime *, uint8_t *byte);
/* Transport fault or overrun invalidates all prior authorization and buffered frames. */
void sv_runtime_link_lost(sv_runtime *);
/* Adapter-only API. Epoch must be fresh across reconnect/reset, from a CSPRNG or
 * non-repeating trusted identity. It is a replay discriminator, not a MAC. */
bool sv_runtime_authorize_trusted(sv_runtime *, uint32_t epoch);
#endif
