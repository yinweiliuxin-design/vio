param([switch]$Rebuild)
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$work=Join-Path $root 'work/v26/firmware'
if($env:SV_BUILD_WORK){$work=[IO.Path]::GetFullPath($env:SV_BUILD_WORK)}
if(!(Test-Path $work) -and !$env:SV_BUILD_WORK){$work=Join-Path $PSScriptRoot 'build-local'}
if(!$env:IDF_PATH){$env:IDF_PATH=Join-Path $work 'vendor/esp-idf-v5.4.3'}
if(!$env:IDF_TOOLS_PATH){$env:IDF_TOOLS_PATH=Join-Path $work 'esp-tools'}
if(!(Test-Path (Join-Path $env:IDF_PATH 'tools/idf.py'))){throw 'Install official ESP-IDF5.4.3 and set IDF_PATH/IDF_TOOLS_PATH. No automatic downloads.'}
$env:TEMP=Join-Path $work 'tmp';$env:TMP=$env:TEMP
$env:CCACHE_DIR=Join-Path $work 'ccache'
$env:PIP_CACHE_DIR=Join-Path $work 'pip-cache'
$env:IDF_COMPONENT_MANAGER=0
$env:PATH='C:\Windows\System32;C:\Windows;<LOCAL_USER_HOME>\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd;'+$env:PATH
$runtime='<LOCAL_USER_HOME>/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if($env:PYTHON){$runtime=$env:PYTHON}elseif(!(Test-Path $runtime)){$runtime=(Get-Command python.exe -ErrorAction Stop).Source}
New-Item -ItemType Directory -Force $work,$env:TEMP,$env:CCACHE_DIR,(Join-Path $PSScriptRoot 'verification')|Out-Null
$status=[ordered]@{status='BUILDING';sdk='ESP-IDF5.4.3';target='esp32-single-core';hardwareTests=0;productionFreezePermitted=$false}
$result=Join-Path $PSScriptRoot 'verification/esp-native-build.json'
Start-Transcript (Join-Path $PSScriptRoot 'verification/esp-native-build.log')
try{
    $lines=& $runtime (Join-Path $env:IDF_PATH 'tools/idf_tools.py') export --format key-value
    if($LASTEXITCODE -ne 0){throw 'Official environment export failed'}
    foreach($line in $lines){if($line -match '^([A-Z_]+)=(.*)$'){
        $name=$Matches[1];$value=$Matches[2].Replace('%PATH%',$env:PATH);Set-Item ('Env:\'+$name) $value
    }}
    $python=Join-Path $env:IDF_PYTHON_ENV_PATH 'Scripts/python.exe'
    $short=Join-Path $work 'xt'
    if(!(Test-Path $short)){New-Item -ItemType Junction -Path $short -Target (Join-Path $env:IDF_TOOLS_PATH 'tools/xtensa-esp-elf/esp-14.2.0_20250730/xtensa-esp-elf')|Out-Null}
    $env:PATH=(Join-Path $short 'bin')+';'+$env:PATH
    $actions=if($Rebuild){@('clean','build')}else{@('build')}
    & $python (Join-Path $env:IDF_PATH 'tools/idf.py') -C (Join-Path $PSScriptRoot 'esp32') -B (Join-Path $work 'eb') @actions 2>&1 | ForEach-Object {Write-Host ([string]$_)}
    if($LASTEXITCODE -ne 0){throw 'ESP target build failed'}
    $status.status='CROSS_COMPILE_PASS_NOT_HARDWARE_RUN'
    $status.rebuiltFromClean=[bool]$Rebuild
    $artifactPaths=@('smartvio_rf_diag.elf','smartvio_rf_diag.bin','smartvio_rf_diag.map','bootloader/bootloader.bin','partition_table/partition-table.bin','flash_args','flasher_args.json')|ForEach-Object {Join-Path (Join-Path $work 'eb') $_}
    $status.artifacts=@($artifactPaths|Get-FileHash -Algorithm SHA256|Select-Object Path,Hash)
    $espInputs=@(Get-ChildItem (Join-Path $PSScriptRoot 'esp32/main') -File|Select-Object -ExpandProperty FullName)+@('esp32/CMakeLists.txt','esp32/sdkconfig','esp32/sdkconfig.defaults','sv_control.c','sv_control.h','sv_radio_core.c','sv_radio_core.h','sv_resample.h','build-esp-v26.ps1'|ForEach-Object {Join-Path $PSScriptRoot $_})
    $status.inputs=@($espInputs|Get-FileHash|Select-Object Path,Hash)
}catch{$status.status='CROSS_COMPILE_FAILED';$status.error=$_.Exception.Message;throw}
finally{$status.updatedAtUtc=[DateTime]::UtcNow.ToString('o');$status|ConvertTo-Json -Depth 5|Set-Content $result -Encoding utf8;Stop-Transcript}
