idf_component_register(SRCS "smartvio_rf.c" "pcm_rx.c" "../../sv_control.c" "../../sv_radio_core.c"
    INCLUDE_DIRS "." "../.." REQUIRES bt nvs_flash esp_driver_uart esp_driver_i2s esp_timer)
