param([switch]$ContractsOnly)
$ErrorActionPreference='Stop'
$PSDefaultParameterValues['Get-Content:Encoding']='utf8'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$work=Join-Path $root 'work/v26/firmware'
$log=Join-Path $PSScriptRoot 'verification'
$records=@()
$pins=Get-Content (Join-Path $PSScriptRoot 'contracts/pins.json') -Raw|ConvertFrom-Json
[xml]$xml=Get-Content (Join-Path $work 'downloads/STM32H743VITx.xml') -Raw
$ns=New-Object Xml.XmlNamespaceManager($xml.NameTable);$ns.AddNamespace('s','http://dummy.com')
foreach($p in $pins.stm32.signals){
    $node=$xml.SelectSingleNode("/s:Mcu/s:Pin[@Position='$($p.pin)']",$ns)
    $gpio=($p.gpio -split ' ')[0];$identity=($node.GetAttribute('Name') -split ' ')[0]
    if($gpio -ne $identity){throw "GPIO mismatch $($p.pin)"}
    $function=if($p.function -like 'GPIO*'){'GPIO'}else{$p.function}
    $capabilities=@($node.SelectNodes('s:Signal',$ns)|ForEach-Object {$_.GetAttribute('Name')})
    if($function -notin $capabilities){throw "Unsupported function $function at $gpio"}
    $records+=@{pin=$p.pin;identity=$identity;function=$function;af=$p.af;capability='OFFICIAL_XML_PASS_AF_MANUALLY_REVIEWED'}
}
$c=Get-Content (Join-Path $PSScriptRoot 'contracts/clocks.json') -Raw|ConvertFrom-Json
$f=$c.audioCandidate.adcFrame
if($f.frameLengthBits -ne 64 -or $f.lanes -ne 2 -or $f.physicalSlotsPerLane -ne 2 -or $f.slotWidthBits -ne 32 -or $f.activeMaskPerLane -ne '0x03' -or $f.bclkHz -ne $f.sampleHz*64 -or $c.audioCandidate.mco2.sckiHz -ne 512*$f.sampleHz){throw 'Clock arithmetic mismatch'}
& (Join-Path $PSScriptRoot 'audit-pins.ps1')
$parity=Get-Content (Join-Path $log 'live-net-parity.json') -Raw|ConvertFrom-Json
$vendorRecord=Get-Content (Join-Path $log 'vendor-handoff.json') -Raw|ConvertFrom-Json
$portableVendor=Join-Path $PSScriptRoot 'vendor'
if($vendorRecord.files.Count -ne 178 -or (Get-ChildItem $portableVendor -Recurse -File).Count -ne 178){throw 'Portable vendor count changed'}
foreach($file in $vendorRecord.files){if((Get-FileHash (Join-Path $portableVendor $file.path)).Hash -ne $file.sha256){throw "Portable vendor hash changed $($file.path)"}}
@{status='PASS_ALL_178_INCLUDED_VENDOR_FILES_SHA256';manifestSha256=(Get-FileHash (Join-Path $log 'vendor-handoff.json')).Hash;files=178;hardwareTests=0}|ConvertTo-Json|Set-Content (Join-Path $log 'vendor-check.json') -Encoding utf8
@{status='PASS_CONTRACT_CAPABILITY_AND_LIVE_PARITY_ONLY';signals=$records;baselineRetained=$parity.baseline;baselineSha256=$parity.baselineSha256;liveSourceSha256=$parity.sourceSha256;hardwareTests=0;afReview='Official DS12110 Table10 manual review; XML does not encode AF number'}|ConvertTo-Json -Depth 6|Set-Content (Join-Path $log 'contracts-check.json') -Encoding utf8
if($ContractsOnly){Write-Output 'Contracts/live parity refreshed without rebuilding either target';return}
$inputs=Get-Content (Join-Path $log 'build-inputs.json') -Raw|ConvertFrom-Json
if($inputs.status -ne 'BUILD_SUCCEEDED' -or $inputs.target -ne 'All'){throw 'Combined host/ARM build required'}
foreach($file in @($inputs.inputs)+@($inputs.artifacts)){if((Get-FileHash $file.Path -Algorithm SHA256).Hash -ne $file.Hash){throw "Build input changed: $($file.Path)"}}
$bin=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'build/smartvio-h743-DIAG.bin'))
$elf=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'build/smartvio-h743-DIAG.elf'))
if($elf[0] -ne 127 -or $elf[4] -ne 1 -or [BitConverter]::ToUInt16($elf,18) -ne 40){throw 'Not ARM ELF32'}
$sp=[BitConverter]::ToUInt32($bin,0);$reset=[BitConverter]::ToUInt32($bin,4)
if($sp -ne 0x20020000 -or $reset -ne [BitConverter]::ToUInt32($elf,24) -or !($reset -band 1)){throw 'Invalid ARM vectors'}
$dis=Get-Content (Join-Path $log 'stm32-disassembly.txt') -Raw
$early=[regex]::Match($dis,'(?ms)^0[0-9a-f]+ <sv_early_safe_gpio>:\r?\n(.*?)(?=\r?\n\r?\n)').Groups[1].Value
$resetCode=[regex]::Match($dis,'(?ms)^0[0-9a-f]+ <Reset_Handler>:\r?\n(.*?)(?=\r?\n\r?\n)').Groups[1].Value
if(!$early -or $early -match '\sblx?\s' -or $early -match '\sb(?:\.[nw])?\s' -or $early -notmatch '\sdsb\s'){throw 'Early primitive contains call/branch or missing barrier'}
if($resetCode.IndexOf('<sv_early_safe_gpio>') -lt 0 -or $resetCode.IndexOf('<sv_early_safe_gpio>') -gt $resetCode.IndexOf('<SystemInit>')){throw 'Early GPIO order wrong'}
$startup=@{status='PASS_STATIC_NOT_HARDWARE';initialStack=('0x{0:X8}' -f $sp);entry=('0x{0:X8}' -f $reset);binaryBytes=$bin.Length;earlyInstructions=@($early -split '\r?\n'|Where-Object {$_ -match '^\s*[0-9a-f]+:' -and $_ -notmatch '\.word'}).Count;earlyBeforeSystemInit=$true;earlyHasLoopsOrCalls=$false;bootEN='00';chargeAllow=0;PE2=0;PC13=0;PE8='input';resetRF=0;idleHSI_Hz=8000000;measuredLatencyMs=$null;killIgnoreMs=512;bootBudgetQualified=$false;hardwareTests=0}
$startup|ConvertTo-Json|Set-Content (Join-Path $log 'startup-check.json') -Encoding utf8
$newSymbols=@('sv_pot_adc_init','DMA2_Stream0_IRQHandler','ADC_IRQHandler','HAL_ADC_Start_DMA','sv_factory_buttons','sv_ui_process','sv_audio_measure')
foreach($symbol in $newSymbols){if($dis -notmatch ('<'+$symbol+'>')){throw "Missing linked native implementation $symbol"}}
$uiContract=Get-Content (Join-Path $PSScriptRoot 'contracts/ui-controls.json') -Raw|ConvertFrom-Json
if($uiContract.applicableNativeSourceSha256 -ne $parity.sourceSha256){throw 'UI applicability hash differs from live source; explicit review required'}
$hostSuites=@(Get-Content (Join-Path $log 'build-all.log')|Where-Object {$_ -match '^\{"groups":'}|ForEach-Object {$_|ConvertFrom-Json})
$diagnostic=Get-Content (Join-Path $log 'build-all.log')|Where-Object {$_ -match '^PASS diagnostics '}
if($diagnostic -notmatch 'groups=(\d+) assertions=(\d+) PCM_operations=(\d+)'){throw 'Missing new diagnostics host results'}
$hostSuites+=@{groups=[int]$Matches[1];assertions=[int]$Matches[2];PCM_operations=[int]$Matches[3];hardware_tests=0}
if($hostSuites.Count -ne 9){throw 'Missing host suites including target safety adapter'}
$safetySuite=@($hostSuites|Where-Object suite -eq 'target_safety_inputs')
if($safetySuite.Count -ne 1 -or $safetySuite[0].groups -lt 12 -or !$safetySuite[0].legacy26msNegativeReproduced){throw 'Missing target safety regressions'}
$safetyContract=Get-Content (Join-Path $PSScriptRoot 'contracts/input-safety.json') -Raw|ConvertFrom-Json
if($safetyContract.applicableNativeSourceSha256 -ne $parity.sourceSha256 -or $safetyContract.applicableTopologySha256 -ne $parity.topologySha256 -or $parity.componentCount -ne 316 -or $parity.pinCount -ne 1081 -or $parity.netCount -ne 220){throw 'Input safety hardware binding stale'}
foreach($entry in @(@{name='EXTI4_IRQHandler';slot=26},@{name='SysTick_Handler';slot=15})){
    $symbol=[regex]::Match($dis,('(?m)^([0-9a-f]+) <'+$entry.name+'>:'))
    if(!$symbol.Success){throw "Missing linked safety ISR $($entry.name)"}
    $address=([Convert]::ToUInt32($symbol.Groups[1].Value,16) -bor 1)
    if([BitConverter]::ToUInt32($bin,4*$entry.slot) -ne $address){throw "Safety vector does not point to linked ISR $($entry.name)"}
}
foreach($symbol in @('sv_safety_inputs_tick','sv_safety_apply_outputs','sv_input_power_edge')){if($dis -notmatch ('<'+$symbol+'>')){throw "Missing safety target path $symbol"}}
$negativeSafety=Get-Content (Join-Path $log 'safety-negative-check.json') -Raw|ConvertFrom-Json
if($negativeSafety.status -ne 'PASS' -or $negativeSafety.cases.Count -ne 5 -or $negativeSafety.sourceSha256 -ne $parity.sourceSha256){throw 'Safety mutation regressions missing/stale'}
foreach($file in $negativeSafety.inputs){if((Get-FileHash $file.Path).Hash -ne $file.Hash){throw 'Safety regression source changed'}}
$safetyReport=[ordered]@{schema='smartvio.input-safety-validation.v26.1';status='HOST_TARGET_ADAPTER_AND_LINKED_ARM_PASS_NOT_PHYSICAL';sourceSha256=$parity.sourceSha256;topologySha256=$parity.topologySha256;hostEvidence=$safetySuite[0];negativeCases=$negativeSafety.cases;linkedVectors=@('EXTI4 IRQ10 slot26','SysTick slot15');sourceHashes=@(@('stm32/main.c','stm32/safety_inputs.c','stm32/safety_inputs.h','sv_input_guard.c','sv_input_guard.h','tests/test_safety_inputs.c','tests/safety_hal_model.h','contracts/input-safety.json')|ForEach-Object {Get-FileHash (Join-Path $PSScriptRoot $_)}|Select-Object Path,Hash);F01='EXTI latch after1000ms startup rejection;2ms level fallback sampled1ms;26ms legacy negative reproduced';F02='Actual target adapter rawLOW PA2 cutoff and finalGPIOcommit recheck;HP30ms stableLOW/SPK50ms stableHIGH;bounce/race/wrap/latched shutdown tests';mainPoweroff='Linked current main propagates latch before commands/power transitions/RF; retained early safe defaults and existing PE2/PC13/PE7 OFF policy';limitations='Host HAL shim is not electrical/NVIC/latency simulation; main poweroff sequencing is source/static evidence, not hardware execution';hardwareTests=0}
$safetyReport|ConvertTo-Json -Depth 9|Set-Content (Join-Path $log 'input-safety-check.json') -Encoding utf8
$uiReport=[ordered]@{schema='smartvio.controls-validation.v26.1';status='HOST_AND_LINKED_ARM_PASS_NOT_PHYSICAL';hardwareTests=0;sourceSha256=$parity.sourceSha256;nativeSymbols=$newSymbols;hostEvidence=@($hostSuites|Where-Object {$_.suite -in @('ui_pot_dma_programming','native_esp_pcm_host_shim')});ADC='OfficialHAL ADC1 CH9/5/11 DMA2Stream0 normal3rank scan; host scheduler/error tests, not an ADC peripheral simulation';programming='5minute physicalnonce exclusive POWER session; host authorization/deadline/sensorabort tests; PC5highZ/PE2power implemented, no actual pad observation';UI='Controls executable under existing factory grants; consumer mode/power authorization remains unapproved';telemetry='DWT/maxcycle/peak/RMSsum counters are runtime observations only. No measured values recorded';ESPHostShim='Actual pcm_rx.c included with no-opRTOS/I2S API substitutes to test buffer and conversion paths; no concurrent scheduler/radio evidence';USB='No enumeration/current/charge authorization; consumption of new ADC scan has not been measured';normalCharging='DISABLED'}
$uiReport|ConvertTo-Json -Depth 7|Set-Content (Join-Path $log 'ui-controls-check.json') -Encoding utf8
$espStatus=Get-Content (Join-Path $log 'esp-native-build.json') -Raw|ConvertFrom-Json
if($espStatus.status -ne 'CROSS_COMPILE_PASS_NOT_HARDWARE_RUN'){throw 'ESP compile failed'}
foreach($file in $espStatus.artifacts){if((Get-FileHash $file.Path -Algorithm SHA256).Hash -ne $file.Hash){throw 'ESP artifact hash changed'}}
foreach($file in $espStatus.inputs){if((Get-FileHash $file.Path -Algorithm SHA256).Hash -ne $file.Hash){throw 'ESP source hash changed'}}
$espElfPath=Join-Path $work 'eb/smartvio_rf_diag.elf'
$espElf=[IO.File]::ReadAllBytes($espElfPath)
if($espElf[0] -ne 127 -or $espElf[4] -ne 1 -or [BitConverter]::ToUInt16($espElf,18) -ne 94){throw 'Not Xtensa ELF32'}
$armBin=Join-Path $root 'work/v25/firmware/tools/bin'
$armSize=& (Join-Path $armBin 'arm-none-eabi-size.exe') (Join-Path $PSScriptRoot 'build/smartvio-h743-DIAG.elf')
$espSize=& (Join-Path $work 'xt/bin/xtensa-esp32-elf-size.exe') $espElfPath
if($LASTEXITCODE -ne 0){throw 'ELF size failed'}
$summary=[ordered]@{schema='smartvio.firmware.v26.validation';status='CROSS_COMPILED_DIAGNOSTIC_NOT_HARDWARE_QUALIFIED';freezeScope='CANDIDATE_CONTRACT_ONLY';productionFreezePermitted=$false;hardwareTests=0;hostSuites=$hostSuites;hostGroups=($hostSuites.groups|Measure-Object -Sum).Sum;hostAssertions=($hostSuites.assertions|Measure-Object -Sum).Sum;armCrossCompile='PASS_ELF32_ARM';armSizeRaw=$armSize;armBinaryBytes=$bin.Length;armArtifact='build/smartvio-h743-DIAG.elf';espCrossCompile='PASS_ELF32_XTENSA_SINGLE_CORE';espSizeRaw=$espSize;espBinaryBytes=(Get-Item (Join-Path $work 'eb/smartvio_rf_diag.bin')).Length;espArtifact='work/v26/firmware/eb/smartvio_rf_diag.elf';armHardwareExecuted=$false;espHardwareExecuted=$false;liveV26Parity=$parity.status;nativeSourceSha256=$parity.sourceSha256;nativeTopologySha256=$parity.topologySha256;nativeCounts=@{parts=$parity.componentCount;pins=$parity.pinCount;nets=$parity.netCount};startup=$startup;unimplementedDrivers='contracts/driver-status.json';builtAtUtc=$inputs.builtAtUtc;verifiedAtUtc=[DateTime]::UtcNow.ToString('o')}
$summary|ConvertTo-Json -Depth 8|Set-Content (Join-Path $log 'build-status.json') -Encoding utf8
$summary|ConvertTo-Json -Depth 8|Set-Content (Join-Path $log 'v26-implementation-status.json') -Encoding utf8
$freeze=@{schema='smartvio.firmware.freeze-scope.v26';status='CANDIDATE_CONTRACT_ONLY';productionFreezePermitted=$false;firmwareReleasePermitted=$false;hardwareTests=0;nativeSourceSha256=$parity.sourceSha256;nativeTopologySha256=$parity.topologySha256;contracts=@(Get-ChildItem (Join-Path $PSScriptRoot 'contracts') -Filter '*.json'|Get-FileHash|Select-Object Path,Hash);meaning='Source contracts and cross-compiled factory diagnostics only, not measured runtime, electrical/PCB qualification or production firmware'}
$freeze|ConvertTo-Json -Depth 6|Set-Content (Join-Path $log 'freeze-scope.json') -Encoding utf8
Write-Output "PASS hostGroups=$($summary.hostGroups) assertions=$($summary.hostAssertions) ARM=$($bin.Length)B ESP=$($summary.espBinaryBytes)B hardware=0"
Write-Output $armSize
Write-Output $espSize
