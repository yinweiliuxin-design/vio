#ifndef SV_SPEAKER_H
#define SV_SPEAKER_H
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
typedef struct {float state[4];} sv_speaker;
void sv_speaker_reset(sv_speaker *);
int32_t sv_speaker_peak_cap(uint32_t sys_upper_mv);
bool sv_speaker_process(sv_speaker *,float *mono,uint32_t *stereo,size_t frames,uint32_t sys_upper_mv);
#endif
