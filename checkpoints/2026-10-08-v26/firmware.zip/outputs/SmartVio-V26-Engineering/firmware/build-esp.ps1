param([switch]$Rebuild)
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'build-esp-v26.ps1') -Rebuild:$Rebuild
