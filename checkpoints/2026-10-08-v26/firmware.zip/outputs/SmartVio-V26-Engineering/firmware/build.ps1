param([ValidateSet('Host','Arm','All')][string]$Target='All')
$ErrorActionPreference='Stop'
$workspace=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$work=Join-Path $workspace 'work/v26/firmware'
if($env:SV_BUILD_WORK){$work=[IO.Path]::GetFullPath($env:SV_BUILD_WORK)}
$vendor=Join-Path $work 'vendor'
if(Test-Path (Join-Path $PSScriptRoot 'vendor/st/stm32h743xx.h')){$vendor=Join-Path $PSScriptRoot 'vendor'}
if($env:SV_VENDOR_DIR){$vendor=[IO.Path]::GetFullPath($env:SV_VENDOR_DIR)}
if(!(Test-Path $work) -and !$env:SV_BUILD_WORK){$work=Join-Path $PSScriptRoot 'build-local'}
$logs=Join-Path $PSScriptRoot 'verification'
New-Item -ItemType Directory -Force $logs,(Join-Path $work 'build') | Out-Null
[ordered]@{status='DIAGNOSTIC_BUILD_PENDING';target=$Target;productionFreezePermitted=$false;hardwareTests=0} | ConvertTo-Json | Set-Content (Join-Path $logs 'build-status.json') -Encoding utf8
function Invoke-Checked([string]$exe,[string[]]$arguments){
    Write-Output ('COMMAND '+$exe+' '+($arguments -join ' '))
    & $exe @arguments 2>&1 | ForEach-Object {Write-Host ([string]$_)}
    $code=$LASTEXITCODE
    Write-Output "EXIT_CODE $code"
    if($code -ne 0){throw "Command failed: $exe"}
}
Start-Transcript -Path (Join-Path $logs ('build-'+$Target.ToLowerInvariant()+'.log'))
try {
    $dsp=Join-Path $vendor 'cmsis-dsp-1.16.2'
    $sources=@('sv_control.c','sv_telemetry.c','sv_foundation.c','sv_radio_core.c','sv_factory.c','sv_pcm1864.c','sv_speaker.c','sv_ui.c','sv_audio_meter.c','sv_input_guard.c') | ForEach-Object {Join-Path $PSScriptRoot $_}
    $sources+=@('arm_biquad_cascade_df1_f32.c','arm_biquad_cascade_df1_init_f32.c') | ForEach-Object {Join-Path $dsp ('Source/FilteringFunctions/'+$_)}
    if($Target -eq 'Host' -or $Target -eq 'All'){
        $tcc=Join-Path $workspace 'work/v22/tools/tinycc/tcc/tcc.exe'
        if($env:TCC){$tcc=$env:TCC}elseif(!(Test-Path $tcc)){$tcc=(Get-Command tcc.exe -ErrorAction Stop).Source}
        Invoke-Checked $tcc @('-v')
        foreach($test in @('legacy_telemetry','test_foundation','test_radio_core','test_diagnostics','test_audio_contract','test_ui')){
            $exe=Join-Path $work ('build/'+$test+'-HOST-ONLY.exe')
            Invoke-Checked $tcc (@('-std=c11','-Wall','-Werror','-D__GNUC__=9','-D__GNUC_PYTHON__',('-I'+$PSScriptRoot),('-I'+(Join-Path $dsp 'Include')))+$sources+@((Join-Path $PSScriptRoot ('tests/'+$test+'.c')),'-o',$exe))
            Invoke-Checked $exe @()
        }
        & (Join-Path $PSScriptRoot 'generate-i2c-test-header.ps1') -Official (Join-Path $vendor 'st/stm32h743xx.h') -OutputDirectory (Join-Path $work 'build')
        $exe=Join-Path $work 'build/test_i2c_probe-HOST-ONLY.exe'
        Invoke-Checked $tcc @('-std=c11','-Wall','-Werror','-DSV_I2C_REGISTER_MODEL',('-I'+$PSScriptRoot),('-I'+(Join-Path $work 'build')),(Join-Path $PSScriptRoot 'stm32/i2c_probe.c'),(Join-Path $PSScriptRoot 'tests/test_i2c_probe.c'),'-o',$exe)
        Invoke-Checked $exe @()
        $exe=Join-Path $work 'build/test_esp_pcm-HOST-ONLY.exe'
        Invoke-Checked $tcc @('-std=c11','-Wall','-Werror',('-I'+$PSScriptRoot),('-I'+(Join-Path $PSScriptRoot 'tests/esp_model')),(Join-Path $PSScriptRoot 'tests/test_esp_pcm.c'),'-o',$exe)
        Invoke-Checked $exe @()
        $exe=Join-Path $work 'build/test_safety_inputs-HOST-ONLY.exe'
        Invoke-Checked $tcc @('-std=c11','-Wall','-Werror','-DSV_SAFETY_REGISTER_MODEL',('-I'+$PSScriptRoot),('-I'+(Join-Path $PSScriptRoot 'stm32')),('-I'+(Join-Path $PSScriptRoot 'tests')),('-I'+(Join-Path $work 'build')),(Join-Path $PSScriptRoot 'sv_input_guard.c'),(Join-Path $PSScriptRoot 'stm32/safety_inputs.c'),(Join-Path $PSScriptRoot 'tests/test_safety_inputs.c'),'-o',$exe)
        Invoke-Checked $exe @()
    }
    if($Target -eq 'Arm' -or $Target -eq 'All'){
        $gcc=Join-Path $workspace 'work/v25/firmware/tools/bin/arm-none-eabi-gcc.exe'
        if($env:ARM_GCC_BIN){$gcc=Join-Path $env:ARM_GCC_BIN 'arm-none-eabi-gcc.exe'}elseif(!(Test-Path $gcc)){$gcc=(Get-Command arm-none-eabi-gcc.exe -ErrorAction Stop).Source}
        if(!(Test-Path $gcc)){$gcc=$null}
        if(!$gcc){throw 'Official Arm GCC is not available; no MCU binary claimed'}
        $bin=Split-Path $gcc
        Invoke-Checked $gcc @('--version')
        $flags=@('-std=c11','-mcpu=cortex-m7','-mthumb','-mfpu=fpv5-d16','-mfloat-abi=hard','-Os','-g3','-ffunction-sections','-fdata-sections','-fno-common','-Wall','-Wextra','-Werror','-DSTM32H743xx','-DHSE_VALUE=24576000',('-I'+$PSScriptRoot),('-I'+(Join-Path $vendor 'st')),('-I'+(Join-Path $vendor 'cmsis')))
        $hal=Join-Path $vendor 'stm32h7xx-hal-driver-1.11.4'
        $flags+=@('-DUSE_HAL_DRIVER',('-I'+(Join-Path $PSScriptRoot 'stm32')),('-I'+(Join-Path $hal 'Inc')),('-I'+(Join-Path $dsp 'Include')))
        $all=$sources+@((Join-Path $PSScriptRoot 'stm32/main.c'),(Join-Path $PSScriptRoot 'stm32/i2c_probe.c'),(Join-Path $PSScriptRoot 'stm32/audio_hw.c'),(Join-Path $PSScriptRoot 'stm32/fault_store.c'),(Join-Path $PSScriptRoot 'stm32/syscalls.c'),(Join-Path $vendor 'st/system_stm32h7xx.c'),(Join-Path $PSScriptRoot 'stm32/startup_stm32h743xx.s'))
        $all+=Join-Path $PSScriptRoot 'stm32/pot_adc.c'
        $all+=Join-Path $PSScriptRoot 'stm32/safety_inputs.c'
        $all+=@('hal','hal_rcc','hal_rcc_ex','hal_gpio','hal_dma','hal_dma_ex','hal_sai','hal_sai_ex','hal_cortex','hal_pwr','hal_pwr_ex','hal_flash','hal_flash_ex','hal_iwdg','hal_adc','hal_adc_ex') | ForEach-Object {Join-Path $hal ('Src/stm32h7xx_'+$_+'.c')}
        $objects=@()
        foreach($src in $all){
            $obj=Join-Path $work ('build/'+[IO.Path]::GetFileNameWithoutExtension($src)+'.o')
            Invoke-Checked $gcc ($flags+@('-c',$src,'-o',$obj));$objects+=$obj
        }
        $out=Join-Path $PSScriptRoot 'build'
        New-Item -ItemType Directory -Force $out | Out-Null
        $elf=Join-Path $out 'smartvio-h743-DIAG.elf'
        Invoke-Checked $gcc ($flags+@('-nostartfiles','--specs=nano.specs','--specs=nosys.specs',('-T'+(Join-Path $PSScriptRoot 'stm32/stm32h743vi.ld')),'-Wl,--gc-sections',('-Wl,-Map='+(Join-Path $out 'smartvio-h743-DIAG.map')))+$objects+@('-Wl,--start-group','-lc','-lm','-lgcc','-Wl,--end-group','-o',$elf))
        Invoke-Checked (Join-Path $bin 'arm-none-eabi-objcopy.exe') @('-O','ihex',$elf,(Join-Path $out 'smartvio-h743-DIAG.hex'))
        Invoke-Checked (Join-Path $bin 'arm-none-eabi-objcopy.exe') @('-O','binary',$elf,(Join-Path $out 'smartvio-h743-DIAG.bin'))
        Invoke-Checked (Join-Path $bin 'arm-none-eabi-size.exe') @($elf)
        Invoke-Checked (Join-Path $bin 'arm-none-eabi-readelf.exe') @('-h','-A',$elf)
        & (Join-Path $bin 'arm-none-eabi-objdump.exe') '-d' $elf | Set-Content -Encoding utf8 (Join-Path $logs 'stm32-disassembly.txt')
        if($LASTEXITCODE -ne 0){throw 'Disassembly failed'}
        Get-ChildItem $out -File | Get-FileHash -Algorithm SHA256 | Format-Table -AutoSize
        $inputs=@($all)+@(Get-ChildItem $PSScriptRoot -Filter '*.h' -File | Select-Object -ExpandProperty FullName)+
            @(Get-ChildItem (Join-Path $PSScriptRoot 'stm32') -Filter '*.h' -File | Select-Object -ExpandProperty FullName)+@((Join-Path $PSScriptRoot 'stm32/stm32h743vi.ld'),$PSCommandPath)+
            @(Get-ChildItem (Join-Path $dsp 'Include') -Recurse -Filter '*.h' -File | Select-Object -ExpandProperty FullName)+
            @(Get-ChildItem (Join-Path $vendor 'st'),(Join-Path $vendor 'cmsis'),(Join-Path $hal 'Inc') -Recurse -Filter '*.h' -File | Select-Object -ExpandProperty FullName)+
            @(Get-ChildItem (Join-Path $PSScriptRoot 'tests') -Filter '*.c' -File | Select-Object -ExpandProperty FullName)
        $inputs+=@(Get-ChildItem (Join-Path $PSScriptRoot 'tests/esp_model') -Recurse -Filter '*.h' -File|Select-Object -ExpandProperty FullName)+@((Join-Path $PSScriptRoot 'esp32/main/pcm_rx.c'),(Join-Path $PSScriptRoot 'esp32/main/pcm_rx.h'))
        $inputs+=Join-Path $PSScriptRoot 'tests/safety_hal_model.h'
        if($Target -eq 'All'){$inputs+=@((Join-Path $PSScriptRoot 'generate-i2c-test-header.ps1'),(Join-Path $work 'build/i2c-model-device.h'))}
        [ordered]@{status='BUILD_SUCCEEDED';target=$Target;builtAtUtc=[DateTime]::UtcNow.ToString('o');inputs=@($inputs | Sort-Object -Unique | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash);artifacts=@(Get-ChildItem $out -File -Filter '*DIAG*' | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash)} | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $logs 'build-inputs.json') -Encoding utf8
    }
}finally{Stop-Transcript}
