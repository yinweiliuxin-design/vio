#include "sv_foundation.h"
#include <string.h>

static uint32_t age(uint32_t now,uint32_t then){return now-then;}
static const int16_t sine48[48]={
    0,4277,8481,12539,16384,19948,23170,25996,28377,30273,31650,32487,
    32767,32487,31650,30273,28377,25996,23170,19948,16384,12539,8481,4277,
    0,-4277,-8481,-12539,-16384,-19948,-23170,-25996,-28377,-30273,-31650,-32487,
    -32767,-32487,-31650,-30273,-28377,-25996,-23170,-19948,-16384,-12539,-8481,-4277
};
bool sv_audio_set_test(sv_audio *a,sv_audio_mode mode,bool local){
    if(!a)return false;
    a->mode=SV_AUDIO_SILENT;a->phase=0;
    if(mode==SV_AUDIO_SILENT)return true;
    if(!local || (mode!=SV_AUDIO_TONE && mode!=SV_AUDIO_LOOPBACK))return false;
    a->mode=mode;return true;
}
bool sv_audio_process(sv_audio *a,const int16_t *in,int16_t *out,size_t frames,bool allowed){
    if(!a || !out || frames>SV_AUDIO_FRAMES_MAX)return false;
    if(!allowed || a->mode==SV_AUDIO_SILENT){memset(out,0,frames*2*sizeof(*out));return true;}
    if(a->mode==SV_AUDIO_LOOPBACK && !in){memset(out,0,frames*2*sizeof(*out));return false;}
    for(size_t n=0;n<frames;n++){
        if(a->mode==SV_AUDIO_TONE){
            out[n*2]=out[n*2+1]=(int16_t)(sine48[a->phase]/16);
            a->phase=(uint8_t)((a->phase+1)%48);
        }else if(a->mode==SV_AUDIO_LOOPBACK){
            out[n*2]=(int16_t)(in[n*2]/8);out[n*2+1]=(int16_t)(in[n*2+1]/8);
        }else {memset(out,0,frames*2*sizeof(*out));return false;}
    }
    return true;
}
bool sv_audio_speaker_left(const int16_t *in,int16_t *out,size_t frames,uint16_t gain,bool qualified){
    if(!out || frames>SV_AUDIO_FRAMES_MAX)return false;
    if(in && frames){
        uintptr_t a=(uintptr_t)in,b=(uintptr_t)out;
        bool overlap=a<=b?b-a<frames*sizeof(*in):a-b<frames*2*sizeof(*out);
        /* Never mute into an overlapping buffer: that would alter HP/LINE data. */
        if(overlap)return false;
    }
    if(!in || !qualified || gain>32768){memset(out,0,frames*2*sizeof(*out));return false;}
    /* Independent SPK stream, absolute0.40FS cap including DC and square waves.
     * No approved speaker impedance/rating is implied. Buffers must not overlap. */
    for(size_t n=0;n<frames;n++){
        int32_t value=((int32_t)in[n]*gain)/32768;
        if(value>SV_SPEAKER_PEAK_I16)value=SV_SPEAKER_PEAK_I16;
        if(value< -SV_SPEAKER_PEAK_I16)value= -SV_SPEAKER_PEAK_I16;
        out[2*n]=(int16_t)value;out[2*n+1]=0;
    }
    return true;
}
void sv_bt_init(sv_bt *b,sv_bt_hal hal,uint32_t now){
    memset(b,0,sizeof(*b));b->hal=hal;b->last_tick=now;
    if(hal.discoverable && hal.disconnect){
        b->state=hal.discoverable(hal.ctx,false,20)?SV_BT_IDLE:SV_BT_FAULT;
    }
}
void sv_bt_disconnect(sv_bt *b){
    b->authenticated=false;b->generation++;
    bool hidden=b->hal.discoverable && b->hal.discoverable(b->hal.ctx,false,20);
    bool stopped=b->hal.disconnect && b->hal.disconnect(b->hal.ctx,20);
    b->state=hidden && stopped?SV_BT_IDLE:SV_BT_FAULT;
}
bool sv_bt_pair_local(sv_bt *b,bool physical,uint32_t now){
    if(!physical || b->state!=SV_BT_IDLE || age(now,b->last_tick)>100)return false;
    if(!b->hal.discoverable || !b->hal.discoverable(b->hal.ctx,true,20)){
        sv_bt_disconnect(b);b->state=SV_BT_FAULT;return false;
    }
    b->pairing_at=now;b->state=SV_BT_PAIRING;return true;
}
void sv_bt_tick(sv_bt *b,uint32_t now){
    uint32_t dt=age(now,b->last_tick);b->last_tick=now;
    if(b->state==SV_BT_OFF || b->state==SV_BT_FAULT)return;
    if(dt>100){sv_bt_disconnect(b);b->state=SV_BT_FAULT;return;}
    if(b->state==SV_BT_PAIRING && age(now,b->pairing_at)>=60000)sv_bt_disconnect(b);
}
bool sv_bt_authenticated_event(sv_bt *b,bool verified,uint32_t now){
    if(!verified || b->state!=SV_BT_PAIRING || age(now,b->pairing_at)>=60000 || age(now,b->last_tick)>100){
        sv_bt_disconnect(b);return false;
    }
    if(!b->hal.discoverable || !b->hal.discoverable(b->hal.ctx,false,20)){
        sv_bt_disconnect(b);b->state=SV_BT_FAULT;return false;
    }
    b->authenticated=true;b->state=SV_BT_CONNECTED;b->generation++;return true;
}
void sv_bt_disconnected_event(sv_bt *b){sv_bt_disconnect(b);}

void sv_selftest_init(sv_selftest *s,uint32_t now){
    memset(s,0,sizeof(*s));s->started_at=now;s->pending=31;
    /* Algorithm known-answer check; does not claim a RAM/flash or board test. */
    if(sv_crc16((const uint8_t*)"123456789",9)==0x29b1)s->passed|=SV_ST_CORE;
    else s->failed|=SV_ST_CORE;
}
void sv_selftest_tick(sv_selftest *s,uint32_t now,const sv_inputs *i,bool sensor){
    uint32_t pass=s->passed&SV_ST_CORE;
    if(i->power_good)pass|=SV_ST_POWER;
    if(i->clocks_good)pass|=SV_ST_CLOCKS;
    if(sensor)pass|=SV_ST_SENSOR;
    if(i->codec_ready)pass|=SV_ST_AUDIO;
    s->passed=pass;s->pending=31u&~pass;
    if(age(now,s->started_at)>=3000)s->failed|=s->pending;
}
bool sv_selftest_passed(const sv_selftest *s){return s->passed==31 && !s->failed;}

static void commit(sv_runtime *r){
    /* This is the only owner permitted to write board outputs. */
    sv_guard_apply(&r->charge,&r->control,r->now,r->control.input.usb_present);
    if(!r->board_failed && r->board.apply && r->board.fail_off &&
       r->board.apply(r->board.ctx,&r->control.out))return;
    r->board_failed=true;
    sv_tick(&r->control,r->now,NULL);
    r->charge.locked=true;
    if(r->board.fail_off)r->board.fail_off(r->board.ctx);
}
void sv_runtime_init(sv_runtime *r,uint32_t now,const sv_config *cfg,
                     sv_board_hal board,sv_mon_bus mon,const sv_mon_cal *cal,sv_bt_hal bt){
    memset(r,0,sizeof(*r));r->now=now;r->board=board;
    sv_init(&r->control,now,cfg);sv_guard_init(&r->charge);sv_parser_reset(&r->parser);
    sv_mon_init(&r->monitor,now,mon,cal);sv_selftest_init(&r->selftest,now);
    if(board.fail_off)board.fail_off(board.ctx);
    sv_bt_init(&r->bt,bt,now);commit(r);
}
void sv_runtime_link_lost(sv_runtime *r){
    sv_session_end(&r->session);sv_parser_reset(&r->parser);
    r->tx_count=0;r->tx_head=0;
    sv_set_routes(&r->control,0);r->control.pair_open=false;
    if(r->bt.state!=SV_BT_OFF)sv_bt_disconnect(&r->bt);
    commit(r);
}
bool sv_runtime_authorize_trusted(sv_runtime *r,uint32_t epoch){
    if(r->board_failed || r->control.state!=SV_READY || !sv_selftest_passed(&r->selftest))return false;
    if(!sv_session_begin_trusted(&r->session,epoch))return false;
    sv_parser_reset(&r->parser);r->session_at=r->now;
    r->session_bt_generation=r->bt.generation;return true;
}
void sv_runtime_tick(sv_runtime *r,uint32_t now){
    r->now=now;r->rx_this_tick=0;
    sv_inputs i={0};bool settled=false;
    bool valid=!r->board_failed && r->board.sample && r->board.sample(r->board.ctx,now,&i,&settled);
    valid=valid && age(now,i.board_evidence_at)<=20;
    sv_mon_tick(&r->monitor,now,settled && valid);
    sv_mon_apply(&r->monitor,now,&i);
    sv_bt_tick(&r->bt,now);i.bluetooth_authenticated=r->bt.authenticated;
    sv_mon_frame frame;
    sv_selftest_tick(&r->selftest,now,&i,sv_mon_snapshot(&r->monitor,now,&frame));
    i.startup_selftest_passed=sv_selftest_passed(&r->selftest);
    sv_tick(&r->control,now,valid?&i:NULL);
    sv_parser_poll(&r->parser,now);
    if(r->control.state!=SV_READY){
        sv_session_end(&r->session);
        if(r->bt.state==SV_BT_PAIRING || r->bt.state==SV_BT_CONNECTED)sv_bt_disconnect(&r->bt);
    }
    /* Local pairing remains possible before any remote session exists. */
    if(r->control.pair_open && r->bt.state==SV_BT_IDLE){
        bool window=sv_take_pair_window(&r->control,now);
        sv_bt_pair_local(&r->bt,window,now);
    }
    if(r->session.authorized && (age(now,r->session_at)>=2000 ||
       r->session_bt_generation!=r->bt.generation))sv_runtime_link_lost(r);
    commit(r);
}
static void reply(sv_runtime *r,const sv_frame *request,sv_result result){
    sv_frame f={0};uint8_t encoded[270];
    f.type=0x80;f.seq=request->seq;f.session_id=request->session_id;f.length=8;
    f.payload[0]=request->type;f.payload[1]=(uint8_t)result;
    f.payload[2]=(uint8_t)r->control.state;f.payload[3]=r->control.out.charge_allow?1:0;
    for(unsigned j=0;j<4;j++)f.payload[4+j]=(uint8_t)(r->control.faults>>(8*j));
    size_t n=sv_frame_encode(&f,encoded,sizeof(encoded));
    if(n>(size_t)(SV_UART_TX_CAPACITY-r->tx_count)){r->replies_dropped++;return;}
    for(size_t j=0;j<n;j++)r->tx[(r->tx_head+r->tx_count++)%SV_UART_TX_CAPACITY]=encoded[j];
}
bool sv_runtime_rx(sv_runtime *r,const uint8_t *data,size_t length){
    if(!data || length>(size_t)(SV_UART_RX_BUDGET-r->rx_this_tick)){
        r->transport_errors++;sv_runtime_link_lost(r);return false;
    }
    r->rx_this_tick=(uint16_t)(r->rx_this_tick+length);
    for(size_t j=0;j<length;j++){
        sv_frame f;
        if(sv_parser_byte(&r->parser,data[j],r->now,&f)){
            if(f.type==0x80)continue;
            sv_result result=sv_execute(&r->control,&r->session,&f,r->now);
            if(result==SV_OK){
                r->session_at=r->now;
                if(f.type==3 && !sv_bt_pair_local(&r->bt,true,r->now))result=SV_NOT_READY;
                if(f.type==6)sv_runtime_link_lost(r);
            }
            commit(r);reply(r,&f,result);
        }
    }
    return true;
}
bool sv_runtime_tx_byte(sv_runtime *r,uint8_t *byte){
    if(!byte || !r->tx_count)return false;
    *byte=r->tx[r->tx_head];r->tx_head=(uint16_t)((r->tx_head+1)%SV_UART_TX_CAPACITY);
    r->tx_count--;return true;
}
