param([Parameter(Mandatory=$true)][string]$Official,[Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
$source=Get-Content $Official -Raw -Encoding utf8
$lines=[Collections.Generic.List[string]]::new()
$lines.Add('/* GENERATED from pinned official ST CMSIS; host RAM, not hardware. */')
$lines.Add('#ifndef SV_I2C_MODEL_DEVICE_H')
$lines.Add('#define SV_I2C_MODEL_DEVICE_H')
$lines.Add('#include <stdint.h>')
$lines.Add('#define __IO volatile')
$lines.Add('#define __I volatile const')
$lines.Add('#define __O volatile')
foreach($type in @('I2C_TypeDef','GPIO_TypeDef','RCC_TypeDef')){
    $match=[regex]::Match($source,('(?s)typedef struct\s*\{(?:(?!typedef struct).)*?\}\s*'+$type+'\s*;'))
    if(!$match.Success){throw "Missing official type $type"}
    $lines.Add($match.Value)
}
foreach($line in $source -split '\r?\n'){if($line -match '^#define\s+(RCC|I2C)_[A-Z0-9_]+\s+'){$lines.Add($line)}}
foreach($line in @('extern I2C_TypeDef sv_fake_i2c;','extern GPIO_TypeDef sv_fake_gpiob;','extern RCC_TypeDef sv_fake_rcc;','#define I2C1 (&sv_fake_i2c)','#define GPIOB (&sv_fake_gpiob)','#define RCC (&sv_fake_rcc)','uint32_t sv_i2c_model_status(void);','#endif')){$lines.Add($line)}
$out=Join-Path $OutputDirectory 'i2c-model-device.h'
$lines|Set-Content $out -Encoding utf8
@{source=$Official;sourceSha256=(Get-FileHash $Official).Hash;outputSha256=(Get-FileHash $out).Hash;hardwareTests=0}|ConvertTo-Json|Set-Content (Join-Path $OutputDirectory 'i2c-model-provenance.json') -Encoding utf8
