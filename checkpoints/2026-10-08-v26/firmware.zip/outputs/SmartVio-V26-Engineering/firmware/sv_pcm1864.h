#ifndef SV_PCM1864_H
#define SV_PCM1864_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {
    void *ctx;
    bool (*read)(void *,uint8_t,uint8_t *);
    bool (*write)(void *,uint8_t,uint8_t);
} sv_codec_bus;
typedef struct {sv_codec_bus bus;uint32_t at,fault;uint8_t phase,index,sub,old;bool ready;} sv_pcm1864;
enum {SV_PCM_BUS=1,SV_PCM_READBACK=2,SV_PCM_TIMEOUT=4,SV_PCM_RESERVED=8};
void sv_pcm_start(sv_pcm1864 *,sv_codec_bus,uint32_t now);
/* One bounded register operation per tick; clocks running, outputs muted. */
void sv_pcm_tick(sv_pcm1864 *,uint32_t now);
bool sv_pcm_status(sv_pcm1864 *);
#endif
