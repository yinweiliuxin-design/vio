#ifndef SV_SAI_CONTRACT_H
#define SV_SAI_CONTRACT_H
#include <stdbool.h>
#include <stdint.h>
/* RM0433 Rev8 51.4.8 and CR1/FRCR/SLOTR; masks cross-checked against
 * the official CMSIS header in audio_hw.c. No MMIO addresses here. */
#define SV_SAI_CR1_MASK 0x0ff83fefu
#define SV_SAI_FRCR_MASK 0x00077fffu
#define SV_SAI_SLOTR_MASK 0xffff0fdfu
#define SV_SAI_FRCR 0x00051f3fu
#define SV_SAI_SLOTR 0x00030180u
static inline uint32_t sv_sai_cr1(unsigned i){
    static const uint8_t modes[4]={1,3,0,2};
    return 0x010822e0u|modes[i&3]|((i&1)?0x400u:0);
}
static inline bool sv_sai_registers_valid(unsigned i,uint32_t cr1,uint32_t frcr,uint32_t slotr,uint32_t kernel){
    if(i>3 || kernel!=49152000u)return false;
    if((cr1&SV_SAI_CR1_MASK)!=sv_sai_cr1(i) || (frcr&SV_SAI_FRCR_MASK)!=SV_SAI_FRCR ||
       (slotr&SV_SAI_SLOTR_MASK)!=SV_SAI_SLOTR)return false;
    /* NOMCK=1: SCK=kernel/MCKDIV, FS=SCK/(FRL+1). Slaves inherit A. */
    return kernel/((cr1>>20)&63u)==3072000u && kernel/(((cr1>>20)&63u)*((frcr&255u)+1u))==48000u;
}
static inline bool sv_audio_stream_ready(uint32_t pairs,uint32_t sent,uint32_t last_rx,uint32_t last_tx,uint32_t now,uint32_t faults,bool registers){
    return registers && !faults && pairs>=4 && sent>=2 && now-last_rx<=50 && now-last_tx<=50;
}
#endif
