#ifndef SV_AUDIO_METER_H
#define SV_AUDIO_METER_H
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef struct {uint32_t blocks,frames,peak[4],fullscale[4];uint64_t square_sum[4];uint32_t window_frames;} sv_audio_meter;
void sv_audio_measure(sv_audio_meter *,const uint32_t *dac,const uint32_t *speaker,size_t frames);
/* DMA circular buffer has256 words, halves128 words; leave32 words margin. */
static inline bool sv_dma_half_free(unsigned half,uint32_t remaining){return half<2 && (half==0?(remaining>32 && remaining<=128):(remaining>160 && remaining<=256));}
static inline bool sv_dma_lost(uint32_t completed,uint32_t consumed){return completed-consumed>1;}
#endif
