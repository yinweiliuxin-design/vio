param([string]$LivePath,[string]$OutputDirectory)
$ErrorActionPreference='Stop'
$PSDefaultParameterValues['Get-Content:Encoding']='utf8'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
if(!$LivePath){$LivePath=Join-Path $root 'outputs/SmartVio-V26-Engineering/electrical/native-components.json'}
if(!$OutputDirectory){$OutputDirectory=Join-Path $PSScriptRoot 'verification'}
New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
$live=Get-Content $LivePath -Raw | ConvertFrom-Json
$baselinePath=Join-Path $root 'outputs/SmartVio-V24-NativeEDA/electrical/native-components.json'
$baseline=Get-Content $baselinePath -Raw | ConvertFrom-Json
$contract=Get-Content (Join-Path $PSScriptRoot 'contracts/pins.json') -Raw | ConvertFrom-Json
[xml]$xml=Get-Content (Join-Path $root 'work/v26/firmware/downloads/STM32H743VITx.xml') -Raw
$ns=New-Object Xml.XmlNamespaceManager($xml.NameTable)
$ns.AddNamespace('s','http://dummy.com')
$checks=[Collections.Generic.List[object]]::new()
$rows=[Collections.Generic.List[object]]::new()
function Check([string]$label,$actual,$expected){
    $checks.Add([ordered]@{check=$label;actual=$actual;expected=$expected;pass=([string]$actual -ceq [string]$expected)})
}
function Pin($parts,[string]$ref,[int]$number){
    @($parts | Where-Object ref -eq $ref | ForEach-Object {$_.pins} | Where-Object {[int]$_.number -eq $number})
}
function Net([string]$ref,[int]$number,[string]$net){
    $p=@(Pin $live $ref $number)
    Check "$ref.$number count" $p.Count 1
    Check "$ref.$number net" $p[0].net $net
}
# Manufacturer module numbering, not the bare ESP32 chip numbering.
$espNames=@('GND','GND','3V3','I36','I37','I38','I39','EN','I34','I35',
    'IO32','IO33','IO25','IO26','IO27','IO14','IO12','IO13','IO15','IO2','IO0','IO4',
    'NC','NC','IO9','IO10','GND','NC','IO5','IO18','IO23','IO19','IO22','IO21','RXD0','TXD0','NC')
$espNames+=@(38..55 | ForEach-Object {'GND'})
foreach($ref in @('U801','U901')){
    $count=if($ref -eq 'U801'){100}else{55}
    $component=@($live | Where-Object ref -eq $ref)
    Check "$ref component count" $component.Count 1
    Check "$ref pin count" @($component[0].pins).Count $count
    foreach($number in 1..$count){
        $p=@(Pin $live $ref $number)
        $b=@(Pin $baseline $ref $number)
        Check "$ref.$number unique pin" $p.Count 1
        Check "$ref.$number baseline pin" $b.Count 1
        $expected=$b[0].net
        if($ref -eq 'U801' -and $number -eq 2){$expected='ADC_DATA2'}
        if($ref -eq 'U801' -and $number -eq 1){$expected='AUDIO_PWR_EN'}
        if($ref -eq 'U801' -and $number -eq 7){$expected='AUDIO_BUS_EN'}
        if($ref -eq 'U901' -and $number -eq 8){$expected='RF_CHIP_EN'}
        if($ref -eq 'U901' -and $number -eq 3){$expected='V3LOAD'}
        Check "$ref.$number V26 net" $p[0].net $expected
        $connected=![string]::IsNullOrEmpty($p[0].net)
        $identity=$null;$category='UNREVIEWED';$disposition='UNREVIEWED';$conditions='';$sources=@()
        if($ref -eq 'U801'){
            $node=$xml.SelectSingleNode("/s:Mcu/s:Pin[@Position='$number']",$ns)
            $identity=$node.GetAttribute('Name')
            $sources=@('ST_XML package pin','ST_DS Figure5/Table9','ST_AN4899 sections6.1/6.6/7.1')
            if($connected){
                if($identity -match '^(P[A-Z][0-9]+)'){
                    $gpio=$Matches[1];$captured=if($p[0].name -match '^(P[A-Z][0-9]+)'){$Matches[1]}else{'UNKNOWN'}
                    Check "$ref.$number manufacturer GPIO identity" $captured $gpio
                }
                $category=if($identity -match '^P[A-Z][0-9]'){'CONNECTED_SIGNAL'}else{'CONNECTED_REQUIRED_SPECIAL'}
                $disposition='NOT_NC';$conditions='Net identity only. Footprint, electrical limits and physical connection not qualified.'
                if($identity -eq 'BOOT0'){$conditions='R803 10k to GND. Boot address/option bytes must be read and confirmed; no option-byte writes authorized.'}
                if($identity -eq 'NRST'){$conditions='R802 10k to V3D, C811 100nF to GND, J801.5. Reset ramp and debugger loading unmeasured.'}
                if($identity -eq 'VCAP'){$conditions='Dedicated regulator capacitor node, never GPIO or external supply; C807/C808 2.2uF to GND. ESR/layout not qualified.'}
                if($identity -match '^(VDD|VSS|VDDA|VSSA|VBAT|VREF\+)$'){$conditions='Supply/reference/ground connection is mandatory for this design. Net present is not decoupling or power-integrity approval.'}
            }else{
                $category='UNUSED_GPIO';$disposition='CONDITIONAL_NC_NOT_APPROVED';
                $conditions='Unused digital GPIO configured analog/no-pull by V26 DIAG main after early safe output setup. Reset/bootloader/low-power behavior still needs qualification; not a manufacturer NC.'
                if($number -in @(8,9)){
                    $category='UNUSED_LSE_GPIO';$conditions='PC14/15 LSE oscillator functions unused. Keep LSE disabled; qualify GPIO/backup-domain state. No external32k clock is implemented.'
                }elseif($number -in @(17,18)){
                    $category='UNUSED_ANALOG_C_PAD';$conditions='PC2_C/PC3_C package analog pads, not interchangeable with PC2/PC3 digital pads. Keep analog path unused; analog switch/reset policy not implemented or measured.'
                }elseif($number -in @(77,89,90)){
                    $category='UNUSED_JTAG_TRACE';$conditions='PA15 JTDI/PB3 JTDO-SWO/PB4 NJTRST not required by two-wire SWD. Preserve PA13/14. Debug default pulls and trace configuration require explicit review; no SWO/JTAG execution test.'
                }elseif($number -eq 7){
                    $category='UNUSED_BACKUP_GPIO';$conditions='PC13 backup/tamper-domain GPIO unused; do not accidentally enable RTC/tamper output. Backup/reset/low-power state not qualified.'
                }elseif($number -eq 36){
                    $conditions='PB2 is ordinary GPIO here, NOT BOOT0. Actual BOOT0 is pin94 with R803. HOLD sets PB2 analog/no-pull; reset/bootloader behavior still unqualified.'
                }
                Check "$ref.$number unused identity is GPIO" ($identity -match '^P[A-Z][0-9]') $true
            }
        }else{
            $identity=$espNames[$number-1];$sources=@('ESP_MODULE Table3 pp11-12','ESP_MODULE boot Tables4-9','ESP_GUIDE GPIO checklist')
            if($identity -eq 'NC'){
                $category='MANUFACTURER_NC';$disposition='VERIFIED_MUST_REMAIN_NC';$conditions='No electrical connection permitted by module Table3.'
                Check "$ref.$number manufacturer NC" $p[0].net ''
            }elseif($connected){
                $category=if($identity -in @('GND','3V3')){'CONNECTED_REQUIRED_SUPPLY'}else{'CONNECTED_SIGNAL'}
                $disposition='NOT_NC';$conditions='Module pad identity/net checked. Native ESP-IDF single-core Xtensa ELF/BIN cross-compiled; no peripheral execution or physical pad check.'
                if($identity -eq 'EN'){
                    $category='CONNECTED_ENABLE_RESET';$conditions='PC5 RF_ENABLE -> R907470R -> RF_CHIP_EN; R90110k down/C9011uF to GND; J902.6 same EN net. Reset RC may need21.7ms to0.6V: enforce>=30ms LOW/reset then>=5ms after HIGH before UART handshake. EN defaults LOW logically; physical voltage/timing and100mA budget unmeasured.'
                }elseif($identity -eq 'IO0'){
                    $category='CONNECTED_BOOT_STRAP';$conditions='R90210k up; J902.5 factory boot pad. HIGH selects SPI boot, LOW with GPIO2LOW download. Do not change eFuses.'
                }
                $captured=($p[0].name -split '_')[0]
                Check "$ref.$number manufacturer identity" $captured $identity
            }elseif($number -in @(4,5,6,7,9,10)){
                $category='UNUSED_INPUT_ONLY';$disposition='HOLD_NO_INTERNAL_BIAS_OR_NATIVE_DRIVER';
                $conditions='GPIO34..39 have no output or internal pulls. Input-disabled reset is not a completed lifetime policy. Establish external bias or verified digital/RTC input-disable policy, noise/leakage and sleep tests; never configure output or claim internal pulldown.'
            }elseif($number -in @(17,19,20,29)){
                $category='UNUSED_BOOT_STRAP';$disposition='CONDITIONAL_NC_DEFAULT_STRAP';
                $conditions=switch($number){
                    17 {'GPIO12/MTDI internal pulldown =>3.3V VDD_SDIO default; do not pull high to1.8V for this flash. Actual eFuse override must be read, not programmed.'}
                    19 {'GPIO15/MTDO internal pullup =>ROM UART prints enabled and default SDIO timing. No external load may override startup sample.'}
                    20 {'GPIO2 internal pulldown: normal SPI boot permits either; ROM download requires LOW. Verify reset sampling and leakage.'}
                    29 {'GPIO5 module Table4 states pullup. Generic ESP checklist reset table currently says pulldown: source inconsistency unresolved for actual revision; default SDIO timing not used. HOLD reset-state confirmation.'}
                }
            }else{
                $category='UNUSED_GPIO';$disposition='CONDITIONAL_NC_NOT_APPROVED';
                $conditions='Not a mandatory boot/power pin; qualify default digital input bias and native ESP unused-pin policy. No built/qualified ESP unused-pin driver exists to enforce it.'
                if($number -in @(25,26)){$conditions='Module pads25/26 are GPIO9/10, NOT the in-package flash wires on ESP32-U4WDH. Module Table3 reserves6/7/8/11/16/17 internally instead. Leave unused; verify exact module variant before any reassignment; no generic WROOM flash mapping.'}
            }
        }
        if($ref -eq 'U801' -and $number -eq 7){$conditions='PC13 AUDIO_BUS_EN low-speed output to TMUX CMOS plus100k pulldown (~33uA), not PE8. Backup-domain output-current/reset constraints apply; not a LED/heavy load. DefaultLOW; physical reset/RTC state not measured.'}
        $rows.Add([ordered]@{ref=$ref;pin=$number;manufacturerName=$identity;nativeName=$p[0].name;v24Net=$b[0].net;v26Net=$p[0].net;connected=$connected;identityReviewed=![string]::IsNullOrEmpty($identity);category=$category;ncDisposition=$disposition;conditions=$conditions;sources=$sources;physicalQualification='NOT_TESTED_NOT_APPROVED'})
    }
}
# Check active firmware signals independently of inherited V24 nets.
foreach($p in $contract.stm32.signals){Net 'U801' $p.pin $p.net}
foreach($p in $contract.esp32.signals){Net 'U901' $p.pin $p.net}
$ui=Get-Content (Join-Path $PSScriptRoot 'contracts/ui-controls.json') -Raw|ConvertFrom-Json
foreach($p in $ui.pots){Net 'U801' $p.pin ($p.name+'_ADC')}
foreach($p in $ui.buttons){Net 'U801' $p.pin ('KEY_'+$p.name)}
Net 'U1301' 5 'KEY_PWR'
Net 'U1301' 2 'PWR_PB'
foreach($entry in @(
    @('U601',21,'ADC_DATA2_SRC'),@('R691',1,'ADC_DATA2_SRC'),@('R691',2,'ADC_DATA2'),@('U801',2,'ADC_DATA2'),
    @('U601',18,'ADC_DATA'),@('U601',16,'ADC_FS'),@('U601',17,'ADC_BCK'),@('U601',15,'ADC_SCK'),
    @('R810',1,'ADC_FS_SRC'),@('R810',2,'ADC_FS'),@('R811',1,'ADC_BCK_SRC'),@('R811',2,'ADC_BCK'),@('R812',1,'ADC_SCK_SRC'),@('R812',2,'ADC_SCK'),
    @('U1701',4,'MON_USB_ADC'),@('U1701',5,'MON_BAT_ADC'),@('U1701',6,'MON_SYS_ADC'),@('U1701',7,'MON_ICHG_ADC'),
    @('U501',4,'CHARGE_DISABLE'),@('R503',1,'SYS'),@('R503',2,'CHARGE_DISABLE'),
    @('Q1601',1,'CHARGE_GATE'),@('Q1601',2,'GND'),@('Q1601',3,'CHARGE_DISABLE'),
    @('R1601',1,'CHARGE_ALLOW'),@('R1601',2,'CHARGE_GATE'),@('R1602',1,'CHARGE_GATE'),@('R1602',2,'GND'),
    @('J801',1,'V3D'),@('J801',2,'SWDIO'),@('J801',3,'GND'),@('J801',4,'SWCLK'),@('J801',5,'NRST'),
    @('R803',1,'BOOT0'),@('R803',2,'GND'),@('R802',1,'NRST'),@('R802',2,'V3D'),@('C811',1,'NRST'),@('C811',2,'GND'),
    @('C807',1,'VCAP1'),@('C807',2,'GND'),@('C808',1,'VCAP2'),@('C808',2,'GND'),
    @('R901',1,'RF_CHIP_EN'),@('R901',2,'GND'),@('C901',1,'RF_CHIP_EN'),@('C901',2,'GND'),@('R907',1,'RF_ENABLE'),@('R907',2,'RF_CHIP_EN'),@('J902',6,'RF_CHIP_EN'),@('R902',1,'RF_BOOT'),@('R902',2,'V3LOAD'),@('J902',1,'V3LOAD'),
    @('U1901',1,'V3D'),@('U1901',3,'AUDIO_PWR_EN'),@('U1901',6,'V3LOAD'),
    @('U1902',1,'AUDIO_BUS_EN'),@('U1902',4,'AUDIO_BUS_EN'),@('U1902',2,'I2C_SDA'),@('U1902',3,'I2C_AUDIO_SDA'),@('U1902',5,'I2C_SCL'),@('U1902',6,'I2C_AUDIO_SCL'),
    @('U1921',1,'CHARGE_GATE'),@('U1921',6,'CHARGE_GATE'),@('U1921',5,'SYS'),
    @('U601',23,'I2C_AUDIO_SDA'),@('U601',24,'I2C_AUDIO_SCL'),@('J301',5,'HP_DETECT_RAW'),@('J301',6,'GND'),
    @('U1501',8,'USB_VREF'),@('U1501',6,'USB_OVP_MODE'),@('C1502',1,'USB_VREF'),@('C1502',2,'GND'),@('R1501',1,'USB_OVP_MODE'),@('R1501',2,'GND'),@('R1504',1,'USB_VREF'),@('R1504',2,'USB_OVP_MODE')
)){Net $entry[0] $entry[1] $entry[2]}
Check 'R691 value' ($live | Where-Object ref -eq 'R691').value '33R initial'
Check 'R907 value' ($live | Where-Object ref -eq 'R907').value '470R'
Check 'U1501 VREF is power_out' (Pin $live 'U1501' 8)[0].electricalType 'power_out'
Check 'R1504 value' ($live | Where-Object ref -eq 'R1504').value '140k 1%'
Check 'R1501 value' ($live | Where-Object ref -eq 'R1501').value '24.9k 1%'
Check 'U901 supply pin3' (Pin $live 'U901' 3)[0].net 'V3LOAD'
Check 'R1601 value' ($live | Where-Object ref -eq 'R1601').value '4.7k 1%'
Check 'U801 pin7 GPIO corrected PC13' (Pin $live 'U801' 7)[0].name 'PC13_AUDIO_BUS_EN'
$jack=$live | Where-Object ref -eq 'J301'
Check 'Kycon NO switch' $jack.detectionSwitch.type 'isolated_normally_open_make_contact'
Check 'Kycon insertedLOW' $jack.detectionSwitch.plannedGpioWithExistingPullup.inserted 0
Check 'Kycon unpluggedHIGH' $jack.detectionSwitch.plannedGpioWithExistingPullup.unplugged 1
$audioPath=Join-Path $root 'outputs/SmartVio-V26-Engineering/audit/audio/pcm1864-dual-dout-contract.json'
$audio=Get-Content $audioPath -Raw | ConvertFrom-Json
$ours=Get-Content (Join-Path $PSScriptRoot 'contracts/adc-dual-i2s.json') -Raw | ConvertFrom-Json
foreach($reg in $ours.pcm1864Intent.page0){
    $a=@($audio.page0RegisterIntent | Where-Object address -eq $reg.address)
    Check "PCM $($reg.address) mask" $a[0].mask $reg.mask
    Check "PCM $($reg.address) value" $a[0].value $reg.value
}
Check 'audio final evidence hash' (Get-FileHash $audioPath -Algorithm SHA256).Hash $ours.hardwareIntent.audioOwnerContractSha256
Check 'audio sample frequency' $audio.serial.sampleRateHz $ours.frame.sampleHz
Check 'audio BCLK frequency' $audio.serial.BCLK_Hz $ours.frame.bclkHz
Check 'audio SCK frequency' $audio.serial.SCKI_Hz $ours.frame.sckiHz
Check 'audio lane count' $audio.serial.dataLanes $ours.frame.lanes
Check 'audio frame bits' $audio.serial.bitsPerFramePerLane $ours.frame.frameLengthBitsPerLane
Check 'audio mixer unity entries' (($audio.mixer.unityEntries | ForEach-Object {$_.address}) -join ',') ($ours.pcm1864Intent.digitalMixer.unityVirtualAddresses -join ',')
$topology=@($live | Sort-Object ref | ForEach-Object {
    [ordered]@{ref=$_.ref;pins=@($_.pins | Sort-Object {[string]$_.number} | ForEach-Object {
        [ordered]@{number=[string]$_.number;net=[string]$_.net}
    })}
})
$topologyBytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $topology -Depth 6 -Compress))
$sha=[Security.Cryptography.SHA256]::Create()
try{$topologyHash=([BitConverter]::ToString($sha.ComputeHash($topologyBytes))).Replace('-','')}finally{$sha.Dispose()}
$allPins=@($live | ForEach-Object {$_.pins})
$netCount=@($allPins | Where-Object net | Select-Object -ExpandProperty net -Unique).Count
$revisionPath=Join-Path $root 'outputs/SmartVio-V26-Engineering/audit/system-v26/native-revision.json'
$revision=Get-Content $revisionPath -Raw | ConvertFrom-Json
Check 'V26 parent revision component count' @($live).Count $revision.parts
Check 'V26 parent revision exposed netlist pin count' $allPins.Count $revision.pins
$failures=@($checks | Where-Object {!$_.pass})
$hash=(Get-FileHash $LivePath -Algorithm SHA256).Hash
$status=if($failures.Count){'FAIL_LIVE_V26_MISMATCH'}else{'PASS_LOGICAL_NET_PARITY_ONLY'}
$parity=[ordered]@{status=$status;source=$LivePath;sourceSha256=$hash;baseline=$baselinePath;baselineSha256=(Get-FileHash $baselinePath -Algorithm SHA256).Hash;componentCount=@($live).Count;pinCount=$allPins.Count;netCount=$netCount;topologySha256=$topologyHash;topologyHashMeaning='Sorted full component ref/pin-number/net triples only, excludes MPN/value/name/electricalType metadata. Fingerprint is not a topology correctness audit.';checks=$checks.ToArray();failedChecks=$failures;allPinCounts=@{U801=100;U901=55};hardwareTests=0;meaning='V26 live net comparison is independent of original V24 baseline PASS. Not ERC, PCB routing, footprint or electrical approval.'}
$parity | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $OutputDirectory 'live-net-parity.json') -Encoding utf8
$coverage=foreach($ref in @('U801','U901')){
    $items=@($rows | Where-Object ref -eq $ref)
    [ordered]@{ref=$ref;total=$items.Count;identityReviewed=@($items | Where-Object identityReviewed).Count;identityUnreviewed=@($items | Where-Object {!$_.identityReviewed}).Count;connected=@($items | Where-Object connected).Count;unconnected=@($items | Where-Object {!$_.connected}).Count;manufacturerNc=@($items | Where-Object category -eq 'MANUFACTURER_NC').Count;physicalQualificationUnreviewed=$items.Count;categories=@($items | Group-Object -Property {$_.category} | Select-Object Name,Count)}
}
$audit=[ordered]@{status='IDENTITIES_REVIEWED_NC_CONDITIONAL_HARDWARE_HOLD';liveParity=$status;source=$LivePath;sourceSha256=$hash;coverage=$coverage;records=$rows.ToArray();sources=@{
    ST_XML='https://raw.githubusercontent.com/STMicroelectronics/STM32_open_pin_data/master/mcu/STM32H743VITx.xml';ST_DS='https://www.st.com/resource/en/datasheet/stm32h743vi.pdf';
    ST_AN4899='https://www.st.com/resource/en/application_note/an4899-stm32-microcontroller-gpio-configuration-for-hardware-settings-and-lowpower-consumption-stmicroelectronics.pdf';
    ESP_MODULE='https://documentation.espressif.com/esp32-mini-1_datasheet_en.pdf';ESP_GUIDE='https://docs.espressif.com/projects/esp-hardware-design-guidelines/en/latest/esp32/schematic-checklist.html'};
    flash='STM32 internal flash requires no external GPIO flash bus. ESP32-U4WDH internal flash GPIO6/7/8/11/16/17 are not general module pads;55-pad audit is the complete MODULE exposed interface, not a silicon die-pad audit.';
    blockers=@('No measured boot/reset/rail/pin behavior','Unused GPIO low-power and reset policy not qualified','ESP input-only six pads need input-disable/bias decision','GPIO5 reset pull discrepancy in manufacturer documents','RF reset discharge and5ms rise wait unmeasured','ESP cross-compiled, never executed on hardware','No physical footprint/pad validation by firmware worker');hardwareTests=0}
$audit | ConvertTo-Json -Depth 9 | Set-Content (Join-Path $OutputDirectory 'unused-pin-audit.json') -Encoding utf8
Write-Output "LIVE_V26 $status checks=$($checks.Count) failures=$($failures.Count) U801=100 U901=55 sourceSha256=$hash"
$coverage | ConvertTo-Json -Depth 5 | Write-Output
if($failures.Count){$failures | ConvertTo-Json | Write-Output;throw 'Live V26 pin/net parity failed; do not use baseline PASS as substitute'}
