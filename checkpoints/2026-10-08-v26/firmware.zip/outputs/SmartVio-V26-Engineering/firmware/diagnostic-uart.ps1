param([ValidateSet('Vectors','Probe')][string]$Mode='Vectors',[string]$Port)
$ErrorActionPreference='Stop'
function Crc([byte[]]$data){
    [uint32]$crc=65535
    foreach($b in $data){$crc=$crc -bxor ([uint32]$b -shl 8)
        for($j=0;$j -lt 8;$j++){$crc=if($crc -band 32768){(($crc -shl 1) -bxor 0x1021) -band 65535}else{($crc -shl 1) -band 65535}}}
    [uint16]$crc
}
if((Crc ([Text.Encoding]::ASCII.GetBytes('123456789'))) -ne 0x29b1){throw 'CRC known-answer failure'}
# Diagnostic GET_STATUS only. The HOLD target rejects it with AUTH and charge0.
[byte[]]$body=3,4,1,0,1,0,0,0,0,0
$crc=Crc $body
[byte[]]$frame=@(0x53,0x56)+$body+@(($crc -band 255),($crc -shr 8))
$bad=$frame.Clone();$bad[$bad.Length-1]=$bad[$bad.Length-1] -bxor 1
$record=[ordered]@{schema='smartvio.uart.bench-vector.v3';mode=$Mode;getStatusHex=([BitConverter]::ToString($frame).Replace('-',' '));badCrcHex=([BitConverter]::ToString($bad).Replace('-',' '));expectedReplyType=128;expectedResult=1;expectedChargeAllow=0;note='UART vector generation is not a hardware test; raw UART cannot authorize the HOLD target';hardwareExecuted=$false;hardwareTests=0}
if($Mode -eq 'Probe'){
    if(!$Port){throw 'Explicit COM port is required; review READ-ME and hardware-test-plan before powering/connecting'}
    $serial=[IO.Ports.SerialPort]::new($Port,115200,[IO.Ports.Parity]::None,8,[IO.Ports.StopBits]::One)
    $serial.ReadTimeout=1000;$serial.WriteTimeout=250;$serial.DtrEnable=$false;$serial.RtsEnable=$false
    try{
        $serial.Open();$serial.DiscardInBuffer();$serial.Write($frame,0,$frame.Length)
        [byte[]]$reply=New-Object byte[] 22
        for($i=0;$i -lt $reply.Length;$i++){$reply[$i]=[byte]$serial.ReadByte()}
        if($reply[0] -ne 0x53 -or $reply[1] -ne 0x56 -or $reply[2] -ne 3 -or $reply[3] -ne 128 -or
           $reply[4] -ne 1 -or $reply[5] -ne 0 -or [BitConverter]::ToUInt32($reply,6) -ne 1 -or
           [BitConverter]::ToUInt16($reply,10) -ne 8 -or $reply[12] -ne 4 -or $reply[13] -ne 1 -or $reply[15] -ne 0){throw 'Unexpected HOLD reply or charging authorization'}
        if((Crc $reply[2..19]) -ne [BitConverter]::ToUInt16($reply,20)){throw 'Reply CRC failure'}
        $record.hardwareExecuted=$true;$record.hardwareTests=1;$record.replyHex=[BitConverter]::ToString($reply).Replace('-',' ')
        $record.port=$Port;$record.result='ONE_GET_STATUS_AUTH_REPLY_CONFIRMED_ONLY'
    }finally{if($serial.IsOpen){$serial.Close()};$serial.Dispose()}
}
$record | ConvertTo-Json | Set-Content (Join-Path $PSScriptRoot ('verification/uart-'+$Mode.ToLowerInvariant()+'.json')) -Encoding utf8
Write-Output ($record | ConvertTo-Json -Compress)
