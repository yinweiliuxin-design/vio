/* V26 factory diagnostic image. Real peripheral code, never hardware-qualified. */
#include "stm32h7xx_hal.h"
#include "sv_telemetry.h"
#include "sv_factory.h"
#include "board_pins.h"
#include "i2c_probe.h"
#include "audio_hw.h"
#include "fault_store.h"
#include "pot_adc.h"
#include "safety_inputs.h"
#include <string.h>
static volatile uint32_t milliseconds;
static sv_monitor monitor;
static sv_pcm1864 codec;
static sv_factory factory;
static sv_pot_scan pot_scan;
static uint32_t pot_generation;
static bool pot_initialized,selected_peer;
static sv_rf_guard rf;
static IWDG_HandleTypeDef watchdog;
static sv_parser parser;
static uint8_t tx[270];static size_t tx_count,tx_at;
static uint32_t tx_started,rail_at,discharged_at,recorded;
static unsigned power_state;
static bool uart_on,codec_gate;
static uint8_t previous_port;
static uint32_t port_changed,status_at;static unsigned status_index;
/* SWD mailbox: write fields then increment request last; poll completed/result.
 * Bench interface only, not remotely writable production control. */
volatile struct {
    uint32_t request,completed,nonce,faults,state,pairs,monitor_generation,selftest;
    int32_t temperature_deci_c;uint32_t mv[4];
    uint32_t type,length,session,seq,payload[64],result;
} sv_diag;
volatile struct {
    uint32_t version,raw[3],generation,sampled,adc_fault,ui_enabled,picked_up,muted,fx,rate,input,port,events,session_seq,bt_result,program_remaining_ms;
} sv_ui_diag;
volatile uint32_t sv_rf_pcm_diag[8];
uint32_t HAL_GetTick(void){return milliseconds;}
uint32_t sv_target_millis(void){return milliseconds;}
void SysTick_Handler(void){milliseconds++;sv_safety_inputs_tick(milliseconds);}
static void mode(GPIO_TypeDef *p,unsigned n,unsigned m){p->MODER=(p->MODER&~(3u<<(2*n)))|(m<<(2*n));}
static void level(GPIO_TypeDef *p,unsigned n,bool hi){p->BSRR=1u<<(n+(hi?0:16));}
/* Executed before C initialization. Only official CMSIS register definitions. */
void sv_early_safe_gpio(void){
    RCC->AHB4ENR|=RCC_AHB4ENR_GPIOAEN|RCC_AHB4ENR_GPIOBEN|RCC_AHB4ENR_GPIOCEN|RCC_AHB4ENR_GPIOEEN;
    (void)RCC->AHB4ENR;GPIOC->BSRR=SV_C_RF_OFF_BSRR;GPIOE->BSRR=SV_E_BOOT_BSRR;
    GPIOC->OTYPER&=~(SV_PC_RF|SV_PC_AUDIO_BUS);
    GPIOC->MODER=(GPIOC->MODER&~((3u<<10)|(3u<<26)))|(1u<<10)|(1u<<26);
    GPIOE->OTYPER&=~(SV_PE_AUDIO_POWER|SV_PE_BOOT|SV_PE_USB_DISABLE|SV_PE_EN1|SV_PE_EN2|SV_PE_CHARGE);
    GPIOE->MODER=(GPIOE->MODER&~SV_E_SAFE_MODE_MASK)|SV_E_SAFE_MODE_BITS;
    GPIOA->BSRR=0x0fu<<16;GPIOA->MODER=(GPIOA->MODER&~0xffu)|0x55u;
    GPIOB->BSRR=1u<<(10+16);GPIOB->MODER=(GPIOB->MODER&~(3u<<20))|(1u<<20);
    RCC->CR=(RCC->CR&~RCC_CR_HSIDIV)|RCC_CR_HSIDIV_8;__DSB();
}
static void unused(GPIO_TypeDef *p,uint16_t pins){uint32_t mask=0;for(unsigned n=0;n<16;n++)if(pins&(1u<<n))mask|=3u<<(2*n);p->PUPDR&=~mask;p->MODER|=mask;}
static void safe_gpio(void){
    RCC->AHB4ENR|=RCC_AHB4ENR_GPIODEN;(void)RCC->AHB4ENR;
    GPIOC->OSPEEDR&=~((3u<<10)|(3u<<26));
    unused(GPIOA,SV_UNUSED_A);unused(GPIOB,SV_UNUSED_B);unused(GPIOC,SV_UNUSED_C);unused(GPIOD,SV_UNUSED_D);unused(GPIOE,SV_UNUSED_E);
    for(unsigned n=4;n<8;n++)mode(GPIOA,n,0);
    mode(GPIOC,0,0);mode(GPIOC,4,0);mode(GPIOE,8,0);mode(GPIOE,9,0);mode(GPIOE,15,0);
    unused(GPIOE,(15u<<3)|(1u<<11));unused(GPIOD,(3u<<8)|(7u<<11));unused(GPIOC,1u<<9);
}
static void cpu(bool fast){
    if(pot_initialized){sv_pot_adc_stop();pot_initialized=false;}
    RCC->CR=(RCC->CR&~RCC_CR_HSIDIV)|(fast?RCC_CR_HSIDIV_1:RCC_CR_HSIDIV_8);
    SystemCoreClockUpdate();SysTick_Config(SystemCoreClock/1000u);
}
static void pots_start(uint32_t now){
    pot_initialized=sv_pot_adc_init();pot_generation=0;factory.ui.fresh=false;factory.ui.picked_up=false;
    sv_pot_init(&pot_scan,sv_pot_adc_bus(),now);
    if(!pot_initialized){pot_scan.fault=true;sv_factory_fault(&factory,SV_D_FAULT_SENSOR);}
}
static void uart_stop(void){USART3->CR1=0;uart_on=false;tx_count=0;sv_parser_reset(&parser);unused(GPIOD,3u<<8);}
static void uart_start(void){
    RCC->D2CCIP2R=(RCC->D2CCIP2R&~RCC_D2CCIP2R_USART28SEL)|(3u<<RCC_D2CCIP2R_USART28SEL_Pos);
    RCC->APB1LENR|=RCC_APB1LENR_USART3EN;(void)RCC->APB1LENR;
    USART3->CR1=0;USART3->CR2=0;USART3->CR3=0;USART3->PRESC=0;USART3->BRR=(64000000u+57600u)/115200u;
    GPIOD->AFR[1]=(GPIOD->AFR[1]&~0xffu)|0x77u;mode(GPIOD,8,2);mode(GPIOD,9,2);
    USART3->CR1=USART_CR1_RE|USART_CR1_TE|USART_CR1_UE;uart_on=true;
}
static void power_off(uint32_t now){
    sv_audio_emergency_mute();level(GPIOC,13,false);sv_rf_request(&rf,false,false,now);
    uart_stop();sv_audio_hw_stop();level(GPIOE,2,false);power_state=4;discharged_at=now;
    cpu(false);pots_start(now);selected_peer=false;if(!sv_stm32_i2c1_init())sv_factory_fault(&factory,SV_D_FAULT_SENSOR);
}
static void latch_shutdown(void){
    if(sv_safety_shutdown_requested()){
        factory.shutdown=true;factory.armed=false;factory.programming=false;
        factory.port=0;factory.window=false;sv_ui_enable(&factory.ui,false);sv_session_end(&factory.session);
    }
}
static bool evidence(uint32_t now){
    sv_mon_frame f;if(!sv_mon_snapshot(&monitor,now,&f))return false;
    /* TMP117 is board temperature, not the cell NTC. Diagnostic window only. */
    return f.mv[SV_MON_SYS]>=2900 && f.mv[SV_MON_SYS]<=4600 && f.temperature_deci_c>=100 && f.temperature_deci_c<=400 &&
        (GPIOE->IDR&((1u<<8)|(1u<<9)))==((1u<<8)|(1u<<9));
}
static sv_result command(const sv_frame *f,uint32_t now){
    latch_shutdown();
    if((f->type==0x31 || f->type==0x3b) && (!evidence(now) || pot_scan.fault))return SV_NOT_READY;
    if(f->type==0x3b && power_state!=0)return SV_NOT_READY;
    if(f->type==0x35){if(f->length)return SV_LENGTH;factory.shutdown=true;factory.armed=false;factory.programming=false;return SV_OK;}
    if((f->type>=0x36 && f->type<=0x39) || f->type==0x3c){
        if(f->length!=(f->type==0x36?6:0))return SV_LENGTH;
        if(!uart_on || !sv_rf_handshake_ready(&rf,now) || !factory.armed || factory.port!=SV_BT || !evidence(now))return SV_NOT_READY;
        if(tx_count)return SV_NOT_READY;
        sv_frame check=*f;check.type=0x34;check.length=0;
        sv_result r=sv_factory_command(&factory,&check,now);if(r!=SV_OK)return r;
        sv_frame out=*f;out.type=f->type==0x36?0x40:f->type==0x37?0x41:f->type==0x38?0x42:f->type==0x39?0x43:0x22;
        tx_count=sv_frame_encode(&out,tx,sizeof(tx));tx_at=0;tx_started=now;
        if(f->type==0x36)selected_peer=true;
        return SV_OK;
    }
    return sv_factory_command(&factory,f,now);
}
static bool startup_core(void){
    if(sv_crc16((const uint8_t*)"123456789",9)!=0x29b1)return false;
    sv_parser p;sv_parser_reset(&p);
    sv_frame in={.type=0x30,.seq=0x1234,.session_id=0x53562601,.length=3,.payload={0,0x53,0x56}},out;
    uint8_t bytes[270];size_t n=sv_frame_encode(&in,bytes,sizeof(bytes));unsigned received=0;
    if(n!=17)return false;
    for(size_t i=0;i<n;i++)received+=sv_parser_byte(&p,bytes[i],0,&out);
    if(received!=1 || out.type!=in.type || out.seq!=in.seq || out.session_id!=in.session_id || out.length!=3 || memcmp(out.payload,in.payload,3))return false;
    bytes[n-1]^=1;sv_parser_reset(&p);received=0;
    for(size_t i=0;i<n;i++)received+=sv_parser_byte(&p,bytes[i],0,&out);
    return !received;
}
static void uart_service(uint32_t now){
    if(!uart_on)return;
    if(USART3->ISR&(USART_ISR_ORE|USART_ISR_FE|USART_ISR_NE|USART_ISR_PE)){
        USART3->ICR=USART_ICR_ORECF|USART_ICR_FECF|USART_ICR_NECF|USART_ICR_PECF;
        USART3->RQR=USART_RQR_RXFRQ;sv_factory_fault(&factory,SV_D_FAULT_PROTOCOL);return;
    }
    for(unsigned n=0;n<128 && (USART3->ISR&USART_ISR_RXNE_RXFNE);n++){
        sv_frame f;if(sv_parser_byte(&parser,(uint8_t)USART3->RDR,now,&f)){
            if(f.type==0xa1){if(f.length==32 && f.session_id==factory.session.session_id)memcpy((void*)sv_rf_pcm_diag,f.payload,32);continue;}
            if(f.type==0xa0 || f.type==0x80)continue;
            sv_result result=command(&f,now);
            if(!tx_count){sv_frame reply={.type=0xb0,.seq=f.seq,.session_id=f.session_id,.length=9};reply.payload[0]=result;
                memcpy(reply.payload+1,&factory.nonce,4);memcpy(reply.payload+5,&factory.faults,4);
                tx_count=sv_frame_encode(&reply,tx,sizeof(tx));tx_at=0;tx_started=now;}
        }
    }
    sv_parser_poll(&parser,now);
    if(tx_count && (USART3->ISR&USART_ISR_TXE_TXFNF)){USART3->TDR=tx[tx_at++];if(tx_at==tx_count)tx_count=0;}
    if(tx_count && now-tx_started>=250){tx_count=0;sv_factory_fault(&factory,SV_D_FAULT_PROTOCOL);}
}
void HardFault_Handler(void){sv_audio_emergency_mute();GPIOC->BSRR=SV_PC_AUDIO_BUS<<16;GPIOE->BSRR=SV_PE_AUDIO_POWER<<16;__disable_irq();for(;;)__NOP();}
void NMI_Handler(void){HardFault_Handler();}
int main(void){
    safe_gpio();cpu(false);HAL_NVIC_SetPriority(SysTick_IRQn,0,0);sv_safety_inputs_init(0);
    watchdog.Instance=IWDG1;watchdog.Init.Prescaler=IWDG_PRESCALER_256;watchdog.Init.Reload=249;watchdog.Init.Window=IWDG_WINDOW_DISABLE;
    if(HAL_IWDG_Init(&watchdog)!=HAL_OK)HardFault_Handler();
    uint32_t retained=sv_fault_store_load(),faults=retained;if(RCC->RSR&RCC_RSR_IWDG1RSTF)faults|=SV_D_FAULT_RESET;
    RCC->RSR|=RCC_RSR_RMVF;sv_factory_init(&factory,faults);recorded=retained;
    bool core_ok=startup_core();if(!core_ok)sv_factory_fault(&factory,SV_D_FAULT_PROTOCOL);
    if(!sv_stm32_i2c1_init())sv_factory_fault(&factory,SV_D_FAULT_SENSOR);
    sv_mon_init(&monitor,milliseconds,sv_stm32_monitor_bus(),NULL);level(GPIOB,10,true);
    sv_parser_reset(&parser);sv_rf_request(&rf,false,false,milliseconds);pots_start(milliseconds);
    uint32_t last=milliseconds,last_codec=milliseconds;
    for(;;){
        uint32_t now=milliseconds;
        latch_shutdown();
        if(now-last>=1){
            if(now-last>100)sv_factory_fault(&factory,SV_D_FAULT_RESET);
            last=now;sv_mon_tick(&monitor,now,now>=20);
            if(pot_initialized)sv_pot_tick(&pot_scan,now);
            if(pot_scan.valid && pot_scan.generation!=pot_generation){
                pot_generation=pot_scan.generation;
                if(!sv_ui_pots(&factory.ui,pot_scan.raw,pot_scan.sampled))sv_factory_fault(&factory,SV_D_FAULT_SENSOR);
            }
            if(pot_scan.fault)sv_factory_fault(&factory,SV_D_FAULT_SENSOR);
            bool healthy=evidence(now);bool chord=(GPIOA->IDR&((1u<<5)|(1u<<6)))==0;
            sv_factory_tick(&factory,chord,healthy,healthy,now);
            uint8_t keys=(uint8_t)((~GPIOA->IDR>>5)&7u);if(!(GPIOC->IDR&1u))keys|=8;
            unsigned bt_action=sv_factory_buttons(&factory,keys,now);
            if(factory.ui.enabled && !factory.ui.fresh)sv_factory_fault(&factory,SV_D_FAULT_SENSOR);
            if(bt_action){
                sv_frame f={.type=bt_action==1?0x38:0x39,.seq=(uint16_t)(factory.session.last_seq+1),.session_id=factory.session.session_id};
                sv_ui_diag.bt_result=selected_peer?command(&f,now):SV_NOT_READY;
            }
            if(monitor.fault)sv_factory_fault(&factory,SV_D_FAULT_SENSOR);
            if(sv_diag.request!=sv_diag.completed){
                sv_frame f={.type=(uint8_t)sv_diag.type,.length=(uint16_t)sv_diag.length,.session_id=sv_diag.session,.seq=(uint16_t)sv_diag.seq};
                if(sv_diag.length>256)sv_diag.result=SV_LENGTH;
                else {for(unsigned n=0;n<64;n++)memcpy(f.payload+n*4,(const void*)&sv_diag.payload[n],4);sv_diag.result=command(&f,now);}
                __DMB();sv_diag.completed=sv_diag.request;
            }
            latch_shutdown();
            if((!factory.armed || factory.faults || factory.shutdown) && power_state && power_state!=4)power_off(now);
            if(power_state==4 && now-discharged_at>=1000){power_state=0;level(GPIOC,5,false);mode(GPIOC,5,1);}
            if(factory.armed && healthy && !factory.shutdown && !sv_safety_shutdown_requested() && !power_state){
                cpu(!factory.programming);pots_start(now);if(!sv_stm32_i2c1_init())sv_factory_fault(&factory,SV_D_FAULT_SENSOR);
                latch_shutdown();
                if(factory.armed && !factory.faults && !factory.shutdown){
                    if(factory.programming){uart_stop();unused(GPIOC,1u<<5);level(GPIOC,13,false);}
                    level(GPIOE,2,true);rail_at=now;power_state=1;
                }
            }
            if(power_state==1 && now-rail_at>=50){
                if(factory.programming)power_state=5;
                else {
                    level(GPIOC,13,true);
                    if(!sv_audio_hw_start())sv_factory_fault(&factory,SV_D_FAULT_CLOCK);
                    else {sv_pcm_start(&codec,sv_stm32_codec_bus(),now);codec_gate=false;power_state=2;}
                }
            }
            if(power_state==2 && now-last_codec>=1){last_codec=now;sv_pcm_tick(&codec,now);
                if(codec.fault)sv_factory_fault(&factory,SV_D_FAULT_CODEC);
                else if(codec.ready){
                    if(!codec_gate){sv_audio_hw_codec_ready(now);codec_gate=true;}
                    if(sv_audio_hw_ready(now)){power_state=3;status_at=now;status_index=0;}
                }
            }
            if(power_state==3 && now-status_at>=20){
                static const uint8_t regs[]={0x72,0x73,0x74,0x75,0x78},masks[]={15,7,127,255,7},values[]={15,3,0x34,0,7};
                uint8_t v;status_at=now;
                if(!codec.bus.read(codec.bus.ctx,regs[status_index],&v) || (v&masks[status_index])!=values[status_index])sv_factory_fault(&factory,SV_D_FAULT_CODEC);
                status_index=(status_index+1)%5;
            }
            latch_shutdown();
            if(factory.shutdown && power_state && power_state!=4)power_off(now);
            bool rf_on=sv_rf_request(&rf,power_state==3 && factory.port==SV_BT,factory.armed && healthy && !factory.faults && !factory.shutdown,now);
            level(GPIOC,5,rf_on);if(sv_rf_handshake_ready(&rf,now) && !uart_on)uart_start();
            if(!rf_on && uart_on)uart_stop();
            if(!rf_on)selected_peer=false;
            if(factory.port!=previous_port){previous_port=factory.port;port_changed=now;}
            uint8_t desired=0;
            if(power_state==3 && sv_audio_hw_ready(now) && factory.armed && factory.mode && sv_ui_audible(&factory.ui) && healthy && !factory.faults && now-port_changed>=50){
                if(factory.port==SV_LINE)desired=(1u<<0)|(1u<<3);
                if(factory.port==SV_HP && sv_safety_headphone_permitted())desired=(1u<<0)|(1u<<1);
                if(factory.port==SV_SPK && sv_safety_speaker_permitted())desired=1u<<2;
            }
            sv_safety_apply_outputs(desired);
            /* U1921 has no status GPIO. Never invent NTC qualification from
             * TMP117 or infer it from current. Pack configuration is unapproved. */
            level(GPIOE,14,false);
            if(factory.shutdown && (power_state==0 || power_state==4))level(GPIOE,7,false);
            if(factory.faults!=recorded && (power_state==0 || power_state==4)){
                if(sv_fault_store_append(factory.faults))recorded=factory.faults;
                else {factory.faults|=SV_D_FAULT_RESET;recorded=factory.faults;}
            }
            HAL_IWDG_Refresh(&watchdog);
            sv_diag.nonce=factory.nonce;sv_diag.faults=factory.faults;sv_diag.state=power_state;
            sv_diag.pairs=sv_audio_hw_pairs();sv_diag.monitor_generation=monitor.frame.generation;
            sv_diag.selftest=(core_ok?1u:0u)|(healthy?2u:0u)|(codec.ready?4u:0u)|(power_state==3 && sv_audio_hw_ready(now)?8u:0u);
            sv_diag.temperature_deci_c=monitor.frame.temperature_deci_c;
            for(unsigned n=0;n<4;n++)sv_diag.mv[n]=monitor.frame.mv[n];
            sv_ui_diag.version=1;for(unsigned n=0;n<3;n++)sv_ui_diag.raw[n]=pot_scan.raw[n];
            sv_ui_diag.generation=pot_scan.generation;sv_ui_diag.sampled=pot_scan.sampled;sv_ui_diag.adc_fault=pot_scan.fault;
            sv_ui_diag.ui_enabled=factory.ui.enabled;sv_ui_diag.picked_up=factory.ui.picked_up;sv_ui_diag.muted=factory.ui.muted;
            sv_ui_diag.fx=factory.ui.fx;sv_ui_diag.rate=factory.ui.rate;sv_ui_diag.input=factory.input;sv_ui_diag.port=factory.port;
            sv_ui_diag.events=factory.ui.events;sv_ui_diag.session_seq=factory.session.last_seq;
            sv_ui_diag.program_remaining_ms=factory.programming?300000-(now-factory.armed_at):0;
        }
        if(power_state==2 || power_state==3){uint32_t e=sv_audio_hw_service(&factory,now);if(e)sv_factory_fault(&factory,e);}
        uart_service(now);
    }
}
