#ifndef SV_AUDIO_CONTRACT_H
#define SV_AUDIO_CONTRACT_H
/* PCM1864 SLAS831D pp41,58,91-95; H743 DS12110 pp64,94 and RM0433 51.4.4.
 * Parent-approved dual-DOUT replacement for TDM. SAI/DMA remain disabled. */
enum {
    SV_ADC_FS_HZ=48000, SV_ADC_LANES=2, SV_ADC_FRAME_BITS=64, SV_ADC_SLOTS=2,
    SV_ADC_SLOT_BITS=32, SV_ADC_ACTIVE_MASK=0x03, SV_ADC_ACTIVE_WORDS=4,
    SV_ADC_VALID_BITS=24, SV_ADC_BCLK_HZ=3072000, SV_ADC_SCKI_HZ=24576000,
    SV_ADC_FSYNC_BITS=32, SV_ADC_I2S_DELAY_BITS=1,
    SV_PCM1864_FORMAT_MASK=0x1f, SV_PCM1864_FORMAT_VALUE=0x00,
    SV_PCM1864_INPUT_MASK=0xbf, SV_PCM1864_INPUT_RESERVED=0x40,
    SV_PLAY_FS_HZ=48000, SV_PLAY_SLOTS=2, SV_PLAY_SLOT_BITS=32,
    SV_PLAY_BCLK_HZ=3072000, SV_SPEAKER_PEAK_I16=13107
};
/* Negative array sizes enforce constants on both Arm GCC and host TCC0.9.27. */
typedef char sv_assert_adc_frame[(SV_ADC_FRAME_BITS==SV_ADC_SLOTS*SV_ADC_SLOT_BITS)?1:-1];
typedef char sv_assert_adc_bclk[(SV_ADC_BCLK_HZ==SV_ADC_FS_HZ*SV_ADC_FRAME_BITS)?1:-1];
typedef char sv_assert_adc_mask[(SV_ADC_ACTIVE_MASK==(1u<<SV_ADC_SLOTS)-1)?1:-1];
typedef char sv_assert_adc_words[(SV_ADC_ACTIVE_WORDS==SV_ADC_LANES*SV_ADC_SLOTS)?1:-1];
typedef char sv_assert_adc_scki[(SV_ADC_SCKI_HZ==SV_ADC_FS_HZ*512)?1:-1];
typedef char sv_assert_pcm_input_reserved[(SV_PCM1864_INPUT_MASK&SV_PCM1864_INPUT_RESERVED)?-1:1];
typedef char sv_assert_play_bclk[(SV_PLAY_BCLK_HZ==SV_PLAY_FS_HZ*SV_PLAY_SLOTS*SV_PLAY_SLOT_BITS)?1:-1];
/* DOUT1: ADC1L/R; DOUT2: ADC2L/mutedR.32-bit receive words discard low8bits.
 * Digital int16 helpers need a tested DMA/24-bit adapter and coherent lane
 * timestamps; this header supplies neither DMA nor PCM mixer programming. */
#endif
