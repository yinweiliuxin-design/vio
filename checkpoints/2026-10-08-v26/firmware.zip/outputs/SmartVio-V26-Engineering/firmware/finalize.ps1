param([string]$ExpectedSourceSha256='0e910987449bffa901d04ab268c706915137b6e57687c6ca12c37101dc3c9430')
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../..'))
$work=Join-Path $root 'work/v26/firmware'
$verification=Join-Path $PSScriptRoot 'verification'
Start-Transcript (Join-Path $verification 'finalize.log')
try {
    & (Join-Path $PSScriptRoot 'verify.ps1')
    $status=Get-Content (Join-Path $verification 'build-status.json') -Raw -Encoding utf8|ConvertFrom-Json
    if($status.nativeSourceSha256 -ne $ExpectedSourceSha256){throw 'Final source hash changed; review contracts then rerun with explicitly reviewed source hash'}
    $esp=Get-Content (Join-Path $verification 'esp-native-build.json') -Raw -Encoding utf8|ConvertFrom-Json
    $espSources=@(Get-ChildItem (Join-Path $PSScriptRoot 'esp32/main') -File | Select-Object -ExpandProperty FullName)+@(
        (Join-Path $PSScriptRoot 'esp32/CMakeLists.txt'),(Join-Path $PSScriptRoot 'esp32/sdkconfig'),(Join-Path $PSScriptRoot 'esp32/sdkconfig.defaults'),
        (Join-Path $PSScriptRoot 'sv_control.c'),(Join-Path $PSScriptRoot 'sv_control.h'),(Join-Path $PSScriptRoot 'sv_radio_core.c'),(Join-Path $PSScriptRoot 'sv_radio_core.h'),(Join-Path $PSScriptRoot 'sv_resample.h'),(Join-Path $PSScriptRoot 'build-esp-v26.ps1'))
    $espBuiltAt=([DateTime]$esp.updatedAtUtc).ToUniversalTime()
    foreach($file in $espSources){if((Get-Item $file).LastWriteTimeUtc -gt $espBuiltAt){throw "ESP source changed after successful build: $file"}}
    $esp | Add-Member -Force NoteProperty inputs @($espSources|Get-FileHash -Algorithm SHA256|Select-Object Path,Hash)
    $esp | Add-Member -Force NoteProperty inputEvidence 'Post-build source hash capture; source mtimes checked against successful native build timestamp. Actual linked ELF and raw compiler log, not hardware evidence.'
    $esp|ConvertTo-Json -Depth 7|Set-Content (Join-Path $verification 'esp-native-build.json') -Encoding utf8
    $dest=Join-Path $PSScriptRoot 'build/esp32'
    $files=@('smartvio_rf_diag.elf','smartvio_rf_diag.bin','smartvio_rf_diag.map','bootloader/bootloader.bin','partition_table/partition-table.bin','flash_args','flasher_args.json')
    foreach($relative in $files){
        $from=Join-Path (Join-Path $work 'eb') $relative;$to=Join-Path $dest $relative
        New-Item -ItemType Directory -Force (Split-Path $to)|Out-Null
        Copy-Item -LiteralPath $from -Destination $to -Force
        if((Get-FileHash $from).Hash -ne (Get-FileHash $to).Hash){throw "Deliverable copy failed $relative"}
    }
    $clock=[ordered]@{schema='smartvio.sai-clock-review.v26';status='RM_HAL_CMSIS_AND_HOST_ASSERTIONS_PASS_NOT_TARGET_OBSERVED';hardwareTests=0;
        primarySource='https://www.st.com/resource/en/reference_manual/rm0433-stm32h742-stm32h743753-and-stm32h750-value-line-advanced-armbased-32bit-mcus-stmicroelectronics.pdf';
        reference='RM0433 Rev8 51.4.8 pp2248-2250 Table427';localPdfSha256=(Get-FileHash (Join-Path $root 'outputs/SmartVio-V26-Engineering/audit/audio/sources/ST_RM0433.pdf')).Hash;
        HAL='v1.11.4 HAL_SAI_InitProtocol -> SAI_InitI2S -> HAL_SAI_Init';HALSourceSha256=(Get-FileHash (Join-Path $work 'vendor/stm32h7xx-hal-driver-1.11.4/Src/stm32h7xx_hal_sai.c')).Hash;
        mode=@{NOMCK_NODIV=1;MCKDIV=16;OSR=0;MCKEN=0;FRL=63;FSALL=31;NBSLOT=1;SLOTSZ=2;SLOTEN=3};
        arithmetic=@{kernelHz=49152000;BCK='49152000/16=3072000Hz';FS='49152000/(16*(63+1))=48000Hz';MCLK='Separate MCO2 PLL2P/2=24576000Hz=512fs';otherMode='NOMCK0 FS=kernel/(MCKDIV*256*(OSR+1)); not selected'};
        expectedRegisters=@{CR1Mask='0x0FF83FEF';CR1=@('0x010822E1','0x010826E3','0x010822E0','0x010826E2');FRCRMask='0x00077FFF';FRCR='0x00051F3F';SLOTRMask='0xFFFF0FDF';SLOTR='0x00030180'};
        assertions='OfficialCMSIS mask static_asserts; RCC PLL2/source/MCO checks; actual SAI register read/assert afterHAL andDMA startup plus service. Host individual field bitflip/kernel/ALLslots negatives.';
        HALCorrection='InitProtocol setsSlotActiveALL; explicitslots0/1 thenHAL_SAI_Init disabled. MCKDIV16 itself is NOT an error with NODIV1.';
        siliconRevision=@{allowed=@('Y0x1003','V0x2003');unknown='factoryaudio rejected muted';HALRevisionBranch='revY omitsMCKENwrite; >=REV_ID_B writesMCKEN';unqualified='actualREVID/VOS/compensation/errata/clock electrical conditions require review and measurement'};
        muteGate='After codec/mixer/status pass reset qualification baseline. At least4 new pairedRX blocks and2 completions of preparedTX halves; freshness/errors/register mismatch failmute; route50ms guard.';
        targetRegisterSnapshots=$null;actualMeasuredBckHz=$null;actualMeasuredFsHz=$null;actualMeasuredMclkHz=$null;
        hostEvidence=@($status.hostSuites|Where-Object suite -eq 'audio_contract');source='stm32/audio_hw.c';implementationSha256=(Get-FileHash (Join-Path $PSScriptRoot 'stm32/audio_hw.c')).Hash}
    $clock|ConvertTo-Json -Depth 8|Set-Content (Join-Path $verification 'clock-register-check.json') -Encoding utf8
    $armInputs=Get-Content (Join-Path $verification 'build-inputs.json') -Raw -Encoding utf8|ConvertFrom-Json
    $armArtifacts=@(Get-ChildItem (Join-Path $PSScriptRoot 'build') -File -Filter '*DIAG*'|Get-FileHash -Algorithm SHA256|Select-Object Path,Hash)
    $espArtifacts=@($files|ForEach-Object {Get-FileHash (Join-Path $dest $_) -Algorithm SHA256|Select-Object Path,Hash})
    $negative=Get-Content (Join-Path $verification 'parity-negative-check.json') -Raw -Encoding utf8|ConvertFrom-Json
    if($negative.status -ne 'PASS' -or $negative.sourceSha256 -ne $status.nativeSourceSha256){throw 'Parity negatives stale'}
    $status|Add-Member -Force NoteProperty nativeSourceSha256 $status.nativeSourceSha256.ToLowerInvariant()
    $status|Add-Member -Force NoteProperty deliveredArtifacts @($armArtifacts+$espArtifacts)
    $status|Add-Member -Force NoteProperty buildInputManifests @('verification/build-inputs.json','verification/esp-native-build.json')
    $status|Add-Member -Force NoteProperty armBuildInputsSha256 (Get-FileHash (Join-Path $verification 'build-inputs.json')).Hash
    $status|Add-Member -Force NoteProperty espBuildInputsSha256 (Get-FileHash (Join-Path $verification 'esp-native-build.json')).Hash
    $status|Add-Member -Force NoteProperty compilerVersions @{ARM=((& (Join-Path $root 'work/v25/firmware/tools/bin/arm-none-eabi-gcc.exe') --version)[0]);Xtensa=((& (Join-Path $work 'xt/bin/xtensa-esp32-elf-gcc.exe') --version)[0]);ESP_IDF='5.4.3 single-coreESP32';STHAL='1.11.4';CMSIS_DSP='1.16.2 scalarDF1'}
    $status|Add-Member -Force NoteProperty sourceContracts @(Get-ChildItem (Join-Path $PSScriptRoot 'contracts') -Filter '*.json' -File|Get-FileHash|Select-Object Path,Hash)
    $status|Add-Member -Force NoteProperty normalCharging 'DISABLED_ALL_NATIVE_TARGET_STATES_PE14LOW_CEHIGH'
    $status|Add-Member -Force NoteProperty physicalTestsPerformed 0
    $status|Add-Member -Force NoteProperty clockReview 'verification/clock-register-check.json'
    $status|Add-Member -Force NoteProperty parityNegativeCases $negative.cases.Count
    $status|Add-Member -Force NoteProperty espFlashCaution 'NEW 0x3B <=5min MCU-running ROM session holdsV3LOAD,PC5analog beforepower,UART/SAIisolated. NoSTM32NRSTLOW. Fixture MUST hardware-interlock allactivepins toVTREF; stillnotqualified. Open-drainrelease cannotstartEN. Officialdefaultreset output NOTapproved. No flashing.'
    $status|Add-Member -Force NoteProperty newControls 'Actual ADC1 DMA2pot scan,4keydebounce/longpress/PWRLTCrequest,explicit0x3A volumezero-pickup/TONE CMSISLPF/FXtremolo/mix/BTselectedreconnect. Grant-limited factory UI, not consumer powerauthorization. Seecontracts/ui-controls.json andverification/ui-controls-check.json.'
    $status|Add-Member -Force NoteProperty applicableHardware ("V26 source$($status.nativeSourceSha256);316parts1081pins220nets;STM32H743VIT6 Y/V + ESP32-MINI-1U singlecore; PC13bus/PE8fault/PE2power/R907470R/dualI2S/NOjack/selectedspeaker;J501JST2A/VARTA56457201020/K1201-2AQY221R6VY/3zeroohmRC0603JR-070RL")
    $status|Add-Member -Force NoteProperty inputSafetyEvidence 'verification/input-safety-check.json;verification/safety-negative-check.json;F01/F02 host/linked target PASS, physicalTests0'
    $status|Add-Member -Force NoteProperty portableBuild 'BUILD-PORTABLE.txt: ARM_GCC_BIN/TCC/SV_VENDOR_DIR/SV_BUILD_WORK and IDF_PATH/IDF_TOOLS_PATH/PYTHON overrides; no hidden downloads. Minimal vendor/licenses listed; fullparity/finalize additionally require source audit workspace.'
    $status|Add-Member -Force NoteProperty remainingBlockers @('USB stack/current/physicaldetach/VREFINT and charge-onlyauthorization unimplemented','VARTA56457201020 pack/harness/current and worst-case USB100 budget not closed; no production mode grants','IndependentNTCinterlock has noMCUinput; cellpresence/temperature/calibration not qualified','Real clocks/skew/channelorder/DMAWCET/bias/audio/speaker1Vrms/thermal/BTpair-disconnect-reconnect and ADC scan timing not tested','Consumer UI/displayLED/presets/fullDSP, potopen-short/calibration, securityMAC-MITM/bondpolicy/serviceclear incomplete','FlashECC/powerfail/retention and unusedESP/inputonly/straps reset-sleep policy not qualified','ROM programming session implemented but VTREF-gated tri-state fixture still not designed/qualified; no offrail injection proof','F01/F02 physical INT26ms/IRQlatency/headphonebounce-pop/poweroff tests not run')
    $status|Add-Member -Force NoteProperty finalizedAtUtc ([DateTime]::UtcNow.ToString('o'))
    foreach($name in @('build-status.json','v26-implementation-status.json')){
        $status|ConvertTo-Json -Depth 10|Set-Content (Join-Path $verification $name) -Encoding utf8
        Copy-Item -LiteralPath (Join-Path $verification $name) -Destination (Join-Path $PSScriptRoot $name) -Force
    }
    $plan=@{schema='smartvio.factory-test-plan.v26';status='ALL_PHYSICAL_TESTS_NOT_RUN';hardwareTests=0;procedure='READ-ME.txt';chargeEnabled=$false;prerequisites=@('approved currentlimited bench/load fixture; VARTA/JST metadata does not grant load or charging','actual pad numbering/voltage/nooffrailinjection confirmed','core/sensors/retainedfault checks and explicit physical chord+SWD perportgrant','noRDP/optionbyte/eFuse/wholechipErase changes');tests=@(
        @{name='F01 LTC26ms pulse/startup rejection/IRQlatency/latched domain poweroff';status='NOT_RUN'},@{name='F02 raw headphone insertion immediatePA2 mute/stable release/bounce-pop';status='NOT_RUN'},
        @{name='resetEN00 CEhigh RF/PE2/PC13LOW andKILL512ms';status='NOT_RUN'},@{name='ADS1115/TMP117actualI2C andstale/failure shutoff';status='NOT_RUN'},
        @{name='PCMmasked24coeffreadback + postHALregistersnapshot andscopeMCLK/BCK/FS';status='NOT_RUN'},@{name='DMAinitialsilence/postcodec pairedRX+completedTX underrun/lanefault';status='NOT_RUN'},
        @{name='pickup/AUX-L/AUX-R analogchannelorder reducedloopback';status='NOT_RUN'},@{name='LINE/HPinsertLOW/SPK separate tone-loadtest';status='NOT_RUN'},
        @{name='SPK850HPF DC/square/<1Vrms/BTL/RMS/heat/acousticfixture';status='NOT_RUN'},@{name='Classicselectedpair/auth/encrypt/media/disconnect/reconnect BLEquiesce';status='NOT_RUN'},
        @{name='USBwakeOFFhousekeep/nocharge/unplug/NVMpowerfail/watchdog';status='NOT_RUN'},
        @{name='VOL/TONE/FX ADCscan/endpoint/stale/negativefault and buttondebounce/long/chord/volumezero-pickup';status='NOT_RUN'},
        @{name='ROMprogram5min PC5highZ/PE2power/VTREFfixtureinterlock/reset/faultabort nooffrail injection';status='NOT_RUN'});stopCriteria='UnexpectedCELOW/resetEN11/offrail injection,stale/bus/clock/DMA/readback/retainedfault,excesscurrent/ringing/heat,unsafe speakerBTL grounding: stopbenchpower, retainlogs; noautomaticfaultclear'}
    $plan|ConvertTo-Json -Depth 6|Set-Content (Join-Path $verification 'hardware-test-plan.json') -Encoding utf8
    $safety=Get-Content (Join-Path $verification 'input-safety-check.json') -Raw -Encoding utf8|ConvertFrom-Json
    $completion=[ordered]@{schema='smartvio.f01-f02-completion.v26.1';status='SOFTWARE_FIXES_AND_CURRENT_TARGET_BUILDS_PASS_PHYSICAL_PENDING';nativeSourceSha256=$status.nativeSourceSha256;topologySha256=$status.nativeTopologySha256;nativeCounts=$status.nativeCounts;F01='PC4 EXTI4 latch after startup rejection; shortest26ms pulse regressions pass;2ms level fallback';F02='PA4 raw insertion cuts speaker target via SysTick and atomic final output commit; stable release/bounce/race regressions pass';mainSourceSha256=(Get-FileHash (Join-Path $PSScriptRoot 'stm32/main.c')).Hash;inputSafetySourceHashes=$safety.sourceHashes;hostSuites=$status.hostSuites.Count;hostGroups=$status.hostGroups;hostAssertions=$status.hostAssertions;targetSafety=$safety.hostEvidence;safetyNegativeCases=$safety.negativeCases.Count;parityNegativeCases=$negative.cases.Count;ARM=$status.armCrossCompile;ESP=$status.espCrossCompile;espRebuiltFromClean=$esp.rebuiltFromClean;artifacts=$status.deliveredArtifacts;evidence=@('verification/input-safety-check.json','verification/safety-negative-check.json','verification/build-all.log','verification/build-inputs.json','verification/esp-native-build.json','verification/esp-native-build.log','verification/live-net-parity.json','verification/parity-negative-check.json','verification/vendor-check.json','verification/build-status.json');normalCharging=$status.normalCharging;hardwareTests=0;physicalRemaining=@('LTC26ms pulse/RC/startup-boundary/IRQlatency and actual PE2/PC13/PE7 shutdown','Headphone raw cutoff latency/bounce/pop and stable release on actual board');productionFreezePermitted=$false;EDA_PCB_globalSourceWritten=$false;pinReviewReportWritten=$false;completedAtUtc=[DateTime]::UtcNow.ToString('o')}
    $completion|ConvertTo-Json -Depth 10|Set-Content (Join-Path $verification 'f01-f02-completion.json') -Encoding utf8
    $before=Join-Path $root 'outputs/SmartVio-V25-Engineering/firmware'
    $changed=foreach($file in Get-ChildItem $PSScriptRoot -Recurse -File){
        if($file.Name -in @('changed-paths.json','finalize.log')){continue}
        $rel=$file.FullName.Substring($PSScriptRoot.Length+1);$prior=Join-Path $before $rel
        $hash=(Get-FileHash $file.FullName).Hash
        if(!(Test-Path $prior) -or (Get-FileHash $prior).Hash -ne $hash){[ordered]@{path=$file.FullName;relative=$rel;sha256=$hash;comparison='new_or_changed_vs_preserved_V25'}}
    }
    @{status='EXACT_FIRMWARE_PATH_INVENTORY_VS_PRESERVED_V25';files=@($changed);self='verification/changed-paths.json excludedfromselfhash';workAuthoredScripts=@(Get-ChildItem $work -File -Filter '*.ps1'|Get-FileHash|Select-Object Path,Hash);dependencyRoots=@('work/v26/firmware/vendor','work/v26/firmware/esp-tools','work/v26/firmware/downloads','work/v26/firmware/eb','work/v26/firmware/build');dependencyDetail='Official extracted SDK/tools and generated caches are dependencies, not authoredfiles; exact compiled input hashes and provenance in build-inputs.json,official-setup.json,esp-native-build.json andvendor/cmsis-dsp-1.16.2/provenance.json';nativeWritten=$false;V25Written=$false}|ConvertTo-Json -Depth 7|Set-Content (Join-Path $verification 'changed-paths.json') -Encoding utf8
    Write-Output "FINAL PASS source=$($status.nativeSourceSha256) ARM=$($status.armBinaryBytes) ESP=$($status.espBinaryBytes) host=$($status.hostGroups)/$($status.hostAssertions) physicalTests=0"
    Write-Output "ESP deliverables copied and SHA256 matched: $dest"
} finally {Stop-Transcript}
