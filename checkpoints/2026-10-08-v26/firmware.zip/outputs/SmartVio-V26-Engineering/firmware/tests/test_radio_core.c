#include "sv_radio_core.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned assertions,groups;
#define CHECK(x) do{assertions++;if(!(x)){fprintf(stderr,"FAIL radio %d\n",__LINE__);exit(1);}}while(0)
int main(void){
    sv_radio_core r;sv_radio_init(&r);
    const uint8_t peer[6]={1,2,3,4,5,6},other[6]={1,2,3,4,5,7},zero[6]={0},ones[6]={255,255,255,255,255,255};
    groups++;CHECK(!sv_radio_window(&r,0));
    CHECK(!sv_radio_open_local(&r,peer,false,true,0));
    CHECK(!sv_radio_open_local(&r,peer,true,false,0));
    CHECK(!sv_radio_open_local(&r,zero,true,true,0));CHECK(!sv_radio_open_local(&r,ones,true,true,0));
    CHECK(sv_radio_open_local(&r,peer,true,true,UINT32_MAX-100));
    CHECK(sv_radio_window(&r,0)&&sv_radio_peer(&r,peer)&&!sv_radio_peer(&r,other));
    CHECK(sv_radio_window(&r,59898));CHECK(!sv_radio_window(&r,59899));
    sv_radio_tick(&r,59899);CHECK(!r.local_window&&!r.connected&&!r.classic_authenticated&&!r.encrypted);
    r.faults=1;CHECK(!sv_radio_open_local(&r,peer,true,true,0));
    groups++;sv_radio_init(&r);sv_frame f={0};
    for(unsigned type=0;type<256;type++){
        f.type=(uint8_t)type;f.length=0;
        CHECK(sv_radio_command(&r,&f,0)==((type==0x20||type==0x21)?SV_OK:SV_AUTH));
        CHECK(!r.local_window&&!r.connected);
    }
    f.type=0x20;f.length=1;CHECK(sv_radio_command(&r,&f,0)==SV_LENGTH);
    CHECK(sv_radio_open_local(&r,peer,true,true,0));
    f.type=0x22;f.length=0;CHECK(sv_radio_command(&r,&f,0)==SV_AUTH);
    f.type=0x21;CHECK(sv_radio_command(&r,&f,0)==SV_OK&&!r.local_window);
    groups++;uint8_t pcm[4098];
    for(int32_t n=-4;n<=4100;n++){
        memset(pcm,0x5a,sizeof(pcm));
        int32_t expected=n>0&&n<=4096&&n%4==0?n:0;
        CHECK(sv_radio_silence(pcm+1,n)==expected);
        CHECK(pcm[0]==0x5a&&pcm[4097]==0x5a);
        for(unsigned j=1;j<4097;j++)CHECK(pcm[j]==(j<=(unsigned)expected?0:0x5a));
    }
    CHECK(sv_radio_silence(pcm,INT32_MIN)==0);CHECK(sv_radio_silence(NULL,4)==0);
    printf("{\"groups\":%u,\"assertions\":%u,\"failed\":0,\"hardware_tests\":0}\n",groups,assertions);
    return 0;
}
