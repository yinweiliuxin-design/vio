#include "i2c-model-device.h"
#include "stm32/i2c_probe.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
I2C_TypeDef sv_fake_i2c;GPIO_TypeDef sv_fake_gpiob;RCC_TypeDef sv_fake_rcc;
static unsigned checks,groups,polls,count;
static uint32_t now,script[8],seen_cr2[8],seen_txdr[8],hold_status;
static bool clock_running,expire_at_stop;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL I2C model %d\n",__LINE__);exit(1);}}while(0)
uint32_t sv_target_millis(void){return now;}
uint32_t sv_i2c_model_status(void){
    unsigned i=polls++;uint32_t status=i<count?script[i]:hold_status;
    if(i<8){seen_cr2[i]=I2C1->CR2;seen_txdr[i]=I2C1->TXDR;}
    if(status&I2C_ISR_RXNE)I2C1->RXDR=i==3?0x12:0x34;
    if(expire_at_stop && (status&I2C_ISR_STOPF))now=2;
    else if(clock_running)now++;
    I2C1->ISR=status;return status;
}
static void setup(bool read){
    memset(&sv_fake_i2c,0,sizeof(sv_fake_i2c));memset(&sv_fake_rcc,0,sizeof(sv_fake_rcc));
    memset(&sv_fake_gpiob,0xff,sizeof(sv_fake_gpiob));
    memset(script,0,sizeof(script));memset(seen_cr2,0,sizeof(seen_cr2));memset(seen_txdr,0,sizeof(seen_txdr));
    now=polls=0;clock_running=expire_at_stop=false;hold_status=0;
    RCC->CR=RCC_CR_HSIRDY|RCC_CR_HSIDIV_1;CHECK(sv_stm32_i2c1_init());
    if(read){count=6;script[1]=I2C_ISR_TXIS;script[2]=I2C_ISR_TC;script[3]=script[4]=I2C_ISR_RXNE;script[5]=I2C_ISR_STOPF;}
    else {count=5;script[1]=script[2]=script[3]=I2C_ISR_TXIS;script[4]=I2C_ISR_STOPF;}
}
int main(void){
    sv_mon_bus bus=sv_stm32_monitor_bus();uint8_t data[2]={0xab,0xcd};
    groups++;setup(true);
    CHECK((RCC->D2CCIP2R&RCC_D2CCIP2R_I2C123SEL)==RCC_D2CCIP2R_I2C123SEL_1);
    CHECK((GPIOB->AFR[1]&255)==0x44&&(GPIOB->MODER&0x000f0000)==0x000a0000);
    CHECK((GPIOB->OTYPER&0x300)==0x300&&!(GPIOB->PUPDR&0x000f0000));
    CHECK(I2C1->TIMINGR==0xf0741313);
    RCC->CR=RCC_CR_HSIRDY|RCC_CR_HSIDIV_8;CHECK(sv_stm32_i2c1_init());CHECK(I2C1->TIMINGR==0x10741313);
    RCC->CR=RCC_CR_HSIRDY|RCC_CR_HSIDIV_2;CHECK(!sv_stm32_i2c1_init());
    RCC->CR=0;CHECK(!sv_stm32_i2c1_init());
    groups++;setup(true);
    CHECK(bus.read(NULL,0x49,15,data,2,2));CHECK(data[0]==0x12&&data[1]==0x34&&polls==6);
    CHECK((seen_cr2[1]&I2C_CR2_SADD)==(0x49u<<1));
    CHECK((seen_cr2[1]&I2C_CR2_NBYTES)==(1u<<I2C_CR2_NBYTES_Pos));
    CHECK(!(seen_cr2[1]&(I2C_CR2_AUTOEND|I2C_CR2_RD_WRN))&&seen_txdr[2]==15);
    CHECK((seen_cr2[3]&(I2C_CR2_AUTOEND|I2C_CR2_RD_WRN))==(I2C_CR2_AUTOEND|I2C_CR2_RD_WRN));
    CHECK((seen_cr2[3]&I2C_CR2_NBYTES)==(2u<<I2C_CR2_NBYTES_Pos));
    CHECK(I2C1->CR1&I2C_CR1_PE);
    groups++;setup(false);data[0]=0xab;data[1]=0xcd;
    CHECK(bus.write(NULL,0x48,1,data,2,2));CHECK(polls==5);
    CHECK((seen_cr2[1]&I2C_CR2_NBYTES)==(3u<<I2C_CR2_NBYTES_Pos));
    CHECK((seen_cr2[1]&I2C_CR2_AUTOEND)&&!(seen_cr2[1]&I2C_CR2_RD_WRN));
    CHECK(seen_txdr[2]==1&&seen_txdr[3]==0xab&&seen_txdr[4]==0xcd);
    groups++;
    const uint32_t errors[]={I2C_ISR_NACKF,I2C_ISR_BERR,I2C_ISR_ARLO,I2C_ISR_OVR};
    for(unsigned e=0;e<4;e++)for(unsigned phase=1;phase<6;phase++){
        setup(true);script[phase]=errors[e]|I2C_ISR_BUSY;
        CHECK(!bus.read(NULL,0x49,0,data,2,2));CHECK(!(I2C1->CR1&I2C_CR1_PE));
        CHECK((I2C1->CR2&I2C_CR2_STOP)==(errors[e]==I2C_ISR_ARLO?0:I2C_CR2_STOP));
        unsigned previous=polls;CHECK(!bus.read(NULL,0x49,0,data,2,2));CHECK(polls==previous+1);
    }
    groups++;setup(true);expire_at_stop=true;
    CHECK(!bus.read(NULL,0x49,0,data,2,2)&&!(I2C1->CR1&I2C_CR1_PE));
    setup(false);expire_at_stop=true;CHECK(!bus.write(NULL,0x48,1,data,2,2)&&!(I2C1->CR1&I2C_CR1_PE));
    setup(true);count=0;hold_status=I2C_ISR_BUSY;clock_running=true;
    CHECK(!bus.read(NULL,0x49,0,data,2,2)&&polls<=2&&!(I2C1->CR1&I2C_CR1_PE));
    setup(true);count=0;hold_status=I2C_ISR_BUSY;
    CHECK(!bus.read(NULL,0x49,0,data,2,2)&&polls==200000&&!(I2C1->CR1&I2C_CR1_PE));
    groups++;setup(true);
    CHECK(!bus.read(NULL,0x50,0,data,2,2));CHECK(!bus.read(NULL,0x49,0,data,1,2));
    CHECK(!bus.read(NULL,0x49,0,NULL,2,2));CHECK(!bus.read(NULL,0x49,0,data,2,0));
    CHECK(!bus.read(NULL,0x49,0,data,2,3));CHECK(polls==0);
    printf("{\"groups\":%u,\"assertions\":%u,\"failed\":0,\"register_model\":true,\"hardware_tests\":0}\n",groups,checks);
    return 0;
}
