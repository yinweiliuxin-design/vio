#include "sv_foundation.h"
#include "stm32/board_pins.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned checks,groups;
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);exit(1);}}while(0)
#define GROUP(x) do{groups++;printf("TEST %s\n",x);}while(0)
static sv_inputs good(void){
    sv_inputs i={0};
    i.power_good=i.clocks_good=i.codec_ready=i.startup_selftest_passed=true;
    i.usb_present=i.usb_configured=i.usb_authorization_valid=i.physical_usb_valid=true;
    i.usb_measurement_valid=i.battery_measurement_valid=i.temperature_valid=true;
    i.battery_present=i.board_budget_valid=i.speaker_calibrated=true;
    i.bluetooth_authenticated=true;i.v3d_measurement_valid=true;i.v3d_mv=3300;
    i.usb_mv=5000;i.battery_mv=3800;i.temperature_deci_c=250;
    i.usb_budget_ma=500;i.board_usb_budget_ma=50;return i;
}
/* Test fixture only. These numbers are not approval of an actual cell. */
static sv_config config(void){sv_config c={true,true,198,20,50,400,4250,5};return c;}
static void tick(sv_control *c,sv_inputs *i){sv_tick(c,c->last_tick+5,i);}
static uint32_t rng=0x71db903u;
static uint32_t random32(void){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static bool parse(sv_parser *p,const uint8_t *b,size_t n,uint32_t t,sv_frame *f){
    bool accepted=false;for(size_t j=0;j<n;j++)if(sv_parser_byte(p,b[j],t,f))accepted=true;return accepted;
}
typedef struct {unsigned visible,disconnects,fail_off,applies;bool fail,fail_apply,stale;sv_inputs input;uint16_t adc,temp;} fixture;
static bool visible(void *ctx,bool enabled,uint32_t timeout){
    fixture *f=ctx;CHECK(timeout==20);f->visible=enabled?1:0;return !f->fail;
}
static bool disconnect(void *ctx,uint32_t timeout){fixture *f=ctx;CHECK(timeout==20);f->disconnects++;return !f->fail;}
static bool sample(void *ctx,uint32_t t,sv_inputs *i,bool *settled){fixture *f=ctx;*i=f->input;i->board_evidence_at=f->stale?t-21:t;*settled=true;return true;}
static bool apply(void *ctx,const sv_outputs *o){fixture *f=ctx;f->applies++;CHECK(!(o->hp_enable&&o->speaker_enable));return !f->fail_apply;}
static void fail_off(void *ctx){((fixture*)ctx)->fail_off++;}
static bool read_bus(void *ctx,uint8_t addr,uint8_t reg,uint8_t *out,size_t n,uint32_t timeout){
    fixture *f=ctx;CHECK(n==2&&timeout==2);uint16_t v=0;
    if(addr==0x48){
        if(reg==1)v=f->adc|0x8000;
        else {static const uint16_t raw[]={15094,11472,13283,8000};v=raw[((f->adc>>12)&7)-4];}
    }else if(addr==0x49){
        if(reg==15)v=0x0117;else if(reg==1)v=f->temp|0x2000;else if(reg==0)v=3200;
    }else return false;
    out[0]=(uint8_t)(v>>8);out[1]=(uint8_t)v;return true;
}
static bool write_bus(void *ctx,uint8_t addr,uint8_t reg,const uint8_t *in,size_t n,uint32_t timeout){
    fixture *f=ctx;CHECK(reg==1&&n==2&&timeout==2);
    uint16_t v=(uint16_t)((in[0]<<8)|in[1]);
    if(addr==0x48)f->adc=v;else if(addr==0x49)f->temp=v;else return false;return true;
}
int main(void){
    sv_control c;sv_inputs i=good();sv_config cfg=config();
    GROUP("pcm1864_dual_i2s_64bit_per_lane_preserves_four_words");
    CHECK(SV_ADC_LANES==2&&SV_ADC_SLOTS==2&&SV_ADC_SLOT_BITS==32&&SV_ADC_FRAME_BITS==64);
    CHECK(SV_ADC_FS_HZ*SV_ADC_FRAME_BITS==3072000&&SV_ADC_ACTIVE_MASK==0x03);
    CHECK(SV_ADC_ACTIVE_WORDS==4&&SV_ADC_VALID_BITS==24&&SV_ADC_FSYNC_BITS==32);
    CHECK(((0x44&~SV_PCM1864_FORMAT_MASK)|SV_PCM1864_FORMAT_VALUE)==0x40);
    CHECK(SV_ADC_I2S_DELAY_BITS==1&&SV_ADC_SCKI_HZ/SV_ADC_FS_HZ==512);
    CHECK(SV_PLAY_BCLK_HZ==3072000&&SV_PLAY_SLOTS==2&&SV_SPEAKER_PEAK_I16==13107);
    /* Contract arithmetic only, not a PCM1864 register transaction. */
    CHECK(SV_PCM1864_INPUT_MASK==0xbf&&SV_PCM1864_INPUT_RESERVED==0x40);
    const unsigned input_values[]={1,1,4,0},input_resets[]={0x41,0x41,0x42,0x42},input_full[]={0x41,0x41,0x44,0x40};
    for(unsigned reg=0;reg<4;reg++){
        CHECK(((input_resets[reg]&~SV_PCM1864_INPUT_MASK)|input_values[reg])==input_full[reg]);
        for(unsigned old=0;old<256;old++){
            unsigned next=(old&~SV_PCM1864_INPUT_MASK)|input_values[reg];
            CHECK((next&SV_PCM1864_INPUT_RESERVED)==(old&SV_PCM1864_INPUT_RESERVED));
            CHECK((next&SV_PCM1864_INPUT_MASK)==input_values[reg]);
        }
    }
    GROUP("startup_gpio_bootstrap100_ce_disabled_no_mode_pulses");
    uint32_t odr=0xffff;
    odr=(odr|(SV_E_BOOT_BSRR&0xffffu))&~(SV_E_BOOT_BSRR>>16);
    CHECK((odr&SV_PE_BOOT)!=0&&(odr&SV_PE_USB_DISABLE)!=0);
    CHECK((odr&(SV_PE_EN1|SV_PE_EN2|SV_PE_CHARGE))==0);
    for(uint32_t prior=0;prior<=65535;prior++){
        uint32_t result=(prior|(SV_E_BOOT_BSRR&0xffffu))&~(SV_E_BOOT_BSRR>>16);
        CHECK(!(result&(SV_PE_EN1|SV_PE_EN2|SV_PE_CHARGE)));
        CHECK((result&(SV_PE_BOOT|SV_PE_USB_DISABLE))==(SV_PE_BOOT|SV_PE_USB_DISABLE));
    }
    for(unsigned k=0;k<1000;k++){
        uint32_t prior=random32(),result=(prior&~SV_E_SAFE_MODE_MASK)|SV_E_SAFE_MODE_BITS;
        CHECK((result&~SV_E_SAFE_MODE_MASK)==(prior&~SV_E_SAFE_MODE_MASK));
        for(unsigned pin=0;pin<16;pin++)if(pin==7||pin==10||pin==12||pin==13||pin==14)
            CHECK(((result>>(pin*2))&3u)==1u);
    }
    sv_input_mode mode={0};uint32_t write=0;
    for(unsigned k=0;k<1000;k++)CHECK(!sv_input_mode_next(&mode,false,false,&write));
    CHECK(sv_input_mode_next(&mode,false,true,&write));
    odr=(odr|(write&0xffffu))&~(write>>16);CHECK(!(odr&SV_PE_EN1)&&(odr&SV_PE_EN2));
    for(unsigned k=0;k<1000;k++)CHECK(!sv_input_mode_next(&mode,false,true,&write));
    uint32_t old_en=odr&(SV_PE_EN1|SV_PE_EN2);
    odr=(odr|(SV_E_MUTE_BSRR&0xffffu))&~(SV_E_MUTE_BSRR>>16);
    CHECK((odr&(SV_PE_EN1|SV_PE_EN2))==old_en&&!(odr&SV_PE_CHARGE));
    CHECK(sv_input_mode_next(&mode,true,true,&write));CHECK((write&0xffffu)==(SV_PE_EN1|SV_PE_EN2));
    sv_init(&c,0,NULL);CHECK(!c.out.chg_en1&&!c.out.chg_en2&&!c.out.charge_allow);
    GROUP("rf_off_settle_and_unused_gpio_preserve_connected_swd_charger_pins");
    sv_rf_guard rf={0};CHECK(!sv_rf_handshake_ready(&rf,100));
    CHECK(!sv_rf_request(&rf,true,true,100));CHECK(!rf.enabled);
    CHECK(!sv_rf_request(&rf,true,false,UINT32_MAX-40));CHECK(!rf.enabled);
    CHECK(!sv_rf_request(&rf,true,true,UINT32_MAX-11));
    CHECK(sv_rf_request(&rf,true,true,UINT32_MAX-2));
    CHECK(!sv_rf_handshake_ready(&rf,1));CHECK(sv_rf_handshake_ready(&rf,2));
    CHECK(sv_rf_request(&rf,true,true,3));CHECK(rf.enabled_at==UINT32_MAX-2);
    CHECK(!sv_rf_request(&rf,false,true,4));CHECK(!sv_rf_handshake_ready(&rf,100));
    CHECK(!sv_rf_request(&rf,true,true,33));
    CHECK(sv_rf_request(&rf,true,true,100));CHECK(!sv_rf_handshake_ready(&rf,104));
    CHECK(sv_rf_handshake_ready(&rf,105));
    CHECK(!sv_rf_request(&rf,true,false,106)&&!rf.enabled);
    const uint16_t unused[]={SV_UNUSED_A,SV_UNUSED_B,SV_UNUSED_C,SV_UNUSED_D,SV_UNUSED_E};
    const uint16_t connected[]={0x38ffu,0x0f03u,0x03f3u,0x3f00u,0xfff8u};
    unsigned unused_count=0;
    for(unsigned port=0;port<5;port++){
        CHECK(!(unused[port]&connected[port]));
        uint32_t mask=sv_gpio_mode_mask(unused[port]);
        for(unsigned pin=0;pin<16;pin++){
            CHECK(((mask>>(2*pin))&3u)==((unused[port]&(1u<<pin))?3u:0u));
            if(unused[port]&(1u<<pin))unused_count++;
        }
        for(unsigned k=0;k<100;k++){
            uint32_t prior=random32();CHECK(((prior|mask)&~mask)==(prior&~mask));
        }
    }
    CHECK(unused_count==30&&!(SV_UNUSED_A&((1u<<13)|(1u<<14))));
    CHECK(!(SV_UNUSED_C&SV_PC_AUDIO_BUS)&&!(SV_UNUSED_E&SV_PE_AUDIO_POWER));
    CHECK(!(SV_E_BOOT_BSRR&SV_PE_AUDIO_POWER)&&(SV_E_BOOT_BSRR&(SV_PE_AUDIO_POWER<<16)));
    CHECK((SV_C_RF_OFF_BSRR>>16)==(SV_PC_RF|SV_PC_AUDIO_BUS));
    GROUP("zero_config_and_missing_authorizations_fail_closed");
    sv_init(&c,0,NULL);tick(&c,&i);CHECK(c.state==SV_READY&&!c.out.charge_allow);
    sv_init(&c,0,&cfg);i.startup_selftest_passed=false;tick(&c,&i);CHECK(c.state==SV_BOOT&&!c.out.charge_allow);
    i=good();tick(&c,&i);CHECK(c.out.charge_allow);
    i.battery_measurement_valid=false;tick(&c,&i);CHECK(!c.out.charge_allow);
    i=good();i.usb_authorization_valid=false;tick(&c,&i);CHECK(!c.out.charge_allow&&!c.out.chg_en1&&!c.out.chg_en2);
    i=good();i.physical_usb_valid=false;tick(&c,&i);CHECK(!c.out.charge_allow);
    i=good();i.battery_present=false;tick(&c,&i);CHECK(!c.out.charge_allow);
    i=good();i.board_usb_budget_ma=100;tick(&c,&i);CHECK(!c.out.charge_allow);
    i=good();i.usb_budget_ma=100;tick(&c,&i);CHECK(!c.out.charge_allow);

    GROUP("4180mv_regression_normal_cv_region_does_not_terminate");
    sv_init(&c,0,&cfg);i=good();
    for(unsigned mv=4170;mv<=4230;mv++){i.battery_mv=(uint16_t)mv;tick(&c,&i);CHECK(c.out.charge_allow);}
    i.battery_mv=4245;tick(&c,&i);CHECK(!c.out.charge_allow&&(c.faults&SV_F_CHARGER));
    i.battery_mv=3800;for(unsigned n=0;n<30;n++)tick(&c,&i);
    CHECK(!sv_ack_fault_local(&c,c.last_tick));
    cfg.battery_error_bound_mv=20;sv_init(&c,0,&cfg);tick(&c,&i);CHECK(!c.out.charge_allow);cfg=config();

    GROUP("faults_shutdown_and_route_mutation_cannot_rearm_charge");
    sv_init(&c,0,&cfg);i=good();tick(&c,&i);c.out.charge_allow=false;
    CHECK(sv_set_routes(&c,SV_LINE));CHECK(!c.out.charge_allow);
    CHECK(!c.out.dac_unmute);for(unsigned k=0;k<10;k++)tick(&c,&i);CHECK(c.out.dac_unmute);
    CHECK(sv_set_routes(&c,SV_SPK));i.headphones_raw=true;tick(&c,&i);CHECK(!c.out.speaker_enable);
    for(unsigned k=0;k<6;k++)tick(&c,&i);CHECK(!sv_set_routes(&c,SV_HP));
    for(unsigned k=0;k<4;k++)tick(&c,&i);CHECK(sv_set_routes(&c,SV_HP));
    i.clocks_good=false;tick(&c,&i);CHECK(c.state==SV_FAULT&&!c.out.port_enable);
    i=good();for(unsigned n=0;n<30;n++)tick(&c,&i);CHECK(sv_ack_fault_local(&c,c.last_tick));CHECK(!c.out.charge_allow);
    sv_stop_local(&c,c.last_tick);sv_tick(&c,c.last_tick+101,&i);CHECK(c.state==SV_OFF&&!c.out.boot_hold);
    sv_tick(&c,0,NULL);CHECK(c.state==SV_OFF&&!c.out.boot_hold);
    sv_init(&c,UINT32_MAX-10,&cfg);sv_tick(&c,5,&i);CHECK(c.state==SV_READY);
    sv_tick(&c,4,&i);CHECK(c.faults&SV_F_TIMING);
    CHECK(!c.out.chg_en1&&!c.out.chg_en2&&!c.out.charge_allow);
    sv_init(&c,0,NULL);i=good();i.usb_suspended=true;tick(&c,&i);
    CHECK(c.state==SV_STOPPING&&c.out.chg_en1&&c.out.chg_en2&&!c.out.charge_allow&&!c.out.port_enable);
    for(unsigned k=0;k<10;k++)tick(&c,&i);CHECK(c.state==SV_OFF&&!c.out.boot_hold);

    GROUP("uart_v3_bounds_crc_timeout_version_recovery");
    struct {uint32_t before;sv_parser p;uint32_t after;} guard={0};
    guard.before=0x10203040;guard.after=0x55667788;
    sv_parser *p=&guard.p;sv_frame f={0},decoded={0};uint8_t bytes[270];
    f.type=5;f.seq=65535;f.session_id=0x12345678;f.length=1;f.payload[0]=SV_LINE;
    CHECK(sv_crc16((const uint8_t*)"123456789",9)==0x29b1);
    size_t n=sv_frame_encode(&f,bytes,sizeof(bytes));CHECK(n==15);
    CHECK(bytes[2]==3&&bytes[6]==0x78&&bytes[9]==0x12&&bytes[10]==1&&bytes[12]==SV_LINE);
    CHECK(parse(p,bytes,n,0,&decoded));CHECK(decoded.session_id==f.session_id&&decoded.seq==65535);
    bytes[n-1]^=1;CHECK(!parse(p,bytes,n,1,&decoded));sv_parser_reset(p);
    bytes[n-1]^=1;bytes[2]=2;CHECK(!parse(p,bytes,n,2,&decoded));sv_parser_reset(p);
    bytes[2]=3;CHECK(!parse(p,bytes,5,3,&decoded));sv_parser_poll(p,253);CHECK(!p->count);
    bytes[10]=1;bytes[11]=1;CHECK(!parse(p,bytes,12,254,&decoded));
    f.length=256;for(unsigned k=0;k<256;k++)f.payload[k]=(uint8_t)k;
    n=sv_frame_encode(&f,bytes,sizeof(bytes));CHECK(n==270);sv_parser_reset(p);
    CHECK(parse(p,bytes,n,300,&decoded)&&decoded.length==256);
    CHECK(!sv_frame_encode(&f,bytes,269));f.length=257;CHECK(!sv_frame_encode(&f,bytes,270));
    sv_parser_reset(p);for(unsigned k=0;k<1000000;k++){
        sv_parser_byte(p,(uint8_t)random32(),k/20,&decoded);CHECK(p->count<=270);
    }
    CHECK(guard.before==0x10203040&&guard.after==0x55667788);

    GROUP("session_epoch_sequence_and_auth_boundaries");
    sv_session s={0};sv_init(&c,0,&cfg);i=good();tick(&c,&i);
    f=(sv_frame){.type=4,.seq=65535,.session_id=12};
    CHECK(sv_execute(&c,&s,&f,5)==SV_AUTH);CHECK(sv_session_begin_trusted(&s,12));
    CHECK(sv_execute(&c,&s,&f,5)==SV_OK);CHECK(sv_execute(&c,&s,&f,5)==SV_REPLAY);
    f.seq=0;CHECK(sv_execute(&c,&s,&f,5)==SV_OK);f.seq=32768;CHECK(sv_execute(&c,&s,&f,5)==SV_REPLAY);
    sv_session_end(&s);CHECK(sv_session_begin_trusted(&s,13));f.seq=1;CHECK(sv_execute(&c,&s,&f,5)==SV_AUTH);
    f.session_id=13;f.type=5;f.length=2;CHECK(sv_execute(&c,&s,&f,5)==SV_LENGTH&&!s.have_seq);

    GROUP("bt_physical_pair_timeout_disconnect_and_missing_hal");
    fixture fx={0};sv_bt bt;sv_bt_hal radio={&fx,visible,disconnect};sv_bt_init(&bt,radio,0);
    CHECK(bt.state==SV_BT_IDLE&&!fx.visible);CHECK(!sv_bt_pair_local(&bt,false,0));
    CHECK(sv_bt_pair_local(&bt,true,0));CHECK(fx.visible);
    CHECK(sv_bt_authenticated_event(&bt,true,0));CHECK(bt.authenticated&&!fx.visible);
    sv_bt_disconnected_event(&bt);CHECK(!bt.authenticated&&bt.state==SV_BT_IDLE);
    CHECK(!sv_bt_authenticated_event(&bt,true,0));
    CHECK(sv_bt_pair_local(&bt,true,0));for(uint32_t t=50;t<=60000;t+=50)sv_bt_tick(&bt,t);
    CHECK(bt.state==SV_BT_IDLE&&!fx.visible);CHECK(!sv_bt_authenticated_event(&bt,true,60000));
    fx.fail=true;CHECK(!sv_bt_pair_local(&bt,true,60000));CHECK(bt.state==SV_BT_FAULT);
    sv_bt_init(&bt,(sv_bt_hal){0},0);CHECK(bt.state==SV_BT_OFF&&!sv_bt_pair_local(&bt,true,0));

    GROUP("audio_1khz_tone_level_and_loopback_mute");
    sv_audio a={0};int16_t out[256],in[256];
    for(unsigned k=0;k<256;k++)in[k]=(k&1)?-32768:32767;
    CHECK(!sv_audio_set_test(&a,SV_AUDIO_TONE,false));CHECK(sv_audio_set_test(&a,SV_AUDIO_TONE,true));
    CHECK(sv_audio_process(&a,NULL,out,96,true));int32_t sum=0;
    for(unsigned k=0;k<96;k++){CHECK(out[k*2]==out[k*2+1]);CHECK(out[k*2]>=-2048&&out[k*2]<=2048);sum+=out[k*2];}
    CHECK(sum==0&&out[24]==2047&&out[72]==-2047&&out[0]==out[96]);
    CHECK(sv_audio_process(&a,NULL,out,128,false));for(unsigned k=0;k<256;k++)CHECK(out[k]==0);
    CHECK(!sv_audio_process(&a,NULL,out,129,true));CHECK(sv_audio_set_test(&a,SV_AUDIO_LOOPBACK,true));
    CHECK(sv_audio_process(&a,in,out,128,true));CHECK(out[0]==4095&&out[1]==-4096);
    CHECK(!sv_audio_process(&a,NULL,out,128,true));CHECK(out[0]==0);
    CHECK(!sv_audio_speaker_left(in,out,128,23197,false));CHECK(out[0]==0);
    CHECK(!sv_audio_speaker_left(in,out,128,32769,true));CHECK(out[0]==0);
    CHECK(sv_audio_speaker_left(in,out,128,32768,true));
    for(unsigned k=0;k<128;k++){CHECK(out[2*k]==((k&1)?-13107:13107));CHECK(out[2*k+1]==0);CHECK(in[k]==((k&1)?-32768:32767));}
    for(unsigned k=0;k<128;k++)in[k]=-32768;
    CHECK(sv_audio_speaker_left(in,out,128,32768,true));
    for(unsigned k=0;k<128;k++)CHECK(out[2*k]==-13107&&out[2*k+1]==0);
    for(unsigned k=0;k<128;k++)in[k]=32767;
    CHECK(sv_audio_speaker_left(in,out,128,32768,true));
    for(unsigned k=0;k<128;k++)CHECK(out[2*k]==13107&&out[2*k+1]==0);

    GROUP("speaker_exhaustive_int16_domain_gain_boundaries_and_slot_isolation");
    const uint16_t gains[]={0,1,16384,32767,32768};
    for(unsigned g=0;g<sizeof(gains)/sizeof(gains[0]);g++)for(int32_t raw=0;raw<=65535;raw++){
        int16_t original=(int16_t)(raw<=32767?raw:raw-65536);
        in[0]=original;in[1]=1234;out[2]=5678;
        CHECK(sv_audio_speaker_left(in,out,1,gains[g],true));
        CHECK(out[0]>=-13107&&out[0]<=13107);
        CHECK(out[1]==0&&out[2]==5678);
        CHECK(in[0]==original&&in[1]==1234);
        int32_t expected=((int32_t)original*gains[g])/32768;
        if(expected>13107)expected=13107;if(expected< -13107)expected= -13107;
        CHECK(out[0]==expected);
    }
    GROUP("speaker_overlapping_buffers_rejected_without_touching_hp_line");
    for(unsigned k=0;k<256;k++)in[k]=(int16_t)k;
    CHECK(!sv_audio_speaker_left(in,in,16,32768,true));
    CHECK(!sv_audio_speaker_left(in,in+1,16,32768,true));
    CHECK(!sv_audio_speaker_left(in+1,in,16,32768,true));
    CHECK(!sv_audio_speaker_left(in,in+1,16,32768,false));
    for(unsigned k=0;k<256;k++)CHECK(in[k]==(int16_t)k);

    GROUP("startup_selftest_pending_and_latched_timeout");
    sv_selftest st;sv_selftest_init(&st,0);i=good();sv_selftest_tick(&st,0,&i,false);
    CHECK(!sv_selftest_passed(&st)&&(st.pending&SV_ST_SENSOR));
    sv_selftest_tick(&st,3000,&i,false);sv_selftest_tick(&st,3010,&i,true);CHECK(!sv_selftest_passed(&st));

    GROUP("runtime_full_sensor_path_guard_disconnect_and_apply_failure");
    fx=(fixture){0};fx.input=good();fx.input.usb_present=false;
    sv_runtime r;sv_board_hal board={&fx,sample,apply,fail_off};sv_mon_bus bus={&fx,read_bus,write_bus};
    sv_mon_cal cal={0};cal.electrical_calibration_approved=cal.thermal_attachment_approved=true;
    for(unsigned k=0;k<4;k++)cal.gain_ppm[k]=1000000;
    sv_runtime_init(&r,0,&cfg,board,bus,&cal,radio);
    for(uint32_t t=0;t<=3500;t+=5){fx.input.usb_present=t>=1200;sv_runtime_tick(&r,t);if(t<3200)CHECK(!r.control.out.charge_allow);}
    CHECK(r.control.state==SV_READY&&r.control.out.charge_allow);
    CHECK(sv_runtime_authorize_trusted(&r,77));f=(sv_frame){.type=5,.seq=1,.session_id=77,.length=1};f.payload[0]=SV_LINE;
    n=sv_frame_encode(&f,bytes,sizeof(bytes));CHECK(sv_runtime_rx(&r,bytes,n));CHECK(r.control.out.dac_unmute);
    sv_bt_disconnected_event(&r.bt);sv_runtime_tick(&r,3505);
    CHECK(!r.session.authorized&&!r.control.out.active_routes);
    CHECK(sv_runtime_authorize_trusted(&r,78));CHECK(!sv_runtime_rx(&r,bytes,129));CHECK(!r.session.authorized);
    CHECK(sv_runtime_authorize_trusted(&r,79));
    for(uint32_t t=3510;t<=5510;t+=5)sv_runtime_tick(&r,t);CHECK(!r.session.authorized);
    fx.stale=true;sv_runtime_tick(&r,5515);CHECK(!r.control.out.charge_allow&&(r.control.faults&SV_F_INPUT));
    fx.stale=false;fx.fail_apply=true;sv_runtime_tick(&r,5520);CHECK(r.board_failed&&fx.fail_off>1&&!r.control.out.charge_allow);
    GROUP("reboot_guard_never_auto_rearms_with_usb_continuously_attached");
    for(unsigned reboot=0;reboot<3;reboot++){
        fx=(fixture){0};fx.input=good();
        sv_runtime_init(&r,0,&cfg,board,bus,&cal,radio);
        for(uint32_t t=0;t<=4000;t+=5){
            sv_runtime_tick(&r,t);CHECK(r.charge.locked&&!r.control.out.charge_allow);
        }
    }
    printf("{\"groups\":%u,\"assertions\":%u,\"failed\":0,\"hardware_tests\":0}\n",groups,checks);
    return 0;
}
