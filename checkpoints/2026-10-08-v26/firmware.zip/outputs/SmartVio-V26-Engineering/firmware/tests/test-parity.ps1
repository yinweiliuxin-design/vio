$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../..'))
$firmware=Split-Path $PSScriptRoot
$source=Join-Path $root 'outputs/SmartVio-V26-Engineering/electrical/native-components.json'
$original=Get-Content $source -Raw -Encoding utf8
$work=Join-Path $root 'work/v26/firmware/parity-negative'
New-Item -ItemType Directory -Force $work | Out-Null
$cases=@(
    @{name='PE3_wrong_data_lane';ref='U801';pin=2;property='net';value='ADC_DATA'},
    @{name='RF_EN_old_direct_net';ref='U901';pin=8;property='net';value='RF_ENABLE'},
    @{name='RF_default_pullup';ref='R901';pin=2;property='net';value='V3D'},
    @{name='ISET_stale_3v3';ref='U1701';pin=7;property='net';value='MON_3V3_ADC'},
    @{name='BOOT0_left_open';ref='U801';pin=94;property='net';value=$null},
    @{name='ESP_manufacturer_NC_grounded';ref='U901';pin=23;property='net';value='GND'},
    @{name='USB_VREF_wrong_direction';ref='U1501';pin=8;property='electricalType';value='power_in'},
    @{name='R907_wrong_value';ref='R907';property='value';value='10k'},
    @{name='PC13_mislabeled_PE8';ref='U801';pin=7;property='name';value='PE8_AUDIO_BUS_EN'},
    @{name='ESP_offrail_wrong_supply';ref='U901';pin=3;property='net';value='V3D'},
    @{name='BUS_switch_bypass';ref='U1902';pin=3;property='net';value='I2C_SDA'},
    @{name='NTC_interlock_not_gate';ref='U1921';pin=1;property='net';value='CHARGE_ALLOW'},
    @{name='Kycon_detect_not_grounded';ref='J301';pin=6;property='net';value='V3LOAD'}
)
$records=foreach($case in $cases){
    $parts=$original | ConvertFrom-Json
    $item=$parts | Where-Object ref -eq $case.ref
    if($case.ContainsKey('pin')){$item=$item.pins | Where-Object {[int]$_.number -eq $case.pin}}
    $item.($case.property)=$case.value
    $fixture=Join-Path $work ($case.name+'.json')
    $parts | ConvertTo-Json -Depth 50 | Set-Content $fixture -Encoding utf8
    $out=Join-Path $work $case.name
    $failed=$false
    try {& (Join-Path $firmware 'audit-pins.ps1') -LivePath $fixture -OutputDirectory $out | Out-Null}
    catch {$failed=$true}
    $result=Get-Content (Join-Path $out 'live-net-parity.json') -Raw -Encoding utf8 | ConvertFrom-Json
    if(!$failed -or !$result.failedChecks.Count -or $result.status -ne 'FAIL_LIVE_V26_MISMATCH'){throw "Mutation was not detected: $($case.name)"}
    Write-Host "NEGATIVE PASS $($case.name) failures=$($result.failedChecks.Count)"
    [ordered]@{name=$case.name;ref=$case.ref;pin=$case.pin;property=$case.property;detected=$true;failedChecks=$result.failedChecks;fixture=$fixture}
}
$summary=[ordered]@{status='PASS';cases=$records;sourceSha256=(Get-FileHash $source -Algorithm SHA256).Hash;sourceWritten=$false;hardwareTests=0;verifiedAtUtc=[DateTime]::UtcNow.ToString('o')}
$summary | ConvertTo-Json -Depth 9 | Set-Content (Join-Path $firmware 'verification/parity-negative-check.json') -Encoding utf8
Write-Output "PARITY NEGATIVES PASS cases=$($records.Count) original native untouched"
