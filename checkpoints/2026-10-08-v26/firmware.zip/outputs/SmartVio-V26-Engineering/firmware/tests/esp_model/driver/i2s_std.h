#ifndef SV_TEST_I2S_H
#define SV_TEST_I2S_H
#include <stddef.h>
/* Semantic API shim, not ESP-IDF enum values or a peripheral model. Target
 * is separately compiled against real pinned SDK headers and libraries. */
typedef void *i2s_chan_handle_t;
typedef struct {unsigned dma_desc_num,dma_frame_num;} i2s_chan_config_t;
typedef struct {struct{int rate;}clk_cfg;struct{int width,mode;}slot_cfg;struct{int mclk,bclk,ws,dout,din;struct{int bclk_inv,ws_inv,mclk_inv;}invert_flags;}gpio_cfg;} i2s_std_config_t;
#define I2S_CHANNEL_DEFAULT_CONFIG(a,b) ((i2s_chan_config_t){0})
#define I2S_STD_CLK_DEFAULT_CONFIG(a) {a}
#define I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(a,b) {a,b}
#define I2S_DATA_BIT_WIDTH_32BIT 32
#define I2S_SLOT_MODE_STEREO 2
#define I2S_GPIO_UNUSED -1
#define ESP_OK 0
static int i2s_new_channel(const i2s_chan_config_t *c,void *tx,i2s_chan_handle_t *rx){(void)c;(void)tx;*rx=(void*)1;return 0;}
static int i2s_channel_init_std_mode(i2s_chan_handle_t h,const i2s_std_config_t *s){(void)h;(void)s;return 0;}
static int i2s_channel_enable(i2s_chan_handle_t h){(void)h;return 0;}
static int i2s_channel_read(i2s_chan_handle_t h,void *out,size_t cap,size_t *n,unsigned timeout){(void)h;(void)out;(void)cap;(void)timeout;*n=0;return -1;}
#endif
