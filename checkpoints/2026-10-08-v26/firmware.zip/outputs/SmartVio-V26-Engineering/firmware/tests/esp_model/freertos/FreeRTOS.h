#ifndef SV_TEST_FREERTOS_H
#define SV_TEST_FREERTOS_H
/* HOST ONLY API shim. No scheduling/interrupt/concurrency simulation. */
typedef int portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(p) ((void)(p))
#define portEXIT_CRITICAL(p) ((void)(p))
#define pdPASS 1
#endif
