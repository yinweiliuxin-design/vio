#ifndef SV_TEST_TASK_H
#define SV_TEST_TASK_H
static int xTaskCreate(void(*f)(void*),const char *s,unsigned n,void *v,unsigned p,void *h){(void)f;(void)s;(void)n;(void)v;(void)p;(void)h;return 1;}
#endif
