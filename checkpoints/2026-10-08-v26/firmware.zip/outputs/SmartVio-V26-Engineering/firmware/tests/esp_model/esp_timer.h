#ifndef SV_TEST_TIMER_H
#define SV_TEST_TIMER_H
#include <stdint.h>
static int64_t simulated_us;
static int64_t esp_timer_get_time(void){return simulated_us;}
#endif
