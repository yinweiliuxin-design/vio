$ErrorActionPreference='Stop'
$firmware=Split-Path $PSScriptRoot
$root=[IO.Path]::GetFullPath((Join-Path $firmware '../../..'))
$work=Join-Path $root 'work/v26/firmware'
if($env:SV_BUILD_WORK){$work=[IO.Path]::GetFullPath($env:SV_BUILD_WORK)}
$tcc=Join-Path $root 'work/v22/tools/tinycc/tcc/tcc.exe'
if($env:TCC){$tcc=$env:TCC}elseif(!(Test-Path $tcc)){$tcc=(Get-Command tcc.exe -ErrorAction Stop).Source}
$out=Join-Path $work 'safety-negative'
New-Item -ItemType Directory -Force $out|Out-Null
$cases=@(
    @{name='F01_drop_EXTI_latch';file='safety_inputs.c';from='sv_input_power_edge(&sv_input_safety,sv_target_millis());';to='(void)0;';compileReject=$false},
    @{name='F02_drop_tick_raw_cutoff';file='safety_inputs.c';from='if(inserted)GPIOA->BSRR=(uint32_t)GPIO_PIN_2<<16;';to='(void)inserted;';compileReject=$false},
    @{name='F02_bypass_final_commit';file='safety_inputs.c';from='desired=initialized?sv_input_output_mask(&sv_input_safety,desired,raw):0;';to='desired&=15;';compileReject=$false},
    @{name='F01_remove_startup_rejection';file='sv_input_guard.c';from='if(!g->armed){count(&g->ignored_edges);return;}';to='(void)g;';compileReject=$false},
    @{name='F01_restore_30ms_fallback';file='sv_input_guard.h';from='SV_PWR_LEVEL_FILTER_MS=2';to='SV_PWR_LEVEL_FILTER_MS=30';compileReject=$true}
)
Start-Transcript (Join-Path $firmware 'verification/safety-negative.log')
try {
    $records=foreach($case in $cases){
        $stage=Join-Path $out $case.name
        New-Item -ItemType Directory -Force $stage|Out-Null
        foreach($rel in @('sv_input_guard.c','sv_input_guard.h','stm32/safety_inputs.c','stm32/safety_inputs.h')){
            Copy-Item -LiteralPath (Join-Path $firmware $rel) -Destination (Join-Path $stage (Split-Path $rel -Leaf)) -Force
        }
        $mutant=Join-Path $stage $case.file
        $content=Get-Content $mutant -Raw -Encoding utf8
        if(!$content.Contains($case.from)){throw "Mutation anchor missing $($case.name)"}
        $content.Replace($case.from,$case.to)|Set-Content $mutant -Encoding utf8
        $exe=Join-Path $stage 'negative-HOST-ONLY.exe'
        $ErrorActionPreference='Continue'
        $compiler=@(& $tcc '-std=c11' '-Wall' '-Werror' '-DSV_SAFETY_REGISTER_MODEL' ('-I'+$stage) ('-I'+$firmware) ('-I'+(Join-Path $firmware 'stm32')) ('-I'+$PSScriptRoot) ('-I'+(Join-Path $work 'build')) (Join-Path $stage 'sv_input_guard.c') (Join-Path $stage 'safety_inputs.c') (Join-Path $PSScriptRoot 'test_safety_inputs.c') '-o' $exe 2>&1)
        $compileCode=$LASTEXITCODE
        $ErrorActionPreference='Stop'
        $compiler|Set-Content (Join-Path $stage 'compile.log') -Encoding utf8
        if($case.compileReject){
            if($compileCode -eq 0 -or ($compiler -join "`n") -notmatch 'negative|sv_assert_int_filter_fits'){throw "Expected safety static assertion missing $($case.name)"}
            $runCode=$null
        }else{
            if($compileCode -ne 0){throw "Mutant failed to compile instead of exercising regression $($case.name)"}
            $ErrorActionPreference='Continue'
            $run=@(& $exe 2>&1);$runCode=$LASTEXITCODE
            $ErrorActionPreference='Stop'
            $run|Set-Content (Join-Path $stage 'test.log') -Encoding utf8
            if($runCode -eq 0 -or ($run -join "`n") -notmatch 'FAIL target safety'){throw "Regression not detected $($case.name)"}
        }
        Write-Host "SAFETY NEGATIVE PASS $($case.name) compile=$compileCode run=$runCode"
        [ordered]@{name=$case.name;detected=$true;compileExit=$compileCode;testExit=$runCode;stage=$stage}
    }
    $native=Join-Path $root 'outputs/SmartVio-V26-Engineering/electrical/native-components.json'
    $result=[ordered]@{status='PASS';sourceSha256=(Get-FileHash $native).Hash;cases=@($records);inputs=@(@('sv_input_guard.c','sv_input_guard.h','stm32/safety_inputs.c','stm32/safety_inputs.h','tests/test_safety_inputs.c','tests/safety_hal_model.h','tests/test-safety-negative.ps1')|ForEach-Object {Get-FileHash (Join-Path $firmware $_)}|Select-Object Path,Hash);hardwareTests=0;productionSourceWritten=$false;verifiedAtUtc=[DateTime]::UtcNow.ToString('o')}
    $result|ConvertTo-Json -Depth 7|Set-Content (Join-Path $firmware 'verification/safety-negative-check.json') -Encoding utf8
} finally {Stop-Transcript}
