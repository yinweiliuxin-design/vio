/* Exercise actual native PCM source in a single-thread HOST API shim.
 * No claim of FreeRTOS, DMA, I2S waveform or Bluetooth execution. */
#include "../esp32/main/pcm_rx.c"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
static unsigned groups,checks;
#define C(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL ESPPCM line%d\n",__LINE__);exit(1);}}while(0)
static int16_t decode(uint8_t *b){uint32_t w=(uint32_t)b[0]|((uint32_t)b[1]<<8);return w>=32768?(int16_t)((int32_t)w-65536):(int16_t)w;}
int main(void){
    uint8_t out[4100];groups++;memset(out,0xa5,sizeof(out));
    C(!sv_esp_pcm_read(NULL,4));C(!sv_esp_pcm_read(out,0));C(!sv_esp_pcm_read(out,-1));
    C(!sv_esp_pcm_read(out,INT_MAX));C(!sv_esp_pcm_read(out,4097));C(!sv_esp_pcm_read(out,3));
    for(unsigned i=0;i<sizeof(out);i++)C(out[i]==0xa5);
    groups++;C(sv_esp_pcm_read(out,4096)==4096);for(unsigned i=0;i<4096;i++)C(!out[i]);C(out[4096]==0xa5);
    groups++;sv_esp_pcm_gate(true);simulated_us=0;last_input=0;count=4096;head=0;
    for(unsigned i=0;i<4096;i++){ring[i][0]=INT16_MIN;ring[i][1]=INT16_MAX;}
    C(sv_esp_pcm_read(out,4096)==4096);
    for(unsigned i=0;i<4096;i+=4){C(decode(out+i)==INT16_MIN);C(decode(out+i+2)==INT16_MAX);}
    C(count<4096&&count>2900);C(out[4096]==0xa5);
    sv_esp_pcm_gate(false);C(count==0&&!primed);sv_esp_pcm_gate(true);
    groups++;underflows=UINT32_MAX;C(sv_esp_pcm_read(out,4096)==4096);C(underflows==UINT32_MAX);for(unsigned i=0;i<4096;i++)C(!out[i]);
    count=10;last_input=0;simulated_us=51000;C(sv_esp_pcm_read(out,4)==4);C(!count&&!primed);
    groups++;sv_esp_pcm_stats stats;sv_esp_pcm_snapshot(&stats);C(stats.version==1&&stats.underflows==UINT32_MAX&&stats.enabled==1&&stats.buffered==0);
    count_up(&frames,UINT32_MAX);count_up(&frames,1);C(frames==UINT32_MAX);
    C(sample(0x80000000u)==INT16_MIN);C(sample(0x7fffffffu)==INT16_MAX);
    printf("{\"groups\":%u,\"assertions\":%u,\"suite\":\"native_esp_pcm_host_shim\",\"hardware_tests\":0}\n",groups,checks);return 0;
}
