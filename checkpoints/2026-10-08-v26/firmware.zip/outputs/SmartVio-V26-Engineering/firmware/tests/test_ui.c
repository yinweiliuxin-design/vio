#include "sv_factory.h"
#include "sv_audio_meter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
static unsigned checks,groups;
#define C(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL UI line%d: %s\n",__LINE__,#x);exit(1);}}while(0)
static uint32_t buttons(sv_ui *u,uint8_t keys,uint32_t begin,uint32_t duration,bool auth){uint32_t e=0;for(uint32_t n=0;n<duration;n++)e|=sv_ui_tick(u,keys,auth,begin+n);return e;}
static void fresh(sv_ui *u,uint32_t now){uint32_t p[3]={0,4095,4095};C(sv_ui_pots(u,p,now));}
typedef struct {int state;bool start_ok;unsigned starts,stops;uint32_t raw[3];} model;
static bool start(void *v){model *m=v;m->starts++;return m->start_ok;}
static int poll(void *v,uint32_t raw[3]){model *m=v;memcpy(raw,m->raw,sizeof(m->raw));return m->state;}
static void stop(void *v){((model*)v)->stops++;}
static void arm(sv_factory *d){sv_factory_init(d,0);d->armed=true;d->grants=63;d->session.authorized=true;d->session.session_id=99;d->session.have_seq=true;d->session.last_seq=1;}
static double tone_gain(double hz,bool dry){
    sv_ui u;sv_ui_init(&u);sv_ui_enable(&u,true);fresh(&u,0);
    uint32_t p[3]={4095,dry?4095u:0u,0};C(sv_ui_pots(&u,p,1));u.gain=1;u.tone=dry?1:0;
    double in=0,out=0;
    for(unsigned n=0;n<48000;n++){
        int32_t l=(int32_t)(100000.0*sin(6.283185307179586*hz*n/48000)),r=0,original=l;
        C(sv_ui_process(&u,&l,&r));C(!r);
        if(n>=24000){in+=(double)original*original;out+=(double)l*l;}
    }
    return sqrt(out/in);
}
static void click(sv_factory *d,unsigned key,bool longpress,uint32_t *now){
    for(unsigned n=0;n<40;n++)sv_factory_buttons(d,0,(*now)++);
    for(unsigned n=0;n<(longpress?1600u:100u);n++)sv_factory_buttons(d,(uint8_t)(1u<<key),(*now)++);
    for(unsigned n=0;n<40;n++)sv_factory_buttons(d,0,(*now)++);
}
int main(void){
    groups++;sv_ui u;sv_ui_init(&u);sv_ui_enable(&u,true);
    C(!buttons(&u,1,0,2000,true));C(!buttons(&u,0,2000,40,true));
    for(unsigned n=0;n<50;n++)C(!sv_ui_tick(&u,n&1,true,2040+n));
    C(!buttons(&u,0,2100,40,true));C(!buttons(&u,1,2140,100,true));C(buttons(&u,0,2240,40,true)==1);
    C(buttons(&u,1,2300,2000,true)==256);C(!buttons(&u,1,4300,2000,true));C(!buttons(&u,0,6300,40,true));
    C(!buttons(&u,3,6400,2000,true));C(!buttons(&u,0,8400,40,true));
    C(!buttons(&u,4,8500,100,false));C(!buttons(&u,0,8600,40,false));
    groups++;sv_ui_init(&u);sv_ui_enable(&u,true);
    C(!buttons(&u,0,UINT32_MAX-100,40,true));C(!buttons(&u,8,UINT32_MAX-60,100,true));C(buttons(&u,0,40,40,true)==8);
    groups++;uint32_t p[3]={4095,4095,4095};C(sv_ui_pots(&u,p,100));C(!sv_ui_audible(&u));
    p[0]=64;C(sv_ui_pots(&u,p,101));C(sv_ui_audible(&u));sv_ui_tick(&u,0,true,202);C(!sv_ui_audible(&u));
    p[0]=4095;C(sv_ui_pots(&u,p,203));C(!sv_ui_audible(&u));p[0]=4096;C(!sv_ui_pots(&u,p,204));
    groups++;model m={.start_ok=true,.raw={1,2,4095}};sv_pot_scan s;sv_pot_bus bus={start,poll,stop,&m};
    sv_pot_init(&s,bus,UINT32_MAX-2);sv_pot_tick(&s,UINT32_MAX-2);C(s.pending&&!s.valid);
    sv_pot_tick(&s,UINT32_MAX);C(!s.valid);m.state=1;sv_pot_tick(&s,1);C(s.valid&&!s.fault&&s.generation==1&&s.raw[2]==4095&&m.stops==1);
    sv_pot_tick(&s,20);C(!s.pending);sv_pot_tick(&s,21);C(s.pending);m.state=0;sv_pot_tick(&s,26);C(s.fault&&!s.valid);
    sv_pot_init(&s,bus,0);m.start_ok=false;sv_pot_tick(&s,0);C(s.fault&&!s.valid);
    m.start_ok=true;m.state=-1;sv_pot_init(&s,bus,0);sv_pot_tick(&s,0);sv_pot_tick(&s,1);C(s.fault);
    m.state=1;m.raw[1]=4096;sv_pot_init(&s,bus,0);sv_pot_tick(&s,0);sv_pot_tick(&s,1);C(s.fault&&!s.valid);
    groups++;sv_factory d;arm(&d);fresh(&d.ui,0);
    sv_frame f={.type=0x3a,.session_id=99,.seq=2,.length=1,.payload={1}};C(sv_factory_command(&d,&f,0)==SV_OK);C(d.ui.enabled&&!d.port);
    C(sv_factory_command(&d,&f,1)==SV_REPLAY);uint32_t now=40;
    d.grants=SV_D_POWER|SV_D_LINE;click(&d,SV_UI_MODE,false,&now);C(d.port==SV_LINE);click(&d,SV_UI_MODE,false,&now);C(!d.port);
    click(&d,SV_UI_FX,false,&now);C(d.ui.fx);click(&d,SV_UI_FX,true,&now);C(d.ui.rate==1);
    click(&d,SV_UI_MIX,false,&now);C(d.input==1);click(&d,SV_UI_MIX,false,&now);C(d.input==4);click(&d,SV_UI_MIX,true,&now);C(d.input==0);
    click(&d,SV_UI_MODE,true,&now);C(d.ui.muted);d.armed=false;click(&d,SV_UI_FX,false,&now);C(d.ui.fx);
    groups++;sv_ui_init(&u);sv_ui_enable(&u,true);fresh(&u,0);p[0]=p[1]=p[2]=4095;C(sv_ui_pots(&u,p,1));
    for(unsigned rate=0;rate<3;rate++)for(unsigned fx=0;fx<2;fx++){
        u.rate=(uint8_t)rate;u.fx=fx!=0;
        for(unsigned n=0;n<48000;n++){int32_t l=n&1?INT_MIN:INT_MAX,r=0;C(sv_ui_process(&u,&l,&r));C(l>=-8388608&&l<=8388607);C(!r);}
    }
    u.muted=true;int32_t l=INT_MIN,r=INT_MAX;C(sv_ui_process(&u,&l,&r)&&!l&&!r);
    u.muted=false;u.filter[0][0]=NAN;l=10;r=20;C(!sv_ui_process(&u,&l,&r)&&!l&&!r&&!u.picked_up);
    groups++;sv_audio_meter meter={0};uint32_t dac[256],spk[256];for(unsigned i=0;i<128;i++){dac[2*i]=0x80000000u;dac[2*i+1]=0x7fffff00u;spk[2*i]=0x100u;spk[2*i+1]=0;}
    for(unsigned i=0;i<1000;i++){sv_audio_measure(&meter,dac,spk,128);C(meter.window_frames<=48000);C(meter.square_sum[0]==(uint64_t)meter.window_frames*8388608u*8388608u);C(!meter.square_sum[3]);}
    C(meter.peak[0]==8388608&&meter.peak[1]==8388607&&meter.peak[2]==1&&meter.peak[3]==0);
    meter.blocks=meter.frames=UINT32_MAX;sv_audio_measure(&meter,dac,spk,128);C(meter.blocks==UINT32_MAX&&meter.frames==UINT32_MAX);
    uint32_t old=meter.window_frames;sv_audio_measure(&meter,dac,spk,129);C(meter.window_frames==old);
    groups++;for(unsigned h=0;h<3;h++)for(unsigned n=0;n<300;n++)C(sv_dma_half_free(h,n)==(h==0?(n>32&&n<=128):h==1?(n>160&&n<=256):false));
    C(!sv_dma_lost(0,UINT32_MAX));C(sv_dma_lost(1,UINT32_MAX));C(sv_dma_lost(10,8));
    groups++;sv_factory_init(&d,0);f=(sv_frame){.type=0x3b,.session_id=123,.seq=1,.length=1,.payload={SV_D_POWER}};
    C(sv_factory_command(&d,&f,0)==SV_PHYSICAL);d.window=true;d.nonce=123;d.opened_at=UINT32_MAX-100;
    C(sv_factory_command(&d,&f,5)==SV_OK);C(d.programming&&d.armed&&d.grants==1&&!d.port&&!d.ui.enabled);
    f.type=0x32;C(sv_factory_command(&d,&f,6)==SV_NOT_READY);
    sv_factory_tick(&d,false,true,true,300004);C(d.programming&&d.armed);sv_factory_tick(&d,false,true,true,300005);C(!d.programming&&!d.armed);
    d.window=true;d.opened_at=300006;f.type=0x3b;C(sv_factory_command(&d,&f,300006)==SV_OK);
    sv_factory_tick(&d,false,true,false,300007);C(d.faults&&!d.programming&&!d.armed);C(sv_factory_command(&d,&f,300008)==SV_NOT_READY);
    groups++;arm(&d);d.mode=2;d.port=SV_SPK;d.input=4;sv_ui_enable(&d.ui,true);fresh(&d.ui,0);p[0]=p[1]=p[2]=4095;C(sv_ui_pots(&d.ui,p,1));
    uint32_t a[256],b[256],out[256],phase=0;for(unsigned n=0;n<256;n++){a[n]=n&1?0x7fffff00u:0x80000000u;b[n]=0x80000000u;}
    for(unsigned n=0;n<300;n++){sv_factory_render(&d,a,b,out,spk,128,&phase);for(unsigned j=0;j<128;j++){C(!out[2*j]&&!out[2*j+1]&&!spk[2*j+1]);C(abs(sv_sample24(spk[2*j]))<=sv_speaker_peak_cap(5500));}}
    d.port=SV_BT;d.mode=0;sv_factory_render(&d,a,b,out,spk,128,&phase);for(unsigned j=0;j<256;j++)C(!out[j]&&!spk[j]);
    groups++;C(tone_gain(100,false)>0.99);C(tone_gain(12000,false)<0.01);C(tone_gain(12000,true)>0.999);
    printf("{\"groups\":%u,\"assertions\":%u,\"suite\":\"ui_pot_dma_programming\",\"hardware_tests\":0}\n",groups,checks);return 0;
}
