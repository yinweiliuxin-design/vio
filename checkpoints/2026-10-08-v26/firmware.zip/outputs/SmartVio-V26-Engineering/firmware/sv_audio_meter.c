#include "sv_audio_meter.h"
#include <string.h>
#include <limits.h>
static void increment(uint32_t *n,uint32_t v){*n=UINT32_MAX-*n<v?UINT32_MAX:*n+v;}
void sv_audio_measure(sv_audio_meter *m,const uint32_t *dac,const uint32_t *speaker,size_t frames){
    if(!m || !dac || !speaker || frames>128)return;
    /* <=48000 fullscale signed24 squares fits uint64; window is not wall time. */
    if(m->window_frames+frames>48000){m->window_frames=0;memset(m->square_sum,0,sizeof(m->square_sum));memset(m->peak,0,sizeof(m->peak));}
    for(size_t i=0;i<frames;i++)for(unsigned c=0;c<4;c++){
        uint32_t w=(c<2?dac:speaker)[2*i+(c&1)]>>8;
        int32_t value=(w&0x800000u)?(int32_t)w-16777216:(int32_t)w;
        uint32_t magnitude=value<0?(uint32_t)-value:(uint32_t)value;
        if(magnitude>m->peak[c])m->peak[c]=magnitude;
        if(magnitude>=8388607)increment(&m->fullscale[c],1);
        m->square_sum[c]+=(uint64_t)magnitude*magnitude;
    }
    increment(&m->blocks,1);increment(&m->frames,(uint32_t)frames);m->window_frames+=(uint32_t)frames;
}
