SMARTVIO V25 PCB HANDOFF -- ENGINEERING CANDIDATE / HOLD
No full product, electrical, assembled-mechanical or production approval.
productionApproved=false for EVERY board and CAM file.

AUTHORITATIVE CURRENT OUTPUTS
verification/final-summary.json is the canonical machine-readable inventory;
root final-summary.json is an identical copy. Both give exact board hashes,
track/via/filled-zone statistics, real DRC, unconnected details, latest source
and native schematic parity, per-board blockers and CAM file hashes.
verification/CAM-index.json is the portable CAM index. relativePackPath is
relative to outputs/SmartVio-V25-Engineering, the engineering package root;
relativeWorkspacePath is relative to workspace ROOT. Absolute paths are only
for this host. All CAM entries and manifests contain the portable paths.
footprint-map.json maps source references to actual candidate library IDs and
explicit exposed-pad aliases. This is not footprint/process approval.
verification/current-native-parity.json independently compares saved boards
against the actual current native schematic export and source JSON. It also
checks footprint IDs, board values and proposed-harness pad/net assignments.

Current source SHA256:
72ae4e7478b3184a50a32783ac7704fbcf23aafa1197f089a666b7c7699a35bd
292 components / 995 pins / 208 named nets. Latest controls metadata is X1SON.
Main DSN route-basis source SHA256 (not rewritten to pretend newest basis):
c3cf838f184bc2a50f5ec8f46a998342dc6cf1402db8976f6b50a1c9844f19c6
Immutable basis: verification/SmartVio-main-final-source-unrouted-contract.json
and routing/main-final-292-bounded.contract.json. Board/DSN/SES hashes and exact
pad/net/position inventory are locked. Latest metadata matches the saved copper
graph through actual current parity; it does not retroactively change provenance.

FINAL BOARDS, KEPT DISTINCT
1. SmartVio-main-delivery-HOLD.kicad_pcb: real 72x39x1 mm four-layer native
   bounded SES route, NOT COMPLETE. 219 unconnected; 127 dangling-track warnings.
   DRC errors excluding connectivity are zero, not a route-completion claim.
   No main manufacturing CAM. Intermediate imported, filled and original boards
   remain preserved. Review both F/B components and In1/In2 copper in KiCad.
2. SmartVio-power-prototype-delivery-HOLD.kicad_pcb: 58x38x1 mm four-layer
   charger/power/telemetry prototype, 79 original parts + JP1/2/3 = 82 footprints.
   Native DRC 0 violations and 0 unconnected under the listed active checks.
   PowerPrototype.kicad_sch and all parent-created child sheets/libraries remain
   intact. Native schematic-export versus PCB parity is 0 differences.
   Engineering-only CAM: engineering-export/power-delivery-HOLD/CAM-manifest.json.
3. SmartVio-usb-manufacturer-land-HOLD.kicad_pcb: 24x22x1 mm two-layer real
   route. DRC 0 violations / 1 unconnected: U1401 B2 GND. The 0.4 mm-pitch centre
   ball cannot escape with this standard through-via process. No USB CAM; review
   HDI capability or a parent-approved protection architecture change, not a
   guessed bridge or unapproved replacement. USB MODE1 C1502.1 is USB_VREF;
   R1504 is USB_VREF/MODE; U1501.8 is USB_VREF. All match latest native source.
4. SmartVio-sensor-delivery-HOLD.kicad_pcb: independent 16x10x0.8 mm two-layer
   temperature subboard, 3 footprints. DRC 0 violations / 0 unconnected.
   Engineering-only CAM: engineering-export/sensor-HOLD/CAM-manifest.json.
5. final-292/SmartVio-audio-tentative.kicad_pcb: body-envelopes only. Four jacks
   have unresolved Lumberg DA6/8 contact land/drills; DB=7 is not guessed.
   Source parity lacks 20 physical pins (14 connected schematic pins). Its
   native 0/0 DRC does NOT imply electrical completion. No CAM.
6. final-292/SmartVio-cover-tentative.kicad_pcb: mechanical carrier concept,
   not an approved 148x49 rigid product board. Missing 27 source physical pins.
   Native 0/0 on padless bodies is NOT electrical completion. No CAM.

DRC LIMITATIONS -- NEVER "ALL RULES PASS"
All native reports preserve these five ignored categories explicitly:
missing_courtyard; track_not_centered_on_via; tuning_profile_track_geometries;
footprint_filters_mismatch; footprint_type_mismatch.
No exclusion or threshold was relaxed to conceal a reported violation.
Signal assumptions are 0.15 mm clearance / 0.15 mm minimum width, 0.6/0.3 mm
via/drill, 0.25 mm board edge. These are manufacturing-capability assumptions,
not evidence of an approved fabricator or high-current design.
The main algorithm ended after the ten-minute limit, 2 complete route passes.
Algorithm counts 223/8 are NOT native DRC; native results above are authoritative.
Old main-final-290 PID14372 was verified and terminated with no SES. Logs remain
in work/v25/pcb/main-final-290-router.log. The latest bounded log and real SES
remain in work/v25/pcb/main-final-292-bounded-router.log and routing/.
No router remains running. No more routing was launched for this handoff.

FOOTPRINT AND CURRENT-COPPER GATES
BQ U501 physical EP=17; audio U301/U902 EP=17 aliases explicit. TPS259470 and
TPS63070 asymmetrical official lands do not gain invented extra EP numbers.
ESP32-MINI-1U official 13.2x13.5 footprint is used; assembly coax clearance HOLD.
GCT J401 was explicitly corrected in the separate latest USB board to official
A6: right locating hole oval0.72x0.52, contacts0.30x0.87 at row +/-0.865,
shield copper oval. Prior USB geometry/boards and contracts are preserved.
See verification/usb-land-update.json; never silently substitute old footprints.
Q1201 is PMV30UN2R, pin1G/2S/3D; existing KiCad SOT23 pads are retained.
SSR pad centres/sizes/numbers match the audio official land; stock roundrect
corners are retained versus official rectangles. No silent SSR reroute/substitute.
D1201..7 retained DPY0.4x0.65 pads differ from TI proposal0.3x0.5 at +/-0.35.
Latest source correctly calls DPY X1SON. Network parity does not approve the
wrong land. Exact next ECO is verification/controls-land-eco.json: official
NSMD example, radius0.05, mask+0.07, paste0, unchanged reference/side/orientation
and net assignments. Apply only to a NEW ECO copy, reconnect/re-fill/DRC/parity,
regenerate immutable DSN contract. TI SMD preference/process review still HOLD.
L1101 generic4x4 is unapproved; XGL4020-152MEC4 remains a proposal (4.3 max,
height2.1) requiring physical land, DCR/Isat/thermal selection. No MPN guessed.
FL1501 generic CMC is not the newly proposed official land; not auto-replaced.
Critical passive heights are CAD budgets, not proof of assembled fit.

POWER/CAM REVIEW NOTES
Power native has manually seeded BQ lead fanout, short FB, eFuse escape and
TPS63070-to-inductor switch paths: 0.25 mm neck to short0.6 mm copper. Routed
power net class0.6 mm is real; necessary short0.15/0.2 necks remain and require
current/thermal review. Main supply routes are not approved merely because
autorouting created0.2 mm tracks. Filled internal GND is pierced by signals,
not an uninterrupted reference plane. EP vias/paste and feedback/return loops
must be reviewed along with copper weight, temperature and switching EMI.
CAM manifests contain Gerbers (power4Cu, sensor2Cu), F.Paste/B.Paste steel-stencil
layer data, F/B mask/silk, outline, separate PTH/NPTH drill, drill maps/report,
native-all positions and assembly-candidate positions. B.Paste is legitimately
empty for these all-front SMD boards; no custom stencil thickness/opening approval.
Power142 holes match142 native0.3 mm vias; sensor2 holes match2 native vias.
Power positions82 raw/79 assembly exclude JP manual test pads; sensor3 raw/2
assembly exclude J1802 manual endpoint. Coordinates follow native KiCad export,
not a machine-specific pick-and-place transformation. Review rotation/origin.
The Gerber job's outline extents include stroke thickness; nominal native
edge-centre dimensions remain58x38 and16x10. Default stack is not fabricator approval.

MECHANICAL/INTERCONNECT INTEGRATION
Read GEOMETRY-REVIEW.txt and final-292/placement.json,csv for coordinates,
height budgets, F/B courts and partition. Placement courts have no collision,
but critical analog/power decoupling positions are not qualified.
z=0 is existing violin BACK mounting plane, outward control front, not strings.
The battery/socket/wire stack is unresolved. 5 mm protrusion plus <=6 mm screw
does not prove engagement: recessed seats, head/flange/washer, wood thickness,
pilot/torque/pullout remain HOLD. No new cavity or approved smaller battery.
USB H_USB_1 both ends: 1GND,2DM,3DP,4V3D,5CC_FAULT_N,6USB_DATA_DISABLE;
H_USB_2:1USB_DATA_FAULT_N,2USB_5V_SAFE,3VBUS_RAW. SPK_N/P adjacent on cover.
These are explicit candidate solder harnesses, not selected catalog connectors
or proof of controlled impedance/ESD protection/strain relief.

REPRODUCIBLE NEXT INTEGRATION (NO AUTOMATIC RELEASE)
Use work/v24/tools/kicad/bin/python.exe and native kicad-cli.exe10.0.6.
Set KICAD_CONFIG_HOME=work/v25/pcb/config and DOCUMENTS_HOME plus
KICAD_DOCUMENTS_HOME=work/v25/pcb/documents BEFORE pcbnew import.
1. Parent links footprint-map IDs and EP aliases into native schematic on its
   own authority; compare native export and per-board original refs again.
2. Resolve missing contacts/process/fit gates, make NEW board/ECO copy, retain
   originals. Use work/v25/pcb/build_candidate.py only for a new placement.
3. route_bridge.py export --board ... --dsn ... --ack-tentative-netlist locks
   exact board/DSN/pad snapshot. Optional --power-width 0.6 is for qualified
   prototype power classes, never an electrical approval.
4. run_router.ps1 with ABSOLUTE -Dsn/-Ses, -Passes 5 -FanoutPasses 4
   -Timeout '00:10:00' -StrictSignalRules. Local official Freerouting2.4.1 and
   java25 only. Capture log. Do not permit unbounded reruns.
5. route_bridge.py import writes a DIFFERENT output, refusing stale hashes or
   pad/net movement. Native original coordinates are preserved.
6. Apply manual critical route fixes, real zone fills, native pcb drc --format
   json, actual latest JSON/XML/pad parity. Preserve intermediate DRC reports.
7. Only export_hold_cam.py after zero reported violations AND zero unconnected;
   CAM always HOLD. Parent must approve fabrication/assembly gates separately.

Historical root tentative files, old engineering-export/power-HOLD, final-292
initial-placement boards and intermediate cleanup/routing copies are retained
for provenance, NOT authoritative manufacturing files. Only final-summary paths
identify this handoff. The worker stops writes after reporting this frozen output.
